-- Etapa 6 (Roteiro): rode ANTES de abrir o app com o código novo.
-- Sem isso, o envio (push) de mood_collections falha com "column script_note_uuid does not exist".
alter table public.mood_collections
  add column if not exists script_note_uuid text;
