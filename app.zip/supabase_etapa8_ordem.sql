-- Etapa 8 (Ordem das cenas): rode ANTES de abrir o app com o código novo.
-- Sem isso, o envio (push) de mood_collections falha com "column scene_order does not exist".
alter table public.mood_collections
  add column if not exists scene_order double precision;
