import React from 'react';
import { ScrollView, Text, View } from 'react-native';
import { registerRootComponent } from 'expo';

// Mostra erros na tela em vez de fechar o app (versão de diagnóstico).
let setGlobalError = null;
let pending = null;

function describe(e) {
  try {
    return String((e && (e.stack || e.message)) || e);
  } catch (_) {
    return 'Erro desconhecido';
  }
}

function report(e) {
  const text = describe(e);
  if (setGlobalError) setGlobalError(text);
  else pending = text;
}

try {
  if (global.ErrorUtils && global.ErrorUtils.setGlobalHandler) {
    global.ErrorUtils.setGlobalHandler((e) => report(e));
  }
} catch (_) {}

let App = null;
try {
  App = require('./App').default;
} catch (e) {
  pending = describe(e);
}

function ErrorView({ text }) {
  return (
    <View style={{ flex: 1, backgroundColor: '#000', paddingTop: 60, paddingHorizontal: 16 }}>
      <Text style={{ color: '#FF3030', fontSize: 20, fontWeight: 'bold', marginBottom: 12 }}>
        Erro no app (tire um print)
      </Text>
      <ScrollView>
        <Text selectable style={{ color: '#fff', fontSize: 12 }}>
          {text}
        </Text>
      </ScrollView>
    </View>
  );
}

class Boundary extends React.Component {
  state = { error: null };
  static getDerivedStateFromError(error) {
    return { error: describe(error) };
  }
  render() {
    if (this.state.error) return <ErrorView text={this.state.error} />;
    return this.props.children;
  }
}

function Root() {
  const [err, setErr] = React.useState(pending);
  React.useEffect(() => {
    setGlobalError = setErr;
    if (pending) setErr(pending);
    return () => {
      setGlobalError = null;
    };
  }, []);
  if (err || !App) return <ErrorView text={err || 'App não carregou'} />;
  return (
    <Boundary>
      <App />
    </Boundary>
  );
}

registerRootComponent(Root);
