-- Etapa 7 (Status das cenas): rode ANTES de abrir o app com o código novo.
-- Sem isso, o envio (push) de mood_collections falha com "column scene_status does not exist".
-- 0 Ideia, 1 Roteirizada, 2 Gravada, 3 Editada, 4 Publicada.
alter table public.mood_collections
  add column if not exists scene_status integer not null default 0;
update public.mood_collections set scene_status = 2 where scene_done = true and scene_status = 0;
