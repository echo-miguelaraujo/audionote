-- Etapa 10 (Ligação entre cenas: transição e gancho): rode ANTES de abrir o app com o código novo.
alter table public.mood_collections
  add column if not exists scene_transition text,
  add column if not exists scene_hook       text;
