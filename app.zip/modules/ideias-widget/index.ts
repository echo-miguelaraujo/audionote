import { requireOptionalNativeModule } from 'expo';

type IdeiasWidgetNative = {
  setNotes(json: string): void;
  consumePending(): string;
};

/** Fica null fora do Android ou se o módulo nativo não estiver no build. */
export const IdeiasWidget = requireOptionalNativeModule<IdeiasWidgetNative>('IdeiasWidget');
