import { requireOptionalNativeModule } from 'expo';

type IdeiasWidgetNative = {
  setNotes(json: string): void;
  /** Próximos compromissos + dias marcados (páginas Agenda e Calendário do widget). */
  setAgenda?(json: string): void;
  consumePending(): string;
  /** Gravação em primeiro plano (blockId -1 = nota nova). */
  startRecording?(blockId: number): boolean;
  pauseRecording?(): void;
  resumeRecording?(): void;
  stopRecording?(): void;
  discardRecording?(): void;
  haptic?(kind: string): void;
  /** JSON: state, ms, level, blockId, part, notice, error, last. */
  getRecordingState?(): string;
  /** Recupera a gravação que ficou no disco se o app foi encerrado no meio dela. */
  recoverInterrupted?(): number;
};

/** Fica null fora do Android ou se o módulo nativo não estiver no build. */
export const IdeiasWidget = requireOptionalNativeModule<IdeiasWidgetNative>('IdeiasWidget');
