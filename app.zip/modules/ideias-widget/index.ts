import { requireOptionalNativeModule } from 'expo';

type IdeiasWidgetNative = {
  setNotes(json: string): void;
  /** Próximos compromissos + dias marcados (páginas Agenda e Calendário do widget). */
  setAgenda?(json: string): void;
  consumePending(): string;
};

/** Fica null fora do Android ou se o módulo nativo não estiver no build. */
export const IdeiasWidget = requireOptionalNativeModule<IdeiasWidgetNative>('IdeiasWidget');
