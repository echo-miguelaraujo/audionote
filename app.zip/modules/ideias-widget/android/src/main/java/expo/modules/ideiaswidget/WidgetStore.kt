package expo.modules.ideiaswidget

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object Ideias {
  const val ACTION_RECORD = "expo.modules.ideiaswidget.RECORD"
  const val ACTION_STOP = "expo.modules.ideiaswidget.STOP"
  const val EXTRA_BLOCK_ID = "block_id"
}

/** Guarda o que o widget precisa (lista de notas, estado) e as gravações ainda não importadas pelo app. */
object WidgetStore {
  private const val PREFS = "ideias_widget"

  private fun prefs(ctx: Context) =
    ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

  @Synchronized
  fun setNotes(ctx: Context, json: String) {
    prefs(ctx).edit().putString("notes", json).apply()
  }

  fun notes(ctx: Context): List<Pair<Long, String>> {
    val out = ArrayList<Pair<Long, String>>()
    try {
      val arr = JSONArray(prefs(ctx).getString("notes", "[]") ?: "[]")
      for (i in 0 until arr.length()) {
        val o = arr.getJSONObject(i)
        out.add(Pair(o.getLong("id"), o.optString("title", "Nota")))
      }
    } catch (e: Exception) {
      // lista inválida: o widget mostra só "Gravar Novo"
    }
    return out
  }

  fun isRecording(ctx: Context): Boolean = prefs(ctx).getBoolean("recording", false)

  fun setRecording(ctx: Context, value: Boolean) {
    prefs(ctx).edit().putBoolean("recording", value).commit()
  }

  @Synchronized
  fun addPending(ctx: Context, file: String, blockId: Long, durationMs: Long) {
    val arr = try {
      JSONArray(prefs(ctx).getString("pending", "[]") ?: "[]")
    } catch (e: Exception) {
      JSONArray()
    }
    arr.put(JSONObject().put("file", file).put("blockId", blockId).put("durationMs", durationMs))
    prefs(ctx).edit().putString("pending", arr.toString()).commit()
  }

  /** Entrega as gravações pendentes (JSON) e limpa a lista. */
  @Synchronized
  fun consumePending(ctx: Context): String {
    val s = prefs(ctx).getString("pending", "[]") ?: "[]"
    prefs(ctx).edit().putString("pending", "[]").commit()
    return s
  }
}
