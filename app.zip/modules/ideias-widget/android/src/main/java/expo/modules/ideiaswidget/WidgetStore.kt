package expo.modules.ideiaswidget

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object Ideias {
  const val ACTION_RECORD = "expo.modules.ideiaswidget.RECORD"
  const val ACTION_STOP = "expo.modules.ideiaswidget.STOP"
  const val ACTION_PAUSE = "expo.modules.ideiaswidget.PAUSE"
  const val ACTION_RESUME = "expo.modules.ideiaswidget.RESUME"
  const val ACTION_DISCARD = "expo.modules.ideiaswidget.DISCARD"
  const val EXTRA_BLOCK_ID = "block_id"
  const val EXTRA_FROM_APP = "from_app"
  const val ACTION_TAB = "expo.modules.ideiaswidget.TAB"
  const val EXTRA_PAGE = "page"
}

/** Uma linha da página "Agenda" do widget. */
data class AgendaRow(val day: String, val title: String, val whenText: String)

/** Guarda o que o widget precisa (lista de notas, estado) e as gravações ainda não importadas pelo app. */
object WidgetStore {
  private const val PREFS = "ideias_widget"

  private fun prefs(ctx: Context) =
    ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

  @Synchronized
  fun setNotes(ctx: Context, json: String) {
    prefs(ctx).edit().putString("notes", json).apply()
  }

  fun notes(ctx: Context): List<Pair<Long, String>> {
    val out = ArrayList<Pair<Long, String>>()
    try {
      val arr = JSONArray(prefs(ctx).getString("notes", "[]") ?: "[]")
      for (i in 0 until arr.length()) {
        val o = arr.getJSONObject(i)
        out.add(Pair(o.getLong("id"), o.optString("title", "Nota")))
      }
    } catch (e: Exception) {
      // lista inválida: o widget mostra só "Gravar Novo"
    }
    return out
  }

  /** Página aberta no widget: 0 = Gravação, 1 = Agenda, 2 = Calendário. */
  fun page(ctx: Context): Int = prefs(ctx).getInt("page", 0)

  fun setPage(ctx: Context, page: Int) {
    prefs(ctx).edit().putInt("page", page).apply()
  }

  /** JSON enviado pelo app: {"upcoming":[{"day","title","when"}], "marks":["2026-10-06", ...]}. */
  @Synchronized
  fun setAgenda(ctx: Context, json: String) {
    prefs(ctx).edit().putString("agenda", json).apply()
  }

  fun upcoming(ctx: Context): List<AgendaRow> {
    val out = ArrayList<AgendaRow>()
    try {
      val root = JSONObject(prefs(ctx).getString("agenda", "{}") ?: "{}")
      val arr = root.optJSONArray("upcoming") ?: JSONArray()
      for (i in 0 until arr.length()) {
        val o = arr.getJSONObject(i)
        out.add(AgendaRow(o.optString("day", ""), o.optString("title", ""), o.optString("when", "")))
      }
    } catch (e: Exception) {
      // sem dados: a página mostra "Nada marcado"
    }
    return out
  }

  /** Dias (aaaa-mm-dd) que têm compromisso, para marcar no calendário. */
  fun marks(ctx: Context): Set<String> {
    val out = HashSet<String>()
    try {
      val root = JSONObject(prefs(ctx).getString("agenda", "{}") ?: "{}")
      val arr = root.optJSONArray("marks") ?: JSONArray()
      for (i in 0 until arr.length()) out.add(arr.getString(i))
    } catch (e: Exception) {
      // sem marcações
    }
    return out
  }

  fun isRecording(ctx: Context): Boolean = prefs(ctx).getBoolean("recording", false)

  fun setRecording(ctx: Context, value: Boolean) {
    prefs(ctx).edit().putBoolean("recording", value).commit()
  }

  /**
   * Guarda uma gravação pronta para o app importar. `group` liga as partes de uma gravação longa
   * (divididas a cada 25 min) para que caiam na mesma nota; `recovered` marca o que foi salvo
   * depois de uma interrupção inesperada.
   */
  @Synchronized
  fun addPending(
    ctx: Context,
    file: String,
    blockId: Long,
    durationMs: Long,
    group: String = "",
    recovered: Boolean = false
  ) {
    val arr = try {
      JSONArray(prefs(ctx).getString("pending", "[]") ?: "[]")
    } catch (e: Exception) {
      JSONArray()
    }
    arr.put(
      JSONObject()
        .put("file", file)
        .put("blockId", blockId)
        .put("durationMs", durationMs)
        .put("group", group)
        .put("recovered", recovered)
    )
    prefs(ctx).edit().putString("pending", arr.toString()).commit()
  }

  /** Sessão de gravação em andamento (para recuperar o áudio se o app for encerrado de repente). */
  @Synchronized
  fun saveSession(ctx: Context, json: String, sync: Boolean) {
    val e = prefs(ctx).edit().putString("session", json)
    if (sync) e.commit() else e.apply()
  }

  @Synchronized
  fun readSession(ctx: Context): JSONObject? {
    val s = prefs(ctx).getString("session", null) ?: return null
    return try {
      JSONObject(s)
    } catch (e: Exception) {
      null
    }
  }

  @Synchronized
  fun clearSession(ctx: Context) {
    prefs(ctx).edit().remove("session").commit()
  }

  /** Entrega as gravações pendentes (JSON) e limpa a lista. */
  @Synchronized
  fun consumePending(ctx: Context): String {
    val s = prefs(ctx).getString("pending", "[]") ?: "[]"
    prefs(ctx).edit().putString("pending", "[]").commit()
    return s
  }
}
