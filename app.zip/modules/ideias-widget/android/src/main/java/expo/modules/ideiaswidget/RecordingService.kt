package expo.modules.ideiaswidget

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import android.widget.Toast
import java.io.File

/**
 * Grava o áudio em segundo plano (sem abrir o app). O arquivo vai para a mesma pasta
 * "audios" do app; o app importa para o banco na próxima vez que abrir.
 */
class RecordingService : Service() {
  private var recorder: MediaRecorder? = null
  private var file: File? = null
  private var startedAt = 0L
  private var blockId = -1L

  companion object {
    @Volatile
    var active = false
    private const val CHANNEL_ID = "ideias_gravacao"
    private const val NOTIF_ID = 4101
  }

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    if (intent?.action == Ideias.ACTION_STOP) {
      finishRecording()
    } else {
      startRecording(intent?.getLongExtra(Ideias.EXTRA_BLOCK_ID, -1L) ?: -1L)
    }
    return START_NOT_STICKY
  }

  private fun startRecording(target: Long) {
    if (active) return // já está gravando: ignora toque repetido

    try {
      startForegroundNotification()
    } catch (e: Exception) {
      fail("Não foi possível iniciar a gravação.")
      return
    }

    try {
      val dir = File(filesDir, "audios")
      if (!dir.exists()) dir.mkdirs()
      val f = File(dir, "rec_${System.currentTimeMillis()}.m4a")
      val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()
      r.setAudioSource(MediaRecorder.AudioSource.MIC)
      r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
      r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
      r.setAudioChannels(1)
      r.setAudioSamplingRate(44100)
      r.setAudioEncodingBitRate(64000)
      r.setOutputFile(f.absolutePath)
      r.prepare()
      r.start()

      recorder = r
      file = f
      blockId = target
      startedAt = System.currentTimeMillis()
      active = true
      WidgetStore.setRecording(this, true)
      IdeiasWidgetProvider.updateAll(this)
    } catch (e: Exception) {
      releaseQuietly()
      fail("Não foi possível gravar pelo widget.")
    }
  }

  private fun finishRecording() {
    val r = recorder
    val f = file
    if (r == null || f == null) {
      closeService()
      return
    }
    val durationMs = System.currentTimeMillis() - startedAt
    var ok = true
    try {
      r.stop()
    } catch (e: RuntimeException) {
      ok = false // gravação curta demais
    }
    try {
      r.release()
    } catch (e: Exception) {
    }
    recorder = null
    file = null

    if (ok && f.exists() && f.length() > 0 && durationMs >= 1000) {
      WidgetStore.addPending(this, f.name, blockId, durationMs)
      Toast.makeText(this, "Gravação salva. Abra o app para transcrever.", Toast.LENGTH_LONG).show()
    } else {
      f.delete()
    }
    closeService()
  }

  private fun closeService() {
    active = false
    WidgetStore.setRecording(this, false)
    IdeiasWidgetProvider.updateAll(this)
    if (Build.VERSION.SDK_INT >= 24) stopForeground(Service.STOP_FOREGROUND_REMOVE)
    else @Suppress("DEPRECATION") stopForeground(true)
    stopSelf()
  }

  private fun fail(message: String) {
    Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    closeService()
  }

  private fun releaseQuietly() {
    try {
      recorder?.release()
    } catch (e: Exception) {
    }
    recorder = null
    file?.delete()
    file = null
  }

  private fun startForegroundNotification() {
    val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    if (Build.VERSION.SDK_INT >= 26) {
      nm.createNotificationChannel(
        NotificationChannel(CHANNEL_ID, getString(R.string.ideias_channel_name), NotificationManager.IMPORTANCE_LOW)
      )
    }

    val stopIntent = PendingIntent.getService(
      this,
      1,
      Intent(this, RecordingService::class.java).setAction(Ideias.ACTION_STOP),
      PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    val launch = packageManager.getLaunchIntentForPackage(packageName)
    val openApp = if (launch != null) {
      PendingIntent.getActivity(this, 2, launch, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    } else null

    val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID)
    else @Suppress("DEPRECATION") Notification.Builder(this)

    builder
      .setSmallIcon(android.R.drawable.ic_btn_speak_now)
      .setContentTitle("Gravando ideia…")
      .setContentText("Toque em Parar para salvar.")
      .setOngoing(true)
      .setUsesChronometer(true)
      .setWhen(System.currentTimeMillis())
      .setContentIntent(openApp)
      .addAction(android.R.drawable.ic_media_pause, "Parar", stopIntent)

    val notification = builder.build()
    if (Build.VERSION.SDK_INT >= 29) {
      startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
    } else {
      startForeground(NOTIF_ID, notification)
    }
  }

  override fun onDestroy() {
    // Se o sistema derrubar o serviço no meio da gravação, salva o que deu.
    if (recorder != null) finishRecording()
    active = false
    super.onDestroy()
  }
}
