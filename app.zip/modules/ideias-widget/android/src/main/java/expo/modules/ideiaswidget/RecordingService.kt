package expo.modules.ideiaswidget

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

/**
 * Serviço único de gravação (usado pela tela de Gravação e pelo widget). Roda em primeiro plano
 * (notificação com Pausar/Parar), então a gravação continua com a tela apagada ou o app fechado.
 *
 * - Formato AAC "ADTS" (.aac): pode ser tocado mesmo se o arquivo ficar incompleto.
 * - Pausar fecha o trecho atual e retomar abre outro; ao terminar, os trechos são unidos.
 * - Uma sessão fica salva em disco: se o app for encerrado de repente, o áudio é recuperado.
 * - Gravações longas são divididas em partes de 25 min (limite de envio para a IA).
 * - Pausa sozinho se uma chamada/outro app tomar o áudio ou se o fone for desconectado.
 */
class RecordingService : Service() {
  private val handler = Handler(Looper.getMainLooper())
  private var recorder: MediaRecorder? = null
  private val segments = ArrayList<File>()
  private var segCounter = 0

  @Volatile private var blockId = -1L
  private var group = ""
  private var fromApp = false
  @Volatile private var paused = false
  @Volatile private var partIndex = 1
  @Volatile private var totalBeforeMs = 0L
  @Volatile private var partMs = 0L
  @Volatile private var resumedAt = 0L
  @Volatile private var level = 0f
  private var savedParts = 0
  private var shortParts = 0
  private var lastPersist = 0L
  private var finishing = false
  private var focusRequest: AudioFocusRequest? = null
  private var noisyRegistered = false

  companion object {
    @Volatile
    var active = false

    @Volatile private var instance: RecordingService? = null
    @Volatile private var notice = ""
    @Volatile private var error = ""
    @Volatile private var lastResult = ""

    private const val CHANNEL_ID = "ideias_gravacao"
    private const val NOTIF_ID = 4101
    private const val MIN_MS = 1000L
    private const val PART_LIMIT_MS = 25L * 60L * 1000L // 25 min ~ 12,5 MB, abaixo do limite de envio (14 MB)
    private const val BYTES_PER_SEC = 8300L // 64 kbps + cabeçalhos ADTS

    /** Pede ao serviço para começar a gravar (blockId -1 = nota nova). */
    fun begin(ctx: Context, target: Long, fromApp: Boolean): Boolean {
      val i = Intent(ctx, RecordingService::class.java)
        .setAction(Ideias.ACTION_RECORD)
        .putExtra(Ideias.EXTRA_BLOCK_ID, target)
        .putExtra(Ideias.EXTRA_FROM_APP, fromApp)
      return try {
        if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        true
      } catch (e: Exception) {
        error = "O Android não deixou iniciar a gravação."
        false
      }
    }

    /** Pausar, retomar, parar ou descartar. Sem gravação em andamento, não faz nada. */
    fun command(ctx: Context, action: String) {
      if (!active) return
      try {
        ctx.startService(Intent(ctx, RecordingService::class.java).setAction(action))
      } catch (e: Exception) {
        // serviço já encerrou
      }
    }

    /** Estado atual para a tela (JSON). */
    fun snapshot(): String {
      val o = JSONObject()
      val s = instance
      if (active && s != null) {
        o.put("state", if (s.paused) "paused" else "recording")
        o.put("ms", s.elapsedMs())
        o.put("level", s.level.toDouble())
        o.put("blockId", s.blockId)
        o.put("part", s.partIndex)
      } else {
        o.put("state", "idle")
        o.put("ms", 0)
        o.put("level", 0.0)
        o.put("blockId", -1)
        o.put("part", 1)
      }
      o.put("notice", notice)
      o.put("error", error)
      o.put("last", lastResult)
      return o.toString()
    }

    /** Une trechos (.aac) em um único arquivo na pasta "audios". Em ADTS basta juntar os bytes. */
    fun joinSegments(ctx: Context, segs: List<File>): File? {
      val good = segs.filter { it.exists() && it.length() > 0L }
      if (good.isEmpty()) return null
      val dir = File(ctx.filesDir, "audios")
      if (!dir.exists()) dir.mkdirs()
      var out = File(dir, "rec_${System.currentTimeMillis()}.aac")
      var n = 1
      while (out.exists()) {
        out = File(dir, "rec_${System.currentTimeMillis()}_$n.aac")
        n++
      }
      return try {
        val moved = good.size == 1 && good[0].renameTo(out)
        if (!moved) {
          FileOutputStream(out).use { os ->
            for (f in good) f.inputStream().use { it.copyTo(os) }
          }
        }
        segs.forEach { it.delete() }
        out
      } catch (e: Exception) {
        out.delete()
        null
      }
    }

    /**
     * Se o app foi encerrado no meio de uma gravação, junta o que ficou no disco e deixa como
     * gravação pendente (o app importa na abertura). Retorna quantas foram recuperadas.
     */
    fun recoverOrphan(ctx: Context): Int {
      if (active) return 0
      val s = WidgetStore.readSession(ctx) ?: return 0
      var count = 0
      try {
        val dir = File(ctx.filesDir, "rec_tmp")
        val names = s.optJSONArray("files") ?: JSONArray()
        val files = ArrayList<File>()
        for (i in 0 until names.length()) files.add(File(dir, names.getString(i)))
        val bytes = files.filter { it.exists() }.sumOf { it.length() }
        var dur = s.optLong("durationMs", 0L)
        if (dur <= 0L) dur = bytes * 1000L / BYTES_PER_SEC
        if (bytes > 0L && dur >= MIN_MS) {
          val out = joinSegments(ctx, files)
          if (out != null) {
            WidgetStore.addPending(ctx, out.name, s.optLong("blockId", -1L), dur, s.optString("group", ""), true)
            count = 1
          }
        } else {
          files.forEach { it.delete() }
        }
      } catch (e: Exception) {
        // sem o que recuperar
      }
      WidgetStore.clearSession(ctx)
      return count
    }
  }

  // ---------- ciclo de vida ----------

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onCreate() {
    super.onCreate()
    instance = this
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    when (intent?.action) {
      Ideias.ACTION_RECORD -> startRecording(
        intent?.getLongExtra(Ideias.EXTRA_BLOCK_ID, -1L) ?: -1L,
        intent?.getBooleanExtra(Ideias.EXTRA_FROM_APP, false) ?: false
      )
      Ideias.ACTION_STOP -> finishRecording(false)
      Ideias.ACTION_DISCARD -> finishRecording(true)
      Ideias.ACTION_PAUSE -> if (active) pauseRecording("") else stopSelf()
      Ideias.ACTION_RESUME -> if (active) resumeRecording() else stopSelf()
      else -> stopSelf()
    }
    return START_NOT_STICKY
  }

  override fun onDestroy() {
    // Se o sistema derrubar o serviço no meio da gravação, salva o que deu.
    if (active && !finishing) {
      notice = "A gravação foi interrompida pelo sistema. O que deu para gravar foi salvo."
      finishRecording(false)
    }
    active = false
    if (instance === this) instance = null
    super.onDestroy()
  }

  // ---------- começar / pausar / retomar / terminar ----------

  private fun startRecording(target: Long, app: Boolean) {
    fromApp = app
    try {
      startForegroundNotification()
    } catch (e: Exception) {
      fail("Não foi possível iniciar a gravação.")
      return
    }
    if (active) return // já está gravando: só renovou o aviso

    // Sobra de uma gravação interrompida: salva antes de começar a nova.
    try {
      recoverOrphan(this)
    } catch (e: Exception) {
    }

    finishing = false
    blockId = target
    group = System.currentTimeMillis().toString()
    partIndex = 1
    totalBeforeMs = 0L
    partMs = 0L
    resumedAt = 0L
    level = 0f
    savedParts = 0
    shortParts = 0
    segCounter = 0
    segments.clear()
    paused = false
    notice = ""
    error = ""
    lastResult = ""

    requestFocus()
    registerNoisy()
    if (!beginSegment()) {
      abandonFocus()
      unregisterNoisy()
      error = "Não foi possível gravar. O microfone pode estar em uso por outro app."
      WidgetStore.clearSession(this)
      fail(error)
      return
    }
    active = true
    WidgetStore.setRecording(this, true)
    IdeiasWidgetProvider.updateAll(this)
    updateNotification()
    lastPersist = SystemClock.elapsedRealtime()
    handler.post(tick)
  }

  private fun pauseRecording(reason: String) {
    if (!active || paused) return
    endSegment()
    paused = true
    level = 0f
    if (reason.isNotEmpty()) notice = reason
    persistSession(true)
    updateNotification()
  }

  private fun resumeRecording() {
    if (!active || !paused) return
    requestFocus()
    if (beginSegment()) {
      paused = false
      notice = ""
      updateNotification()
    } else {
      notice = "Não foi possível retomar: o microfone está em uso por outro app."
    }
  }

  private fun finishRecording(discard: Boolean) {
    if (finishing) return
    finishing = true
    if (!active) {
      closeService()
      return
    }
    endSegment()
    val files = ArrayList(segments)
    segments.clear()
    if (discard) {
      files.forEach { it.delete() }
      lastResult = "discarded"
    } else {
      savePart(files, partMs)
      lastResult = when {
        savedParts > 0 -> "saved"
        shortParts > 0 -> "short"
        error.isNotEmpty() -> "error"
        else -> "empty"
      }
      if (!fromApp) {
        val msg = when (lastResult) {
          "saved" -> "Gravação salva. Abra o app para transcrever."
          "short" -> "Gravação curta demais (menos de 1 s): descartada."
          else -> null
        }
        if (msg != null) Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
      }
    }
    WidgetStore.clearSession(this)
    closeService()
  }

  /** Passou de 25 min: fecha esta parte, guarda e já começa a próxima (mesma nota). */
  private fun rotatePart() {
    endSegment()
    val files = ArrayList(segments)
    segments.clear()
    savePart(files, partMs)
    totalBeforeMs += partMs
    partMs = 0L
    partIndex += 1
    segCounter = 0
    notice = "Gravação dividida: parte $partIndex iniciada (limite de 25 min por parte)."
    if (!beginSegment()) {
      error = "Não foi possível continuar a gravação."
      lastResult = if (savedParts > 0) "saved" else "error"
      WidgetStore.clearSession(this)
      closeService()
      return
    }
    persistSession(true)
    updateNotification()
  }

  private fun savePart(files: List<File>, durationMs: Long) {
    if (durationMs < MIN_MS) {
      files.forEach { it.delete() }
      shortParts++
      return
    }
    val out = joinSegments(this, files)
    if (out == null) {
      error = "Não foi possível salvar o áudio."
      return
    }
    WidgetStore.addPending(this, out.name, blockId, durationMs, group, false)
    savedParts++
  }

  private fun onRecorderError() {
    if (!active || finishing) return
    notice = "A gravação foi interrompida pelo sistema. O que deu para gravar foi salvo."
    finishRecording(false)
  }

  // ---------- MediaRecorder ----------

  private fun beginSegment(): Boolean {
    var r: MediaRecorder? = null
    return try {
      val dir = File(filesDir, "rec_tmp")
      if (!dir.exists()) dir.mkdirs()
      val f = File(dir, "seg_${group}_${partIndex}_${segCounter++}.aac")
      r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()
      r.setAudioSource(MediaRecorder.AudioSource.MIC)
      r.setOutputFormat(MediaRecorder.OutputFormat.AAC_ADTS)
      r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
      r.setAudioChannels(1)
      r.setAudioSamplingRate(44100)
      r.setAudioEncodingBitRate(64000)
      r.setOutputFile(f.absolutePath)
      r.setOnErrorListener { _, _, _ -> handler.post { onRecorderError() } }
      r.prepare()
      r.start()
      recorder = r
      segments.add(f)
      resumedAt = SystemClock.elapsedRealtime()
      persistSession(true)
      true
    } catch (e: Exception) {
      try {
        r?.release()
      } catch (x: Exception) {
      }
      recorder = null
      false
    }
  }

  /** Fecha o trecho que está gravando (solta o microfone) e soma o tempo dele. */
  private fun endSegment() {
    val r = recorder ?: return
    recorder = null
    if (resumedAt > 0L) partMs += SystemClock.elapsedRealtime() - resumedAt
    resumedAt = 0L
    try {
      r.stop()
    } catch (e: RuntimeException) {
      // trecho curto demais, sem dados: descarta só ele
      if (segments.isNotEmpty()) segments.removeAt(segments.size - 1).delete()
    }
    try {
      r.release()
    } catch (e: Exception) {
    }
  }

  private fun elapsedMs(): Long {
    val r = resumedAt
    val running = if (r > 0L) SystemClock.elapsedRealtime() - r else 0L
    return totalBeforeMs + partMs + running
  }

  private fun partElapsedMs(): Long {
    val r = resumedAt
    val running = if (r > 0L) SystemClock.elapsedRealtime() - r else 0L
    return partMs + running
  }

  /** A cada 50 ms: nível do microfone, limite de 25 min e batimento da sessão salva em disco. */
  private val tick = object : Runnable {
    override fun run() {
      if (!active) return
      if (!paused) {
        val r = recorder
        if (r != null) {
          try {
            val raw = (r.maxAmplitude / 12000f).coerceIn(0f, 1f)
            level = Math.max(raw, level * 0.85f)
          } catch (e: Exception) {
          }
        }
        if (partElapsedMs() >= PART_LIMIT_MS) rotatePart()
      } else {
        level = 0f
      }
      val now = SystemClock.elapsedRealtime()
      if (now - lastPersist >= 2000L) {
        lastPersist = now
        persistSession(false)
      }
      if (active) handler.postDelayed(this, 50)
    }
  }

  private fun persistSession(sync: Boolean) {
    try {
      val o = JSONObject()
      o.put("group", group)
      o.put("blockId", blockId)
      o.put("part", partIndex)
      o.put("durationMs", partElapsedMs())
      val arr = JSONArray()
      segments.forEach { arr.put(it.name) }
      o.put("files", arr)
      WidgetStore.saveSession(this, o.toString(), sync)
    } catch (e: Exception) {
    }
  }

  // ---------- interrupções: chamada, outro app, fone ----------

  private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
    if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
      if (active && !paused) pauseRecording("Pausada: uma chamada ou outro app usou o áudio. Toque em retomar.")
    }
  }

  private val noisyReceiver = object : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
      if (intent?.action == AudioManager.ACTION_AUDIO_BECOMING_NOISY) {
        if (active && !paused) pauseRecording("Pausada: o fone foi desconectado. Toque em retomar.")
      }
    }
  }

  @Suppress("DEPRECATION")
  private fun requestFocus() {
    try {
      val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
      if (Build.VERSION.SDK_INT >= 26) {
        val attrs = AudioAttributes.Builder()
          .setUsage(AudioAttributes.USAGE_MEDIA)
          .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
          .build()
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
          .setAudioAttributes(attrs)
          .setOnAudioFocusChangeListener(focusListener, handler)
          .build()
        am.requestAudioFocus(req)
        focusRequest = req
      } else {
        am.requestAudioFocus(focusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
      }
    } catch (e: Exception) {
      // segue sem foco: só não pausa sozinho em chamadas
    }
  }

  @Suppress("DEPRECATION")
  private fun abandonFocus() {
    try {
      val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
      if (Build.VERSION.SDK_INT >= 26) {
        focusRequest?.let { am.abandonAudioFocusRequest(it) }
        focusRequest = null
      } else {
        am.abandonAudioFocus(focusListener)
      }
    } catch (e: Exception) {
    }
  }

  private fun registerNoisy() {
    if (noisyRegistered) return
    try {
      registerReceiver(noisyReceiver, IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY))
      noisyRegistered = true
    } catch (e: Exception) {
    }
  }

  private fun unregisterNoisy() {
    if (!noisyRegistered) return
    try {
      unregisterReceiver(noisyReceiver)
    } catch (e: Exception) {
    }
    noisyRegistered = false
  }

  // ---------- encerramento e notificação ----------

  private fun closeService() {
    handler.removeCallbacks(tick)
    active = false
    paused = false
    level = 0f
    resumedAt = 0L
    abandonFocus()
    unregisterNoisy()
    WidgetStore.setRecording(this, false)
    IdeiasWidgetProvider.updateAll(this)
    if (Build.VERSION.SDK_INT >= 24) stopForeground(Service.STOP_FOREGROUND_REMOVE)
    else @Suppress("DEPRECATION") stopForeground(true)
    stopSelf()
  }

  private fun fail(message: String) {
    if (!fromApp) Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    error = message
    closeService()
  }

  private fun ensureChannel() {
    if (Build.VERSION.SDK_INT >= 26) {
      val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
      nm.createNotificationChannel(
        NotificationChannel(CHANNEL_ID, getString(R.string.ideias_channel_name), NotificationManager.IMPORTANCE_LOW)
      )
    }
  }

  private fun buildNotification(): Notification {
    ensureChannel()
    val piFlags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    val stopIntent = PendingIntent.getService(
      this, 1, Intent(this, RecordingService::class.java).setAction(Ideias.ACTION_STOP), piFlags
    )
    val toggleIntent = PendingIntent.getService(
      this, 3,
      Intent(this, RecordingService::class.java).setAction(if (paused) Ideias.ACTION_RESUME else Ideias.ACTION_PAUSE),
      piFlags
    )
    val launch = packageManager.getLaunchIntentForPackage(packageName)
    val openApp = if (launch != null) PendingIntent.getActivity(this, 2, launch, piFlags) else null

    val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID)
    else @Suppress("DEPRECATION") Notification.Builder(this)

    builder
      .setSmallIcon(android.R.drawable.ic_btn_speak_now)
      .setContentTitle(if (paused) "Gravação pausada" else "Gravando ideia…")
      .setContentText(if (partIndex > 1) "Parte $partIndex · use os botões para controlar." else "Use Pausar ou Parar para controlar.")
      .setOngoing(true)
      .setOnlyAlertOnce(true)
      .setContentIntent(openApp)

    if (paused) {
      builder.setUsesChronometer(false).setShowWhen(false)
    } else {
      builder.setUsesChronometer(true).setShowWhen(true).setWhen(System.currentTimeMillis() - elapsedMs())
    }

    builder
      .addAction(
        if (paused) android.R.drawable.ic_media_play else android.R.drawable.ic_media_pause,
        if (paused) "Retomar" else "Pausar",
        toggleIntent
      )
      .addAction(android.R.drawable.ic_menu_save, "Parar", stopIntent)

    return builder.build()
  }

  private fun startForegroundNotification() {
    val notification = buildNotification()
    if (Build.VERSION.SDK_INT >= 29) {
      startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
    } else {
      startForeground(NOTIF_ID, notification)
    }
  }

  private fun updateNotification() {
    try {
      val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
      nm.notify(NOTIF_ID, buildNotification())
    } catch (e: Exception) {
    }
  }
}
