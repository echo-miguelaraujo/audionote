package expo.modules.ideiaswidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews

class IdeiasWidgetProvider : AppWidgetProvider() {
  override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
    for (id in appWidgetIds) {
      manager.updateAppWidget(id, buildViews(context))
    }
  }

  companion object {
    fun updateAll(context: Context) {
      val manager = AppWidgetManager.getInstance(context)
      val ids = manager.getAppWidgetIds(ComponentName(context, IdeiasWidgetProvider::class.java))
      if (ids.isEmpty()) return
      for (id in ids) {
        manager.updateAppWidget(id, buildViews(context))
      }
    }

    private fun actionIntent(ctx: Context, action: String, blockId: Long, code: Int): PendingIntent {
      val intent = Intent(ctx, WidgetActionReceiver::class.java)
        .setAction(action)
        .putExtra(Ideias.EXTRA_BLOCK_ID, blockId)
      return PendingIntent.getBroadcast(
        ctx,
        code,
        intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
      )
    }

    fun buildViews(ctx: Context): RemoteViews {
      val v = RemoteViews(ctx.packageName, R.layout.ideias_widget)
      val rows = intArrayOf(R.id.ideias_row_1, R.id.ideias_row_2, R.id.ideias_row_3)
      val recording = WidgetStore.isRecording(ctx) && RecordingService.active

      if (recording) {
        v.setViewVisibility(R.id.ideias_row_stop, View.VISIBLE)
        v.setViewVisibility(R.id.ideias_row_new, View.GONE)
        for (r in rows) v.setViewVisibility(r, View.GONE)
        v.setImageViewResource(R.id.ideias_circle, R.drawable.ideias_circle_red)
        val stop = actionIntent(ctx, Ideias.ACTION_STOP, -1L, 10)
        v.setOnClickPendingIntent(R.id.ideias_row_stop, stop)
        v.setOnClickPendingIntent(R.id.ideias_circle, stop)
        return v
      }

      v.setViewVisibility(R.id.ideias_row_stop, View.GONE)
      v.setViewVisibility(R.id.ideias_row_new, View.VISIBLE)
      v.setImageViewResource(R.id.ideias_circle, R.drawable.ideias_circle_white)
      val record = actionIntent(ctx, Ideias.ACTION_RECORD, -1L, 20)
      v.setOnClickPendingIntent(R.id.ideias_circle, record)
      v.setOnClickPendingIntent(R.id.ideias_row_new, record)

      val notes = WidgetStore.notes(ctx)
      for (i in rows.indices) {
        if (i < notes.size) {
          val (id, title) = notes[i]
          v.setTextViewText(rows[i], title)
          v.setViewVisibility(rows[i], View.VISIBLE)
          v.setOnClickPendingIntent(rows[i], actionIntent(ctx, Ideias.ACTION_RECORD, id, 30 + i))
        } else {
          v.setViewVisibility(rows[i], View.GONE)
        }
      }
      return v
    }
  }
}
