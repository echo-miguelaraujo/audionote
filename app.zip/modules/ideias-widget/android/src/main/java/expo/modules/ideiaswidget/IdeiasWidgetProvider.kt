package expo.modules.ideiaswidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class IdeiasWidgetProvider : AppWidgetProvider() {
  override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
    for (id in appWidgetIds) {
      manager.updateAppWidget(id, buildViews(context))
    }
  }

  companion object {
    fun updateAll(context: Context) {
      val manager = AppWidgetManager.getInstance(context)
      val ids = manager.getAppWidgetIds(ComponentName(context, IdeiasWidgetProvider::class.java))
      if (ids.isEmpty()) return
      for (id in ids) {
        manager.updateAppWidget(id, buildViews(context))
      }
    }

    private fun actionIntent(ctx: Context, action: String, blockId: Long, code: Int): PendingIntent {
      val intent = Intent(ctx, WidgetActionReceiver::class.java)
        .setAction(action)
        .putExtra(Ideias.EXTRA_BLOCK_ID, blockId)
      return PendingIntent.getBroadcast(
        ctx,
        code,
        intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
      )
    }

    /** Toque nas bolinhas (ou no título): troca de página. Cada página usa um código próprio. */
    private fun tabIntent(ctx: Context, page: Int): PendingIntent {
      val intent = Intent(ctx, WidgetActionReceiver::class.java)
        .setAction(Ideias.ACTION_TAB)
        .putExtra(Ideias.EXTRA_PAGE, page)
      return PendingIntent.getBroadcast(
        ctx,
        50 + page,
        intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
      )
    }

    private fun openAppIntent(ctx: Context): PendingIntent? {
      val launch = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName) ?: return null
      return PendingIntent.getActivity(
        ctx,
        40,
        launch,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
      )
    }

    fun buildViews(ctx: Context): RemoteViews {
      val v = RemoteViews(ctx.packageName, R.layout.ideias_widget)
      val recording = WidgetStore.isRecording(ctx) && RecordingService.active

      var page = WidgetStore.page(ctx)
      if (page < 0 || page > 2) page = 0
      if (recording) page = 0 // gravando: mostra sempre a página com o botão de parar

      // Título da página e bolinhas.
      val monthName = SimpleDateFormat("MMMM", Locale("pt", "BR")).format(Calendar.getInstance().time)
      val monthTitle = monthName.replaceFirstChar { c -> c.uppercase() }
      val titles = arrayOf("Gravação", "Agenda", monthTitle)
      v.setTextViewText(R.id.ideias_title, titles[page])
      v.setOnClickPendingIntent(R.id.ideias_title, tabIntent(ctx, (page + 1) % 3))

      val dots = intArrayOf(R.id.ideias_dot_0, R.id.ideias_dot_1, R.id.ideias_dot_2)
      val boxes = intArrayOf(R.id.ideias_dotbox_0, R.id.ideias_dotbox_1, R.id.ideias_dotbox_2)
      for (i in 0 until 3) {
        v.setImageViewResource(dots[i], if (i == page) R.drawable.ideias_dot_on else R.drawable.ideias_dot_off)
        v.setOnClickPendingIntent(boxes[i], tabIntent(ctx, i))
      }

      v.setViewVisibility(R.id.ideias_page_rec, if (page == 0) View.VISIBLE else View.GONE)
      v.setViewVisibility(R.id.ideias_page_agenda, if (page == 1) View.VISIBLE else View.GONE)
      v.setViewVisibility(R.id.ideias_page_cal, if (page == 2) View.VISIBLE else View.GONE)
      v.setViewVisibility(R.id.ideias_circle, if (page == 0) View.VISIBLE else View.GONE)

      when (page) {
        0 -> buildRecordingPage(ctx, v, recording)
        1 -> buildAgendaPage(ctx, v)
        else -> buildCalendarPage(ctx, v)
      }
      return v
    }

    private fun buildRecordingPage(ctx: Context, v: RemoteViews, recording: Boolean) {
      val rows = intArrayOf(R.id.ideias_row_1, R.id.ideias_row_2, R.id.ideias_row_3)

      if (recording) {
        v.setViewVisibility(R.id.ideias_row_stop, View.VISIBLE)
        for (r in rows) v.setViewVisibility(r, View.GONE)
        v.setImageViewResource(R.id.ideias_circle, R.drawable.ideias_circle_red)
        val stop = actionIntent(ctx, Ideias.ACTION_STOP, -1L, 10)
        v.setOnClickPendingIntent(R.id.ideias_row_stop, stop)
        v.setOnClickPendingIntent(R.id.ideias_circle, stop)
        return
      }

      v.setViewVisibility(R.id.ideias_row_stop, View.GONE)
      v.setImageViewResource(R.id.ideias_circle, R.drawable.ideias_circle_white)
      val record = actionIntent(ctx, Ideias.ACTION_RECORD, -1L, 20)
      v.setOnClickPendingIntent(R.id.ideias_circle, record)

      val notes = WidgetStore.notes(ctx)
      for (i in rows.indices) {
        if (i < notes.size) {
          val (id, title) = notes[i]
          v.setTextViewText(rows[i], title)
          v.setViewVisibility(rows[i], View.VISIBLE)
          v.setOnClickPendingIntent(rows[i], actionIntent(ctx, Ideias.ACTION_RECORD, id, 30 + i))
        } else {
          v.setViewVisibility(rows[i], View.GONE)
        }
      }
    }

    private fun buildAgendaPage(ctx: Context, v: RemoteViews) {
      val items = WidgetStore.upcoming(ctx)
      val rowIds = intArrayOf(R.id.ideias_ag_1, R.id.ideias_ag_2, R.id.ideias_ag_3)
      val dayIds = intArrayOf(R.id.ideias_ag_day_1, R.id.ideias_ag_day_2, R.id.ideias_ag_day_3)
      val titleIds = intArrayOf(R.id.ideias_ag_title_1, R.id.ideias_ag_title_2, R.id.ideias_ag_title_3)
      val whenIds = intArrayOf(R.id.ideias_ag_when_1, R.id.ideias_ag_when_2, R.id.ideias_ag_when_3)

      for (i in rowIds.indices) {
        if (i < items.size) {
          v.setTextViewText(dayIds[i], items[i].day)
          v.setTextViewText(titleIds[i], items[i].title)
          v.setTextViewText(whenIds[i], items[i].whenText)
          v.setViewVisibility(rowIds[i], View.VISIBLE)
        } else {
          v.setViewVisibility(rowIds[i], View.GONE)
        }
      }
      v.setViewVisibility(R.id.ideias_ag_empty, if (items.isEmpty()) View.VISIBLE else View.GONE)

      val open = openAppIntent(ctx)
      if (open != null) v.setOnClickPendingIntent(R.id.ideias_page_agenda, open)
    }

    private fun buildCalendarPage(ctx: Context, v: RemoteViews) {
      val marks = WidgetStore.marks(ctx)
      val now = Calendar.getInstance()
      val todayKey = keyOf(now)

      // Semana atual, de domingo a sábado.
      val cur = Calendar.getInstance()
      cur.set(Calendar.HOUR_OF_DAY, 12)
      cur.add(Calendar.DAY_OF_MONTH, -(cur.get(Calendar.DAY_OF_WEEK) - 1))

      v.removeAllViews(R.id.ideias_cal_grid)
      for (col in 0 until 7) {
        val cell = RemoteViews(ctx.packageName, R.layout.ideias_cell)
        cell.setTextViewText(R.id.ideias_cell_text, cur.get(Calendar.DAY_OF_MONTH).toString())
        val key = keyOf(cur)
        if (key == todayKey) {
          cell.setInt(R.id.ideias_cell_text, "setBackgroundResource", R.drawable.ideias_cell_today)
        } else if (marks.contains(key)) {
          cell.setInt(R.id.ideias_cell_text, "setBackgroundResource", R.drawable.ideias_cell_event)
        }
        v.addView(R.id.ideias_cal_grid, cell)
        cur.add(Calendar.DAY_OF_MONTH, 1)
      }

      // Próximo compromisso, embaixo da semana.
      val next = WidgetStore.upcoming(ctx).firstOrNull()
      v.setTextViewText(
        R.id.ideias_cal_next,
        if (next != null) "${next.title} · ${next.whenText}" else "Nada marcado nos próximos dias."
      )

      val open = openAppIntent(ctx)
      if (open != null) v.setOnClickPendingIntent(R.id.ideias_page_cal, open)
    }

    private fun keyOf(c: Calendar): String =
      String.format(Locale.US, "%04d-%02d-%02d", c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
  }
}
