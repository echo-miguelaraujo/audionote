package expo.modules.ideiaswidget

import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

class IdeiasWidgetModule : Module() {
  override fun definition() = ModuleDefinition {
    Name("IdeiasWidget")

    // Lista (JSON) das notas mais recentes que o widget mostra.
    Function("setNotes") { json: String ->
      val ctx = appContext.reactContext ?: return@Function
      WidgetStore.setNotes(ctx, json)
      IdeiasWidgetProvider.updateAll(ctx)
    }

    // Próximos compromissos e dias marcados (JSON) para as páginas Agenda e Calendário.
    Function("setAgenda") { json: String ->
      val ctx = appContext.reactContext ?: return@Function
      WidgetStore.setAgenda(ctx, json)
      IdeiasWidgetProvider.updateAll(ctx)
    }

    // Gravações prontas (feitas pelo serviço) que o app ainda não importou (JSON).
    Function("consumePending") {
      val ctx = appContext.reactContext
      return@Function if (ctx != null) WidgetStore.consumePending(ctx) else "[]"
    }

    // ---- Gravação (serviço em primeiro plano) ----

    // Começa a gravar. blockId -1 = nota nova (criada só ao parar).
    Function("startRecording") { blockId: Double ->
      val ctx = appContext.reactContext ?: return@Function false
      return@Function RecordingService.begin(ctx, blockId.toLong(), true)
    }

    Function("pauseRecording") {
      val ctx = appContext.reactContext
      if (ctx != null) RecordingService.command(ctx, Ideias.ACTION_PAUSE)
      return@Function Unit
    }

    Function("resumeRecording") {
      val ctx = appContext.reactContext
      if (ctx != null) RecordingService.command(ctx, Ideias.ACTION_RESUME)
      return@Function Unit
    }

    // Para e guarda a gravação (vira "pendente" para o app importar).
    Function("stopRecording") {
      val ctx = appContext.reactContext
      if (ctx != null) RecordingService.command(ctx, Ideias.ACTION_STOP)
      return@Function Unit
    }

    // Para e apaga a gravação.
    Function("discardRecording") {
      val ctx = appContext.reactContext
      if (ctx != null) RecordingService.command(ctx, Ideias.ACTION_DISCARD)
      return@Function Unit
    }

    // Estado atual (JSON): state, ms, level, blockId, part, notice, error, last.
    Function("getRecordingState") {
      return@Function RecordingService.snapshot()
    }

    // Vibração curta: "light" ou "strong".
    Function("haptic") { kind: String ->
      val ctx = appContext.reactContext ?: return@Function
      Haptics.play(ctx, kind)
    }

    // Recupera a gravação que ficou no disco se o app foi encerrado no meio dela. Retorna 0 ou 1.
    Function("recoverInterrupted") {
      val ctx = appContext.reactContext ?: return@Function 0
      return@Function RecordingService.recoverOrphan(ctx)
    }
  }
}
