package expo.modules.ideiaswidget

import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

class IdeiasWidgetModule : Module() {
  override fun definition() = ModuleDefinition {
    Name("IdeiasWidget")

    // Lista (JSON) das notas mais recentes que o widget mostra.
    Function("setNotes") { json: String ->
      val ctx = appContext.reactContext ?: return@Function
      WidgetStore.setNotes(ctx, json)
      IdeiasWidgetProvider.updateAll(ctx)
    }

    // Gravações feitas pelo widget que o app ainda não importou (JSON).
    Function("consumePending") {
      val ctx = appContext.reactContext
      return@Function if (ctx != null) WidgetStore.consumePending(ctx) else "[]"
    }
  }
}
