package expo.modules.ideiaswidget

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast

/** Recebe os toques do widget e liga/desliga o serviço de gravação. */
class WidgetActionReceiver : BroadcastReceiver() {
  override fun onReceive(context: Context, intent: Intent) {
    when (intent.action) {
      Ideias.ACTION_RECORD -> {
        if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
          Toast.makeText(context, "Abra o app Ideias uma vez e permita o microfone.", Toast.LENGTH_LONG).show()
          return
        }
        val blockId = intent.getLongExtra(Ideias.EXTRA_BLOCK_ID, -1L)
        val svc = Intent(context, RecordingService::class.java)
          .setAction(Ideias.ACTION_RECORD)
          .putExtra(Ideias.EXTRA_BLOCK_ID, blockId)
        try {
          if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(svc) else context.startService(svc)
        } catch (e: Exception) {
          Toast.makeText(context, "O Android não deixou gravar pelo widget. Abra o app.", Toast.LENGTH_LONG).show()
        }
      }
      Ideias.ACTION_STOP -> {
        try {
          context.startService(Intent(context, RecordingService::class.java).setAction(Ideias.ACTION_STOP))
        } catch (e: Exception) {
          // serviço já parou: só atualiza o widget
          WidgetStore.setRecording(context, false)
          IdeiasWidgetProvider.updateAll(context)
        }
      }
    }
  }
}
