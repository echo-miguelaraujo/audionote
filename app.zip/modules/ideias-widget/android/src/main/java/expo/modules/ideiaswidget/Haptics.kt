package expo.modules.ideiaswidget

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

/** Vibração curta para confirmar iniciar, pausar, parar e descartar. */
object Haptics {
  fun play(ctx: Context, kind: String) {
    try {
      val v: Vibrator? = if (Build.VERSION.SDK_INT >= 31) {
        (ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
      } else {
        @Suppress("DEPRECATION")
        ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
      }
      if (v == null || !v.hasVibrator()) return
      val strong = kind == "strong"
      val ms = if (strong) 40L else 18L
      if (Build.VERSION.SDK_INT >= 26) {
        v.vibrate(VibrationEffect.createOneShot(ms, if (strong) 200 else 110))
      } else {
        @Suppress("DEPRECATION")
        v.vibrate(ms)
      }
    } catch (e: Exception) {
      // sem vibração: segue normal
    }
  }
}
