-- Etapa 13 (Painéis Gravação e Edição): rode ANTES de abrir o app com o código novo.
-- Sem isso, o envio (push) de mood_items falha com "column view does not exist".
alter table public.mood_items
  add column if not exists view text not null default 'canvas',
  add column if not exists link_id text;
