-- Etapa 12 (Ordem de gravação e de edição): rode ANTES de abrir o app com o código novo.
-- Sem isso, o envio (push) de mood_collections falha com "column shoot_order does not exist".
alter table public.mood_collections
  add column if not exists shoot_order double precision,
  add column if not exists edit_order double precision,
  add column if not exists shoot_done boolean not null default false;

-- A ordem fixa antiga vira a ordem de edição (o app local já faz isso sozinho).
update public.mood_collections set edit_order = scene_order
  where scene_order is not null and edit_order is null;
