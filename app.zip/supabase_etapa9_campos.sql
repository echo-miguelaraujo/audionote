-- Etapa 9 (Campos de produção das cenas): rode ANTES de abrir o app com o código novo.
alter table public.mood_collections
  add column if not exists scene_duration text,
  add column if not exists scene_shot     text,
  add column if not exists scene_dialogue text,
  add column if not exists scene_date     text;
