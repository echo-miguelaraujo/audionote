import React, { useCallback, useEffect, useState } from 'react';
import { appAlert, DialogHost } from './src/dialog';
import { AppState, BackHandler, StyleSheet, Text, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useShareIntent } from 'expo-share-intent';
import * as ScreenOrientation from 'expo-screen-orientation';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import {
  Inter_300Light,
  Inter_400Regular,
  Inter_400Regular_Italic,
  Inter_700Bold,
  Inter_700Bold_Italic,
  Inter_800ExtraBold,
  useFonts,
} from '@expo-google-fonts/inter';
import { countQueue, getDb } from './src/db';
import { processQueue, subscribeQueue } from './src/queue';
import { AgendaScreen } from './src/AgendaScreen';
import { Background } from './src/Background';
import { loadBg } from './src/background';
import { CollectionScreen } from './src/CollectionScreen';
import { CollectionPicker } from './src/CollectionPicker';
import { PaletteExtractor } from './src/PaletteExtractor';
import { createLinkCard, refreshLinkCard } from './src/linkCards';
import { extractUrl } from './src/linkPreview';
import { LibraryScreen } from './src/LibraryScreen';
import { MoodboardScreen } from './src/MoodboardScreen';
import { NoteScreen } from './src/NoteScreen';
import { QueueScreen } from './src/QueueScreen';
import { RecordingScreen } from './src/RecordingScreen';
import { askNotificationPermission, importWidgetRecordings, syncWidgetAgenda, syncWidgetNotes } from './src/widget';
import { SettingsScreen } from './src/SettingsScreen';
import { initSync, scheduleSyncIfPending } from './src/sync';
import { Tab, TabBar } from './src/TabBar';
import { ErrorBoundary } from './src/ErrorBoundary';
import { colors } from './src/theme';

function Main() {
  const [tab, setTab] = useState<Tab>('rec');
  const [version, setVersion] = useState(0);
  const [dbError, setDbError] = useState<string | null>(null);
  const [dbReady, setDbReady] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const closeSettings = useCallback(() => setSettingsOpen(false), []);
  const [queueOpen, setQueueOpen] = useState(false);
  const closeQueue = useCallback(() => setQueueOpen(false), []);
  const [noteBlock, setNoteBlockRaw] = useState<number | null>(null);
  /** Notas abertas antes da atual (links entre notas): o voltar retorna a elas. */
  const [noteBack, setNoteBack] = useState<number[]>([]);
  // Abrir uma nota de fora (Biblioteca, Agenda, Gravação...) começa uma pilha nova.
  const setNoteBlock = useCallback((id: number | null) => {
    setNoteBack([]);
    setNoteBlockRaw(id);
  }, []);
  /** Abrir uma nota de dentro de outra: guarda a atual na pilha. */
  const openNoteFromNote = useCallback(
    (id: number) => {
      setNoteBack((b) => (noteBlock !== null ? [...b, noteBlock] : b));
      setNoteBlockRaw(id);
    },
    [noteBlock]
  );
  // Pilha de coleções abertas: [coleção da raiz, coleção de dentro, ...]. Vazia = nenhuma aberta.
  const [moodStack, setMoodStack] = useState<number[]>([]);
  // Apresentação do quadro (tela cheia): vale para toda a pilha, para continuar ao entrar numa coleção de dentro.
  const [presenting, setPresenting] = useState(false);
  const moodOpen = moodStack.length > 0 ? moodStack[moodStack.length - 1] : null;
  const openMood = useCallback((id: number) => setMoodStack([id]), []);
  const openSubMood = useCallback(
    (id: number) => setMoodStack((s) => (s.includes(id) ? s.slice(0, s.indexOf(id) + 1) : [...s, id])),
    []
  );
  const closeMood = useCallback(() => {
    setMoodStack((s) => s.slice(0, -1));
    setVersion((v) => v + 1);
  }, []);
  /** Abrir uma coleção a partir de uma nota: fecha a nota e mostra a coleção. */
  const openMoodFromNote = useCallback(
    (id: number) => {
      setNoteBlock(null);
      setMoodStack((s) => (s.includes(id) ? s.slice(0, s.indexOf(id) + 1) : [id]));
      setVersion((v) => v + 1);
    },
    []
  );
  const [pendingCount, setPendingCount] = useState(0);

  // Sem coleção aberta não há o que apresentar.
  useEffect(() => {
    if (moodStack.length === 0 && presenting) setPresenting(false);
  }, [moodStack, presenting]);

  // Link recebido pelo "Compartilhar" de outro app: pergunta em qual quadro colocar.
  const { hasShareIntent, shareIntent, resetShareIntent } = useShareIntent();
  const [sharedUrl, setSharedUrl] = useState<string | null>(null);

  useEffect(() => {
    getDb()
      .then(() => setDbReady(true))
      .catch((e) => setDbError(String(e)));
  }, []);

  const bump = useCallback(() => setVersion((v) => v + 1), []);

  useEffect(() => {
    if (!dbReady || !hasShareIntent) return;
    const url = extractUrl(shareIntent.webUrl ?? shareIntent.text ?? '');
    resetShareIntent();
    if (url) setSharedUrl(url);
    else appAlert('Não consegui usar o que foi compartilhado', 'Compartilhe um link (endereço que começa com http).');
  }, [dbReady, hasShareIntent, shareIntent, resetShareIntent]);

  const placeSharedLink = useCallback(
    async (collectionId: number) => {
      const url = sharedUrl;
      setSharedUrl(null);
      if (!url) return;
      try {
        const it = await createLinkCard(collectionId, url);
        setNoteBlock(null);
        setMoodStack([collectionId]);
        setVersion((v) => v + 1);
        // A prévia chega depois; quando chegar, o quadro recarrega.
        refreshLinkCard(it.id, it.content)
          .then(() => setVersion((v) => v + 1))
          .catch(() => {});
      } catch (e) {
        appAlert('Não consegui criar o cartão do link', String(e));
      }
    },
    [sharedUrl]
  );

  const closeNote = useCallback(() => {
    if (noteBack.length > 0) {
      setNoteBlockRaw(noteBack[noteBack.length - 1]);
      setNoteBack((b) => b.slice(0, -1));
    } else setNoteBlockRaw(null);
    setVersion((v) => v + 1);
  }, [noteBack]);

  // Quando algo é salvo, atualiza as telas e já tenta transcrever.
  const handleSaved = useCallback(() => {
    setVersion((v) => v + 1);
    processQueue().catch(() => {});
  }, []);

  // Contador de pendentes (aparece na tela de Gravação).
  useEffect(() => {
    if (!dbReady) return;
    countQueue().then(setPendingCount).catch(() => {});
  }, [dbReady, version]);

  // Widget: importa as gravações feitas por ele e mantém a lista de notas dele atualizada.
  const importFromWidget = useCallback(() => {
    importWidgetRecordings()
      .then((list) => {
        if (list.length > 0) handleSaved();
        if (list.some((r) => r.recovered)) {
          appAlert(
            'Gravação recuperada',
            'O app foi encerrado no meio de uma gravação. O áudio que deu para salvar foi recuperado e será transcrito.'
          );
        }
      })
      .catch(() => {});
  }, [handleSaved]);

  useEffect(() => {
    if (!dbReady) return;
    askNotificationPermission();
    loadBg();
  }, [dbReady]);

  useEffect(() => {
    if (!dbReady) return;
    syncWidgetNotes();
    syncWidgetAgenda();
  }, [dbReady, version]);

  // Sincronização com o Supabase: liga ao abrir; as mudanças vindas da nuvem atualizam as telas.
  useEffect(() => {
    if (!dbReady) return;
    return initSync(() => setVersion((v) => v + 1));
  }, [dbReady]);

  // Qualquer alteração local (version muda) agenda um envio, se houver pendências.
  useEffect(() => {
    if (!dbReady) return;
    scheduleSyncIfPending();
  }, [dbReady, version]);

  // Fila: roda ao abrir, ao voltar para o app e a cada 45 s (respeita o tempo de espera de cada tentativa).
  useEffect(() => {
    if (!dbReady) return;
    const run = () => processQueue().catch(() => {});
    importFromWidget();
    run();
    const sub = AppState.addEventListener('change', (st) => {
      if (st === 'active') {
        syncWidgetAgenda();
        importFromWidget();
        run();
      }
    });
    const timer = setInterval(run, 45000);
    const unsub = subscribeQueue(() => setVersion((v) => v + 1));
    return () => {
      sub.remove();
      clearInterval(timer);
      unsub();
    };
  }, [dbReady, importFromWidget]);

  const changeTab = (t: Tab) => setTab(t);

  // Só o Moodboard (coleções e dentro de cada coleção) pode ficar na horizontal; o resto fica em pé.
  const landscapeOk = (tab === 'mood' || moodOpen !== null) && noteBlock === null;
  useEffect(() => {
    const lock = landscapeOk
      ? ScreenOrientation.unlockAsync()
      : ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT_UP);
    lock.catch(() => {});
  }, [landscapeOk]);

  // Botão voltar do Android.
  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (settingsOpen || queueOpen || noteBlock !== null || moodOpen !== null) return false; // a tela aberta trata o voltar
      if (tab === 'lib' || tab === 'agenda' || tab === 'mood') {
        setTab('rec');
        return true;
      }
      return false;
    });
    return () => sub.remove();
  }, [tab, settingsOpen, queueOpen, noteBlock, moodOpen]);

  if (dbError) {
    return (
      <View style={styles.center}>
        <Text style={styles.err}>Erro ao abrir o banco de dados:{'\n'}{dbError}</Text>
      </View>
    );
  }
  if (!dbReady) return <View style={styles.root} />;

  return (
    <View style={styles.root}>
      <StatusBar style={tab === 'mood' ? 'dark' : 'light'} />
      <Background />
      <View style={[styles.flex, tab !== 'rec' && styles.hidden]}>
        <RecordingScreen
          onSaved={handleSaved}
          onOpenSettings={() => setSettingsOpen(true)}
          pendingCount={pendingCount}
          onOpenQueue={() => setQueueOpen(true)}
          onOpenNote={setNoteBlock}
          version={version}
        />
      </View>
      {tab === 'lib' && (
        <View style={styles.flex}>
          <LibraryScreen
            version={version}
            onOpen={setNoteBlock}
            onChanged={bump}
          />
        </View>
      )}
      {tab === 'mood' && (
        <View style={StyleSheet.absoluteFill}>
          <ErrorBoundary>
            <MoodboardScreen version={version} onOpen={openMood} onChanged={bump} />
          </ErrorBoundary>
        </View>
      )}
      {tab === 'agenda' && (
        <View style={styles.flex}>
          <AgendaScreen version={version} onOpenNote={setNoteBlock} />
        </View>
      )}
      {/* No Moodboard o quadro com pontilhado ocupa a tela toda; a barra fica por cima, no rodapé. */}
      {/* Com coleção, nota, fila ou configurações abertas, a barra some (essas telas ocupam tudo). */}
      {moodOpen === null && noteBlock === null && !queueOpen && !settingsOpen && (
        <View style={tab === 'mood' ? styles.barOverlay : undefined} pointerEvents="box-none">
          <TabBar active={tab} onChange={changeTab} />
        </View>
      )}
      {/* As coleções abertas ficam empilhadas (a de cima é a atual); a nota abre por cima de todas. */}
      {moodStack.map((id, idx) => (
        <CollectionScreen
          key={id}
          collectionId={id}
          version={version}
          onClose={closeMood}
          onOpenCollection={openSubMood}
          onOpenNote={setNoteBlock}
          presenting={presenting}
          isTop={idx === moodStack.length - 1}
          onPresent={setPresenting}
        />
      ))}
      {noteBlock !== null && (
        <NoteScreen key={noteBlock} blockId={noteBlock} onClose={closeNote} onOpenCollection={openMoodFromNote} onOpenNote={openNoteFromNote} />
      )}
      <CollectionPicker
        visible={sharedUrl !== null}
        title="Em qual quadro colocar?"
        onCancel={() => setSharedUrl(null)}
        onPick={placeSharedLink}
      />
      {queueOpen && <QueueScreen onClose={closeQueue} />}
      {settingsOpen && <SettingsScreen onClose={closeSettings} />}
    </View>
  );
}

export default function App() {
  const [loaded, error] = useFonts({
    Inter_300Light,
    Inter_400Regular,
    Inter_400Regular_Italic,
    Inter_700Bold,
    Inter_700Bold_Italic,
    Inter_800ExtraBold,
  });

  useEffect(() => {
    if (error) appAlert('Erro ao carregar a fonte', String(error));
  }, [error]);

  return (
    <SafeAreaProvider>
      {loaded || error ? <Main /> : <View style={styles.root} />}
      <DialogHost />
      <PaletteExtractor />
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  flex: { flex: 1 },
  hidden: { display: 'none' },
  barOverlay: { position: 'absolute', left: 0, right: 0, bottom: 0 },
  center: { flex: 1, backgroundColor: colors.bg, alignItems: 'center', justifyContent: 'center', padding: 24 },
  err: { color: colors.red, fontSize: 16 },
});
