import React, { useCallback, useEffect, useState } from 'react';
import { appAlert, DialogHost } from './src/dialog';
import { AppState, BackHandler, StyleSheet, Text, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import * as ScreenOrientation from 'expo-screen-orientation';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import {
  Inter_300Light,
  Inter_400Regular,
  Inter_400Regular_Italic,
  Inter_700Bold,
  Inter_700Bold_Italic,
  Inter_800ExtraBold,
  useFonts,
} from '@expo-google-fonts/inter';
import { countQueue, getDb } from './src/db';
import { processQueue, subscribeQueue } from './src/queue';
import { AgendaScreen } from './src/AgendaScreen';
import { Background } from './src/Background';
import { loadBg } from './src/background';
import { CollectionScreen } from './src/CollectionScreen';
import { LibraryScreen } from './src/LibraryScreen';
import { MoodboardScreen } from './src/MoodboardScreen';
import { NoteScreen } from './src/NoteScreen';
import { QueueScreen } from './src/QueueScreen';
import { RecordingScreen } from './src/RecordingScreen';
import { askNotificationPermission, importWidgetRecordings, syncWidgetAgenda, syncWidgetNotes } from './src/widget';
import { SettingsScreen } from './src/SettingsScreen';
import { Tab, TabBar } from './src/TabBar';
import { colors } from './src/theme';

function Main() {
  const [tab, setTab] = useState<Tab>('rec');
  const [version, setVersion] = useState(0);
  const [dbError, setDbError] = useState<string | null>(null);
  const [dbReady, setDbReady] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const closeSettings = useCallback(() => setSettingsOpen(false), []);
  const [queueOpen, setQueueOpen] = useState(false);
  const closeQueue = useCallback(() => setQueueOpen(false), []);
  const [noteBlock, setNoteBlock] = useState<number | null>(null);
  const [moodOpen, setMoodOpen] = useState<number | null>(null);
  const closeMood = useCallback(() => {
    setMoodOpen(null);
    setVersion((v) => v + 1);
  }, []);
  const [pendingCount, setPendingCount] = useState(0);

  useEffect(() => {
    getDb()
      .then(() => setDbReady(true))
      .catch((e) => setDbError(String(e)));
  }, []);

  const bump = useCallback(() => setVersion((v) => v + 1), []);

  const closeNote = useCallback(() => {
    setNoteBlock(null);
    setVersion((v) => v + 1);
  }, []);

  // Quando algo é salvo, atualiza as telas e já tenta transcrever.
  const handleSaved = useCallback(() => {
    setVersion((v) => v + 1);
    processQueue().catch(() => {});
  }, []);

  // Contador de pendentes (aparece na tela de Gravação).
  useEffect(() => {
    if (!dbReady) return;
    countQueue().then(setPendingCount).catch(() => {});
  }, [dbReady, version]);

  // Widget: importa as gravações feitas por ele e mantém a lista de notas dele atualizada.
  const importFromWidget = useCallback(() => {
    importWidgetRecordings()
      .then((n) => {
        if (n > 0) handleSaved();
      })
      .catch(() => {});
  }, [handleSaved]);

  useEffect(() => {
    if (!dbReady) return;
    askNotificationPermission();
    loadBg();
  }, [dbReady]);

  useEffect(() => {
    if (!dbReady) return;
    syncWidgetNotes();
    syncWidgetAgenda();
  }, [dbReady, version]);

  // Fila: roda ao abrir, ao voltar para o app e a cada 45 s (respeita o tempo de espera de cada tentativa).
  useEffect(() => {
    if (!dbReady) return;
    const run = () => processQueue().catch(() => {});
    importFromWidget();
    run();
    const sub = AppState.addEventListener('change', (st) => {
      if (st === 'active') {
        syncWidgetAgenda();
        importFromWidget();
        run();
      }
    });
    const timer = setInterval(run, 45000);
    const unsub = subscribeQueue(() => setVersion((v) => v + 1));
    return () => {
      sub.remove();
      clearInterval(timer);
      unsub();
    };
  }, [dbReady, importFromWidget]);

  const changeTab = (t: Tab) => setTab(t);

  // Só o Moodboard (coleções e dentro de cada coleção) pode ficar na horizontal; o resto fica em pé.
  const landscapeOk = tab === 'mood' || moodOpen !== null;
  useEffect(() => {
    const lock = landscapeOk
      ? ScreenOrientation.unlockAsync()
      : ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT_UP);
    lock.catch(() => {});
  }, [landscapeOk]);

  // Botão voltar do Android.
  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (settingsOpen || queueOpen || noteBlock !== null || moodOpen !== null) return false; // a tela aberta trata o voltar
      if (tab === 'lib' || tab === 'agenda' || tab === 'mood') {
        setTab('rec');
        return true;
      }
      return false;
    });
    return () => sub.remove();
  }, [tab, settingsOpen, queueOpen, noteBlock, moodOpen]);

  if (dbError) {
    return (
      <View style={styles.center}>
        <Text style={styles.err}>Erro ao abrir o banco de dados:{'\n'}{dbError}</Text>
      </View>
    );
  }
  if (!dbReady) return <View style={styles.root} />;

  return (
    <View style={styles.root}>
      <StatusBar style={tab === 'mood' ? 'dark' : 'light'} />
      <Background />
      <View style={[styles.flex, tab !== 'rec' && styles.hidden]}>
        <RecordingScreen
          onSaved={handleSaved}
          onOpenSettings={() => setSettingsOpen(true)}
          pendingCount={pendingCount}
          onOpenQueue={() => setQueueOpen(true)}
        />
      </View>
      {tab === 'lib' && (
        <View style={styles.flex}>
          <LibraryScreen
            version={version}
            onOpen={setNoteBlock}
            onChanged={bump}
          />
        </View>
      )}
      {tab === 'mood' && (
        <View style={StyleSheet.absoluteFill}>
          <MoodboardScreen version={version} onOpen={setMoodOpen} onChanged={bump} />
        </View>
      )}
      {tab === 'agenda' && (
        <View style={styles.flex}>
          <AgendaScreen version={version} onOpenNote={setNoteBlock} />
        </View>
      )}
      {/* No Moodboard o quadro com pontilhado ocupa a tela toda; a barra fica por cima, no rodapé. */}
      <View style={tab === 'mood' ? styles.barOverlay : undefined} pointerEvents="box-none">
        <TabBar active={tab} onChange={changeTab} />
      </View>
      {noteBlock !== null && <NoteScreen blockId={noteBlock} onClose={closeNote} />}
      {moodOpen !== null && <CollectionScreen collectionId={moodOpen} onClose={closeMood} />}
      {queueOpen && <QueueScreen onClose={closeQueue} />}
      {settingsOpen && <SettingsScreen onClose={closeSettings} />}
    </View>
  );
}

export default function App() {
  const [loaded, error] = useFonts({
    Inter_300Light,
    Inter_400Regular,
    Inter_400Regular_Italic,
    Inter_700Bold,
    Inter_700Bold_Italic,
    Inter_800ExtraBold,
  });

  useEffect(() => {
    if (error) appAlert('Erro ao carregar a fonte', String(error));
  }, [error]);

  return (
    <SafeAreaProvider>
      {loaded || error ? <Main /> : <View style={styles.root} />}
      <DialogHost />
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  flex: { flex: 1 },
  hidden: { display: 'none' },
  barOverlay: { position: 'absolute', left: 0, right: 0, bottom: 0 },
  center: { flex: 1, backgroundColor: colors.bg, alignItems: 'center', justifyContent: 'center', padding: 24 },
  err: { color: colors.red, fontSize: 16 },
});
