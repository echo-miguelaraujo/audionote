import React, { useCallback, useEffect, useState } from 'react';
import { Alert, BackHandler, StyleSheet, Text, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import {
  Inter_300Light,
  Inter_400Regular,
  Inter_700Bold,
  Inter_800ExtraBold,
  useFonts,
} from '@expo-google-fonts/inter';
import { getDb } from './src/db';
import { BlockScreen } from './src/BlockScreen';
import { LibraryScreen } from './src/LibraryScreen';
import { RecordingScreen } from './src/RecordingScreen';
import { Tab, TabBar } from './src/TabBar';
import { colors } from './src/theme';

function Main() {
  const [tab, setTab] = useState<Tab>('rec');
  const [selectMode, setSelectMode] = useState(false);
  const [openBlock, setOpenBlock] = useState<number | null>(null);
  const [pendingTarget, setPendingTarget] = useState<number | null>(null);
  const [version, setVersion] = useState(0);
  const [popupOpen, setPopupOpen] = useState(false);
  const [dbError, setDbError] = useState<string | null>(null);
  const [dbReady, setDbReady] = useState(false);

  useEffect(() => {
    getDb()
      .then(() => setDbReady(true))
      .catch((e) => setDbError(String(e)));
  }, []);

  const bump = useCallback(() => setVersion((v) => v + 1), []);
  const consumePending = useCallback(() => setPendingTarget(null), []);

  const changeTab = (t: Tab) => {
    setSelectMode(false);
    if (t === 'lib') setOpenBlock(null);
    setTab(t);
  };

  // Botão voltar do Android.
  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (tab === 'lib') {
        if (selectMode) {
          setSelectMode(false);
          setTab('rec');
        } else if (openBlock !== null) {
          setOpenBlock(null);
        } else {
          setTab('rec');
        }
        return true;
      }
      return false;
    });
    return () => sub.remove();
  }, [tab, selectMode, openBlock]);

  if (dbError) {
    return (
      <View style={styles.center}>
        <Text style={styles.err}>Erro ao abrir o banco de dados:{'\n'}{dbError}</Text>
      </View>
    );
  }
  if (!dbReady) return <View style={styles.root} />;

  return (
    <View style={styles.root}>
      <StatusBar style="light" />
      <View style={[styles.flex, tab !== 'rec' && styles.hidden]}>
        <RecordingScreen
          pendingTarget={pendingTarget}
          onConsumePending={consumePending}
          onChooseExisting={() => {
            setSelectMode(true);
            setOpenBlock(null);
            setTab('lib');
          }}
          onSaved={bump}
          onPopupChange={setPopupOpen}
        />
      </View>
      {tab === 'lib' && (
        <View style={styles.flex}>
          {openBlock === null || selectMode ? (
            <LibraryScreen
              selectMode={selectMode}
              version={version}
              onOpen={setOpenBlock}
              onSelect={(id) => {
                setSelectMode(false);
                setPendingTarget(id);
                setTab('rec');
              }}
              onChanged={bump}
            />
          ) : (
            <BlockScreen
              blockId={openBlock}
              version={version}
              onBack={() => setOpenBlock(null)}
              onChanged={bump}
            />
          )}
        </View>
      )}
      <TabBar active={tab} onChange={changeTab} dimmed={popupOpen && tab === 'rec'} />
    </View>
  );
}

export default function App() {
  const [loaded, error] = useFonts({
    Inter_300Light,
    Inter_400Regular,
    Inter_700Bold,
    Inter_800ExtraBold,
  });

  useEffect(() => {
    if (error) Alert.alert('Erro ao carregar a fonte', String(error));
  }, [error]);

  return (
    <SafeAreaProvider>
      {loaded || error ? <Main /> : <View style={styles.root} />}
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  flex: { flex: 1 },
  hidden: { display: 'none' },
  center: { flex: 1, backgroundColor: colors.bg, alignItems: 'center', justifyContent: 'center', padding: 24 },
  err: { color: colors.red, fontSize: 16 },
});
