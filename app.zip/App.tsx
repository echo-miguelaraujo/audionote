import React, { useCallback, useEffect, useState } from 'react';
import { Alert, AppState, BackHandler, StyleSheet, Text, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import {
  Inter_300Light,
  Inter_400Regular,
  Inter_400Regular_Italic,
  Inter_700Bold,
  Inter_700Bold_Italic,
  Inter_800ExtraBold,
  useFonts,
} from '@expo-google-fonts/inter';
import { countQueue, getDb } from './src/db';
import { processQueue, subscribeQueue } from './src/queue';
import { BlockScreen } from './src/BlockScreen';
import { LibraryScreen } from './src/LibraryScreen';
import { NoteScreen } from './src/NoteScreen';
import { QueueScreen } from './src/QueueScreen';
import { RecordingScreen } from './src/RecordingScreen';
import { SettingsScreen } from './src/SettingsScreen';
import { Tab, TabBar } from './src/TabBar';
import { colors } from './src/theme';

function Main() {
  const [tab, setTab] = useState<Tab>('rec');
  const [selectMode, setSelectMode] = useState(false);
  const [openBlock, setOpenBlock] = useState<number | null>(null);
  const [pendingTarget, setPendingTarget] = useState<number | null>(null);
  const [version, setVersion] = useState(0);
  const [popupOpen, setPopupOpen] = useState(false);
  const [dbError, setDbError] = useState<string | null>(null);
  const [dbReady, setDbReady] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const closeSettings = useCallback(() => setSettingsOpen(false), []);
  const [queueOpen, setQueueOpen] = useState(false);
  const closeQueue = useCallback(() => setQueueOpen(false), []);
  const [noteBlock, setNoteBlock] = useState<number | null>(null);
  const [pendingCount, setPendingCount] = useState(0);

  useEffect(() => {
    getDb()
      .then(() => setDbReady(true))
      .catch((e) => setDbError(String(e)));
  }, []);

  const bump = useCallback(() => setVersion((v) => v + 1), []);

  const closeNote = useCallback(() => {
    setNoteBlock(null);
    setVersion((v) => v + 1);
  }, []);

  // Quando algo é salvo, atualiza as telas e já tenta transcrever.
  const handleSaved = useCallback(() => {
    setVersion((v) => v + 1);
    processQueue().catch(() => {});
  }, []);

  // Contador de pendentes (aparece na tela de Gravação).
  useEffect(() => {
    if (!dbReady) return;
    countQueue().then(setPendingCount).catch(() => {});
  }, [dbReady, version]);

  // Fila: roda ao abrir, ao voltar para o app e a cada 45 s (respeita o tempo de espera de cada tentativa).
  useEffect(() => {
    if (!dbReady) return;
    const run = () => processQueue().catch(() => {});
    run();
    const sub = AppState.addEventListener('change', (st) => {
      if (st === 'active') run();
    });
    const timer = setInterval(run, 45000);
    const unsub = subscribeQueue(() => setVersion((v) => v + 1));
    return () => {
      sub.remove();
      clearInterval(timer);
      unsub();
    };
  }, [dbReady]);

  const consumePending = useCallback(() => setPendingTarget(null), []);

  const changeTab = (t: Tab) => {
    setSelectMode(false);
    if (t === 'lib') setOpenBlock(null);
    setTab(t);
  };

  // Botão voltar do Android.
  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (settingsOpen || queueOpen || noteBlock !== null) return false; // a tela aberta trata o voltar
      if (tab === 'lib') {
        if (selectMode) {
          setSelectMode(false);
          setTab('rec');
        } else if (openBlock !== null) {
          setOpenBlock(null);
        } else {
          setTab('rec');
        }
        return true;
      }
      return false;
    });
    return () => sub.remove();
  }, [tab, selectMode, openBlock, settingsOpen, queueOpen, noteBlock]);

  if (dbError) {
    return (
      <View style={styles.center}>
        <Text style={styles.err}>Erro ao abrir o banco de dados:{'\n'}{dbError}</Text>
      </View>
    );
  }
  if (!dbReady) return <View style={styles.root} />;

  return (
    <View style={styles.root}>
      <StatusBar style="light" />
      <View style={[styles.flex, tab !== 'rec' && styles.hidden]}>
        <RecordingScreen
          pendingTarget={pendingTarget}
          onConsumePending={consumePending}
          onChooseExisting={() => {
            setSelectMode(true);
            setOpenBlock(null);
            setTab('lib');
          }}
          onSaved={handleSaved}
          onPopupChange={setPopupOpen}
          onOpenSettings={() => setSettingsOpen(true)}
          pendingCount={pendingCount}
          onOpenQueue={() => setQueueOpen(true)}
        />
      </View>
      {tab === 'lib' && (
        <View style={styles.flex}>
          {openBlock === null || selectMode ? (
            <LibraryScreen
              selectMode={selectMode}
              version={version}
              onOpen={setOpenBlock}
              onSelect={(id) => {
                setSelectMode(false);
                setPendingTarget(id);
                setTab('rec');
              }}
              onChanged={bump}
            />
          ) : (
            <BlockScreen
              blockId={openBlock}
              version={version}
              onBack={() => setOpenBlock(null)}
              onChanged={bump}
              onOpenNote={setNoteBlock}
            />
          )}
        </View>
      )}
      <TabBar active={tab} onChange={changeTab} dimmed={popupOpen && tab === 'rec'} />
      {noteBlock !== null && <NoteScreen blockId={noteBlock} onClose={closeNote} />}
      {queueOpen && <QueueScreen onClose={closeQueue} />}
      {settingsOpen && <SettingsScreen onClose={closeSettings} />}
    </View>
  );
}

export default function App() {
  const [loaded, error] = useFonts({
    Inter_300Light,
    Inter_400Regular,
    Inter_400Regular_Italic,
    Inter_700Bold,
    Inter_700Bold_Italic,
    Inter_800ExtraBold,
  });

  useEffect(() => {
    if (error) Alert.alert('Erro ao carregar a fonte', String(error));
  }, [error]);

  return (
    <SafeAreaProvider>
      {loaded || error ? <Main /> : <View style={styles.root} />}
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  flex: { flex: 1 },
  hidden: { display: 'none' },
  center: { flex: 1, backgroundColor: colors.bg, alignItems: 'center', justifyContent: 'center', padding: 24 },
  err: { color: colors.red, fontSize: 16 },
});
