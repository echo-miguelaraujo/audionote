import * as ImagePicker from 'expo-image-picker';
import { appAlert } from './dialog';
import { GemResult, ImageRead, readImages } from './gemini';
import { saveMedia, storedRef } from './media';
import { Note, appendSections, emptyNote, escapeHtml } from './note';
import { loadGeminiSettings } from './settings';

export type PickedImage = { uri: string; fileName?: string | null; base64: string; mime: string };

const MAX_IMAGES = 6;

async function pickFrom(source: 'camera' | 'library'): Promise<PickedImage[] | null> {
  const opts: ImagePicker.ImagePickerOptions = {
    mediaTypes: ['images'],
    quality: 0.8,
    base64: true,
  };
  let r: ImagePicker.ImagePickerResult;
  if (source === 'camera') {
    const perm = await ImagePicker.requestCameraPermissionsAsync();
    if (!perm.granted) {
      appAlert('Sem acesso à câmera', 'Libere a câmera para o app nas configurações do celular.');
      return null;
    }
    r = await ImagePicker.launchCameraAsync(opts);
  } else {
    r = await ImagePicker.launchImageLibraryAsync({
      ...opts,
      allowsMultipleSelection: true,
      selectionLimit: MAX_IMAGES,
    });
  }
  if (r.canceled || r.assets.length === 0) return null;
  const out: PickedImage[] = [];
  for (const a of r.assets.slice(0, MAX_IMAGES)) {
    if (!a.base64) continue;
    out.push({ uri: a.uri, fileName: a.fileName, base64: a.base64, mime: a.mimeType || 'image/jpeg' });
  }
  return out.length > 0 ? out : null;
}

/** Pergunta de onde vem a imagem (câmera ou galeria) e devolve as escolhidas. */
export function askImages(title: string): Promise<PickedImage[] | null> {
  return new Promise((resolve) => {
    let settled = false;
    const done = (v: Promise<PickedImage[] | null> | null) => {
      if (settled) return;
      settled = true;
      if (!v) return resolve(null);
      v.then(resolve).catch((e) => {
        appAlert('Não consegui pegar a imagem', String(e));
        resolve(null);
      });
    };
    appAlert(title, 'Foto do caderno, print ou imagem da galeria (até 6 páginas).', [
      { text: 'Tirar foto', onPress: () => done(pickFrom('camera')) },
      { text: 'Escolher da galeria', onPress: () => done(pickFrom('library')) },
      { text: 'Cancelar', style: 'cancel', onPress: () => done(null) },
    ]);
  });
}

export type ImageResult =
  | { ok: true; read: ImageRead; html: string; media: string[] }
  | { ok: false; message: string };

/** Manda as imagens para o Gemini e devolve o texto lido. Guarda as imagens no app (para ficarem na nota). */
export async function readPickedImages(images: PickedImage[], headings: string[]): Promise<ImageResult> {
  const { apiKey, model } = await loadGeminiSettings();
  if (!apiKey.trim()) {
    return { ok: false, message: 'Coloque a chave do Gemini em Configurações para ler imagens.' };
  }
  const r: GemResult<ImageRead> = await readImages(
    apiKey,
    model,
    images.map((i) => ({ base64: i.base64, mime: i.mime })),
    headings
  );
  if (!r.ok) return { ok: false, message: r.error.message };
  if (r.data.sections.length === 0) {
    return { ok: false, message: 'Não encontrei texto legível nessa imagem. Tente uma foto mais de perto e com boa luz.' };
  }
  const media = images.map((i) => saveMedia(i.uri, i.fileName, 'jpg'));
  return { ok: true, read: r.data, html: '', media };
}

/** HTML das imagens originais (ficam no fim, para conferir o que a IA leu). */
export const imagesHtml = (media: string[]): string =>
  media.map((m) => `<p><img src="${escapeHtml(storedRef(m))}"></p>`).join('');

/** Nota nova a partir do texto lido (título sugerido + texto + imagem original no fim). */
export function noteFromImage(res: Extract<ImageResult, { ok: true }>): Note {
  const base: Note = { ...emptyNote(), title: res.read.title };
  const withText = appendSections(base, res.read.sections);
  return { ...withText, html: withText.html + imagesHtml(res.media) };
}
