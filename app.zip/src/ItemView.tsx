import { useBoardLook } from './boardTheme';
import { usePerf } from './perf';
import React, { memo, useEffect, useState } from 'react';
import { Icon } from './Icon';
import { Image, StyleSheet, Text, View } from 'react-native';
import { VideoView, useVideoPlayer } from 'expo-video';
import { Collage } from './Collage';
import { Block, LINK_CARD, MoodCollection, MoodItem, NOTE_CARD, SUBCOL_CARD, SWATCH_CARD, VIDEO_CARD } from './db';
import { readableOn } from './boardGeometry';
import { domainOf, parseLink } from './linkPreview';
import { mediaUri } from './media';
import { parseSwatch } from './palette';
import { RichText } from './RichText';
import { parseTextBox } from './textBox';
import { parseFicha } from './ficha';
import { formatDuration, parseVideo } from './videoData';
import { colors, fonts, TYPE, SPACE, swatchFallback } from './theme';

export type Live = { dx: number; dy: number; s: number; r: number };

/** Toca o vídeo dentro do próprio cartão, por cima da capa. Ao desmontar, o player é liberado e a capa volta. */
function InlineVideo({ src, w, h, onFail }: { src: string; w: number; h: number; onFail: () => void }) {
  const player = useVideoPlayer({ uri: mediaUri(src) }, (p) => {
    p.loop = true;
    p.play();
  });
  const [ready, setReady] = useState(false);
  useEffect(() => {
    const a = player.addListener('statusChange', ({ status }) => {
      if (status === 'error') onFail();
      if (status === 'readyToPlay') setReady(true);
    });
    return () => a.remove();
  }, [player, onFail]);
  return (
    <VideoView
      player={player}
      pointerEvents="none"
      style={{ position: 'absolute', left: 0, top: 0, width: w, height: h, opacity: ready ? 1 : 0 }}
      contentFit="cover"
      nativeControls={false}
      allowsFullscreen={false}
    />
  );
}

/** Item do quadro. Só desenha: todos os toques são tratados pelo quadro (que descobre qual item foi tocado pela conta, não pelo Android). */
export const ItemView = memo(function ItemView({
  item,
  sw,
  selected,
  live,
  col,
  note,
  onSize,
  onLoaded,
  captionMark,
  playing,
  onPlayFail,
  forceLight,
}: {
  item: MoodItem;
  sw: number;
  selected: boolean;
  live: Live | null;
  col?: MoodCollection;
  note?: Block;
  onSize: (id: number, w: number, h: number) => void;
  /** Avisa quando uma imagem do item terminou de carregar (ou falhou). Usado pela exportação. */
  onLoaded?: (id: number) => void;
  /** Mostra o 💬 no canto quando o item tem legenda (modo de edição). */
  captionMark?: boolean;
  /** Vídeo tocando dentro do cartão (some a capa e o botão de play). */
  playing?: boolean;
  onPlayFail?: (id: number) => void;
  /** Exportação: cartões sempre no tema claro, qualquer que seja a aparência do quadro. */
  forceLight?: boolean;
}) {
  const look = useBoardLook();
  const shadowsOn = usePerf().shadows;
  const dark = look.dark && !forceLight;
  const ink = dark ? colors.onDark : colors.onLight;
  const L = live ?? { dx: 0, dy: 0, s: 1, r: 0 };
  const transform = [
    { translateX: L.dx },
    { translateY: L.dy },
    { rotate: `${item.rot + L.r}deg` },
    { scale: L.s },
  ];

  let body: React.ReactNode;
  if (item.kind === 'image') {
    const img = (
      <Image
        source={{ uri: mediaUri(item.content) }}
        resizeMode="cover"
        onLoadEnd={() => onLoaded?.(item.id)}
        style={{ width: item.w * sw, height: item.h * sw }}
      />
    );
    // Com cor: moldura de ~0.015 u em volta da imagem.
    body = item.color ? <View style={{ backgroundColor: item.color, padding: sw * SPACE.xs }}>{img}</View> : img;
  } else if (item.kind === 'video') {
    // Capa do vídeo com o botão de tocar e a duração. O vídeo só toca na tela cheia (toque no cartão).
    const d = parseVideo(item.content);
    const k = item.w / VIDEO_CARD.w;
    const dur = formatDuration(d.dur);
    const circle = sw * 0.11 * k;
    const tri = circle * 0.36;
    const box = (
      <View style={{ width: item.w * sw, height: item.h * sw, backgroundColor: '#111', overflow: 'hidden' }}>
        {!!d.poster && (
          <Image
            source={{ uri: mediaUri(d.poster) }}
            resizeMode="cover"
            onLoadEnd={() => onLoaded?.(item.id)}
            style={StyleSheet.absoluteFill}
          />
        )}
        {playing && !!d.src && (
          <InlineVideo src={d.src} w={item.w * sw} h={item.h * sw} onFail={() => onPlayFail?.(item.id)} />
        )}
        {!playing && <View style={{ ...StyleSheet.absoluteFillObject, alignItems: 'center', justifyContent: 'center' }}>
          <View
            style={{
              width: circle,
              height: circle,
              borderRadius: circle / 2,
              backgroundColor: 'rgba(0,0,0,0.55)',
              borderWidth: 1.5,
              borderColor: 'rgba(255,255,255,0.85)',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <View
              style={{
                marginLeft: tri * 0.2,
                width: 0,
                height: 0,
                borderTopWidth: tri * 0.62,
                borderBottomWidth: tri * 0.62,
                borderLeftWidth: tri,
                borderTopColor: 'transparent',
                borderBottomColor: 'transparent',
                borderLeftColor: '#fff',
              }}
            />
          </View>
        </View>}
        {!playing && (!!dur || !d.src) && (
          <View
            style={{
              position: 'absolute',
              right: sw * 0.012 * k,
              bottom: sw * 0.012 * k,
              backgroundColor: 'rgba(0,0,0,0.7)',
              borderRadius: sw * 0.01 * k,
              paddingHorizontal: sw * 0.012 * k,
              paddingVertical: sw * 0.004 * k,
            }}
          >
            <Text style={{ color: '#fff', fontFamily: fonts.regular, fontSize: sw * 0.024 * k }}>{d.src ? dur : 'indisponível'}</Text>
          </View>
        )}
      </View>
    );
    body = item.color ? <View style={{ backgroundColor: item.color, padding: sw * SPACE.xs }}>{box}</View> : box;
  } else if (item.kind === 'collection') {
    // Mesmo desenho da aba Coleções (nome + colagem), na escala do cartão.
    const k = item.w / SUBCOL_CARD.w;
    const fs = sw * 0.058 * k;
    const cbg = item.color;
    body = (
      <View
        style={{
          width: item.w * sw,
          alignItems: 'center',
          backgroundColor: cbg ?? undefined,
          paddingVertical: cbg ? sw * 0.015 * k : 0,
          borderRadius: cbg ? sw * 0.02 * k : 0,
        }}
      >
        <Text
          numberOfLines={1}
          style={{
            fontFamily: fonts.regular,
            fontSize: fs,
            letterSpacing: -fs * 0.04,
            color: cbg ? readableOn(cbg) : ink,
            marginBottom: sw * 0.02 * k,
            maxWidth: '100%',
          }}
        >
          {col?.name ?? ''}
        </Text>
        <Collage covers={col?.covers ?? []} sw={sw * k} />
      </View>
    );
  } else if (item.kind === 'note') {
    // Cartão preto: título em negrito e o índice (títulos) da nota; sem títulos, o começo do texto.
    const k = item.w / NOTE_CARD.w;
    const title = note ? note.noteTitle || note.name : 'Nota';
    const tf = sw * 0.04 * k;
    const nbg = item.color ?? (dark ? look.card : colors.onLight);
    const nfg = readableOn(nbg);
    const sub = nfg === colors.onDark ? colors.mutedLight : colors.subtle;
    const outline = note?.outline ?? [];
    const lf = sw * 0.028 * k;
    body = (
      <View
        style={{
          width: item.w * sw,
          height: item.h * sw,
          backgroundColor: nbg,
          borderRadius: sw * 0.02 * k,
          padding: sw * 0.03 * k,
          overflow: 'hidden',
        }}
      >
        <Text
          numberOfLines={2}
          style={{ color: nfg, fontFamily: fonts.bold, fontWeight: '700', fontSize: tf, letterSpacing: -tf * 0.04 }}
        >
          {title}
        </Text>
        {outline.length > 0 ? (
          <View style={{ marginTop: sw * 0.012 * k }}>
            {outline.map((h, i) => (
              <Text
                key={`${i}${h}`}
                numberOfLines={1}
                style={{ color: sub, fontFamily: fonts.regular, fontSize: lf, lineHeight: lf * 1.45 }}
              >
                {`•  ${h}`}
              </Text>
            ))}
          </View>
        ) : (
          !!note?.preview && (
            <Text
              numberOfLines={3}
              style={{ color: sub, fontFamily: fonts.light, fontSize: sw * 0.03 * k, marginTop: sw * 0.01 * k }}
            >
              {note.preview}
            </Text>
          )
        )}
      </View>
    );
  } else if (item.kind === 'link') {
    const d = parseLink(item.content);
    const k = item.w / LINK_CARD.w;
    const bg = item.color ?? (dark ? look.card : colors.onDark);
    const fg = readableOn(bg);
    const sub = fg === colors.onLight ? colors.subtle : colors.line;
    const pad = sw * 0.018 * k;
    const loading = d.fetchedAt === null;
    const noPreview = d.fetchedAt === 0;
    body = (
      <View
        style={{
          width: item.w * sw,
          height: item.h * sw,
          backgroundColor: bg,
          borderRadius: sw * 0.02 * k,
          borderWidth: 1,
          borderColor: colors.line,
          overflow: 'hidden',
          elevation: shadowsOn ? 2 : 0,
        }}
      >
        {!!d.img && (
          <Image
            source={{ uri: mediaUri(d.img) }}
            resizeMode="cover"
            onLoadEnd={() => onLoaded?.(item.id)}
            style={{ width: item.w * sw, height: (item.w * sw) / d.ar }}
          />
        )}
        <View style={{ padding: pad }}>
          <Text
            numberOfLines={2}
            style={{ color: fg, fontFamily: fonts.bold, fontSize: sw * 0.03 * k, letterSpacing: -sw * 0.001 * k }}
          >
            {d.title || domainOf(d.url)}
          </Text>
          {(!!d.desc || loading || noPreview) && (
            <Text numberOfLines={2} style={{ color: sub, fontFamily: fonts.light, fontSize: sw * 0.024 * k, marginTop: pad * 0.3 }}>
              {d.desc || (loading ? 'carregando…' : d.url)}
            </Text>
          )}
          <Text numberOfLines={1} style={{ color: colors.red, fontFamily: fonts.regular, fontSize: sw * 0.022 * k, marginTop: pad * 0.4 }}>
            {d.site || domainOf(d.url)}
            {noPreview ? '  ·  sem prévia' : ''}
          </Text>
        </View>
      </View>
    );
  } else if (item.kind === 'swatch') {
    const sd = parseSwatch(item.content);
    const k = item.w / SWATCH_CARD.w;
    const bg = item.color ?? colors.onDark;
    const fg = readableOn(bg);
    const pad = sw * 0.02 * k;
    const cols = sd ? sd.colors : [...swatchFallback];
    const stripeW = (item.w * sw - pad * 2) / cols.length;
    const fs = Math.min(sw * 0.026 * k, stripeW / 4.4);
    body = (
      <View
        style={{
          width: item.w * sw,
          height: item.h * sw,
          backgroundColor: bg,
          borderRadius: sw * 0.02 * k,
          borderWidth: 1,
          borderColor: colors.line,
          padding: pad,
          overflow: 'hidden',
        }}
      >
        <View style={{ flex: 1, flexDirection: 'row', borderRadius: sw * 0.012 * k, overflow: 'hidden' }}>
          {cols.map((c, i) => (
            <View key={`${c}${i}`} style={{ flex: 1, backgroundColor: c }} />
          ))}
        </View>
        <View style={{ flexDirection: 'row', marginTop: pad * 0.5 }}>
          {sd ? (
            cols.map((c, i) => (
              <Text
                key={`${c}${i}`}
                numberOfLines={1}
                style={{ width: stripeW, textAlign: 'center', color: fg, fontFamily: fonts.regular, fontSize: fs }}
              >
                {c}
              </Text>
            ))
          ) : (
            <Text style={{ flex: 1, textAlign: 'center', color: colors.subtle, fontFamily: fonts.regular, fontSize: sw * 0.026 * k }}>
              paleta inválida
            </Text>
          )}
        </View>
      </View>
    );
  } else if (item.kind === 'text') {
    const rtColor = item.color && parseTextBox(item).on ? colors.onLight : ink;
    const rt = <RichText html={item.content} base={item.w * sw} width={(item.h || 0.6) * sw} color={rtColor} />;
    // Solto: só o texto. Em box: fundo (cor e/ou imagem) com respiro e cantos ajustáveis.
    const tb = parseTextBox(item);
    body = tb.on ? (
      <View style={{ backgroundColor: item.color ?? undefined, padding: sw * tb.pad, borderRadius: sw * tb.radius, overflow: 'hidden' }}>
        {tb.img ? (
          <Image source={{ uri: mediaUri(tb.img) }} resizeMode="cover" style={StyleSheet.absoluteFillObject} />
        ) : null}
        {rt}
      </View>
    ) : (
      rt
    );
  } else if (item.kind === 'ficha') {
    // Ficha solta: cartão com título e, embaixo, texto corrido ou campos preenchidos.
    const f = parseFicha(item.content);
    const wpx = item.w * sw;
    const pad = sw * SPACE.md;
    body = (
      <View
        style={{
          width: wpx,
          backgroundColor: item.color ?? (dark ? look.card : colors.paper),
          borderRadius: sw * 0.03,
          borderWidth: 1,
          borderColor: colors.line,
          padding: pad,
        }}
      >
        {!!f.title && (
          <Text style={{ color: item.color ? colors.onLight : ink, fontFamily: fonts.bold, fontSize: sw * TYPE.subtitle, marginBottom: pad * 0.5 }}>{f.title}</Text>
        )}
        {f.mode === 'text' ? (
          <RichText html={f.html || '<p></p>'} base={sw * TYPE.body} width={wpx - 2 * pad} color={item.color ? colors.onLight : ink} />
        ) : (
          f.fields.map((fl) => (
            <View key={fl.id} style={{ marginTop: pad * 0.5 }}>
              <Text style={{ color: colors.subtle, fontFamily: fonts.regular, fontSize: sw * TYPE.caption }}>{fl.label || 'Campo'}</Text>
              <Text style={{ color: fl.value ? (item.color ? colors.onLight : ink) : colors.subtle, fontFamily: fonts.bold, fontSize: sw * TYPE.body }}>
                {fl.value || '—'}
              </Text>
            </View>
          ))
        )}
      </View>
    );
  } else {
    // Tipo ainda sem desenho neste aparelho (ex.: paleta vinda de outro).
    body = <View style={{ width: item.w * sw, height: item.h * sw, backgroundColor: colors.hairline, borderRadius: sw * 0.02 }} />;
  }

  return (
    <View
      pointerEvents="none"
      onLayout={(e) => onSize(item.id, e.nativeEvent.layout.width, e.nativeEvent.layout.height)}
      style={{ position: 'absolute', left: item.x * sw, top: item.y * sw, transform }}
    >
      {body}
      {selected && (
        <View
          pointerEvents="none"
          style={{ ...StyleSheet.absoluteFillObject, borderWidth: 2, borderColor: colors.red }}
        />
      )}
      {captionMark && !!item.caption && (
        <View style={{ position: 'absolute', top: -sw * 0.03, right: -sw * 0.01 }}>
          <Icon name="chat" size={sw * TYPE.body * 1.3} color="#FFFFFF" />
        </View>
      )}
    </View>
  );
});

