import React, { memo } from 'react';
import { Image, StyleSheet, Text, View } from 'react-native';
import { Collage } from './Collage';
import { Block, LINK_CARD, MoodCollection, MoodItem, NOTE_CARD, SUBCOL_CARD, SWATCH_CARD } from './db';
import { readableOn } from './boardGeometry';
import { domainOf, parseLink } from './linkPreview';
import { mediaUri } from './media';
import { parseSwatch } from './palette';
import { RichText } from './RichText';
import { colors, fonts, TYPE, SPACE, swatchFallback } from './theme';

export type Live = { dx: number; dy: number; s: number; r: number };

/** Item do quadro. Só desenha: todos os toques são tratados pelo quadro (que descobre qual item foi tocado pela conta, não pelo Android). */
export const ItemView = memo(function ItemView({
  item,
  sw,
  selected,
  live,
  col,
  note,
  onSize,
  onLoaded,
  captionMark,
}: {
  item: MoodItem;
  sw: number;
  selected: boolean;
  live: Live | null;
  col?: MoodCollection;
  note?: Block;
  onSize: (id: number, w: number, h: number) => void;
  /** Avisa quando uma imagem do item terminou de carregar (ou falhou). Usado pela exportação. */
  onLoaded?: (id: number) => void;
  /** Mostra o 💬 no canto quando o item tem legenda (modo de edição). */
  captionMark?: boolean;
}) {
  const L = live ?? { dx: 0, dy: 0, s: 1, r: 0 };
  const transform = [
    { translateX: L.dx },
    { translateY: L.dy },
    { rotate: `${item.rot + L.r}deg` },
    { scale: L.s },
  ];

  let body: React.ReactNode;
  if (item.kind === 'image') {
    const img = (
      <Image
        source={{ uri: mediaUri(item.content) }}
        resizeMode="cover"
        onLoadEnd={() => onLoaded?.(item.id)}
        style={{ width: item.w * sw, height: item.h * sw }}
      />
    );
    // Com cor: moldura de ~0.015 u em volta da imagem.
    body = item.color ? <View style={{ backgroundColor: item.color, padding: sw * SPACE.xs }}>{img}</View> : img;
  } else if (item.kind === 'collection') {
    // Mesmo desenho da aba Coleções (nome + colagem), na escala do cartão.
    const k = item.w / SUBCOL_CARD.w;
    const fs = sw * 0.058 * k;
    const cbg = item.color;
    body = (
      <View
        style={{
          width: item.w * sw,
          alignItems: 'center',
          backgroundColor: cbg ?? undefined,
          paddingVertical: cbg ? sw * 0.015 * k : 0,
          borderRadius: cbg ? sw * 0.02 * k : 0,
        }}
      >
        <Text
          numberOfLines={1}
          style={{
            fontFamily: fonts.regular,
            fontSize: fs,
            letterSpacing: -fs * 0.04,
            color: cbg ? readableOn(cbg) : colors.onLight,
            marginBottom: sw * 0.02 * k,
            maxWidth: '100%',
          }}
        >
          {col?.name ?? ''}
        </Text>
        <Collage covers={col?.covers ?? []} sw={sw * k} />
      </View>
    );
  } else if (item.kind === 'note') {
    // Cartão preto: título em negrito e o índice (títulos) da nota; sem títulos, o começo do texto.
    const k = item.w / NOTE_CARD.w;
    const title = note ? note.noteTitle || note.name : 'Nota';
    const tf = sw * 0.04 * k;
    const nbg = item.color ?? colors.onLight;
    const nfg = readableOn(nbg);
    const sub = nfg === colors.onDark ? colors.mutedLight : colors.subtle;
    const outline = note?.outline ?? [];
    const lf = sw * 0.028 * k;
    body = (
      <View
        style={{
          width: item.w * sw,
          height: item.h * sw,
          backgroundColor: nbg,
          borderRadius: sw * 0.02 * k,
          padding: sw * 0.03 * k,
          overflow: 'hidden',
        }}
      >
        <Text
          numberOfLines={2}
          style={{ color: nfg, fontFamily: fonts.bold, fontWeight: '700', fontSize: tf, letterSpacing: -tf * 0.04 }}
        >
          {title}
        </Text>
        {outline.length > 0 ? (
          <View style={{ marginTop: sw * 0.012 * k }}>
            {outline.map((h, i) => (
              <Text
                key={`${i}${h}`}
                numberOfLines={1}
                style={{ color: sub, fontFamily: fonts.regular, fontSize: lf, lineHeight: lf * 1.45 }}
              >
                {`•  ${h}`}
              </Text>
            ))}
          </View>
        ) : (
          !!note?.preview && (
            <Text
              numberOfLines={3}
              style={{ color: sub, fontFamily: fonts.light, fontSize: sw * 0.03 * k, marginTop: sw * 0.01 * k }}
            >
              {note.preview}
            </Text>
          )
        )}
      </View>
    );
  } else if (item.kind === 'link') {
    const d = parseLink(item.content);
    const k = item.w / LINK_CARD.w;
    const bg = item.color ?? colors.onDark;
    const fg = readableOn(bg);
    const sub = fg === colors.onLight ? colors.subtle : colors.line;
    const pad = sw * 0.018 * k;
    const loading = d.fetchedAt === null;
    const noPreview = d.fetchedAt === 0;
    body = (
      <View
        style={{
          width: item.w * sw,
          height: item.h * sw,
          backgroundColor: bg,
          borderRadius: sw * 0.02 * k,
          borderWidth: 1,
          borderColor: colors.line,
          overflow: 'hidden',
          elevation: 2,
        }}
      >
        {!!d.img && (
          <Image
            source={{ uri: mediaUri(d.img) }}
            resizeMode="cover"
            onLoadEnd={() => onLoaded?.(item.id)}
            style={{ width: item.w * sw, height: (item.w * sw * 9) / 16 }}
          />
        )}
        <View style={{ padding: pad }}>
          <Text
            numberOfLines={2}
            style={{ color: fg, fontFamily: fonts.bold, fontSize: sw * 0.03 * k, letterSpacing: -sw * 0.001 * k }}
          >
            {d.title || domainOf(d.url)}
          </Text>
          {(!!d.desc || loading || noPreview) && (
            <Text numberOfLines={2} style={{ color: sub, fontFamily: fonts.light, fontSize: sw * 0.024 * k, marginTop: pad * 0.3 }}>
              {d.desc || (loading ? 'carregando…' : d.url)}
            </Text>
          )}
          <Text numberOfLines={1} style={{ color: colors.red, fontFamily: fonts.regular, fontSize: sw * 0.022 * k, marginTop: pad * 0.4 }}>
            {d.site || domainOf(d.url)}
            {noPreview ? '  ·  sem prévia' : ''}
          </Text>
        </View>
      </View>
    );
  } else if (item.kind === 'swatch') {
    const sd = parseSwatch(item.content);
    const k = item.w / SWATCH_CARD.w;
    const bg = item.color ?? colors.onDark;
    const fg = readableOn(bg);
    const pad = sw * 0.02 * k;
    const cols = sd ? sd.colors : [...swatchFallback];
    const stripeW = (item.w * sw - pad * 2) / cols.length;
    const fs = Math.min(sw * 0.026 * k, stripeW / 4.4);
    body = (
      <View
        style={{
          width: item.w * sw,
          height: item.h * sw,
          backgroundColor: bg,
          borderRadius: sw * 0.02 * k,
          borderWidth: 1,
          borderColor: colors.line,
          padding: pad,
          overflow: 'hidden',
        }}
      >
        <View style={{ flex: 1, flexDirection: 'row', borderRadius: sw * 0.012 * k, overflow: 'hidden' }}>
          {cols.map((c, i) => (
            <View key={`${c}${i}`} style={{ flex: 1, backgroundColor: c }} />
          ))}
        </View>
        <View style={{ flexDirection: 'row', marginTop: pad * 0.5 }}>
          {sd ? (
            cols.map((c, i) => (
              <Text
                key={`${c}${i}`}
                numberOfLines={1}
                style={{ width: stripeW, textAlign: 'center', color: fg, fontFamily: fonts.regular, fontSize: fs }}
              >
                {c}
              </Text>
            ))
          ) : (
            <Text style={{ flex: 1, textAlign: 'center', color: colors.subtle, fontFamily: fonts.regular, fontSize: sw * 0.026 * k }}>
              paleta inválida
            </Text>
          )}
        </View>
      </View>
    );
  } else if (item.kind === 'text') {
    const rt = <RichText html={item.content} base={item.w * sw} width={(item.h || 0.6) * sw} />;
    // Com cor: fundo atrás do bloco de texto, com um respiro.
    body = item.color ? (
      <View style={{ backgroundColor: item.color, padding: sw * SPACE.sm, borderRadius: sw * 0.01 }}>{rt}</View>
    ) : (
      rt
    );
  } else {
    // Tipo ainda sem desenho neste aparelho (ex.: paleta vinda de outro).
    body = <View style={{ width: item.w * sw, height: item.h * sw, backgroundColor: colors.hairline, borderRadius: sw * 0.02 }} />;
  }

  return (
    <View
      pointerEvents="none"
      onLayout={(e) => onSize(item.id, e.nativeEvent.layout.width, e.nativeEvent.layout.height)}
      style={{ position: 'absolute', left: item.x * sw, top: item.y * sw, transform }}
    >
      {body}
      {selected && (
        <View
          pointerEvents="none"
          style={{ ...StyleSheet.absoluteFillObject, borderWidth: 2, borderColor: colors.red }}
        />
      )}
      {captionMark && !!item.caption && (
        <Text style={{ position: 'absolute', top: -sw * 0.03, right: -sw * 0.01, fontSize: sw * TYPE.body }}>💬</Text>
      )}
    </View>
  );
});

