import React, { useEffect, useState } from 'react';
import { Modal, Pressable, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { ColorWheel } from './ColorWheel';
import { fonts } from './theme';

type Props = {
  visible: boolean;
  /** Cor atual do botão escolhido (#RRGGBB). */
  initial: string;
  onCancel: () => void;
  onPick: (hex: string) => void;
};

/** Janela com a roda de cores para escolher uma das cores do fundo. */
export function BgColorDialog({ visible, initial, onCancel, onPick }: Props) {
  const { width: sw, height: sh } = useWindowDimensions();
  const [color, setColor] = useState(initial);

  useEffect(() => {
    if (visible) setColor(initial);
  }, [visible, initial]);

  const sq = sw * 0.085;
  return (
    <Modal visible={visible} transparent animationType="fade" statusBarTranslucent onRequestClose={onCancel}>
      <Pressable style={[styles.overlay, { paddingTop: sh * 0.08 }]} onPress={onCancel}>
        <Pressable style={{ width: sw * 0.84, borderRadius: sw * 0.074, padding: sw * 0.06, backgroundColor: '#FFFFFF' }} onPress={() => {}}>
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
            <Text style={{ color: '#000', fontFamily: fonts.bold, fontSize: sw * 0.06, letterSpacing: -1 }}>Escolher cor</Text>
            <View style={{ width: sq, height: sq, borderRadius: sq * 0.38, backgroundColor: color }} />
          </View>
          <View style={{ marginTop: sw * 0.05 }}>
            <ColorWheel key={initial} initial={initial} size={sw * 0.6} onChange={setColor} />
          </View>
          <View style={styles.row}>
            <Pressable onPress={onCancel} hitSlop={12}>
              <Text style={{ color: '#808080', fontFamily: fonts.bold, fontSize: sw * 0.05 }}>Cancelar</Text>
            </Pressable>
            <Pressable onPress={() => onPick(color)} hitSlop={12}>
              <Text style={{ color: '#000', fontFamily: fonts.bold, fontSize: sw * 0.05 }}>Usar</Text>
            </Pressable>
          </View>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.78)', alignItems: 'center' },
  row: { flexDirection: 'row', justifyContent: 'flex-end', gap: 28, marginTop: 28 },
});
