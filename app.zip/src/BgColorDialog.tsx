import React, { useEffect, useState } from 'react';
import { View, useWindowDimensions } from 'react-native';
import { ColorWheel } from './ColorWheel';
import { ColorChip, DialogActions, DialogShell, DialogTitle } from './DialogBase';
import { SPACE } from './theme';

type Props = {
  visible: boolean;
  /** Cor atual do botão escolhido (#RRGGBB). */
  initial: string;
  onCancel: () => void;
  onPick: (hex: string) => void;
};

/** Janela com a roda de cores para escolher uma das cores do fundo. */
export function BgColorDialog({ visible, initial, onCancel, onPick }: Props) {
  const { width: sw } = useWindowDimensions();
  const [color, setColor] = useState(initial);

  useEffect(() => {
    if (visible) setColor(initial);
  }, [visible, initial]);

  return (
    <DialogShell visible={visible} onClose={onCancel}>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
        <DialogTitle>Escolher cor</DialogTitle>
        <ColorChip color={color} />
      </View>
      <View style={{ marginTop: sw * SPACE.lg }}>
        <ColorWheel key={initial} initial={initial} size={sw * 0.6} onChange={setColor} />
      </View>
      <DialogActions onCancel={onCancel} confirmLabel="Usar" onConfirm={() => onPick(color)} />
    </DialogShell>
  );
}
