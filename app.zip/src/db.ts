import * as SQLite from 'expo-sqlite';
import { removeAudioFile } from './storage';

export type Block = {
  id: number;
  name: string;
  createdAt: number;
  audioCount: number;
};

export type AudioItem = {
  id: number;
  blockId: number;
  name: string;
  fileName: string;
  durationMs: number;
  createdAt: number;
  position: number;
  /** Fase 2: 'saved' | 'pending' | 'transcribed' */
  status: string;
};

let dbPromise: Promise<SQLite.SQLiteDatabase> | null = null;

export function getDb(): Promise<SQLite.SQLiteDatabase> {
  if (!dbPromise) {
    dbPromise = (async () => {
      const db = await SQLite.openDatabaseAsync('ideias.db');
      await db.execAsync(`
        PRAGMA journal_mode = WAL;
        PRAGMA foreign_keys = ON;
        CREATE TABLE IF NOT EXISTS meta (
          key TEXT PRIMARY KEY NOT NULL,
          value TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS blocks (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          created_at INTEGER NOT NULL,
          audio_counter INTEGER NOT NULL DEFAULT 0,
          note_json TEXT
        );
        CREATE TABLE IF NOT EXISTS audios (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          block_id INTEGER NOT NULL REFERENCES blocks(id) ON DELETE CASCADE,
          name TEXT NOT NULL,
          file_name TEXT NOT NULL,
          duration_ms INTEGER NOT NULL DEFAULT 0,
          created_at INTEGER NOT NULL,
          position INTEGER NOT NULL DEFAULT 0,
          status TEXT NOT NULL DEFAULT 'saved',
          transcript_json TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_audios_block ON audios(block_id, position);
      `);
      return db;
    })();
  }
  return dbPromise;
}

export async function listBlocks(): Promise<Block[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<{
    id: number;
    name: string;
    created_at: number;
    audio_count: number;
  }>(
    `SELECT b.id, b.name, b.created_at,
            (SELECT COUNT(*) FROM audios a WHERE a.block_id = b.id) AS audio_count
     FROM blocks b
     ORDER BY b.created_at DESC, b.id DESC`
  );
  return rows.map((r) => ({
    id: r.id,
    name: r.name,
    createdAt: r.created_at,
    audioCount: r.audio_count,
  }));
}

export async function createBlock(): Promise<number> {
  const db = await getDb();
  let newId = 0;
  await db.withTransactionAsync(async () => {
    const row = await db.getFirstAsync<{ value: string }>(
      `SELECT value FROM meta WHERE key = 'block_counter'`
    );
    const next = (row ? parseInt(row.value, 10) : 0) + 1;
    await db.runAsync(
      `INSERT OR REPLACE INTO meta (key, value) VALUES ('block_counter', ?)`,
      String(next)
    );
    const res = await db.runAsync(
      `INSERT INTO blocks (name, created_at) VALUES (?, ?)`,
      `Áudio ${next}`,
      Date.now()
    );
    newId = res.lastInsertRowId;
  });
  return newId;
}

export async function renameBlock(id: number, name: string): Promise<void> {
  const db = await getDb();
  await db.runAsync(`UPDATE blocks SET name = ? WHERE id = ?`, name, id);
}

export async function getBlock(id: number): Promise<Block | null> {
  const all = await listBlocks();
  return all.find((b) => b.id === id) ?? null;
}

export async function deleteBlock(id: number): Promise<void> {
  const db = await getDb();
  const files = await db.getAllAsync<{ file_name: string }>(
    `SELECT file_name FROM audios WHERE block_id = ?`,
    id
  );
  await db.runAsync(`DELETE FROM audios WHERE block_id = ?`, id);
  await db.runAsync(`DELETE FROM blocks WHERE id = ?`, id);
  files.forEach((f) => removeAudioFile(f.file_name));
}

type AudioRow = {
  id: number;
  block_id: number;
  name: string;
  file_name: string;
  duration_ms: number;
  created_at: number;
  position: number;
  status: string;
};

const mapAudio = (r: AudioRow): AudioItem => ({
  id: r.id,
  blockId: r.block_id,
  name: r.name,
  fileName: r.file_name,
  durationMs: r.duration_ms,
  createdAt: r.created_at,
  position: r.position,
  status: r.status,
});

export async function listAudios(blockId: number): Promise<AudioItem[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<AudioRow>(
    `SELECT id, block_id, name, file_name, duration_ms, created_at, position, status
     FROM audios WHERE block_id = ? ORDER BY position ASC, id ASC`,
    blockId
  );
  return rows.map(mapAudio);
}

export async function addAudio(
  blockId: number,
  fileName: string,
  durationMs: number
): Promise<void> {
  const db = await getDb();
  await db.withTransactionAsync(async () => {
    await db.runAsync(
      `UPDATE blocks SET audio_counter = audio_counter + 1 WHERE id = ?`,
      blockId
    );
    const b = await db.getFirstAsync<{ audio_counter: number }>(
      `SELECT audio_counter FROM blocks WHERE id = ?`,
      blockId
    );
    const pos = await db.getFirstAsync<{ p: number | null }>(
      `SELECT MAX(position) AS p FROM audios WHERE block_id = ?`,
      blockId
    );
    await db.runAsync(
      `INSERT INTO audios (block_id, name, file_name, duration_ms, created_at, position, status)
       VALUES (?, ?, ?, ?, ?, ?, 'saved')`,
      blockId,
      `Gravação ${b?.audio_counter ?? 1}`,
      fileName,
      Math.round(durationMs),
      Date.now(),
      (pos?.p ?? -1) + 1
    );
  });
}

export async function renameAudio(id: number, name: string): Promise<void> {
  const db = await getDb();
  await db.runAsync(`UPDATE audios SET name = ? WHERE id = ?`, name, id);
}

export async function deleteAudio(id: number): Promise<void> {
  const db = await getDb();
  const row = await db.getFirstAsync<{ file_name: string }>(
    `SELECT file_name FROM audios WHERE id = ?`,
    id
  );
  await db.runAsync(`DELETE FROM audios WHERE id = ?`, id);
  if (row) removeAudioFile(row.file_name);
}

/** Move o áudio uma posição para cima (-1) ou para baixo (+1). */
export async function moveAudio(
  blockId: number,
  audioId: number,
  dir: -1 | 1
): Promise<void> {
  const db = await getDb();
  const items = await listAudios(blockId);
  const i = items.findIndex((a) => a.id === audioId);
  const j = i + dir;
  if (i < 0 || j < 0 || j >= items.length) return;
  const ids = items.map((a) => a.id);
  [ids[i], ids[j]] = [ids[j], ids[i]];
  await db.withTransactionAsync(async () => {
    for (let k = 0; k < ids.length; k++) {
      await db.runAsync(`UPDATE audios SET position = ? WHERE id = ?`, k, ids[k]);
    }
  });
}
