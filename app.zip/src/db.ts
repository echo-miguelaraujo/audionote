import * as SQLite from 'expo-sqlite';
import { parseNote, notePreview } from './note';
import { removeAudioFile } from './storage';

export type Block = {
  id: number;
  name: string;
  createdAt: number;
  audioCount: number;
  pendingCount: number;
  hasNote: boolean;
  /** Título da nota (o assunto) e começo do texto, para a Biblioteca. */
  noteTitle: string;
  preview: string;
};

export type AudioItem = {
  id: number;
  blockId: number;
  name: string;
  fileName: string;
  durationMs: number;
  createdAt: number;
  position: number;
  /** 'saved' (sem IA) | 'pending' | 'transcribed' | 'error' */
  status: string;
  lastError: string | null;
  nextRetryAt: number | null;
};

export type QueueItem = {
  id: number;
  blockId: number;
  blockName: string;
  audioName: string;
  status: string;
  lastError: string | null;
  nextRetryAt: number | null;
  createdAt: number;
};

let dbPromise: Promise<SQLite.SQLiteDatabase> | null = null;

export function getDb(): Promise<SQLite.SQLiteDatabase> {
  if (!dbPromise) {
    dbPromise = (async () => {
      const db = await SQLite.openDatabaseAsync('ideias.db');
      await db.execAsync(`
        PRAGMA journal_mode = WAL;
        PRAGMA foreign_keys = ON;
        CREATE TABLE IF NOT EXISTS meta (
          key TEXT PRIMARY KEY NOT NULL,
          value TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS blocks (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          created_at INTEGER NOT NULL,
          audio_counter INTEGER NOT NULL DEFAULT 0,
          note_json TEXT
        );
        CREATE TABLE IF NOT EXISTS audios (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          block_id INTEGER NOT NULL REFERENCES blocks(id) ON DELETE CASCADE,
          name TEXT NOT NULL,
          file_name TEXT NOT NULL,
          duration_ms INTEGER NOT NULL DEFAULT 0,
          created_at INTEGER NOT NULL,
          position INTEGER NOT NULL DEFAULT 0,
          status TEXT NOT NULL DEFAULT 'saved',
          transcript_json TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_audios_block ON audios(block_id, position);
      `);
      const cols = await db.getAllAsync<{ name: string }>(`PRAGMA table_info(audios)`);
      const names = new Set(cols.map((c) => c.name));
      if (!names.has('last_error')) await db.execAsync(`ALTER TABLE audios ADD COLUMN last_error TEXT`);
      if (!names.has('next_retry_at'))
        await db.execAsync(`ALTER TABLE audios ADD COLUMN next_retry_at INTEGER`);
      return db;
    })();
  }
  return dbPromise;
}

export async function listBlocks(): Promise<Block[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<{
    id: number;
    name: string;
    created_at: number;
    audio_count: number;
    pending_count: number;
    has_note: number;
    note_json: string | null;
  }>(
    `SELECT b.id, b.name, b.created_at,
            (SELECT COUNT(*) FROM audios a WHERE a.block_id = b.id) AS audio_count,
            (SELECT COUNT(*) FROM audios a WHERE a.block_id = b.id
               AND a.status IN ('pending','error')) AS pending_count,
            (b.note_json IS NOT NULL) AS has_note,
            b.note_json
     FROM blocks b
     ORDER BY b.created_at DESC, b.id DESC`
  );
  return rows.map((r) => {
    const note = parseNote(r.note_json);
    const noteTitle = (note?.title ?? '').trim() || (note?.topics.find((t) => t.title.trim())?.title ?? '').trim();
    return {
      id: r.id,
      name: r.name,
      createdAt: r.created_at,
      audioCount: r.audio_count,
      pendingCount: r.pending_count,
      hasNote: !!r.has_note,
      noteTitle,
      preview: notePreview(note),
    };
  });
}

export async function createBlock(): Promise<number> {
  const db = await getDb();
  let newId = 0;
  await db.withTransactionAsync(async () => {
    const row = await db.getFirstAsync<{ value: string }>(
      `SELECT value FROM meta WHERE key = 'block_counter'`
    );
    const next = (row ? parseInt(row.value, 10) : 0) + 1;
    await db.runAsync(
      `INSERT OR REPLACE INTO meta (key, value) VALUES ('block_counter', ?)`,
      String(next)
    );
    const res = await db.runAsync(
      `INSERT INTO blocks (name, created_at) VALUES (?, ?)`,
      `Nota ${next}`,
      Date.now()
    );
    newId = res.lastInsertRowId;
  });
  return newId;
}

export async function renameBlock(id: number, name: string): Promise<void> {
  const db = await getDb();
  await db.runAsync(`UPDATE blocks SET name = ? WHERE id = ?`, name, id);
}

export async function getBlock(id: number): Promise<Block | null> {
  const all = await listBlocks();
  return all.find((b) => b.id === id) ?? null;
}

export async function deleteBlock(id: number): Promise<void> {
  const db = await getDb();
  const files = await db.getAllAsync<{ file_name: string }>(
    `SELECT file_name FROM audios WHERE block_id = ?`,
    id
  );
  await db.runAsync(`DELETE FROM audios WHERE block_id = ?`, id);
  await db.runAsync(`DELETE FROM blocks WHERE id = ?`, id);
  files.forEach((f) => removeAudioFile(f.file_name));
}

type AudioRow = {
  id: number;
  block_id: number;
  name: string;
  file_name: string;
  duration_ms: number;
  created_at: number;
  position: number;
  status: string;
  last_error: string | null;
  next_retry_at: number | null;
};

const mapAudio = (r: AudioRow): AudioItem => ({
  id: r.id,
  blockId: r.block_id,
  name: r.name,
  fileName: r.file_name,
  durationMs: r.duration_ms,
  createdAt: r.created_at,
  position: r.position,
  status: r.status,
  lastError: r.last_error,
  nextRetryAt: r.next_retry_at,
});

export async function listAudios(blockId: number): Promise<AudioItem[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<AudioRow>(
    `SELECT id, block_id, name, file_name, duration_ms, created_at, position, status,
            last_error, next_retry_at
     FROM audios WHERE block_id = ? ORDER BY position ASC, id ASC`,
    blockId
  );
  return rows.map(mapAudio);
}

export async function addAudio(
  blockId: number,
  fileName: string,
  durationMs: number
): Promise<void> {
  const db = await getDb();
  await db.withTransactionAsync(async () => {
    await db.runAsync(
      `UPDATE blocks SET audio_counter = audio_counter + 1 WHERE id = ?`,
      blockId
    );
    const b = await db.getFirstAsync<{ audio_counter: number }>(
      `SELECT audio_counter FROM blocks WHERE id = ?`,
      blockId
    );
    const pos = await db.getFirstAsync<{ p: number | null }>(
      `SELECT MAX(position) AS p FROM audios WHERE block_id = ?`,
      blockId
    );
    await db.runAsync(
      `INSERT INTO audios (block_id, name, file_name, duration_ms, created_at, position, status)
       VALUES (?, ?, ?, ?, ?, ?, 'pending')`,
      blockId,
      `Gravação ${b?.audio_counter ?? 1}`,
      fileName,
      Math.round(durationMs),
      Date.now(),
      (pos?.p ?? -1) + 1
    );
  });
}

export async function deleteAudio(id: number): Promise<void> {
  const db = await getDb();
  const row = await db.getFirstAsync<{ file_name: string }>(
    `SELECT file_name FROM audios WHERE id = ?`,
    id
  );
  await db.runAsync(`DELETE FROM audios WHERE id = ?`, id);
  if (row) removeAudioFile(row.file_name);
}


// ---------- Fase 2: notas, transcrições e fila ----------

export async function getNoteJson(blockId: number): Promise<string | null> {
  const db = await getDb();
  const row = await db.getFirstAsync<{ note_json: string | null }>(
    `SELECT note_json FROM blocks WHERE id = ?`,
    blockId
  );
  return row?.note_json ?? null;
}

export async function saveNoteJson(blockId: number, json: string): Promise<void> {
  const db = await getDb();
  await db.runAsync(`UPDATE blocks SET note_json = ? WHERE id = ?`, json, blockId);
}

export async function getTranscriptText(audioId: number): Promise<string | null> {
  const db = await getDb();
  const row = await db.getFirstAsync<{ transcript_json: string | null }>(
    `SELECT transcript_json FROM audios WHERE id = ?`,
    audioId
  );
  if (!row?.transcript_json) return null;
  try {
    const t = JSON.parse(row.transcript_json)?.text;
    return typeof t === 'string' ? t : null;
  } catch {
    return null;
  }
}

export async function setTranscriptText(audioId: number, text: string): Promise<void> {
  const db = await getDb();
  await db.runAsync(
    `UPDATE audios SET transcript_json = ? WHERE id = ?`,
    JSON.stringify({ text }),
    audioId
  );
}

export async function setAudioState(
  audioId: number,
  status: string,
  lastError: string | null,
  nextRetryAt: number | null
): Promise<void> {
  const db = await getDb();
  await db.runAsync(
    `UPDATE audios SET status = ?, last_error = ?, next_retry_at = ? WHERE id = ?`,
    status,
    lastError,
    nextRetryAt,
    audioId
  );
}

/** Coloca o áudio de volta na fila (ex.: áudios da Fase 1 ou com erro). */
export async function requeueAudio(audioId: number): Promise<void> {
  await setAudioState(audioId, 'pending', null, null);
}

export async function listPendingAudios(): Promise<AudioItem[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<AudioRow>(
    `SELECT id, block_id, name, file_name, duration_ms, created_at, position, status,
            last_error, next_retry_at
     FROM audios WHERE status = 'pending' ORDER BY created_at ASC, id ASC`
  );
  return rows.map(mapAudio);
}

export async function listQueue(): Promise<QueueItem[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<{
    id: number;
    block_id: number;
    block_name: string;
    audio_name: string;
    status: string;
    last_error: string | null;
    next_retry_at: number | null;
    created_at: number;
  }>(
    `SELECT a.id, a.block_id, b.name AS block_name, a.name AS audio_name, a.status,
            a.last_error, a.next_retry_at, a.created_at
     FROM audios a JOIN blocks b ON b.id = a.block_id
     WHERE a.status IN ('pending','error')
     ORDER BY a.created_at ASC, a.id ASC`
  );
  return rows.map((r) => ({
    id: r.id,
    blockId: r.block_id,
    blockName: r.block_name,
    audioName: r.audio_name,
    status: r.status,
    lastError: r.last_error,
    nextRetryAt: r.next_retry_at,
    createdAt: r.created_at,
  }));
}

export async function countQueue(): Promise<number> {
  const db = await getDb();
  const row = await db.getFirstAsync<{ n: number }>(
    `SELECT COUNT(*) AS n FROM audios WHERE status IN ('pending','error')`
  );
  return row?.n ?? 0;
}

/** Aplica o resultado na nota e marca o áudio como transcrito, tudo numa transação só. */
export async function commitTranscribed(
  audioId: number,
  blockId: number,
  noteJson: string,
  clearFile: boolean
): Promise<void> {
  const db = await getDb();
  await db.withTransactionAsync(async () => {
    await db.runAsync(`UPDATE blocks SET note_json = ? WHERE id = ?`, noteJson, blockId);
    await db.runAsync(
      `UPDATE audios SET status = 'transcribed', last_error = NULL, next_retry_at = NULL${
        clearFile ? ", file_name = ''" : ''
      } WHERE id = ?`,
      audioId
    );
  });
}
