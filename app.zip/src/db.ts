import * as SQLite from 'expo-sqlite';
import { parseNote, notePreview, noteDisplayTitle, noteText, noteIsEmpty } from './note';
import { removeAudioFile } from './storage';

export type Block = {
  id: number;
  name: string;
  createdAt: number;
  audioCount: number;
  pendingCount: number;
  hasNote: boolean;
  favorite: boolean;
  categoryId: number | null;
  /** Título da nota (o assunto) e começo do texto, para a Biblioteca. */
  noteTitle: string;
  preview: string;
  /** Texto completo da nota (sem formatação), usado na busca. */
  body: string;
};

export type Category = {
  id: number;
  name: string;
  color: string;
  createdAt: number;
};

export type AudioItem = {
  id: number;
  blockId: number;
  name: string;
  fileName: string;
  durationMs: number;
  createdAt: number;
  position: number;
  /** 'saved' (sem IA) | 'pending' | 'transcribed' | 'error' */
  status: string;
  lastError: string | null;
  nextRetryAt: number | null;
};

export type QueueItem = {
  id: number;
  blockId: number;
  blockName: string;
  audioName: string;
  status: string;
  lastError: string | null;
  nextRetryAt: number | null;
  createdAt: number;
};

let dbPromise: Promise<SQLite.SQLiteDatabase> | null = null;

export function getDb(): Promise<SQLite.SQLiteDatabase> {
  if (!dbPromise) {
    dbPromise = (async () => {
      const db = await SQLite.openDatabaseAsync('ideias.db');
      await db.execAsync(`
        PRAGMA journal_mode = WAL;
        PRAGMA foreign_keys = ON;
        CREATE TABLE IF NOT EXISTS meta (
          key TEXT PRIMARY KEY NOT NULL,
          value TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS blocks (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          created_at INTEGER NOT NULL,
          audio_counter INTEGER NOT NULL DEFAULT 0,
          note_json TEXT
        );
        CREATE TABLE IF NOT EXISTS audios (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          block_id INTEGER NOT NULL REFERENCES blocks(id) ON DELETE CASCADE,
          name TEXT NOT NULL,
          file_name TEXT NOT NULL,
          duration_ms INTEGER NOT NULL DEFAULT 0,
          created_at INTEGER NOT NULL,
          position INTEGER NOT NULL DEFAULT 0,
          status TEXT NOT NULL DEFAULT 'saved',
          transcript_json TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_audios_block ON audios(block_id, position);
      `);
      const cols = await db.getAllAsync<{ name: string }>(`PRAGMA table_info(audios)`);
      const names = new Set(cols.map((c) => c.name));
      const bcols = await db.getAllAsync<{ name: string }>(`PRAGMA table_info(blocks)`);
      if (!bcols.some((c) => c.name === 'favorite'))
        await db.execAsync(`ALTER TABLE blocks ADD COLUMN favorite INTEGER NOT NULL DEFAULT 0`);
      if (!bcols.some((c) => c.name === 'category_id'))
        await db.execAsync(`ALTER TABLE blocks ADD COLUMN category_id INTEGER`);
      await db.execAsync(`
        CREATE TABLE IF NOT EXISTS categories (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          color TEXT NOT NULL,
          created_at INTEGER NOT NULL
        );
      `);
      await db.execAsync(`
        CREATE TABLE IF NOT EXISTS calendar_events (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          audio_id INTEGER NOT NULL,
          block_id INTEGER NOT NULL,
          title TEXT NOT NULL,
          start_at INTEGER NOT NULL,
          all_day INTEGER NOT NULL DEFAULT 0,
          calendar_event_id TEXT,
          created_at INTEGER NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_calev_audio ON calendar_events(audio_id);
      `);
      await db.execAsync(`
        CREATE TABLE IF NOT EXISTS agenda_items (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          title TEXT NOT NULL,
          start_at INTEGER NOT NULL,
          all_day INTEGER NOT NULL DEFAULT 1,
          category_id INTEGER,
          notes TEXT,
          created_at INTEGER NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_agenda_start ON agenda_items(start_at);
      `);
      if (!names.has('last_error')) await db.execAsync(`ALTER TABLE audios ADD COLUMN last_error TEXT`);
      if (!names.has('next_retry_at'))
        await db.execAsync(`ALTER TABLE audios ADD COLUMN next_retry_at INTEGER`);
      return db;
    })();
  }
  return dbPromise;
}

export async function listBlocks(): Promise<Block[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<{
    id: number;
    name: string;
    created_at: number;
    audio_count: number;
    pending_count: number;
    has_note: number;
    favorite: number;
    category_id: number | null;
    note_json: string | null;
  }>(
    `SELECT b.id, b.name, b.created_at,
            (SELECT COUNT(*) FROM audios a WHERE a.block_id = b.id) AS audio_count,
            (SELECT COUNT(*) FROM audios a WHERE a.block_id = b.id
               AND a.status IN ('pending','error')) AS pending_count,
            (b.note_json IS NOT NULL) AS has_note,
            b.favorite,
            b.category_id,
            b.note_json
     FROM blocks b
     ORDER BY b.favorite DESC, b.created_at DESC, b.id DESC`
  );
  return rows.map((r) => {
    const note = parseNote(r.note_json);
    const noteTitle = noteDisplayTitle(note);
    return {
      id: r.id,
      name: r.name,
      createdAt: r.created_at,
      audioCount: r.audio_count,
      pendingCount: r.pending_count,
      hasNote: !!r.has_note,
      favorite: !!r.favorite,
      categoryId: r.category_id ?? null,
      noteTitle,
      preview: notePreview(note),
      body: noteText(note),
    };
  });
}

export async function createBlock(): Promise<number> {
  const db = await getDb();
  let newId = 0;
  await db.withTransactionAsync(async () => {
    const row = await db.getFirstAsync<{ value: string }>(
      `SELECT value FROM meta WHERE key = 'block_counter'`
    );
    const next = (row ? parseInt(row.value, 10) : 0) + 1;
    await db.runAsync(
      `INSERT OR REPLACE INTO meta (key, value) VALUES ('block_counter', ?)`,
      String(next)
    );
    const res = await db.runAsync(
      `INSERT INTO blocks (name, created_at) VALUES (?, ?)`,
      `Nota ${next}`,
      Date.now()
    );
    newId = res.lastInsertRowId;
  });
  return newId;
}

export async function renameBlock(id: number, name: string): Promise<void> {
  const db = await getDb();
  await db.runAsync(`UPDATE blocks SET name = ? WHERE id = ?`, name, id);
}

export async function getBlock(id: number): Promise<Block | null> {
  const all = await listBlocks();
  return all.find((b) => b.id === id) ?? null;
}

export async function deleteBlock(id: number): Promise<void> {
  const db = await getDb();
  const files = await db.getAllAsync<{ file_name: string }>(
    `SELECT file_name FROM audios WHERE block_id = ?`,
    id
  );
  await db.withTransactionAsync(async () => {
    await db.runAsync(`DELETE FROM audios WHERE block_id = ?`, id);
    await db.runAsync(`DELETE FROM blocks WHERE id = ?`, id);
  });
  // Só mexe nos arquivos depois que o banco já foi limpo.
  files.forEach((f) => removeAudioFile(f.file_name));
}

type AudioRow = {
  id: number;
  block_id: number;
  name: string;
  file_name: string;
  duration_ms: number;
  created_at: number;
  position: number;
  status: string;
  last_error: string | null;
  next_retry_at: number | null;
};

const mapAudio = (r: AudioRow): AudioItem => ({
  id: r.id,
  blockId: r.block_id,
  name: r.name,
  fileName: r.file_name,
  durationMs: r.duration_ms,
  createdAt: r.created_at,
  position: r.position,
  status: r.status,
  lastError: r.last_error,
  nextRetryAt: r.next_retry_at,
});

export async function listAudios(blockId: number): Promise<AudioItem[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<AudioRow>(
    `SELECT id, block_id, name, file_name, duration_ms, created_at, position, status,
            last_error, next_retry_at
     FROM audios WHERE block_id = ? ORDER BY position ASC, id ASC`,
    blockId
  );
  return rows.map(mapAudio);
}

export async function addAudio(
  blockId: number,
  fileName: string,
  durationMs: number
): Promise<void> {
  const db = await getDb();
  await db.withTransactionAsync(async () => {
    await db.runAsync(
      `UPDATE blocks SET audio_counter = audio_counter + 1 WHERE id = ?`,
      blockId
    );
    const b = await db.getFirstAsync<{ audio_counter: number }>(
      `SELECT audio_counter FROM blocks WHERE id = ?`,
      blockId
    );
    const pos = await db.getFirstAsync<{ p: number | null }>(
      `SELECT MAX(position) AS p FROM audios WHERE block_id = ?`,
      blockId
    );
    await db.runAsync(
      `INSERT INTO audios (block_id, name, file_name, duration_ms, created_at, position, status)
       VALUES (?, ?, ?, ?, ?, ?, 'pending')`,
      blockId,
      `Gravação ${b?.audio_counter ?? 1}`,
      fileName,
      Math.round(durationMs),
      Date.now(),
      (pos?.p ?? -1) + 1
    );
  });
}

/** Gravações que já foram marcadas com erro por não ter nenhuma fala (de versões antigas do app). */
export async function listNoSpeechAudios(): Promise<{ id: number; blockId: number }[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<any>(
    `SELECT id, block_id FROM audios WHERE status = 'error' AND last_error LIKE 'Nenhuma fala%'`
  );
  return rows.map((r) => ({ id: r.id, blockId: r.block_id }));
}

export async function deleteAudio(id: number): Promise<void> {
  const db = await getDb();
  const row = await db.getFirstAsync<{ file_name: string }>(
    `SELECT file_name FROM audios WHERE id = ?`,
    id
  );
  await db.runAsync(`DELETE FROM audios WHERE id = ?`, id);
  if (row) removeAudioFile(row.file_name);
}

/**
 * Tira uma gravação da fila (apaga o áudio). Se a nota ficou sem nenhum áudio e sem
 * conteúdo nenhum, a nota vazia também é apagada, para não sobrar um item "Nota vazia".
 */
export async function deleteQueueItem(audioId: number): Promise<void> {
  const db = await getDb();
  const row = await db.getFirstAsync<{ block_id: number }>(
    `SELECT block_id FROM audios WHERE id = ?`,
    audioId
  );
  await deleteAudio(audioId);
  if (!row) return;
  const left = await db.getFirstAsync<{ n: number }>(
    `SELECT COUNT(*) AS n FROM audios WHERE block_id = ?`,
    row.block_id
  );
  if ((left?.n ?? 0) > 0) return;
  const blk = await db.getFirstAsync<{ note_json: string | null }>(
    `SELECT note_json FROM blocks WHERE id = ?`,
    row.block_id
  );
  if (blk && noteIsEmpty(parseNote(blk.note_json))) await deleteBlock(row.block_id);
}


// ---------- Fase 2: notas, transcrições e fila ----------

export async function getNoteJson(blockId: number): Promise<string | null> {
  const db = await getDb();
  const row = await db.getFirstAsync<{ note_json: string | null }>(
    `SELECT note_json FROM blocks WHERE id = ?`,
    blockId
  );
  return row?.note_json ?? null;
}

export async function saveNoteJson(blockId: number, json: string): Promise<void> {
  const db = await getDb();
  await db.runAsync(`UPDATE blocks SET note_json = ? WHERE id = ?`, json, blockId);
}

export type DetectedEvent = { title: string; start: string; allDay: boolean; excerpt?: string };
export type StoredTranscript = {
  text: string;
  sections?: { heading: string; text: string }[];
  events: DetectedEvent[];
  title?: string;
};

export async function getTranscript(audioId: number): Promise<StoredTranscript | null> {
  const db = await getDb();
  const row = await db.getFirstAsync<{ transcript_json: string | null }>(
    `SELECT transcript_json FROM audios WHERE id = ?`,
    audioId
  );
  if (!row?.transcript_json) return null;
  try {
    const j = JSON.parse(row.transcript_json);
    if (typeof j?.text !== 'string') return null;
    return { text: j.text, events: Array.isArray(j.events) ? j.events : [], title: typeof j.title === 'string' ? j.title : undefined,
      sections: Array.isArray(j.sections) ? j.sections : undefined };
  } catch {
    return null;
  }
}

export async function setTranscript(audioId: number, t: StoredTranscript): Promise<void> {
  const db = await getDb();
  await db.runAsync(`UPDATE audios SET transcript_json = ? WHERE id = ?`, JSON.stringify(t), audioId);
}

export async function setAudioState(
  audioId: number,
  status: string,
  lastError: string | null,
  nextRetryAt: number | null
): Promise<void> {
  const db = await getDb();
  await db.runAsync(
    `UPDATE audios SET status = ?, last_error = ?, next_retry_at = ? WHERE id = ?`,
    status,
    lastError,
    nextRetryAt,
    audioId
  );
}

/** Coloca o áudio de volta na fila (ex.: áudios da Fase 1 ou com erro). */
export async function requeueAudio(audioId: number): Promise<void> {
  await setAudioState(audioId, 'pending', null, null);
}

export async function listPendingAudios(): Promise<AudioItem[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<AudioRow>(
    `SELECT id, block_id, name, file_name, duration_ms, created_at, position, status,
            last_error, next_retry_at
     FROM audios WHERE status = 'pending' ORDER BY created_at ASC, id ASC`
  );
  return rows.map(mapAudio);
}

export async function listQueue(): Promise<QueueItem[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<{
    id: number;
    block_id: number;
    block_name: string;
    audio_name: string;
    status: string;
    last_error: string | null;
    next_retry_at: number | null;
    created_at: number;
  }>(
    `SELECT a.id, a.block_id, b.name AS block_name, a.name AS audio_name, a.status,
            a.last_error, a.next_retry_at, a.created_at
     FROM audios a JOIN blocks b ON b.id = a.block_id
     WHERE a.status IN ('pending','error')
     ORDER BY a.created_at ASC, a.id ASC`
  );
  return rows.map((r) => ({
    id: r.id,
    blockId: r.block_id,
    blockName: r.block_name,
    audioName: r.audio_name,
    status: r.status,
    lastError: r.last_error,
    nextRetryAt: r.next_retry_at,
    createdAt: r.created_at,
  }));
}

export async function countQueue(): Promise<number> {
  const db = await getDb();
  const row = await db.getFirstAsync<{ n: number }>(
    `SELECT COUNT(*) AS n FROM audios WHERE status IN ('pending','error')`
  );
  return row?.n ?? 0;
}

/** Aplica o resultado na nota e marca o áudio como transcrito, tudo numa transação só. */
export async function commitTranscribed(
  audioId: number,
  blockId: number,
  noteJson: string,
  clearFile: boolean
): Promise<boolean> {
  const db = await getDb();
  let applied = false;
  await db.withTransactionAsync(async () => {
    // Se a gravação foi apagada da fila enquanto era transcrita, não escreve nada na nota.
    const exists = await db.getFirstAsync<{ id: number }>(`SELECT id FROM audios WHERE id = ?`, audioId);
    if (!exists) return;
    await db.runAsync(`UPDATE blocks SET note_json = ? WHERE id = ?`, noteJson, blockId);
    await db.runAsync(
      `UPDATE audios SET status = 'transcribed', last_error = NULL, next_retry_at = NULL${
        clearFile ? ", file_name = ''" : ''
      } WHERE id = ?`,
      audioId
    );
    applied = true;
  });
  return applied;
}

// ---------- Favoritas ----------

export async function setFavorite(blockId: number, fav: boolean): Promise<void> {
  const db = await getDb();
  await db.runAsync(`UPDATE blocks SET favorite = ? WHERE id = ?`, fav ? 1 : 0, blockId);
}

export async function isFavorite(blockId: number): Promise<boolean> {
  const db = await getDb();
  const row = await db.getFirstAsync<{ favorite: number }>(`SELECT favorite FROM blocks WHERE id = ?`, blockId);
  return !!row?.favorite;
}

// ---------- Agenda ----------

export type CalendarRecord = {
  id: number;
  audioId: number;
  blockId: number;
  title: string;
  startAt: number;
  allDay: boolean;
  calendarEventId: string | null;
  createdAt: number;
};

export async function listCalendarRecords(audioId: number): Promise<CalendarRecord[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<any>(`SELECT * FROM calendar_events WHERE audio_id = ?`, audioId);
  return rows.map(mapCal);
}

export async function listRecentCalendarRecords(limit = 15): Promise<CalendarRecord[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<any>(`SELECT * FROM calendar_events ORDER BY created_at DESC, id DESC LIMIT ?`, limit);
  return rows.map(mapCal);
}

const mapCal = (r: any): CalendarRecord => ({
  id: r.id,
  audioId: r.audio_id,
  blockId: r.block_id,
  title: r.title,
  startAt: r.start_at,
  allDay: !!r.all_day,
  calendarEventId: r.calendar_event_id ?? null,
  createdAt: r.created_at,
});

export async function addCalendarRecord(r: Omit<CalendarRecord, 'id' | 'createdAt'>): Promise<void> {
  const db = await getDb();
  await db.runAsync(
    `INSERT INTO calendar_events (audio_id, block_id, title, start_at, all_day, calendar_event_id, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    r.audioId,
    r.blockId,
    r.title,
    r.startAt,
    r.allDay ? 1 : 0,
    r.calendarEventId,
    Date.now()
  );
}

export async function deleteCalendarRecord(id: number): Promise<void> {
  const db = await getDb();
  await db.runAsync(`DELETE FROM calendar_events WHERE id = ?`, id);
}


export async function listCalendarRecordsInRange(fromMs: number, toMs: number): Promise<CalendarRecord[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<any>(
    `SELECT * FROM calendar_events WHERE start_at >= ? AND start_at < ?`,
    fromMs,
    toMs
  );
  return rows.map(mapCal);
}

// ---------- Compromissos da aba Agenda (criados dentro do app) ----------

export type AgendaItem = {
  id: number;
  title: string;
  startAt: number;
  allDay: boolean;
  categoryId: number | null;
  notes: string;
};

const mapAgenda = (r: any): AgendaItem => ({
  id: r.id,
  title: r.title,
  startAt: r.start_at,
  allDay: !!r.all_day,
  categoryId: r.category_id ?? null,
  notes: r.notes ?? '',
});

export async function listAgendaItems(fromMs: number, toMs: number): Promise<AgendaItem[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<any>(
    `SELECT * FROM agenda_items WHERE start_at >= ? AND start_at < ? ORDER BY start_at ASC, id ASC`,
    fromMs,
    toMs
  );
  return rows.map(mapAgenda);
}

export async function createAgendaItem(it: Omit<AgendaItem, 'id'>): Promise<void> {
  const db = await getDb();
  await db.runAsync(
    `INSERT INTO agenda_items (title, start_at, all_day, category_id, notes, created_at) VALUES (?, ?, ?, ?, ?, ?)`,
    it.title,
    it.startAt,
    it.allDay ? 1 : 0,
    it.categoryId,
    it.notes,
    Date.now()
  );
}

export async function updateAgendaItem(id: number, it: Omit<AgendaItem, 'id'>): Promise<void> {
  const db = await getDb();
  await db.runAsync(
    `UPDATE agenda_items SET title = ?, start_at = ?, all_day = ?, category_id = ?, notes = ? WHERE id = ?`,
    it.title,
    it.startAt,
    it.allDay ? 1 : 0,
    it.categoryId,
    it.notes,
    id
  );
}

export async function deleteAgendaItem(id: number): Promise<void> {
  const db = await getDb();
  await db.runAsync(`DELETE FROM agenda_items WHERE id = ?`, id);
}

// ---------- Categorias ----------

export async function listCategories(): Promise<Category[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<{ id: number; name: string; color: string; created_at: number }>(
    `SELECT id, name, color, created_at FROM categories ORDER BY created_at ASC, id ASC`
  );
  return rows.map((r) => ({ id: r.id, name: r.name, color: r.color, createdAt: r.created_at }));
}

export async function createCategory(name: string, color: string): Promise<void> {
  const db = await getDb();
  await db.runAsync(
    `INSERT INTO categories (name, color, created_at) VALUES (?, ?, ?)`,
    name,
    color,
    Date.now()
  );
}

export async function updateCategory(id: number, name: string, color: string): Promise<void> {
  const db = await getDb();
  await db.runAsync(`UPDATE categories SET name = ?, color = ? WHERE id = ?`, name, color, id);
}

/** Apaga a categoria; as notas dela ficam sem categoria. */
export async function deleteCategory(id: number): Promise<void> {
  const db = await getDb();
  await db.withTransactionAsync(async () => {
    await db.runAsync(`UPDATE blocks SET category_id = NULL WHERE category_id = ?`, id);
    await db.runAsync(`UPDATE agenda_items SET category_id = NULL WHERE category_id = ?`, id);
    await db.runAsync(`DELETE FROM categories WHERE id = ?`, id);
  });
}

export async function setBlockCategory(blockId: number, categoryId: number | null): Promise<void> {
  const db = await getDb();
  await db.runAsync(`UPDATE blocks SET category_id = ? WHERE id = ?`, categoryId, blockId);
}
