import { parseLink } from './linkPreview';
import * as SQLite from 'expo-sqlite';
import { parseNote, notePreview, noteDisplayTitle, noteText, noteIsEmpty } from './note';
import { nameFromRef } from './media';
import { parseTags, stringifyTags } from './tags';
import { removeAudioFile } from './storage';
import { migrateSyncSchema } from './syncSchema';

export type Block = {
  id: number;
  name: string;
  createdAt: number;
  audioCount: number;
  pendingCount: number;
  hasNote: boolean;
  favorite: boolean;
  categoryId: number | null;
  /** Id de sincronização (UUID); links entre notas usam ele, nunca o id local. */
  uuid: string;
  /** Fixada no topo da Biblioteca. */
  pinned: boolean;
  tags: string[];
  /** Subnota: id da nota-pai (null = nota de topo). */
  parentId: number | null;
  /** Título da nota-pai, para mostrar "em <pai>". */
  parentTitle?: string;
  /** Modelo do usuário (fica fora da Biblioteca). */
  isTemplate: boolean;
  /** Última edição do conteúdo (não muda ao favoritar, fixar etc.). */
  editedAt: number;
  /** Capa: a da nota ou a primeira imagem do texto (nome do arquivo em media). */
  cover: string | null;
  taskTotal: number;
  taskDone: number;
  hasImage: boolean;
  hasAttachment: boolean;
  /** Título da nota (o assunto) e começo do texto, para a Biblioteca. */
  noteTitle: string;
  preview: string;
  /** Texto completo da nota (sem formatação), usado na busca. */
  body: string;
};

export type Category = {
  id: number;
  name: string;
  color: string;
  createdAt: number;
};

export type AudioItem = {
  id: number;
  blockId: number;
  name: string;
  fileName: string;
  durationMs: number;
  createdAt: number;
  position: number;
  /** 'saved' (sem IA) | 'pending' | 'transcribed' | 'error' */
  status: string;
  lastError: string | null;
  nextRetryAt: number | null;
};

export type QueueItem = {
  id: number;
  blockId: number;
  blockName: string;
  audioName: string;
  status: string;
  lastError: string | null;
  nextRetryAt: number | null;
  createdAt: number;
};

let dbPromise: Promise<SQLite.SQLiteDatabase> | null = null;

export function getDb(): Promise<SQLite.SQLiteDatabase> {
  if (!dbPromise) {
    dbPromise = (async () => {
      const db = await SQLite.openDatabaseAsync('ideias.db');
      await db.execAsync(`
        PRAGMA journal_mode = WAL;
        PRAGMA foreign_keys = ON;
        CREATE TABLE IF NOT EXISTS meta (
          key TEXT PRIMARY KEY NOT NULL,
          value TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS blocks (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          created_at INTEGER NOT NULL,
          audio_counter INTEGER NOT NULL DEFAULT 0,
          note_json TEXT
        );
        CREATE TABLE IF NOT EXISTS audios (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          block_id INTEGER NOT NULL REFERENCES blocks(id) ON DELETE CASCADE,
          name TEXT NOT NULL,
          file_name TEXT NOT NULL,
          duration_ms INTEGER NOT NULL DEFAULT 0,
          created_at INTEGER NOT NULL,
          position INTEGER NOT NULL DEFAULT 0,
          status TEXT NOT NULL DEFAULT 'saved',
          transcript_json TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_audios_block ON audios(block_id, position);
      `);
      const cols = await db.getAllAsync<{ name: string }>(`PRAGMA table_info(audios)`);
      const names = new Set(cols.map((c) => c.name));
      const bcols = await db.getAllAsync<{ name: string }>(`PRAGMA table_info(blocks)`);
      if (!bcols.some((c) => c.name === 'favorite'))
        await db.execAsync(`ALTER TABLE blocks ADD COLUMN favorite INTEGER NOT NULL DEFAULT 0`);
      if (!bcols.some((c) => c.name === 'category_id'))
        await db.execAsync(`ALTER TABLE blocks ADD COLUMN category_id INTEGER`);
      // Notas: fixar, tags, subnotas, modelos e data da última edição do conteúdo.
      // edited_at fica NULL nas notas antigas (vale created_at, via COALESCE): um UPDATE em massa aqui
      // marcaria todas como alteradas e as reenviaria à nuvem sem necessidade.
      if (!bcols.some((c) => c.name === 'pinned'))
        await db.execAsync(`ALTER TABLE blocks ADD COLUMN pinned INTEGER NOT NULL DEFAULT 0`);
      if (!bcols.some((c) => c.name === 'tags')) await db.execAsync(`ALTER TABLE blocks ADD COLUMN tags TEXT`);
      if (!bcols.some((c) => c.name === 'parent_id')) await db.execAsync(`ALTER TABLE blocks ADD COLUMN parent_id INTEGER`);
      if (!bcols.some((c) => c.name === 'is_template'))
        await db.execAsync(`ALTER TABLE blocks ADD COLUMN is_template INTEGER NOT NULL DEFAULT 0`);
      if (!bcols.some((c) => c.name === 'edited_at')) await db.execAsync(`ALTER TABLE blocks ADD COLUMN edited_at INTEGER`);
      await db.execAsync(`
        CREATE TABLE IF NOT EXISTS categories (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          color TEXT NOT NULL,
          created_at INTEGER NOT NULL
        );
      `);
      await db.execAsync(`
        CREATE TABLE IF NOT EXISTS calendar_events (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          audio_id INTEGER NOT NULL,
          block_id INTEGER NOT NULL,
          title TEXT NOT NULL,
          start_at INTEGER NOT NULL,
          all_day INTEGER NOT NULL DEFAULT 0,
          calendar_event_id TEXT,
          created_at INTEGER NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_calev_audio ON calendar_events(audio_id);
      `);
      await db.execAsync(`
        CREATE TABLE IF NOT EXISTS agenda_items (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          title TEXT NOT NULL,
          start_at INTEGER NOT NULL,
          all_day INTEGER NOT NULL DEFAULT 1,
          category_id INTEGER,
          notes TEXT,
          created_at INTEGER NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_agenda_start ON agenda_items(start_at);
      `);
      await db.execAsync(`
        CREATE TABLE IF NOT EXISTS mood_collections (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          created_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS mood_items (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          collection_id INTEGER NOT NULL REFERENCES mood_collections(id) ON DELETE CASCADE,
          kind TEXT NOT NULL,
          content TEXT NOT NULL,
          x REAL NOT NULL DEFAULT 0,
          y REAL NOT NULL DEFAULT 0,
          w REAL NOT NULL DEFAULT 0.4,
          h REAL NOT NULL DEFAULT 0.4,
          rot REAL NOT NULL DEFAULT 0,
          z INTEGER NOT NULL DEFAULT 0,
          bold INTEGER NOT NULL DEFAULT 0,
          created_at INTEGER NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_mood_items_col ON mood_items(collection_id, z);
      `);
      const moodCols = await db.getAllAsync<{ name: string }>(`PRAGMA table_info(mood_collections)`);
      const moodNames = new Set(moodCols.map((c) => c.name));
      if (!moodNames.has('pos_x')) await db.execAsync(`ALTER TABLE mood_collections ADD COLUMN pos_x REAL`);
      if (!moodNames.has('pos_y')) await db.execAsync(`ALTER TABLE mood_collections ADD COLUMN pos_y REAL`);
      // Coleções dentro de coleções: null = coleção da raiz (a que aparece na aba Moodboard).
      if (!moodNames.has('parent_id')) {
        await db.execAsync(`ALTER TABLE mood_collections ADD COLUMN parent_id INTEGER`);
      }
      await db.execAsync(`CREATE INDEX IF NOT EXISTS idx_mood_cols_parent ON mood_collections(parent_id)`);
      // Itens do quadro: legenda (apresentação) e cor do cartão (#RRGGBB). Ambas anuláveis.
      const itemCols = await db.getAllAsync<{ name: string }>(`PRAGMA table_info(mood_items)`);
      const itemNames = new Set(itemCols.map((c) => c.name));
      if (!itemNames.has('caption')) await db.execAsync(`ALTER TABLE mood_items ADD COLUMN caption TEXT`);
      if (!itemNames.has('color')) await db.execAsync(`ALTER TABLE mood_items ADD COLUMN color TEXT`);
      if (!names.has('last_error')) await db.execAsync(`ALTER TABLE audios ADD COLUMN last_error TEXT`);
      if (!names.has('next_retry_at'))
        await db.execAsync(`ALTER TABLE audios ADD COLUMN next_retry_at INTEGER`);
      // Sincronização: uuid, updated_at, dirty e gatilhos em cada tabela que vai para a nuvem.
      await migrateSyncSchema(db);
      return db;
    })();
  }
  return dbPromise;
}

type BlockRow = {
  id: number;
  uuid: string | null;
  name: string;
  created_at: number;
  edited_at: number | null;
  audio_count: number;
  pending_count: number;
  has_note: number;
  favorite: number;
  pinned: number;
  tags: string | null;
  parent_id: number | null;
  is_template: number;
  category_id: number | null;
  note_json: string | null;
};

/** Tarefas (total e feitas) de todas as listas de tarefas do texto. */
export function countTasks(html: string): { total: number; done: number } {
  let total = 0;
  let done = 0;
  for (const m of html.matchAll(/<ul\b[^>]*class="[^"]*\btodo\b[^"]*"[^>]*>([\s\S]*?)<\/ul>/gi)) {
    const inner = m[1];
    total += (inner.match(/<li\b/gi) ?? []).length;
    done += (inner.match(/<li\b[^>]*data-done="true"/gi) ?? []).length;
  }
  return { total, done };
}

/** Capa: a da nota, ou a primeira imagem do texto que esteja na pasta media. */
function coverOf(note: ReturnType<typeof parseNote>): string | null {
  if (!note) return null;
  if (note.cover) return nameFromRef(note.cover);
  const m = /<img\b[^>]*\bsrc="([^"]+)"/i.exec(note.html);
  if (!m || /^(https?:|data:)/i.test(m[1])) return null;
  return nameFromRef(m[1]);
}

const BLOCK_SELECT = `SELECT b.id, b.uuid, b.name, b.created_at, b.edited_at,
            (SELECT COUNT(*) FROM audios a WHERE a.block_id = b.id) AS audio_count,
            (SELECT COUNT(*) FROM audios a WHERE a.block_id = b.id
               AND a.status IN ('pending','error')) AS pending_count,
            (b.note_json IS NOT NULL) AS has_note,
            b.favorite, b.pinned, b.tags, b.parent_id, b.is_template,
            b.category_id,
            b.note_json
     FROM blocks b`;

async function queryBlocks(where: string, params: (string | number)[]): Promise<Block[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<BlockRow>(
    `${BLOCK_SELECT}
     ${where}
     ORDER BY b.pinned DESC, b.created_at DESC, b.id DESC`,
    ...params
  );
  const titles = new Map<number, string>();
  const blocks = rows.map((r): Block => {
    const note = parseNote(r.note_json);
    const noteTitle = noteDisplayTitle(note);
    titles.set(r.id, noteTitle || r.name);
    const html = note?.html ?? '';
    const tasks = countTasks(html);
    const cover = coverOf(note);
    return {
      id: r.id,
      uuid: r.uuid ?? '',
      name: r.name,
      createdAt: r.created_at,
      editedAt: r.edited_at ?? r.created_at,
      audioCount: r.audio_count,
      pendingCount: r.pending_count,
      hasNote: !!r.has_note,
      favorite: !!r.favorite,
      pinned: !!r.pinned,
      tags: parseTags(r.tags),
      parentId: r.parent_id ?? null,
      isTemplate: !!r.is_template,
      categoryId: r.category_id ?? null,
      cover,
      taskTotal: tasks.total,
      taskDone: tasks.done,
      hasImage: !!cover || /<img\b/i.test(html),
      hasAttachment: /class="[^"]*\bfilechip\b/i.test(html),
      noteTitle,
      preview: notePreview(note),
      body: noteText(note),
    };
  });
  // Título da nota-pai ("em Projeto X"): a maioria já está na lista; as outras vêm de uma consulta à parte.
  const missing = [...new Set(blocks.map((b) => b.parentId).filter((x): x is number => x !== null && !titles.has(x)))];
  if (missing.length > 0) {
    const extra = await db.getAllAsync<{ id: number; name: string; note_json: string | null }>(
      `SELECT id, name, note_json FROM blocks WHERE id IN (${missing.map(() => '?').join(',')})`,
      ...missing
    );
    extra.forEach((e) => titles.set(e.id, noteDisplayTitle(parseNote(e.note_json)) || e.name));
  }
  blocks.forEach((b) => {
    if (b.parentId !== null) b.parentTitle = titles.get(b.parentId);
  });
  return blocks;
}

/** Notas da Biblioteca (fixadas primeiro, depois as mais novas). Modelos do usuário ficam de fora. */
export async function listBlocks(onlyIds?: number[]): Promise<Block[]> {
  if (onlyIds && onlyIds.length === 0) return [];
  const where = onlyIds ? `WHERE b.is_template = 0 AND b.id IN (${onlyIds.map(() => '?').join(',')})` : 'WHERE b.is_template = 0';
  return queryBlocks(where, onlyIds ?? []);
}

/** Modelos de nota do usuário. */
export async function listTemplates(): Promise<Block[]> {
  return queryBlocks('WHERE b.is_template = 1', []);
}

export async function createBlock(): Promise<number> {
  const db = await getDb();
  let newId = 0;
  await db.withTransactionAsync(async () => {
    const row = await db.getFirstAsync<{ value: string }>(
      `SELECT value FROM meta WHERE key = 'block_counter'`
    );
    const next = (row ? parseInt(row.value, 10) : 0) + 1;
    await db.runAsync(
      `INSERT OR REPLACE INTO meta (key, value) VALUES ('block_counter', ?)`,
      String(next)
    );
    const res = await db.runAsync(
      `INSERT INTO blocks (name, created_at) VALUES (?, ?)`,
      `Nota ${next}`,
      Date.now()
    );
    newId = res.lastInsertRowId;
  });
  return newId;
}

export async function renameBlock(id: number, name: string): Promise<void> {
  const db = await getDb();
  await db.runAsync(`UPDATE blocks SET name = ?, edited_at = ? WHERE id = ?`, name, Date.now(), id);
}

export async function getBlock(id: number): Promise<Block | null> {
  const all = await listBlocks();
  return all.find((b) => b.id === id) ?? null;
}

export async function deleteBlock(id: number): Promise<void> {
  const db = await getDb();
  const files = await db.getAllAsync<{ file_name: string }>(
    `SELECT file_name FROM audios WHERE block_id = ?`,
    id
  );
  await db.withTransactionAsync(async () => {
    await db.runAsync(`DELETE FROM audios WHERE block_id = ?`, id);
    // Vínculos com coleções: o cartão da nota some dos quadros onde ela estava.
    await db.runAsync(`DELETE FROM mood_items WHERE kind = 'note' AND content = ?`, String(id));
    // Subnotas ficam como notas de topo (o diálogo com a escolha "excluir tudo" vem depois).
    await db.runAsync(`UPDATE blocks SET parent_id = NULL WHERE parent_id = ?`, id);
    await db.runAsync(`DELETE FROM blocks WHERE id = ?`, id);
  });
  // Só mexe nos arquivos depois que o banco já foi limpo.
  files.forEach((f) => removeAudioFile(f.file_name));
}

type AudioRow = {
  id: number;
  block_id: number;
  name: string;
  file_name: string;
  duration_ms: number;
  created_at: number;
  position: number;
  status: string;
  last_error: string | null;
  next_retry_at: number | null;
};

const mapAudio = (r: AudioRow): AudioItem => ({
  id: r.id,
  blockId: r.block_id,
  name: r.name,
  fileName: r.file_name,
  durationMs: r.duration_ms,
  createdAt: r.created_at,
  position: r.position,
  status: r.status,
  lastError: r.last_error,
  nextRetryAt: r.next_retry_at,
});

export async function listAudios(blockId: number): Promise<AudioItem[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<AudioRow>(
    `SELECT id, block_id, name, file_name, duration_ms, created_at, position, status,
            last_error, next_retry_at
     FROM audios WHERE block_id = ? ORDER BY position ASC, id ASC`,
    blockId
  );
  return rows.map(mapAudio);
}

export async function addAudio(
  blockId: number,
  fileName: string,
  durationMs: number
): Promise<void> {
  const db = await getDb();
  await db.withTransactionAsync(async () => {
    await db.runAsync(
      `UPDATE blocks SET audio_counter = audio_counter + 1 WHERE id = ?`,
      blockId
    );
    const b = await db.getFirstAsync<{ audio_counter: number }>(
      `SELECT audio_counter FROM blocks WHERE id = ?`,
      blockId
    );
    const pos = await db.getFirstAsync<{ p: number | null }>(
      `SELECT MAX(position) AS p FROM audios WHERE block_id = ?`,
      blockId
    );
    await db.runAsync(
      `INSERT INTO audios (block_id, name, file_name, duration_ms, created_at, position, status)
       VALUES (?, ?, ?, ?, ?, ?, 'pending')`,
      blockId,
      `Gravação ${b?.audio_counter ?? 1}`,
      fileName,
      Math.round(durationMs),
      Date.now(),
      (pos?.p ?? -1) + 1
    );
  });
}

/** Gravações que já foram marcadas com erro por não ter nenhuma fala (de versões antigas do app). */
export async function listNoSpeechAudios(): Promise<{ id: number; blockId: number }[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<any>(
    `SELECT id, block_id FROM audios WHERE status = 'error' AND last_error LIKE 'Nenhuma fala%'`
  );
  return rows.map((r) => ({ id: r.id, blockId: r.block_id }));
}

export async function deleteAudio(id: number): Promise<void> {
  const db = await getDb();
  const row = await db.getFirstAsync<{ file_name: string }>(
    `SELECT file_name FROM audios WHERE id = ?`,
    id
  );
  await db.runAsync(`DELETE FROM audios WHERE id = ?`, id);
  if (row) removeAudioFile(row.file_name);
}

/**
 * Tira uma gravação da fila (apaga o áudio). Se a nota ficou sem nenhum áudio e sem
 * conteúdo nenhum, a nota vazia também é apagada, para não sobrar um item "Nota vazia".
 */
export async function deleteQueueItem(audioId: number): Promise<void> {
  const db = await getDb();
  const row = await db.getFirstAsync<{ block_id: number }>(
    `SELECT block_id FROM audios WHERE id = ?`,
    audioId
  );
  await deleteAudio(audioId);
  if (!row) return;
  const left = await db.getFirstAsync<{ n: number }>(
    `SELECT COUNT(*) AS n FROM audios WHERE block_id = ?`,
    row.block_id
  );
  if ((left?.n ?? 0) > 0) return;
  const blk = await db.getFirstAsync<{ note_json: string | null }>(
    `SELECT note_json FROM blocks WHERE id = ?`,
    row.block_id
  );
  if (blk && noteIsEmpty(parseNote(blk.note_json))) await deleteBlock(row.block_id);
}


// ---------- Fase 2: notas, transcrições e fila ----------

export async function getNoteJson(blockId: number): Promise<string | null> {
  const db = await getDb();
  const row = await db.getFirstAsync<{ note_json: string | null }>(
    `SELECT note_json FROM blocks WHERE id = ?`,
    blockId
  );
  return row?.note_json ?? null;
}

export async function saveNoteJson(blockId: number, json: string): Promise<void> {
  const db = await getDb();
  await db.runAsync(`UPDATE blocks SET note_json = ?, edited_at = ? WHERE id = ?`, json, Date.now(), blockId);
}

export type DetectedEvent = { title: string; start: string; allDay: boolean; excerpt?: string };
export type StoredTranscript = {
  text: string;
  sections?: { heading: string; text: string }[];
  events: DetectedEvent[];
  title?: string;
};

export async function getTranscript(audioId: number): Promise<StoredTranscript | null> {
  const db = await getDb();
  const row = await db.getFirstAsync<{ transcript_json: string | null }>(
    `SELECT transcript_json FROM audios WHERE id = ?`,
    audioId
  );
  if (!row?.transcript_json) return null;
  try {
    const j = JSON.parse(row.transcript_json);
    if (typeof j?.text !== 'string') return null;
    return { text: j.text, events: Array.isArray(j.events) ? j.events : [], title: typeof j.title === 'string' ? j.title : undefined,
      sections: Array.isArray(j.sections) ? j.sections : undefined };
  } catch {
    return null;
  }
}

export async function setTranscript(audioId: number, t: StoredTranscript): Promise<void> {
  const db = await getDb();
  await db.runAsync(`UPDATE audios SET transcript_json = ? WHERE id = ?`, JSON.stringify(t), audioId);
}

export async function setAudioState(
  audioId: number,
  status: string,
  lastError: string | null,
  nextRetryAt: number | null
): Promise<void> {
  const db = await getDb();
  await db.runAsync(
    `UPDATE audios SET status = ?, last_error = ?, next_retry_at = ? WHERE id = ?`,
    status,
    lastError,
    nextRetryAt,
    audioId
  );
}

/** Coloca o áudio de volta na fila (ex.: áudios da Fase 1 ou com erro). */
export async function requeueAudio(audioId: number): Promise<void> {
  await setAudioState(audioId, 'pending', null, null);
}

export async function listPendingAudios(): Promise<AudioItem[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<AudioRow>(
    `SELECT id, block_id, name, file_name, duration_ms, created_at, position, status,
            last_error, next_retry_at
     FROM audios WHERE status = 'pending' ORDER BY created_at ASC, id ASC`
  );
  return rows.map(mapAudio);
}

export async function listQueue(): Promise<QueueItem[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<{
    id: number;
    block_id: number;
    block_name: string;
    audio_name: string;
    status: string;
    last_error: string | null;
    next_retry_at: number | null;
    created_at: number;
  }>(
    `SELECT a.id, a.block_id, b.name AS block_name, a.name AS audio_name, a.status,
            a.last_error, a.next_retry_at, a.created_at
     FROM audios a JOIN blocks b ON b.id = a.block_id
     WHERE a.status IN ('pending','error')
     ORDER BY a.created_at ASC, a.id ASC`
  );
  return rows.map((r) => ({
    id: r.id,
    blockId: r.block_id,
    blockName: r.block_name,
    audioName: r.audio_name,
    status: r.status,
    lastError: r.last_error,
    nextRetryAt: r.next_retry_at,
    createdAt: r.created_at,
  }));
}

export async function countQueue(): Promise<number> {
  const db = await getDb();
  const row = await db.getFirstAsync<{ n: number }>(
    `SELECT COUNT(*) AS n FROM audios WHERE status IN ('pending','error')`
  );
  return row?.n ?? 0;
}

/** Aplica o resultado na nota e marca o áudio como transcrito, tudo numa transação só. */
export async function commitTranscribed(
  audioId: number,
  blockId: number,
  noteJson: string,
  clearFile: boolean
): Promise<boolean> {
  const db = await getDb();
  let applied = false;
  await db.withTransactionAsync(async () => {
    // Se a gravação foi apagada da fila enquanto era transcrita, não escreve nada na nota.
    const exists = await db.getFirstAsync<{ id: number }>(`SELECT id FROM audios WHERE id = ?`, audioId);
    if (!exists) return;
    await db.runAsync(`UPDATE blocks SET note_json = ?, edited_at = ? WHERE id = ?`, noteJson, Date.now(), blockId);
    await db.runAsync(
      `UPDATE audios SET status = 'transcribed', last_error = NULL, next_retry_at = NULL${
        clearFile ? ", file_name = ''" : ''
      } WHERE id = ?`,
      audioId
    );
    applied = true;
  });
  return applied;
}

// ---------- Favoritas ----------

export async function setFavorite(blockId: number, fav: boolean): Promise<void> {
  const db = await getDb();
  await db.runAsync(`UPDATE blocks SET favorite = ? WHERE id = ?`, fav ? 1 : 0, blockId);
}

export async function setPinned(blockId: number, pinned: boolean): Promise<void> {
  const db = await getDb();
  await db.runAsync(`UPDATE blocks SET pinned = ? WHERE id = ?`, pinned ? 1 : 0, blockId);
}

export async function setBlockTags(blockId: number, tags: string[]): Promise<void> {
  const db = await getDb();
  await db.runAsync(`UPDATE blocks SET tags = ? WHERE id = ?`, stringifyTags(tags), blockId);
}

/** Liga a nota a uma nota-pai (subnota) ou desvincula (null). */
export async function setBlockParent(blockId: number, parentId: number | null): Promise<void> {
  const db = await getDb();
  if (parentId === blockId) return;
  await db.runAsync(`UPDATE blocks SET parent_id = ? WHERE id = ?`, parentId, blockId);
}

export async function isFavorite(blockId: number): Promise<boolean> {
  const db = await getDb();
  const row = await db.getFirstAsync<{ favorite: number }>(`SELECT favorite FROM blocks WHERE id = ?`, blockId);
  return !!row?.favorite;
}

// ---------- Agenda ----------

export type CalendarRecord = {
  id: number;
  audioId: number;
  blockId: number;
  title: string;
  startAt: number;
  allDay: boolean;
  calendarEventId: string | null;
  createdAt: number;
};

export async function listCalendarRecords(audioId: number): Promise<CalendarRecord[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<any>(`SELECT * FROM calendar_events WHERE audio_id = ?`, audioId);
  return rows.map(mapCal);
}

export async function listRecentCalendarRecords(limit = 15): Promise<CalendarRecord[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<any>(`SELECT * FROM calendar_events ORDER BY created_at DESC, id DESC LIMIT ?`, limit);
  return rows.map(mapCal);
}

const mapCal = (r: any): CalendarRecord => ({
  id: r.id,
  audioId: r.audio_id,
  blockId: r.block_id,
  title: r.title,
  startAt: r.start_at,
  allDay: !!r.all_day,
  calendarEventId: r.calendar_event_id ?? null,
  createdAt: r.created_at,
});

export async function addCalendarRecord(r: Omit<CalendarRecord, 'id' | 'createdAt'>): Promise<void> {
  const db = await getDb();
  await db.runAsync(
    `INSERT INTO calendar_events (audio_id, block_id, title, start_at, all_day, calendar_event_id, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    r.audioId,
    r.blockId,
    r.title,
    r.startAt,
    r.allDay ? 1 : 0,
    r.calendarEventId,
    Date.now()
  );
}

export async function deleteCalendarRecord(id: number): Promise<void> {
  const db = await getDb();
  await db.runAsync(`DELETE FROM calendar_events WHERE id = ?`, id);
}


export async function listCalendarRecordsInRange(fromMs: number, toMs: number): Promise<CalendarRecord[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<any>(
    `SELECT * FROM calendar_events WHERE start_at >= ? AND start_at < ?`,
    fromMs,
    toMs
  );
  return rows.map(mapCal);
}

// ---------- Compromissos da aba Agenda (criados dentro do app) ----------

export type AgendaItem = {
  id: number;
  title: string;
  startAt: number;
  allDay: boolean;
  categoryId: number | null;
  notes: string;
};

const mapAgenda = (r: any): AgendaItem => ({
  id: r.id,
  title: r.title,
  startAt: r.start_at,
  allDay: !!r.all_day,
  categoryId: r.category_id ?? null,
  notes: r.notes ?? '',
});

export async function listAgendaItems(fromMs: number, toMs: number): Promise<AgendaItem[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<any>(
    `SELECT * FROM agenda_items WHERE start_at >= ? AND start_at < ? ORDER BY start_at ASC, id ASC`,
    fromMs,
    toMs
  );
  return rows.map(mapAgenda);
}

export async function createAgendaItem(it: Omit<AgendaItem, 'id'>): Promise<void> {
  const db = await getDb();
  await db.runAsync(
    `INSERT INTO agenda_items (title, start_at, all_day, category_id, notes, created_at) VALUES (?, ?, ?, ?, ?, ?)`,
    it.title,
    it.startAt,
    it.allDay ? 1 : 0,
    it.categoryId,
    it.notes,
    Date.now()
  );
}

export async function updateAgendaItem(id: number, it: Omit<AgendaItem, 'id'>): Promise<void> {
  const db = await getDb();
  await db.runAsync(
    `UPDATE agenda_items SET title = ?, start_at = ?, all_day = ?, category_id = ?, notes = ? WHERE id = ?`,
    it.title,
    it.startAt,
    it.allDay ? 1 : 0,
    it.categoryId,
    it.notes,
    id
  );
}

export async function deleteAgendaItem(id: number): Promise<void> {
  const db = await getDb();
  await db.runAsync(`DELETE FROM agenda_items WHERE id = ?`, id);
}

// ---------- Categorias ----------

export async function listCategories(): Promise<Category[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<{ id: number; name: string; color: string; created_at: number }>(
    `SELECT id, name, color, created_at FROM categories ORDER BY created_at ASC, id ASC`
  );
  return rows.map((r) => ({ id: r.id, name: r.name, color: r.color, createdAt: r.created_at }));
}

export async function createCategory(name: string, color: string): Promise<void> {
  const db = await getDb();
  await db.runAsync(
    `INSERT INTO categories (name, color, created_at) VALUES (?, ?, ?)`,
    name,
    color,
    Date.now()
  );
}

export async function updateCategory(id: number, name: string, color: string): Promise<void> {
  const db = await getDb();
  await db.runAsync(`UPDATE categories SET name = ?, color = ? WHERE id = ?`, name, color, id);
}

/** Apaga a categoria; as notas dela ficam sem categoria. */
export async function deleteCategory(id: number): Promise<void> {
  const db = await getDb();
  await db.withTransactionAsync(async () => {
    await db.runAsync(`UPDATE blocks SET category_id = NULL WHERE category_id = ?`, id);
    await db.runAsync(`UPDATE agenda_items SET category_id = NULL WHERE category_id = ?`, id);
    await db.runAsync(`DELETE FROM categories WHERE id = ?`, id);
  });
}

export async function setBlockCategory(blockId: number, categoryId: number | null): Promise<void> {
  const db = await getDb();
  await db.runAsync(`UPDATE blocks SET category_id = ? WHERE id = ?`, categoryId, blockId);
}

// ---------- Moodboard ----------

export type MoodCollection = {
  id: number;
  name: string;
  /** null = coleção da raiz; senão, o id da coleção em que ela está dentro. */
  parentId: number | null;
  count: number;
  /** Imagens da capa (nomes de arquivo), da mais recente para a mais antiga. Até 4. As da própria coleção vêm primeiro; depois as das coleções de dentro. */
  covers: string[];
  /** Posição no quadro livre da raiz, em larguras de tela (canto superior esquerdo). null = ainda sem posição. Coleções de dentro de outra têm a posição no cartão (MoodItem). */
  x: number | null;
  y: number | null;
};

/**
 * Posição e tamanho em "unidades de largura da tela" (1 = largura inteira), para valer em qualquer celular.
 * kind 'collection': content = id da coleção de dentro; w/h = tamanho do cartão.
 * kind 'note': content = id da nota (o cartão é o vínculo nota <-> coleção); w/h = tamanho do cartão.
 */
export type MoodKind = 'image' | 'text' | 'collection' | 'note' | 'link' | 'swatch';
export type MoodItem = {
  id: number;
  collectionId: number;
  kind: MoodKind;
  /** Imagem: nome do arquivo em media. Texto: o próprio texto. Coleção/nota: o id, como texto. */
  content: string;
  x: number;
  y: number;
  /** Imagem: largura. Texto: tamanho da letra. */
  w: number;
  /** Imagem: altura. Texto: largura da caixa. */
  h: number;
  rot: number;
  z: number;
  bold: boolean;
  /** Legenda mostrada na apresentação. null = sem legenda. */
  caption: string | null;
  /** Cor do cartão (#RRGGBB). null = sem cor. */
  color: string | null;
};

/** Tamanho padrão (em unidades) do cartão de uma coleção e do cartão de uma nota dentro de um quadro. */
export const SUBCOL_CARD = { w: 0.46, h: 0.66 };
export const NOTE_CARD = { w: 0.5, h: 0.3 };
/** Cartão de paleta (kind 'swatch') e de link (kind 'link'; h = com imagem, hNoImg = sem). */
export const SWATCH_CARD = { w: 0.6, h: 0.4 };
export const LINK_CARD = { w: 0.6, h: 0.54, hNoImg: 0.26 };

type MoodRow = {
  id: number;
  collection_id: number;
  kind: string;
  content: string;
  x: number;
  y: number;
  w: number;
  h: number;
  rot: number;
  z: number;
  bold: number;
  caption: string | null;
  color: string | null;
};

const MOOD_KINDS: readonly string[] = ['text', 'collection', 'note', 'link', 'swatch'];

const mapMood = (r: MoodRow): MoodItem => ({
  id: r.id,
  collectionId: r.collection_id,
  kind: MOOD_KINDS.includes(r.kind) ? (r.kind as MoodKind) : 'image',
  content: r.content,
  x: r.x,
  y: r.y,
  w: r.w,
  h: r.h,
  rot: r.rot,
  z: r.z,
  bold: r.bold === 1,
  caption: r.caption ?? null,
  color: r.color ?? null,
});

type ColRow = { id: number; name: string; parent_id: number | null; pos_x: number | null; pos_y: number | null };

/** Esta coleção e todas as de dentro dela (recursivo). O parâmetro ? é o id da coleção. */
const DESCENDANTS = `WITH RECURSIVE d(id) AS (
  SELECT ? UNION ALL SELECT c.id FROM mood_collections c JOIN d ON c.parent_id = d.id
)`;

async function buildCollections(db: SQLite.SQLiteDatabase, rows: ColRow[]): Promise<MoodCollection[]> {
  const out: MoodCollection[] = [];
  for (const r of rows) {
    const imgs = await db.getAllAsync<{ content: string }>(
      `${DESCENDANTS}
       SELECT content FROM mood_items
       WHERE kind = 'image' AND collection_id IN (SELECT id FROM d)
       ORDER BY (collection_id = ?) DESC, z DESC, id DESC
       LIMIT 4`,
      r.id,
      r.id
    );
    const total = await db.getFirstAsync<{ n: number }>(
      `SELECT COUNT(*) AS n FROM mood_items WHERE collection_id = ?`,
      r.id
    );
    out.push({
      id: r.id,
      name: r.name,
      parentId: r.parent_id ?? null,
      count: total?.n ?? 0,
      covers: imgs.map((i) => i.content),
      x: r.pos_x,
      y: r.pos_y,
    });
  }
  return out;
}

/** Coleções da raiz (as que aparecem na aba Moodboard). */
export async function listCollections(): Promise<MoodCollection[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<ColRow>(
    `SELECT id, name, parent_id, pos_x, pos_y FROM mood_collections
     WHERE parent_id IS NULL ORDER BY created_at DESC, id DESC`
  );
  return buildCollections(db, rows);
}

export async function listCollectionsByIds(ids: number[]): Promise<MoodCollection[]> {
  if (ids.length === 0) return [];
  const db = await getDb();
  const rows = await db.getAllAsync<ColRow>(
    `SELECT id, name, parent_id, pos_x, pos_y FROM mood_collections WHERE id IN (${ids.map(() => '?').join(',')})`,
    ...ids
  );
  return buildCollections(db, rows);
}

export async function createCollection(name: string, parentId: number | null = null): Promise<number> {
  const db = await getDb();
  const r = await db.runAsync(
    `INSERT INTO mood_collections (name, created_at, parent_id) VALUES (?, ?, ?)`,
    name,
    Date.now(),
    parentId
  );
  return r.lastInsertRowId;
}

/** Cria uma coleção dentro de outra e já coloca o cartão dela no quadro de fora. */
export async function addSubCollection(
  parentId: number,
  name: string,
  x: number,
  y: number,
  scale = 1
): Promise<MoodItem> {
  const childId = await createCollection(name, parentId);
  return addMoodItem({
    collectionId: parentId,
    kind: 'collection',
    content: String(childId),
    x,
    y,
    w: SUBCOL_CARD.w * scale,
    h: SUBCOL_CARD.h * scale,
    rot: 0,
    bold: false,
  });
}

export async function setCollectionPos(id: number, x: number, y: number): Promise<void> {
  const db = await getDb();
  await db.runAsync(`UPDATE mood_collections SET pos_x = ?, pos_y = ? WHERE id = ?`, x, y, id);
}

export async function renameCollection(id: number, name: string): Promise<void> {
  const db = await getDb();
  await db.runAsync(`UPDATE mood_collections SET name = ? WHERE id = ?`, name, id);
}

export async function getCollectionName(id: number): Promise<string> {
  const db = await getDb();
  const r = await db.getFirstAsync<{ name: string }>(`SELECT name FROM mood_collections WHERE id = ?`, id);
  return r?.name ?? '';
}

/** Caminho da raiz até a coleção (inclusive ela), por exemplo [Viagens, Japão, Comidas]. */
export async function collectionPath(id: number): Promise<{ id: number; name: string }[]> {
  const db = await getDb();
  const path: { id: number; name: string }[] = [];
  let cur: number | null = id;
  for (let guard = 0; cur !== null && guard < 50; guard++) {
    const r: { id: number; name: string; parent_id: number | null } | null = await db.getFirstAsync<{
      id: number;
      name: string;
      parent_id: number | null;
    }>(`SELECT id, name, parent_id FROM mood_collections WHERE id = ?`, cur);
    if (!r) break;
    path.unshift({ id: r.id, name: r.name });
    cur = r.parent_id ?? null;
  }
  return path;
}

export type FlatCollection = { id: number; name: string; depth: number; path: string };

/** Todas as coleções, em ordem de árvore (cada uma seguida das suas de dentro), para escolher uma. */
export async function listCollectionTree(): Promise<FlatCollection[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<{ id: number; name: string; parent_id: number | null }>(
    `SELECT id, name, parent_id FROM mood_collections ORDER BY created_at DESC, id DESC`
  );
  const ids = new Set(rows.map((r) => r.id));
  const kids = new Map<number | null, typeof rows>();
  for (const r of rows) {
    const key = r.parent_id !== null && ids.has(r.parent_id) ? r.parent_id : null;
    if (!kids.has(key)) kids.set(key, []);
    kids.get(key)!.push(r);
  }
  const out: FlatCollection[] = [];
  const walk = (key: number | null, depth: number, prefix: string[]) => {
    for (const r of kids.get(key) ?? []) {
      const names = [...prefix, r.name];
      out.push({ id: r.id, name: r.name, depth, path: names.join(' › ') });
      if (depth < 50) walk(r.id, depth + 1, names);
    }
  };
  walk(null, 0, []);
  return out;
}

/** Apaga a coleção, tudo que tem dentro (inclusive as coleções de dentro) e o cartão dela no quadro de fora. Devolve os arquivos de imagem, para o chamador apagar. */
export async function deleteCollection(id: number): Promise<string[]> {
  const db = await getDb();
  const ids = (await db.getAllAsync<{ id: number }>(`${DESCENDANTS} SELECT id FROM d`, id)).map((r) => r.id);
  if (ids.length === 0) return [];
  const ph = ids.map(() => '?').join(',');
  const files = await db.getAllAsync<{ kind: string; content: string }>(
    `SELECT kind, content FROM mood_items WHERE kind IN ('image', 'link') AND collection_id IN (${ph})`,
    ...ids
  );
  await db.withTransactionAsync(async () => {
    await db.runAsync(`DELETE FROM mood_items WHERE collection_id IN (${ph})`, ...ids);
    await db.runAsync(`DELETE FROM mood_items WHERE kind = 'collection' AND content IN (${ph})`, ...ids.map(String));
    await db.runAsync(`DELETE FROM mood_collections WHERE id IN (${ph})`, ...ids);
  });
  return files.flatMap((f) => (f.kind === 'link' ? [parseLink(f.content).img ?? ''] : [f.content])).filter(Boolean);
}

export async function listMoodItems(collectionId: number): Promise<MoodItem[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<MoodRow>(
    `SELECT id, collection_id, kind, content, x, y, w, h, rot, z, bold, caption, color
     FROM mood_items WHERE collection_id = ? ORDER BY z ASC, id ASC`,
    collectionId
  );
  return rows.map(mapMood);
}

export async function addMoodItem(
  it: Omit<MoodItem, 'id' | 'z' | 'caption' | 'color'> & { caption?: string | null; color?: string | null }
): Promise<MoodItem> {
  const db = await getDb();
  const top = await db.getFirstAsync<{ m: number | null }>(
    `SELECT MAX(z) AS m FROM mood_items WHERE collection_id = ?`,
    it.collectionId
  );
  const z = (top?.m ?? 0) + 1;
  const r = await db.runAsync(
    `INSERT INTO mood_items (collection_id, kind, content, x, y, w, h, rot, z, bold, caption, color, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    it.collectionId, it.kind, it.content, it.x, it.y, it.w, it.h, it.rot, z, it.bold ? 1 : 0,
    it.caption ?? null, it.color ?? null, Date.now()
  );
  return { ...it, caption: it.caption ?? null, color: it.color ?? null, id: r.lastInsertRowId, z };
}

export async function updateMoodItem(
  id: number,
  p: Partial<Pick<MoodItem, 'x' | 'y' | 'w' | 'h' | 'rot' | 'z' | 'bold' | 'content' | 'caption' | 'color'>>
): Promise<void> {
  const db = await getDb();
  const sets: string[] = [];
  const vals: (string | number | null)[] = [];
  for (const [k, v] of Object.entries(p)) {
    if (v === undefined) continue; // null é válido (apaga caption/color)
    sets.push(`${k} = ?`);
    vals.push(typeof v === 'boolean' ? (v ? 1 : 0) : v);
  }
  if (sets.length === 0) return;
  await db.runAsync(`UPDATE mood_items SET ${sets.join(', ')} WHERE id = ?`, ...vals, id);
}

export async function deleteMoodItem(id: number): Promise<void> {
  const db = await getDb();
  await db.runAsync(`DELETE FROM mood_items WHERE id = ?`, id);
}

/** Leva o item para a frente de todos e devolve o novo z. */
export async function bringMoodItemToFront(id: number, collectionId: number): Promise<number> {
  const db = await getDb();
  const top = await db.getFirstAsync<{ m: number | null }>(
    `SELECT MAX(z) AS m FROM mood_items WHERE collection_id = ?`,
    collectionId
  );
  const z = (top?.m ?? 0) + 1;
  await db.runAsync(`UPDATE mood_items SET z = ? WHERE id = ?`, z, id);
  return z;
}

// ---------- Vínculos nota <-> coleção ----------
// Um vínculo é um cartão de nota (kind 'note') dentro do quadro da coleção. Os dois lados leem a mesma coisa:
// a coleção mostra o cartão; a nota lista as coleções onde tem cartão.

export async function listNoteLinks(blockId: number): Promise<FlatCollection[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<{ collection_id: number }>(
    `SELECT DISTINCT collection_id FROM mood_items WHERE kind = 'note' AND content = ?`,
    String(blockId)
  );
  const out: FlatCollection[] = [];
  for (const r of rows) {
    const path = await collectionPath(r.collection_id);
    if (path.length === 0) continue;
    out.push({
      id: r.collection_id,
      name: path[path.length - 1].name,
      depth: path.length - 1,
      path: path.map((p) => p.name).join(' › '),
    });
  }
  return out;
}

/** Põe o cartão da nota no quadro da coleção (num ponto livre perto do centro, se não houver posição). Devolve o cartão, ou null se já estava vinculada. */
export async function linkNoteToCollection(
  blockId: number,
  collectionId: number,
  at?: { x: number; y: number }
): Promise<MoodItem | null> {
  const db = await getDb();
  const has = await db.getFirstAsync<{ id: number }>(
    `SELECT id FROM mood_items WHERE collection_id = ? AND kind = 'note' AND content = ?`,
    collectionId,
    String(blockId)
  );
  if (has) return null;
  let x = at?.x;
  let y = at?.y;
  if (x === undefined || y === undefined) {
    const n = await db.getFirstAsync<{ n: number }>(
      `SELECT COUNT(*) AS n FROM mood_items WHERE collection_id = ? AND kind = 'note'`,
      collectionId
    );
    const k = n?.n ?? 0;
    // O quadro de uma coleção tem 5 x 8 unidades; começa no meio e vai enchendo em grade de 3 colunas.
    x = 2.5 - 0.85 + (k % 3) * (NOTE_CARD.w + 0.1);
    y = 4 - 0.5 + Math.floor(k / 3) * (NOTE_CARD.h + 0.1);
  }
  return addMoodItem({
    collectionId,
    kind: 'note',
    content: String(blockId),
    x,
    y,
    w: NOTE_CARD.w,
    h: NOTE_CARD.h,
    rot: 0,
    bold: false,
  });
}

export async function unlinkNoteFromCollection(blockId: number, collectionId: number): Promise<void> {
  const db = await getDb();
  await db.runAsync(
    `DELETE FROM mood_items WHERE collection_id = ? AND kind = 'note' AND content = ?`,
    collectionId,
    String(blockId)
  );
}
