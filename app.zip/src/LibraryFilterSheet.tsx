import React from 'react';
import { Pressable, ScrollView, Text, View, useWindowDimensions } from 'react-native';
import { Category } from './db';
import { SheetShell } from './DialogBase';
import {
  CONTENT_LABEL,
  ContentKind,
  DatePeriod,
  LibFilters,
  NO_FILTERS,
  PERIOD_LABEL,
  countActive,
} from './libraryFilters';
import type { SortDir, SortKey } from './blockSort';
import type { LibraryView } from './settings';
import { Chip } from './TagsDialog';
import { colors, fonts, SPACE, TYPE } from './theme';

type Props = {
  visible: boolean;
  onClose: () => void;
  cats: Category[];
  tags: { key: string; name: string; count: number }[];
  filters: LibFilters;
  onFilters: (f: LibFilters) => void;
  sort: { key: SortKey; dir: SortDir };
  onSort: (key: SortKey) => void;
  view: LibraryView;
  onView: (v: LibraryView) => void;
  /** Quantas notas o resultado atual mostra. */
  count: number;
};

const SORTS: [SortKey, string][] = [
  ['created', 'Criada'],
  ['edited', 'Editada'],
  ['name', 'Nome'],
];

/** Janela única de ordenar, visualizar e filtrar a Biblioteca. */
export function LibraryFilterSheet({ visible, onClose, cats, tags, filters, onFilters, sort, onSort, view, onView, count }: Props) {
  const { width: sw, height: sh } = useWindowDimensions();
  const set = (p: Partial<LibFilters>) => onFilters({ ...filters, ...p });
  const toggleIn = <T,>(arr: T[], v: T) => (arr.includes(v) ? arr.filter((x) => x !== v) : [...arr, v]);

  const Label = ({ children }: { children: string }) => (
    <Text style={{ color: colors.muted, fontFamily: fonts.bold, fontSize: sw * TYPE.caption, marginTop: sw * SPACE.lg, marginBottom: sw * SPACE.sm }}>
      {children}
    </Text>
  );
  const Row = ({ children }: { children: React.ReactNode }) => (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: sw * SPACE.sm }}>{children}</View>
  );

  return (
    <SheetShell visible={visible} onClose={onClose} maxHeight={sh * 0.85}>
      <ScrollView contentContainerStyle={{ padding: sw * SPACE.lg }} showsVerticalScrollIndicator={false}>
        <Text style={{ color: colors.onLight, fontFamily: fonts.bold, fontSize: sw * TYPE.title }}>Ordenar e filtrar</Text>

        <Label>ORDENAR</Label>
        <Row>
          {SORTS.map(([k, label]) => (
            <Chip key={k} sw={sw} on={sort.key === k} label={sort.key === k ? `${label} ${sort.dir === 'asc' ? '↑' : '↓'}` : label} onPress={() => onSort(k)} />
          ))}
        </Row>

        <Label>VISUALIZAÇÃO</Label>
        <Row>
          <Chip sw={sw} on={view === 'list'} label="Lista" onPress={() => onView('list')} />
          <Chip sw={sw} on={view === 'grid'} label="Grade" onPress={() => onView('grid')} />
        </Row>

        <Label>CATEGORIA</Label>
        <Row>
          <Chip sw={sw} on={filters.category === 0} label="Sem categoria" onPress={() => set({ category: filters.category === 0 ? null : 0 })} />
          {cats.map((c) => (
            <Chip key={c.id} sw={sw} on={filters.category === c.id} label={c.name} onPress={() => set({ category: filters.category === c.id ? null : c.id })} />
          ))}
        </Row>

        {tags.length > 0 && (
          <>
            <Label>TAGS (a nota precisa ter todas as marcadas)</Label>
            <Row>
              {tags.map((t) => (
                <Chip key={t.key} sw={sw} on={filters.tags.includes(t.key)} label={`${t.name} ${t.count}`} onPress={() => set({ tags: toggleIn(filters.tags, t.key) })} />
              ))}
            </Row>
          </>
        )}

        <Label>NOTAS</Label>
        <Row>
          <Chip sw={sw} on={filters.favoritesOnly} label="Favoritas" onPress={() => set({ favoritesOnly: !filters.favoritesOnly })} />
          <Chip sw={sw} on={filters.pendingTasks} label="Com tarefas pendentes" onPress={() => set({ pendingTasks: !filters.pendingTasks })} />
        </Row>

        <Label>DATA</Label>
        <Row>
          <Chip sw={sw} on={filters.dateBase === 'created'} label="Criada" onPress={() => set({ dateBase: 'created' })} />
          <Chip sw={sw} on={filters.dateBase === 'edited'} label="Editada" onPress={() => set({ dateBase: 'edited' })} />
        </Row>
        <View style={{ height: sw * SPACE.sm }} />
        <Row>
          {(Object.keys(PERIOD_LABEL) as DatePeriod[]).map((p) => (
            <Chip key={p} sw={sw} on={filters.period === p} label={PERIOD_LABEL[p]} onPress={() => set({ period: filters.period === p ? null : p })} />
          ))}
        </Row>

        <Label>TEM (qualquer um)</Label>
        <Row>
          {(Object.keys(CONTENT_LABEL) as ContentKind[]).map((c) => (
            <Chip key={c} sw={sw} on={filters.content.includes(c)} label={CONTENT_LABEL[c]} onPress={() => set({ content: toggleIn(filters.content, c) })} />
          ))}
        </Row>

        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: sw * SPACE.xl }}>
          <Pressable onPress={() => onFilters(NO_FILTERS)} hitSlop={12} disabled={countActive(filters) === 0}>
            <Text style={{ color: colors.red, opacity: countActive(filters) === 0 ? 0.35 : 1, fontFamily: fonts.bold, fontSize: sw * TYPE.body }}>Limpar tudo</Text>
          </Pressable>
          <Pressable onPress={onClose} hitSlop={12}>
            <Text style={{ color: colors.onLight, fontFamily: fonts.bold, fontSize: sw * TYPE.body }}>
              {`Mostrar ${count} ${count === 1 ? 'nota' : 'notas'}`}
            </Text>
          </Pressable>
        </View>
      </ScrollView>
    </SheetShell>
  );
}
