export type Run = { t: string; b?: boolean; i?: boolean; c?: string };
export type Style = { b?: boolean; i?: boolean; c?: string };

export const plain = (runs: Run[]): string => runs.map((r) => r.t).join('');

const same = (a: Style, b: Style) =>
  !!a.b === !!b.b && !!a.i === !!b.i && (a.c ?? null) === (b.c ?? null);

export function normalize(runs: Run[]): Run[] {
  const out: Run[] = [];
  for (const r of runs) {
    if (!r.t) continue;
    const clean: Run = { t: r.t };
    if (r.b) clean.b = true;
    if (r.i) clean.i = true;
    if (r.c) clean.c = r.c;
    const last = out[out.length - 1];
    if (last && same(last, clean)) last.t += clean.t;
    else out.push(clean);
  }
  return out;
}

/** Sub-trechos entre as posições de caractere [start, end). */
export function sliceRuns(runs: Run[], start: number, end: number): Run[] {
  const out: Run[] = [];
  let pos = 0;
  for (const r of runs) {
    const rs = pos;
    const re = pos + r.t.length;
    pos = re;
    const a = Math.max(start, rs);
    const b = Math.min(end, re);
    if (a < b) out.push({ ...r, t: r.t.slice(a - rs, b - rs) });
  }
  return out;
}

/** Estilo do caractere na posição idx (ou {} se não existir). */
export function styleOfChar(runs: Run[], idx: number): Style {
  if (idx < 0) return {};
  let pos = 0;
  for (const r of runs) {
    if (idx < pos + r.t.length) {
      const s: Style = {};
      if (r.b) s.b = true;
      if (r.i) s.i = true;
      if (r.c) s.c = r.c;
      return s;
    }
    pos += r.t.length;
  }
  return {};
}

/** true se TODOS os caracteres do trecho têm o estilo. */
export function rangeHas(runs: Run[], start: number, end: number, key: 'b' | 'i'): boolean {
  const parts = sliceRuns(runs, start, end);
  return parts.length > 0 && parts.every((p) => !!p[key]);
}

/** Cor única do trecho, null se sem cor, 'mixed' se variada. */
export function colorOfRange(runs: Run[], start: number, end: number): string | null | 'mixed' {
  const parts = sliceRuns(runs, start, end);
  if (parts.length === 0) return null;
  const first = parts[0].c ?? null;
  return parts.every((p) => (p.c ?? null) === first) ? first : 'mixed';
}

export type Patch = { b?: boolean; i?: boolean; c?: string | null };

/** Aplica negrito/itálico (alterna) ou cor ao trecho selecionado. */
export function applyStyle(runs: Run[], start: number, end: number, patch: Patch): Run[] {
  if (start >= end) return runs;
  const len = plain(runs).length;
  const before = sliceRuns(runs, 0, start);
  const mid = sliceRuns(runs, start, end);
  const after = sliceRuns(runs, end, len);
  const allB = mid.length > 0 && mid.every((m) => m.b);
  const allI = mid.length > 0 && mid.every((m) => m.i);
  const styled = mid.map((m) => {
    const n: Run = { ...m };
    if (patch.b) n.b = !allB ? true : undefined;
    if (patch.i) n.i = !allI ? true : undefined;
    if (patch.c !== undefined) n.c = patch.c === null ? undefined : patch.c;
    return n;
  });
  return normalize([...before, ...styled, ...after]);
}

/**
 * Converte a mudança do texto digitado (old -> new) em novos trechos,
 * mantendo a formatação do que não mudou. O texto inserido herda o estilo
 * do caractere anterior (ou o estilo "pendente" escolhido na barra).
 */
export function replaceText(runs: Run[], oldText: string, newText: string, pending: Style | null): Run[] {
  let p = 0;
  const maxP = Math.min(oldText.length, newText.length);
  while (p < maxP && oldText[p] === newText[p]) p++;
  let s = 0;
  const maxS = Math.min(oldText.length - p, newText.length - p);
  while (s < maxS && oldText[oldText.length - 1 - s] === newText[newText.length - 1 - s]) s++;
  const delEnd = oldText.length - s;
  const inserted = newText.slice(p, newText.length - s);
  const before = sliceRuns(runs, 0, p);
  const after = sliceRuns(runs, delEnd, oldText.length);
  if (!inserted) return normalize([...before, ...after]);
  const base = p > 0 ? styleOfChar(runs, p - 1) : styleOfChar(runs, p);
  const style = pending ?? base;
  return normalize([...before, { t: inserted, ...style }, ...after]);
}
