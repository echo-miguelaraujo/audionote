/**
 * Ícones em SVG para as páginas HTML dos editores (WebView). Vêm da biblioteca única `iconSet.ts`
 * (Phosphor Fill: formas cheias, traço grosso, cantos arredondados), na cor do texto (`currentColor`).
 */
import { ICON_SET, ICON_VIEWBOX, IconKey } from './iconSet';

export type HtmlIconName = IconKey;

/** SVG pronto para colar no HTML; usa a cor do texto. A classe `ic` define o tamanho no CSS. */
export const icon = (name: HtmlIconName): string =>
  `<svg class="ic" viewBox="${ICON_VIEWBOX}" fill="currentColor" aria-hidden="true">${ICON_SET[name]}</svg>`;

/** Mapa nome → SVG, para o JavaScript da página montar menus. Vai como JSON dentro do HTML. */
export const iconMap = (names: HtmlIconName[]): string => {
  const o: Record<string, string> = {};
  names.forEach((n) => (o[n] = icon(n)));
  return JSON.stringify(o);
};

/** CSS comum dos ícones nos botões da barra e nos itens dos menus. */
export const ICON_CSS =
  '.ic{width:22px;height:22px;fill:currentColor;stroke:none;pointer-events:none;flex:none}' +
  '.opt .ic{width:18px;height:18px;margin-right:10px;vertical-align:-3px}';
