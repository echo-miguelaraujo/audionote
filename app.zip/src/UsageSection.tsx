import React, { useEffect, useState } from 'react';
import { Text, View, useWindowDimensions } from 'react-native';
import { USAGE_LABELS, UsageKind, UsageMonth, loadUsage } from './usage';
import { colors, fonts, SPACE, TYPE } from './theme';

/** Quanto o Gemini consumiu no mês (só aparece quando já houve uso). */
export function UsageSection() {
  const { width: sw } = useWindowDimensions();
  const [usage, setUsage] = useState<UsageMonth>({});

  useEffect(() => {
    loadUsage().then(setUsage).catch(() => {});
  }, []);

  const kinds = Object.keys(usage) as UsageKind[];
  if (kinds.length === 0) return null;
  const small = { color: colors.muted, fontFamily: fonts.regular, fontSize: sw * TYPE.label };

  return (
    <View style={{ marginTop: sw * SPACE.xl }}>
      <Text style={small}>Uso de tokens neste mês</Text>
      {kinds.map((k) => {
        const u = usage[k]!;
        return (
          <Text key={k} style={[small, { marginTop: sw * SPACE.sm }]}>
            {USAGE_LABELS[k]}: {u.calls} {u.calls === 1 ? 'chamada' : 'chamadas'} · {u.input.toLocaleString('pt-BR')} entrada ·{' '}
            {(u.output + u.thoughts).toLocaleString('pt-BR')} saída
          </Text>
        );
      })}
    </View>
  );
}
