import React from 'react';
import { Pressable, StyleProp, Text, View, ViewStyle, useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { BackButton } from './BackButton';
import { colors, fonts, SPACE, TYPE, tracking, HIT } from './theme';

type HeaderProps = {
  /** Sem `onBack`, o botão de voltar não aparece. */
  onBack?: () => void;
  /** Título curto ao lado do voltar (telas com título grande usam `ScreenTitle` no conteúdo). */
  title?: string;
  /** Linha pequena acima do título (ex.: o caminho "Viagens › Japão"). */
  crumb?: string;
  onTitlePress?: () => void;
  /** Ações à direita: use `HeaderAction` para texto e `IconButton` para ícones. */
  right?: React.ReactNode;
  /** Cor do título: `dark` sobre fundo escuro, `light` sobre fundo claro. */
  surface?: 'dark' | 'light';
  /** Unidade de tamanho (padrão: largura da tela; o moodboard usa o lado menor). */
  u?: number;
  style?: StyleProp<ViewStyle>;
  pointerEvents?: 'box-none' | 'auto';
  /** Cabeçalho sobre uma página/imagem de qualquer cor: voltar e ações ganham uma placa escura translúcida. */
  plate?: boolean;
  /** Avisa o tamanho do cabeçalho (para colocar algo logo abaixo dele). */
  onLayout?: (height: number) => void;
};

/**
 * Cabeçalho padrão de tela: voltar à esquerda, título no meio, ações à direita.
 * Mesmas margens e tamanhos em todas as telas; já considera a área segura do topo.
 */
export function ScreenHeader({ onBack, title, crumb, onTitlePress, right, surface = 'dark', u, style, pointerEvents, plate, onLayout }: HeaderProps) {
  const { width } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const unit = u ?? width;
  const fg = surface === 'dark' ? colors.onDark : colors.onLight;
  const titleSize = unit * (crumb ? TYPE.heading : TYPE.title);

  return (
    <View
      pointerEvents={pointerEvents}
      onLayout={onLayout ? (e) => onLayout(e.nativeEvent.layout.height) : undefined}
      style={[
        {
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'space-between',
          paddingTop: insets.top + unit * SPACE.xs * 3,
          paddingHorizontal: unit * SPACE.lg,
          paddingBottom: unit * SPACE.sm,
        },
        style,
      ]}
    >
      {onBack ? (
        plate ? (
          <View style={{ height: unit * 0.11, minWidth: unit * 0.11, borderRadius: unit * 0.055, alignItems: 'center', justifyContent: 'center', paddingHorizontal: unit * 0.015, backgroundColor: colors.overlayButtonStrong }}>
            <BackButton onPress={onBack} u={unit} />
          </View>
        ) : (
          <BackButton onPress={onBack} u={unit} />
        )
      ) : null}
      {title ? (
        <Pressable onPress={onTitlePress} disabled={!onTitlePress} hitSlop={HIT.sm} style={{ flex: 1 }}>
          {!!crumb && (
            <Text numberOfLines={1} style={{ fontFamily: fonts.regular, fontSize: unit * TYPE.caption, color: surface === 'dark' ? colors.muted : colors.subtle }}>
              {crumb}
            </Text>
          )}
          <Text
            numberOfLines={1}
            style={{ fontFamily: fonts.bold, fontSize: titleSize, letterSpacing: tracking(titleSize), color: fg }}
          >
            {title}
          </Text>
        </Pressable>
      ) : (
        <View style={{ flex: 1 }} />
      )}
      {right ? (
        <View
          style={[
            { flexDirection: 'row', alignItems: 'center', gap: unit * 0.055 },
            plate && { height: unit * 0.11, borderRadius: unit * 0.055, paddingHorizontal: unit * 0.04, backgroundColor: colors.overlayButtonStrong },
          ]}
        >
          {right}
        </View>
      ) : null}
    </View>
  );
}

/** Título grande de tela (Fila, Configurações), no mesmo tamanho em todas. */
export function ScreenTitle({ children }: { children: string }) {
  const { width: sw } = useWindowDimensions();
  const size = sw * TYPE.display;
  return (
    <Text style={{ color: colors.text, fontFamily: fonts.black, fontSize: size, letterSpacing: tracking(size) }}>{children}</Text>
  );
}

/** Ação em texto do cabeçalho ("PDF", "Concluído", "Compartilhar"). */
export function HeaderAction({
  label,
  onPress,
  tone = 'default',
  surface = 'dark',
  u,
}: {
  label: string;
  onPress: () => void;
  tone?: 'default' | 'accent';
  surface?: 'dark' | 'light';
  u?: number;
}) {
  const { width } = useWindowDimensions();
  const unit = u ?? width;
  const fg = tone === 'accent' ? colors.red : surface === 'dark' ? colors.onDark : colors.onLight;
  return (
    <Pressable onPress={onPress} hitSlop={HIT.md} accessibilityRole="button">
      <Text style={{ color: fg, fontFamily: fonts.bold, fontSize: unit * TYPE.body, letterSpacing: tracking(unit * TYPE.body, 0.03) }}>{label}</Text>
    </Pressable>
  );
}
