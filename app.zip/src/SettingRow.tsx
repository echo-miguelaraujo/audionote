import React from 'react';
import { Pressable, Text, View, useWindowDimensions } from 'react-native';
import { colors, fonts, LEADING, MIN_TOUCH, SPACE, TYPE } from './theme';

type Common = {
  label: string;
  /** Explicação curta embaixo do rótulo, em cinza. */
  hint?: string;
  onPress: () => void;
  /** Rótulo para o leitor de tela quando o texto da linha é longo demais. */
  accessibilityLabel?: string;
};
type SwitchRow = Common & { checked: boolean; action?: undefined };
type ActionRow = Common & { action: string; checked?: undefined };

/**
 * Linha padrão das Configurações: texto à esquerda e, à direita, "Sim/Não" (interruptor, com `checked`)
 * ou uma ação em vermelho como "Abrir" (com `action`). Sempre com altura mínima de toque.
 */
export function SettingRow(props: SwitchRow | ActionRow) {
  const { width: sw } = useWindowDimensions();
  const isSwitch = props.checked !== undefined;
  const value = isSwitch ? (props.checked ? 'Sim' : 'Não') : props.action;
  const off = isSwitch && !props.checked;

  return (
    <Pressable
      onPress={props.onPress}
      accessibilityRole={isSwitch ? 'switch' : 'button'}
      accessibilityLabel={props.accessibilityLabel ?? props.label}
      accessibilityState={isSwitch ? { checked: props.checked } : undefined}
      style={{
        minHeight: MIN_TOUCH,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        gap: sw * SPACE.md,
      }}
    >
      <View style={{ flex: 1 }}>
        <Text style={{ color: colors.text, fontFamily: fonts.regular, fontSize: sw * TYPE.body, lineHeight: sw * TYPE.body * LEADING }}>
          {props.label}
        </Text>
        {!!props.hint && (
          <Text
            style={{
              marginTop: sw * SPACE.xs,
              color: colors.muted,
              fontFamily: fonts.regular,
              fontSize: sw * TYPE.caption,
              lineHeight: sw * TYPE.caption * LEADING,
            }}
          >
            {props.hint}
          </Text>
        )}
      </View>
      <Text style={{ color: off ? colors.muted : colors.red, fontFamily: fonts.bold, fontSize: sw * TYPE.body }}>{value}</Text>
    </Pressable>
  );
}
