import React from 'react';
import { Pressable, Text, View, useWindowDimensions } from 'react-native';
import { ColorChip, DialogShell, DialogTitle } from './DialogBase';
import { SliderRow } from './SliderRow';
import { TEXT_BOX_MAX, TextBox } from './textBox';
import { colors, fonts, TYPE, SPACE, HIT } from './theme';

type Props = {
  visible: boolean;
  box: TextBox;
  /** Cor de fundo do box (item.color). */
  color: string | null;
  /** Muda o box na hora (sem salvar): para ver o resultado enquanto arrasta. */
  onLive: (b: TextBox) => void;
  /** Salva o box. */
  onSave: (b: TextBox) => void;
  onPickColor: () => void;
  onPickImage: () => void;
  onClose: () => void;
};

/** Texto do moodboard: solto ou dentro de um box, com respiro, cantos, cor e imagem de fundo. */
export function TextBoxDialog({ visible, box, color, onLive, onSave, onPickColor, onPickImage, onClose }: Props) {
  const { width: sw } = useWindowDimensions();
  const seg = (label: string, on: boolean) => (
    <Pressable
      onPress={() => {
        const next = { ...box, on };
        onLive(next);
        onSave(next);
      }}
      hitSlop={HIT.md}
      style={{
        flex: 1,
        alignItems: 'center',
        paddingVertical: sw * SPACE.sm,
        borderRadius: sw * 0.05,
        backgroundColor: box.on === on ? colors.onLight : 'transparent',
        borderWidth: 1,
        borderColor: colors.line,
      }}
    >
      <Text style={{ color: box.on === on ? colors.paper : colors.onLight, fontFamily: fonts.bold, fontSize: sw * TYPE.body }}>{label}</Text>
    </Pressable>
  );
  const row = (label: string, right: React.ReactNode, onPress: () => void) => (
    <Pressable
      onPress={onPress}
      style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: sw * SPACE.lg }}
    >
      <Text style={{ color: colors.onLight, fontFamily: fonts.regular, fontSize: sw * TYPE.body }}>{label}</Text>
      {right}
    </Pressable>
  );
  return (
    <DialogShell visible={visible} onClose={onClose}>
      <DialogTitle>Box do texto</DialogTitle>
      <View style={{ flexDirection: 'row', gap: sw * SPACE.sm, marginTop: sw * SPACE.md }}>
        {seg('Solto', false)}
        {seg('Em box', true)}
      </View>
      {box.on && (
        <>
          <SliderRow
            label="Respiro"
            value={box.pad}
            min={0}
            max={TEXT_BOX_MAX.pad}
            display={String(Math.round((box.pad / TEXT_BOX_MAX.pad) * 100))}
            onChange={(v) => onLive({ ...box, pad: v })}
            onCommit={(v) => onSave({ ...box, pad: v })}
          />
          <SliderRow
            label="Cantos"
            value={box.radius}
            min={0}
            max={TEXT_BOX_MAX.radius}
            display={String(Math.round((box.radius / TEXT_BOX_MAX.radius) * 100))}
            onChange={(v) => onLive({ ...box, radius: v })}
            onCommit={(v) => onSave({ ...box, radius: v })}
          />
          {row(
            'Cor de fundo',
            color ? (
              <ColorChip color={color} bordered />
            ) : (
              <Text style={{ color: colors.subtle, fontFamily: fonts.regular, fontSize: sw * TYPE.body }}>Sem cor</Text>
            ),
            onPickColor
          )}
          {row(
            'Imagem de fundo',
            <Text style={{ color: colors.subtle, fontFamily: fonts.regular, fontSize: sw * TYPE.body }}>
              {box.img ? 'Trocar' : 'Escolher'}
            </Text>,
            onPickImage
          )}
          {box.img && (
            <Pressable
              hitSlop={HIT.md}
              onPress={() => {
                const next = { ...box, img: null };
                onLive(next);
                onSave(next);
              }}
              style={{ marginTop: sw * SPACE.md }}
            >
              <Text style={{ color: colors.red, fontFamily: fonts.bold, fontSize: sw * TYPE.body }}>Remover imagem</Text>
            </Pressable>
          )}
        </>
      )}
    </DialogShell>
  );
}
