import React, { useEffect, useState } from 'react';
import { Pressable, ScrollView, Text, TextInput, useWindowDimensions } from 'react-native';
import { DialogActions, DialogShell, DialogTitle } from './DialogBase';
import { colors, fonts, TYPE, SPACE } from './theme';

export const ASK_MAX = 600;

const EXAMPLES = [
  'Transformar o diálogo em tabela',
  'Resumir em tópicos',
  'Corrigir ortografia e pontuação',
  'Deixar o texto mais claro',
];

type Props = {
  visible: boolean;
  /** Há um trecho selecionado: o pedido vale só para ele. */
  hasSelection: boolean;
  onCancel: () => void;
  onSubmit: (request: string) => void;
};

/** Pedido livre à IA sobre a nota (ou o trecho selecionado). O resultado só entra na nota se a pessoa permitir. */
export function AskAiDialog({ visible, hasSelection, onCancel, onSubmit }: Props) {
  const { width: sw, height: sh } = useWindowDimensions();
  const [value, setValue] = useState('');

  useEffect(() => {
    if (visible) setValue('');
  }, [visible]);

  const empty = !value.trim();

  return (
    <DialogShell visible={visible} onClose={onCancel} keyboard>
      <DialogTitle>Pedir à IA</DialogTitle>
      <Text style={{ color: colors.subtle, fontFamily: fonts.regular, fontSize: sw * TYPE.caption, marginTop: sw * SPACE.xs }}>
        {hasSelection ? 'Vale só para o trecho selecionado.' : 'Vale para a nota inteira.'} Você vê o resultado antes de aplicar.
      </Text>
      <TextInput
        value={value}
        onChangeText={setValue}
        autoFocus
        multiline
        maxLength={ASK_MAX}
        placeholder="O que você quer que a IA faça?"
        accessibilityLabel="Pedido para a IA"
        placeholderTextColor={colors.subtle}
        style={{
          marginTop: sw * SPACE.md,
          minHeight: sw * 0.26,
          maxHeight: sh * 0.25,
          textAlignVertical: 'top',
          color: colors.onLight,
          fontFamily: fonts.regular,
          fontSize: sw * TYPE.body,
          borderWidth: 1,
          borderColor: colors.line,
          borderRadius: sw * 0.03,
          padding: sw * SPACE.sm,
        }}
      />
      <ScrollView horizontal showsHorizontalScrollIndicator={false} keyboardShouldPersistTaps="handled" style={{ marginTop: sw * SPACE.sm, flexGrow: 0 }}>
        {EXAMPLES.map((ex) => (
          <Pressable
            key={ex}
            accessibilityRole="button"
            onPress={() => setValue(ex)}
            style={{ borderWidth: 1, borderColor: colors.line, borderRadius: sw * 0.05, paddingHorizontal: sw * 0.03, paddingVertical: sw * 0.015, marginRight: sw * 0.02 }}
          >
            <Text style={{ color: colors.onLight, fontFamily: fonts.regular, fontSize: sw * TYPE.caption }}>{ex}</Text>
          </Pressable>
        ))}
      </ScrollView>
      <DialogActions onCancel={onCancel} confirmLabel="Pedir" confirmDisabled={empty} onConfirm={() => onSubmit(value.trim())} />
    </DialogShell>
  );
}
