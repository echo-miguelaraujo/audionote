import React, { useState } from 'react';
import { View, useWindowDimensions } from 'react-native';
import { Button } from './Button';
import { StateMessage } from './StateMessage';
import { exportBackup } from './backup';
import { SPACE } from './theme';

type Status = { ok: boolean; text: string };

/** Exportar uma cópia dos dados, com o resultado logo abaixo do botão. */
export function BackupSection() {
  const { width: sw } = useWindowDimensions();
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState<Status | null>(null);

  const run = async () => {
    setBusy(true);
    setStatus(null);
    try {
      setStatus({ ok: true, text: await exportBackup() });
    } catch (e) {
      setStatus({ ok: false, text: 'Não foi possível exportar: ' + String(e) });
    } finally {
      setBusy(false);
    }
  };

  return (
    <View style={{ marginTop: sw * SPACE.xl }}>
      <Button label="Exportar backup" variant="secondary" onPress={run} loading={busy} />
      {status && (
        <StateMessage kind={status.ok ? 'info' : 'error'} style={{ marginTop: sw * SPACE.lg }}>
          {status.text}
        </StateMessage>
      )}
    </View>
  );
}
