// Box do texto do moodboard (sem dependências, para o banco, a sincronização e a tela usarem sem ciclo).

/**
 * Box do texto. `on: false` = texto solto. `pad` e `radius` em fração da largura da tela.
 * Fundo = cor do cartão (item.color) e/ou imagem (`img`, nome do arquivo em media).
 */
export type TextBox = { on: boolean; pad: number; radius: number; img: string | null };
export const TEXT_BOX_DEFAULT = { pad: 0.02, radius: 0.01 };
export const TEXT_BOX_MAX = { pad: 0.12, radius: 0.1 };

/** Lê o box de um texto. Textos antigos com cor continuam como box padrão; sem box nem cor = solto. */
export function parseTextBox(it: { box: string | null; color: string | null }): TextBox {
  if (it.box) {
    try {
      const j = JSON.parse(it.box);
      return {
        on: j.on !== false,
        pad: typeof j.pad === 'number' ? Math.min(Math.max(j.pad, 0), TEXT_BOX_MAX.pad) : TEXT_BOX_DEFAULT.pad,
        radius: typeof j.radius === 'number' ? Math.min(Math.max(j.radius, 0), TEXT_BOX_MAX.radius) : TEXT_BOX_DEFAULT.radius,
        img: typeof j.img === 'string' && j.img ? j.img : null,
      };
    } catch {
      /* JSON ilegível: cai no padrão */
    }
  }
  return { on: !!it.color, ...TEXT_BOX_DEFAULT, img: null };
}
export const stringifyTextBox = (b: TextBox): string => JSON.stringify(b);
