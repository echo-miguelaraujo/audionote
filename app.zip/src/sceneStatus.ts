import { createContext, useContext } from 'react';

/** Um status de cena. A cor `null` usa o vermelho do app. */
export type SceneStatusDef = { label: string; color: string | null };

/** Lista padrão, usada por projetos que ainda não criaram a própria. */
export const DEFAULT_STATUSES: SceneStatusDef[] = [
  { label: 'Ideia', color: null },
  { label: 'Roteirizada', color: '#E0A100' },
  { label: 'Gravada', color: null },
  { label: 'Editada', color: '#2F6FDE' },
  { label: 'Publicada', color: '#2E9E5B' },
];

/** Cores oferecidas ao editar um status. */
export const STATUS_COLORS: (string | null)[] = [null, '#E0A100', '#2F6FDE', '#2E9E5B', '#8E44AD', '#E67E22', '#16A085', '#7F8C8D'];

/** Lê a lista guardada no projeto (JSON). Vazia ou inválida cai no padrão. */
export function parseStatuses(raw: string | null | undefined): SceneStatusDef[] {
  if (!raw) return DEFAULT_STATUSES;
  try {
    const a = JSON.parse(raw);
    if (!Array.isArray(a)) return DEFAULT_STATUSES;
    const out = a
      .filter((s) => s && typeof s.label === 'string' && s.label.trim())
      .map((s) => ({ label: String(s.label).trim().slice(0, 24), color: typeof s.color === 'string' ? s.color : null }));
    return out.length ? out : DEFAULT_STATUSES;
  } catch {
    return DEFAULT_STATUSES;
  }
}

export const stringifyStatuses = (l: SceneStatusDef[]): string => JSON.stringify(l);

/** Status do índice; índice fora da lista (status apagado) cai no primeiro. */
export const statusAt = (list: SceneStatusDef[], i: number): SceneStatusDef => list[i] ?? list[0] ?? DEFAULT_STATUSES[0];

/** Status do projeto aberto. Quem desenha cenas lê daqui, sem receber por propriedade. */
export const SceneStatusContext = createContext<SceneStatusDef[]>(DEFAULT_STATUSES);
export const useSceneStatuses = () => useContext(SceneStatusContext);
