import { Directory, File, Paths } from 'expo-file-system';
import { getDb } from './db';

/**
 * A pasta escolhida no seletor do Android é do tipo "content://" (SAF). Nesse tipo de pasta
 * o File.copy() não funciona; o jeito é ler os bytes do arquivo do app, criar o arquivo
 * no destino e gravar os bytes lá. Isso carrega o arquivo inteiro na memória, então
 * arquivos muito grandes são pulados (e listados no resumo).
 */
const MAX_BYTES = 100 * 1024 * 1024;

/**
 * Tipo genérico de propósito: com um tipo específico (ex.: audio/mp4) o Android pode
 * acrescentar outra extensão ao nome (rec_1.m4a viraria rec_1.m4a.mp4), e as notas
 * encontram os arquivos pelo nome exato.
 */
const GENERIC_MIME = 'application/octet-stream';

const pad = (n: number) => String(n).padStart(2, '0');

/** Data e hora no formato 20261016-1530, para dar nome único à pasta do backup. */
function stamp(): string {
  const d = new Date();
  return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}`;
}

type Dest = Awaited<ReturnType<typeof Directory.pickDirectoryAsync>>;
type Result = { ok: number; failed: string[]; tooBig: string[] };

const nameOf = (f: File): string => decodeURIComponent(f.uri.split('?')[0].split('/').pop() || '');

/** Copia UM arquivo do app para a pasta de destino e confere se o tamanho gravado bate. */
async function copyOne(src: File, dest: Dest, name: string): Promise<void> {
  const bytes = await src.bytes();
  const out = dest.createFile(name, GENERIC_MIME);
  out.write(bytes);
  if (out.size !== bytes.length) throw new Error(`tamanho diferente em ${name}`);
}

/** Copia todos os arquivos de uma pasta do app para a pasta de destino, um de cada vez. */
async function copyFolder(source: Directory, dest: Dest): Promise<Result> {
  const res: Result = { ok: 0, failed: [], tooBig: [] };
  if (!source.exists) return res;
  for (const item of source.list()) {
    if (!(item instanceof File)) continue;
    const name = nameOf(item);
    if (item.size > MAX_BYTES) {
      res.tooBig.push(name);
      continue;
    }
    try {
      await copyOne(item, dest, name);
      res.ok++;
    } catch {
      res.failed.push(name);
    }
  }
  return res;
}

/**
 * Backup completo: banco (ideias.db) + imagens/vídeos/anexos (media) + áudios (audios).
 * O usuário escolhe a pasta de destino (ex.: Downloads) e o app cria dentro dela
 * uma subpasta "ideias-backup-AAAAMMDD-HHMM". Não altera nada nos dados do app.
 */
export async function exportBackup(): Promise<string> {
  // O banco usa o modo WAL: parte dos dados recentes pode estar num arquivo temporário (-wal).
  // O checkpoint passa tudo para o arquivo principal antes de copiar.
  const db = await getDb();
  await db.execAsync('PRAGMA wal_checkpoint(TRUNCATE);');

  const dbFile = new File(new Directory(Paths.document, 'SQLite'), 'ideias.db');
  if (!dbFile.exists) throw new Error('Arquivo do banco (ideias.db) não encontrado.');

  const target = await Directory.pickDirectoryAsync();
  const folderName = `ideias-backup-${stamp()}`;
  const root = target.createDirectory(folderName);

  // O banco é o item essencial: se falhar, o backup inteiro falha.
  await copyOne(dbFile, root, 'ideias.db');

  const media = await copyFolder(new Directory(Paths.document, 'media'), root.createDirectory('media'));
  const audios = await copyFolder(new Directory(Paths.document, 'audios'), root.createDirectory('audios'));

  const problemas = [...media.failed, ...audios.failed];
  const grandes = [...media.tooBig, ...audios.tooBig];

  let msg =
    `Backup salvo na pasta "${folderName}".\n` +
    `Banco: copiado e conferido. Imagens e anexos: ${media.ok}. Áudios: ${audios.ok}.`;
  if (problemas.length > 0) {
    msg += `\nAtenção: ${problemas.length} arquivo(s) falharam: ${problemas.slice(0, 5).join(', ')}${problemas.length > 5 ? '…' : ''}`;
  }
  if (grandes.length > 0) {
    msg += `\nPulados por serem muito grandes (mais de 100 MB): ${grandes.slice(0, 5).join(', ')}${grandes.length > 5 ? '…' : ''}`;
  }
  return msg;
}
