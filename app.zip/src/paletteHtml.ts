/**
 * Página oculta (WebView) que extrai as cores dominantes de imagens, só no aparelho.
 * RN -> página: window.startJob(id) / window.addImage(id, dataUri) / window.finishJob(id, k)
 * página -> RN: JSON { type, id, ok, colors?, err? }
 * Quantização: k-means (com k-means++) em CIELAB, semente fixa => resultado sempre igual para a mesma entrada.
 */
export const PALETTE_HTML = `<!DOCTYPE html><html><head><meta charset="utf-8"></head><body><script>
var pix=[];
function post(o){window.ReactNativeWebView.postMessage(JSON.stringify(o))}
function mulberry32(a){return function(){a|=0;a=a+0x6D2B79F5|0;var t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
function lin(c){c/=255;return c<=0.04045?c/12.92:Math.pow((c+0.055)/1.055,2.4)}
function rgb2lab(r,g,b){var R=lin(r),G=lin(g),B=lin(b);
var X=(0.4124564*R+0.3575761*G+0.1804375*B)/0.95047,Y=0.2126729*R+0.7151522*G+0.0721750*B,Z=(0.0193339*R+0.1191920*G+0.9503041*B)/1.08883;
var f=function(t){return t>0.008856?Math.cbrt(t):7.787*t+16/116};var fx=f(X),fy=f(Y),fz=f(Z);
return[116*fy-16,500*(fx-fy),200*(fy-fz)]}
function lab2rgb(L,a,b){var fy=(L+16)/116,fx=fy+a/500,fz=fy-b/200;
var inv=function(t){var t3=t*t*t;return t3>0.008856?t3:(t-16/116)/7.787};
var X=inv(fx)*0.95047,Y=inv(fy),Z=inv(fz)*1.08883;
var R=3.2404542*X-1.5371385*Y-0.4985314*Z,G=-0.9692660*X+1.8760108*Y+0.0415560*Z,B=0.0556434*X-0.2040259*Y+1.0572252*Z;
var g=function(c){c=Math.max(0,Math.min(1,c));c=c<=0.0031308?12.92*c:1.055*Math.pow(c,1/2.4)-0.055;return Math.round(c*255)};
return[g(R),g(G),g(B)]}
function hex(rgb){return '#'+rgb.map(function(v){return ('0'+v.toString(16)).slice(-2)}).join('').toUpperCase()}
function d2(L,A,B,c){var x=L-c[0],y=A-c[1],z=B-c[2];return x*x+y*y+z*z}
function quantize(k){
  var n=pix.length/3;if(n<1)return null;
  var L=new Float32Array(n),A=new Float32Array(n),B=new Float32Array(n),i,j;
  for(i=0;i<n;i++){var lab=rgb2lab(pix[i*3],pix[i*3+1],pix[i*3+2]);L[i]=lab[0];A[i]=lab[1];B[i]=lab[2]}
  var K=Math.min(k+3,n),rnd=mulberry32(1234),cent=[];
  var first=Math.floor(rnd()*n);cent.push([L[first],A[first],B[first]]);
  var dist=new Float32Array(n);
  for(i=0;i<n;i++)dist[i]=d2(L[i],A[i],B[i],cent[0]);
  while(cent.length<K){
    var sum=0;for(i=0;i<n;i++)sum+=dist[i];
    if(sum<=0)break;
    var r=rnd()*sum,pick=n-1;
    for(i=0;i<n;i++){r-=dist[i];if(r<=0){pick=i;break}}
    var c=[L[pick],A[pick],B[pick]];cent.push(c);
    for(i=0;i<n;i++){var dd=d2(L[i],A[i],B[i],c);if(dd<dist[i])dist[i]=dd}
  }
  K=cent.length;
  var asg=new Int32Array(n),cnt=new Float64Array(K);
  function assign(){
    for(j=0;j<K;j++)cnt[j]=0;
    for(i=0;i<n;i++){var best=0,bd=Infinity;
      for(j=0;j<K;j++){var dv=d2(L[i],A[i],B[i],cent[j]);if(dv<bd){bd=dv;best=j}}
      asg[i]=best;cnt[best]++}
  }
  for(var it=0;it<10;it++){
    assign();
    var s=[];for(j=0;j<K;j++)s.push([0,0,0]);
    for(i=0;i<n;i++){var a=asg[i];s[a][0]+=L[i];s[a][1]+=A[i];s[a][2]+=B[i]}
    for(j=0;j<K;j++)if(cnt[j]>0)cent[j]=[s[j][0]/cnt[j],s[j][1]/cnt[j],s[j][2]/cnt[j]];
  }
  assign();
  var cl=[];
  for(j=0;j<K;j++)if(cnt[j]>=n*0.02)cl.push({c:cent[j],n:cnt[j]});
  if(cl.length===0){var bj=0;for(j=1;j<K;j++)if(cnt[j]>cnt[bj])bj=j;cl.push({c:cent[bj],n:cnt[bj]})}
  cl.sort(function(p,q){return q.n-p.n});
  var kept=[];
  for(i=0;i<cl.length;i++){
    var m=-1;
    for(j=0;j<kept.length;j++){if(Math.sqrt(d2(cl[i].c[0],cl[i].c[1],cl[i].c[2],kept[j].c))<12){m=j;break}}
    if(m<0)kept.push({c:cl[i].c.slice(),n:cl[i].n});
    else{var t=kept[m],tot=t.n+cl[i].n;
      t.c=[(t.c[0]*t.n+cl[i].c[0]*cl[i].n)/tot,(t.c[1]*t.n+cl[i].c[1]*cl[i].n)/tot,(t.c[2]*t.n+cl[i].c[2]*cl[i].n)/tot];t.n=tot}
  }
  kept.sort(function(p,q){return q.n-p.n});
  return kept.slice(0,k).map(function(o){return hex(lab2rgb(o.c[0],o.c[1],o.c[2]))});
}
window.startJob=function(id){pix=[];post({type:'step',id:id,ok:true})};
window.addImage=function(id,uri){
  var im=new Image();
  im.onload=function(){
    try{
      var w=im.naturalWidth,h=im.naturalHeight;
      if(!w||!h){post({type:'step',id:id,ok:false,err:'imagem vazia'});return}
      var s=64/Math.max(w,h),cw=Math.max(1,Math.round(w*s)),ch=Math.max(1,Math.round(h*s));
      var c=document.createElement('canvas');c.width=cw;c.height=ch;
      var x=c.getContext('2d');x.drawImage(im,0,0,cw,ch);
      var d=x.getImageData(0,0,cw,ch).data;
      for(var i=0;i<d.length;i+=4){if(d[i+3]<128)continue;pix.push(d[i],d[i+1],d[i+2])}
      post({type:'step',id:id,ok:true});
    }catch(e){post({type:'step',id:id,ok:false,err:String(e)})}
  };
  im.onerror=function(){post({type:'step',id:id,ok:false,err:'não abriu a imagem'})};
  im.src=uri;
};
window.finishJob=function(id,k){
  try{var cols=quantize(k);post({type:'done',id:id,ok:!!cols,colors:cols||[],err:cols?undefined:'sem pixels'})}
  catch(e){post({type:'done',id:id,ok:false,err:String(e)})}
  pix=[];
};
post({type:'ready'});
</script></body></html>`;
