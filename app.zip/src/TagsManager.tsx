import React, { useCallback, useEffect, useState } from 'react';
import { Pressable, ScrollView, Text, View, useWindowDimensions } from 'react-native';
import { appAlert, appError } from './dialog';
import { DialogAction, DialogShell, DialogTitle } from './DialogBase';
import { PromptDialog } from './PromptDialog';
import { deleteTagEverywhere, listBlocks, renameTagEverywhere } from './db';
import { tagStats } from './libraryFilters';
import { normalizeTag, tagKey } from './tags';
import { colors, fonts, SPACE, TYPE, HIT } from './theme';

type Stat = { key: string; name: string; count: number };

/** Gerenciar tags: renomear (mesclando se o nome já existir) e apagar de todas as notas. */
export function TagsManager({ visible, onClose, onChanged }: { visible: boolean; onClose: () => void; onChanged?: () => void }) {
  const { width: sw, height: sh } = useWindowDimensions();
  const [stats, setStats] = useState<Stat[]>([]);
  const [renaming, setRenaming] = useState<Stat | null>(null);

  const load = useCallback(async () => {
    setStats(tagStats(await listBlocks()));
  }, []);

  useEffect(() => {
    if (visible) load().catch(() => {});
  }, [visible, load]);

  const done = () => {
    load().catch(() => {});
    onChanged?.();
  };

  const rename = async (from: Stat, raw: string) => {
    const to = normalizeTag(raw);
    if (!to || to === from.name) return;
    const other = stats.find((s) => s.key === tagKey(to) && s.key !== from.key);
    const go = async () => {
      await renameTagEverywhere(from.name, to);
      done();
    };
    if (other) {
      appAlert('Mesclar tags?', `Já existe «${other.name}». As notas de «${from.name}» passam a ter «${other.name}».`, [
        { text: 'Cancelar', style: 'cancel' },
        { text: 'Mesclar', onPress: () => go().catch((e) => appError('Erro', e)) },
      ]);
    } else await go();
  };

  const remove = (t: Stat) =>
    appAlert('Excluir tag?', `«${t.name}» será removida de ${t.count} ${t.count === 1 ? 'nota' : 'notas'}.`, [
      { text: 'Cancelar', style: 'cancel' },
      {
        text: 'Excluir',
        style: 'destructive',
        onPress: async () => {
          try {
            await deleteTagEverywhere(t.name);
          } catch (e) {
            appError('Erro', e);
          }
          done();
        },
      },
    ]);

  return (
    <>
    <DialogShell visible={visible} onClose={onClose} maxHeight={sh * 0.8}>
      <DialogTitle>Tags</DialogTitle>
      <ScrollView style={{ maxHeight: sh * 0.55 }}>
        {stats.length === 0 && (
          <Text style={{ color: colors.subtle, fontFamily: fonts.regular, fontSize: sw * TYPE.body }}>
            Nenhuma tag ainda. Crie na nota ou no menu da Biblioteca.
          </Text>
        )}
        {stats.map((t) => (
          <View key={t.key} style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: sw * SPACE.md, gap: sw * SPACE.md }}>
            <Text style={{ flex: 1, color: colors.onLight, fontFamily: fonts.regular, fontSize: sw * TYPE.body }} numberOfLines={1}>
              {t.name}
            </Text>
            <Text style={{ color: colors.subtle, fontFamily: fonts.regular, fontSize: sw * TYPE.label }}>{t.count}</Text>
            <Pressable onPress={() => setRenaming(t)} hitSlop={HIT.md} accessibilityRole="button" accessibilityLabel={`Renomear ${t.name}`}>
              <Text style={{ color: colors.onLight, fontFamily: fonts.bold, fontSize: sw * TYPE.label }}>Renomear</Text>
            </Pressable>
            <Pressable onPress={() => remove(t)} hitSlop={HIT.md} accessibilityRole="button" accessibilityLabel={`Apagar ${t.name}`}>
              <Text style={{ color: colors.red, fontFamily: fonts.bold, fontSize: sw * TYPE.label }}>Apagar</Text>
            </Pressable>
          </View>
        ))}
      </ScrollView>
      <View style={{ alignItems: 'flex-end', marginTop: sw * SPACE.lg }}>
        <DialogAction label="Fechar" onPress={onClose} />
      </View>
    </DialogShell>
      <PromptDialog
        visible={renaming !== null}
        title="Renomear tag"
        initialValue={renaming?.name ?? ''}
        onCancel={() => setRenaming(null)}
        onSubmit={(v) => {
          const t = renaming;
          setRenaming(null);
          if (t) rename(t, v).catch((e) => appError('Erro', e));
        }}
      />
    </>
  );
}
