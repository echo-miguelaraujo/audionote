import * as Print from 'expo-print';
import { inlineImage, safeFileName, shareCachedCopy } from './exportPdf';
import { mediaUri } from './media';
import { escapeHtml } from './note';
import { DEFAULT_STATUSES, SceneStatusDef, statusAt } from './sceneStatus';

/** Roteiro das cenas em PDF: uma cena por página (capa, título, status e campos de produção), na ordem dos números. */
/** Uma cena como o roteiro em PDF a lê. */
export type ShowScene = {
  id: number;
  number: number;
  name: string;
  cover: string | null;
  status: number;
  desc: string;
  place: string;
  emotion: string;
  duration: string;
  shot: string;
  dialogue: string;
  date: string;
};

export async function shareSceneScriptPdf(title: string, scenes: ShowScene[], statuses: SceneStatusDef[] = DEFAULT_STATUSES): Promise<void> {
  const pages: string[] = [];
  for (const s of scenes) {
    const img = s.cover ? await inlineImage(mediaUri(s.cover)) : '';
    const rows = (
      [
        ['Local', s.place],
        ['Emoção', s.emotion],
        ['Plano', s.shot],
        ['Duração', s.duration],
        ['Data de gravação', s.date],
      ] as [string, string][]
    )
      .filter(([, v]) => !!v)
      .map(([k, v]) => `<tr><th>${k}</th><td>${escapeHtml(v)}</td></tr>`)
      .join('');
    pages.push(`<section>
<div class="n">Cena ${s.number} · ${statusAt(statuses, s.status).label}</div>
<h1>${escapeHtml(s.name || `Cena ${s.number}`)}</h1>
${img ? `<img src="${img}">` : ''}
${s.desc ? `<p>${escapeHtml(s.desc).replace(/\n/g, '<br>')}</p>` : ''}
${rows ? `<table>${rows}</table>` : ''}
${s.dialogue ? `<h2>Falas</h2><p class="d">${escapeHtml(s.dialogue).replace(/\n/g, '<br>')}</p>` : ''}
</section>`);
  }
  const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><style>
*{-webkit-print-color-adjust:exact;print-color-adjust:exact}
body{font-family:Arial,Helvetica,sans-serif;color:#111;margin:0}
section{page-break-after:always;break-after:page;padding:8px 4px}
section:last-child{page-break-after:auto;break-after:auto}
.n{font-size:12px;color:#666;text-transform:uppercase;letter-spacing:.06em}
h1{font-size:26px;margin:4px 0 12px}h2{font-size:15px;margin:16px 0 4px}
img{max-width:100%;max-height:340px;object-fit:contain;border-radius:6px;display:block;margin:0 0 12px}
p{font-size:14px;line-height:1.5;margin:0 0 10px}.d{font-style:italic}
table{border-collapse:collapse;font-size:13px}th{text-align:left;padding:3px 14px 3px 0;color:#666;font-weight:600}td{padding:3px 0}
</style></head><body>${pages.join('') || '<p>Sem cenas.</p>'}</body></html>`;
  const { uri } = await Print.printToFileAsync({ html });
  await shareCachedCopy(uri, `${safeFileName(title, 'Roteiro')}_cenas.pdf`, 'application/pdf', 'Exportar roteiro das cenas', 'com.adobe.pdf');
}
