import React, { useEffect, useRef } from 'react';
import { View } from 'react-native';
import type { Block, MoodCollection, MoodItem } from './db';
import { ItemView } from './ItemView';
import { parseLink } from './linkPreview';
import { parseVideo } from './videoData';
import type { Rect } from './boardGeometry';
import { DotGrid } from './DotGrid';

const noopSize = () => {};

type Props = {
  /** Itens já com x/y relativos ao canto da área (e rot = 0 se for para endireitar). */
  items: MoodItem[];
  /** Área, em unidades; só w e h importam aqui. */
  rect: Rect;
  /** Unidade do quadro em px (lado menor da tela). */
  u: number;
  subs: Record<number, MoodCollection>;
  notes: Record<number, Block>;
  layerRef: React.RefObject<View | null>;
  /** Chamado uma vez, quando as imagens carregaram e o desenho assentou. */
  onReady: () => void;
  /** true = fundo branco com a grade de pontinhos (imagens 16:9 / 9:16). Sem isso, fundo transparente. */
  background?: boolean;
};

/**
 * Os mesmos ItemView do quadro, sem câmera; fundo transparente (ou, com `background`, a grade de pontinhos), na origem (0,0) da tela.
 * Fica por baixo do aviso opaco "Gerando imagem…". A captura é feita por quem a monta (via layerRef).
 */
export function ExportLayer({ items, rect, u, subs, notes, layerRef, onReady, background }: Props) {
  const loaded = useRef(new Set<number>());
  const done = useRef(false);
  const readyRef = useRef(onReady);
  readyRef.current = onReady;

  const finish = (delay: number) => {
    if (done.current) return;
    done.current = true;
    // Folga para o que não avisa quando carrega (capas das coleções, fontes) e para o layout assentar.
    setTimeout(() => readyRef.current(), delay);
  };

  const expected = useRef(
    new Set(
      items
        .filter(
          (i) =>
            i.kind === 'image' ||
            (i.kind === 'link' && !!parseLink(i.content).img) ||
            (i.kind === 'video' && !!parseVideo(i.content).poster)
        )
        .map((i) => i.id)
    )
  ).current;

  useEffect(() => {
    if (expected.size === 0) finish(350);
    const t = setTimeout(() => finish(0), 8000); // nunca fica preso esperando uma imagem
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onLoaded = (id: number) => {
    loaded.current.add(id);
    if (loaded.current.size >= expected.size) finish(350);
  };

  return (
    <View
      ref={layerRef}
      collapsable={false}
      pointerEvents="none"
      style={{ position: 'absolute', left: 0, top: 0, width: rect.w * u, height: rect.h * u, overflow: 'hidden' }}
    >
      {background && <DotGrid width={rect.w * u} height={rect.h * u} />}
      {items.map((it) => (
        <ItemView
          key={it.id}
          item={it}
          sw={u}
          selected={false}
          live={null}
          col={it.kind === 'collection' ? subs[Number(it.content)] : undefined}
          note={it.kind === 'note' ? notes[Number(it.content)] : undefined}
          onSize={noopSize}
          onLoaded={onLoaded}
        />
      ))}
    </View>
  );
}
