import React, { useMemo } from 'react';
import { FlatList, Image, Pressable, Text, View, useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import type { Block } from './db';
import { mediaUri } from './media';
import { colors, fonts, SPACE, TYPE } from './theme';

export const PIN_MARK = '◆ ';

type Props = {
  blocks: Block[];
  /** Espaço no topo (cabeçalho da Biblioteca). */
  top: number;
  colorOf: (categoryId: number | null) => string | null;
  /** Trecho de busca por nota (opcional). */
  snippetOf?: (b: Block) => string;
  onOpen: (b: Block) => void;
  onLongPress: (b: Block) => void;
  emptyText: string;
};

/** Biblioteca em grade: 2 colunas em retrato, 3–4 em paisagem, com a capa de cada nota. */
export function LibraryGrid({ blocks, top, colorOf, snippetOf, onOpen, onLongPress, emptyText }: Props) {
  const { width } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const cols = width >= 900 ? 4 : width >= 600 ? 3 : 2;
  const gap = width * SPACE.md;
  const cardW = (width - gap * (cols + 1)) / cols;
  const coverH = cardW * 0.62;

  const data = useMemo(() => blocks, [blocks]);

  return (
    <FlatList
      key={cols}
      data={data}
      numColumns={cols}
      keyExtractor={(b) => String(b.id)}
      initialNumToRender={8}
      windowSize={7}
      contentContainerStyle={{ paddingTop: top, paddingHorizontal: gap / 2, paddingBottom: insets.bottom + width * 0.3 }}
      ListEmptyComponent={
        <Text style={{ color: colors.muted, fontFamily: fonts.regular, fontSize: width * TYPE.body, textAlign: 'center', marginTop: width * 0.2 }}>
          {emptyText}
        </Text>
      }
      renderItem={({ item: b }) => {
        const cat = colorOf(b.categoryId);
        const title = `${b.pinned ? PIN_MARK : ''}${b.favorite ? '★ ' : ''}${b.noteTitle || (b.pendingCount > 0 ? 'Transcrevendo…' : b.name)}`;
        const sub = snippetOf?.(b) || b.preview || (b.pendingCount > 0 ? 'Aguardando a transcrição…' : 'Nota vazia');
        return (
          <Pressable
            accessibilityRole="button"
            accessibilityLabel={title}
            onPress={() => onOpen(b)}
            onLongPress={() => onLongPress(b)}
            style={{ width: cardW, marginHorizontal: gap / 2, marginBottom: gap }}
          >
            {b.cover ? (
              <Image source={{ uri: mediaUri(b.cover) }} resizeMode="cover" style={{ width: cardW, height: coverH, borderRadius: width * 0.03, backgroundColor: colors.surface }} />
            ) : (
              <View style={{ width: cardW, height: coverH, borderRadius: width * 0.03, backgroundColor: cat ?? colors.surface, alignItems: 'center', justifyContent: 'center' }}>
                <Text style={{ color: cat ? colors.onLight : colors.muted, fontFamily: fonts.bold, fontSize: width * 0.09 }}>
                  {(b.noteTitle || b.name).trim().charAt(0).toUpperCase()}
                </Text>
              </View>
            )}
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: width * SPACE.sm, marginTop: width * SPACE.sm }}>
              {cat && <View style={{ width: width * 0.012, height: width * 0.04, backgroundColor: cat }} />}
              <Text numberOfLines={2} style={{ flex: 1, color: colors.text, fontFamily: fonts.bold, fontSize: width * TYPE.label }}>
                {title}
              </Text>
            </View>
            {!!b.parentTitle && (
              <Text numberOfLines={1} style={{ color: colors.red, fontFamily: fonts.regular, fontSize: width * TYPE.caption }}>
                {`em ${b.parentTitle}`}
              </Text>
            )}
            <Text numberOfLines={2} style={{ color: colors.mutedLight, fontFamily: fonts.light, fontSize: width * TYPE.caption }}>
              {sub}
            </Text>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: width * 0.015, marginTop: width * 0.01 }}>
              {b.taskTotal > 0 && (
                <Text style={{ color: colors.mutedLight, fontFamily: fonts.regular, fontSize: width * TYPE.caption }}>
                  {`${b.taskDone}/${b.taskTotal}`}
                </Text>
              )}
              {b.tags.slice(0, 2).map((t) => (
                <Text key={t} style={{ color: colors.muted, fontFamily: fonts.regular, fontSize: width * TYPE.caption }}>{`#${t}`}</Text>
              ))}
              {b.tags.length > 2 && (
                <Text style={{ color: colors.muted, fontFamily: fonts.regular, fontSize: width * TYPE.caption }}>{`+${b.tags.length - 2}`}</Text>
              )}
            </View>
          </Pressable>
        );
      }}
    />
  );
}
