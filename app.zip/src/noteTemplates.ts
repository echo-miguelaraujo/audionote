import { escapeHtml } from './note';

export type NoteTemplate = { id: string; name: string; title: string; html: string };

const todo = (items: string[]) =>
  `<ul class="todo">${items.map((t) => `<li data-done="false">${escapeHtml(t)}</li>`).join('')}</ul>`;

/** Modelos prontos. {data} vira a data por extenso na hora de criar a nota. */
export const BUILTIN_TEMPLATES: NoteTemplate[] = [
  {
    id: 'meeting',
    name: 'Reunião',
    title: 'Reunião – {data}',
    html:
      '<h2>Participantes</h2><p><br></p>' +
      '<h2>Pauta</h2><ul><li><br></li></ul>' +
      '<h2>Decisões</h2><p><br></p>' +
      '<h2>Próximos passos</h2>' +
      todo(['', '']),
  },
  {
    id: 'tasks',
    name: 'Lista de tarefas / compras',
    title: 'Lista',
    html: todo(['Item 1', 'Item 2', 'Item 3']),
  },
  {
    id: 'diary',
    name: 'Diário / reflexão do dia',
    title: '{data}',
    html:
      '<h2>Como foi o dia?</h2><p><br></p>' +
      '<h2>O que aprendi?</h2><p><br></p>' +
      '<h2>Pelo que sou grato?</h2><p><br></p>' +
      '<h2>Prioridades de amanhã</h2>' +
      todo(['']),
  },
];

/** Data por extenso em português, ex.: "domingo, 18 de outubro de 2026". */
export function longDate(d = new Date()): string {
  const days = ['domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado'];
  const months = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
  return `${days[d.getDay()]}, ${d.getDate()} de ${months[d.getMonth()]} de ${d.getFullYear()}`;
}

export const resolvePlaceholders = (t: string, d = new Date()): string => t.split('{data}').join(longDate(d));

/** Conteúdo (note_json) de uma nota nova feita a partir de um modelo pronto. */
export function templateToNoteJson(t: NoteTemplate): string {
  return JSON.stringify({ v: 2, title: resolvePlaceholders(t.title), cover: null, html: resolvePlaceholders(t.html) });
}

/** Conteúdo para salvar como modelo do usuário: cartões de subnota viram só o título em texto; links de nota ficam. */
export function noteJsonForTemplate(noteJson: string): string {
  try {
    const n = JSON.parse(noteJson);
    n.html = String(n.html ?? '').replace(
      /<div\b[^>]*class="[^"]*\bsubnote\b[^"]*"[^>]*>\s*<span\b[^>]*>([\s\S]*?)<\/span>\s*<\/div>/gi,
      '<p>$1</p>'
    );
    return JSON.stringify(n);
  } catch {
    return noteJson;
  }
}

/** Dados de uma nota criada a partir de um modelo do usuário (resolve {data} também). */
export function userTemplateToNoteJson(noteJson: string): string {
  try {
    const n = JSON.parse(noteJson);
    return JSON.stringify({ ...n, title: resolvePlaceholders(String(n.title ?? '')), html: resolvePlaceholders(String(n.html ?? '')) });
  } catch {
    return noteJson;
  }
}
