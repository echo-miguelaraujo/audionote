import React, { useEffect, useState } from 'react';
import { appAlert } from './dialog';
import {
  ActivityIndicator,
  BackHandler,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  useWindowDimensions,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { AppearanceSection } from './AppearanceSection';
import { Background } from './Background';
import { SyncSection } from './SyncSection';
import { RestructureDialog } from './RestructureDialog';
import { Button } from './Button';
import { ScreenHeader, ScreenTitle } from './ScreenHeader';
import { StateMessage } from './StateMessage';
import { exportBackup } from './backup';
import { CalOption, ensureCalendarPermission, listWritableCalendars, removeCreatedEvent } from './calendar';
import { CalendarRecord, listRecentCalendarRecords } from './db';
import { formatDateTime } from './format';
import { listModels, testConnection } from './gemini';
import {
  DEFAULT_MODEL,
  getCalendarAuto,
  getCalendarId,
  getDeleteAfter,
  loadGeminiSettings,
  saveGeminiSettings,
  setCalendarAuto,
  setCalendarId,
  setDeleteAfter,
} from './settings';
import { colors, fonts, TYPE, SPACE } from './theme';

type Props = { onClose: () => void };

export function SettingsScreen({ onClose }: Props) {
  const { width: sw } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const [apiKey, setApiKey] = useState('');
  const [model, setModel] = useState(DEFAULT_MODEL);
  const [showKey, setShowKey] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [busy, setBusy] = useState<'test' | 'models' | 'backup' | null>(null);
  const [status, setStatus] = useState<{ ok: boolean; text: string } | null>(null);
  const [models, setModels] = useState<string[]>([]);
  const [delAfter, setDelAfter] = useState(false);
  const [organizeAll, setOrganizeAll] = useState(false);
  const [calAuto, setCalAuto] = useState(true);
  const [calId, setCalIdState] = useState<string | null>(null);
  const [cals, setCals] = useState<CalOption[] | null>(null);
  const [records, setRecords] = useState<CalendarRecord[]>([]);

  useEffect(() => {
    loadGeminiSettings()
      .then((s) => {
        setApiKey(s.apiKey);
        setModel(s.model);
      })
      .finally(() => setLoaded(true));
    getDeleteAfter().then(setDelAfter).catch(() => {});
    getCalendarAuto().then(setCalAuto).catch(() => {});
    getCalendarId().then(setCalIdState).catch(() => {});
    listRecentCalendarRecords(8).then(setRecords).catch(() => {});
  }, []);

  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      onClose();
      return true;
    });
    return () => sub.remove();
  }, [onClose]);

  const save = async () => {
    await saveGeminiSettings({ apiKey, model });
    setStatus({ ok: true, text: 'Salvo no celular.' });
  };

  const test = async () => {
    setBusy('test');
    setStatus(null);
    const r = await testConnection(apiKey, model);
    setStatus({ ok: r.ok, text: r.message });
    if (r.ok) await saveGeminiSettings({ apiKey, model });
    setBusy(null);
  };

  const fetchModels = async () => {
    setBusy('models');
    setStatus(null);
    const r = await listModels(apiKey);
    if (r.ok) {
      setModels(r.models);
      if (r.models.length === 0) setStatus({ ok: false, text: 'Nenhum modelo disponível para esta chave.' });
    } else {
      setStatus({ ok: false, text: r.message });
    }
    setBusy(null);
  };

  const toggleCalendar = async () => {
    const v = !calAuto;
    if (v && !(await ensureCalendarPermission())) {
      appAlert('Permissão necessária', 'Permita o acesso à agenda nas configurações do Android para criar compromissos.');
      return;
    }
    setCalAuto(v);
    await setCalendarAuto(v);
  };

  const chooseCalendar = async () => {
    if (!(await ensureCalendarPermission())) {
      appAlert('Permissão necessária', 'Permita o acesso à agenda nas configurações do Android.');
      return;
    }
    try {
      const list = await listWritableCalendars();
      setCals(list);
      if (list.length === 0) appAlert('Nenhuma agenda', 'Não encontrei agendas que aceitem novos compromissos neste celular.');
    } catch (e) {
      appAlert('Erro ao ler as agendas', String(e));
    }
  };

  const removeRecord = (r: CalendarRecord) =>
    appAlert('Remover compromisso?', `"${r.title}" será apagado também da agenda do celular.`, [
      { text: 'Cancelar', style: 'cancel' },
      {
        text: 'Remover',
        style: 'destructive',
        onPress: async () => {
          await removeCreatedEvent(r);
          setRecords(await listRecentCalendarRecords(8));
        },
      },
    ]);

  const runBackup = async () => {
    setBusy('backup');
    setStatus(null);
    try {
      setStatus({ ok: true, text: await exportBackup() });
    } catch (e) {
      setStatus({ ok: false, text: 'Não foi possível exportar: ' + String(e) });
    } finally {
      setBusy(null);
    }
  };

  const label = sw * 0.04;
  const input = sw * 0.048;

  const button = (text: string, onPress: () => void, loading = false, primary = true) => (
    <Button
      label={text}
      onPress={onPress}
      variant={primary ? 'primary' : 'secondary'}
      loading={loading}
      disabled={busy !== null && !loading}
    />
  );

  return (
    <View style={styles.root}>
      <Background />
      <ScreenHeader onBack={onClose} />

      <ScrollView
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={{
          paddingHorizontal: sw * SPACE.xl,
          paddingTop: sw * SPACE.lg,
          paddingBottom: insets.bottom + sw * 0.2,
        }}
      >
        <ScreenTitle>Configurações</ScreenTitle>

        <SyncSection />

        <Text style={[styles.label, { fontSize: label, marginTop: sw * 0.09 }]}>Chave da API do Gemini</Text>
        <View style={styles.row}>
          <TextInput
            value={apiKey}
            onChangeText={setApiKey}
            editable={loaded}
            secureTextEntry={!showKey}
            autoCapitalize="none"
            autoCorrect={false}
            autoComplete="off"
            spellCheck={false}
            placeholder="Cole a chave aqui"
            placeholderTextColor={colors.muted}
            style={[styles.input, { fontSize: input, flex: 1 }]}
          />
          <Pressable onPress={() => setShowKey((v) => !v)} hitSlop={12}>
            <Text style={{ color: colors.muted, fontFamily: fonts.regular, fontSize: label }}>
              {showKey ? 'Ocultar' : 'Mostrar'}
            </Text>
          </Pressable>
        </View>

        <Text style={[styles.label, { fontSize: label, marginTop: sw * SPACE.xl }]}>Modelo</Text>
        <TextInput
          value={model}
          onChangeText={setModel}
          editable={loaded}
          autoCapitalize="none"
          autoCorrect={false}
          autoComplete="off"
          spellCheck={false}
          style={[styles.input, { fontSize: input }]}
        />

        {models.length > 0 && (
          <View style={{ marginTop: sw * SPACE.md }}>
            {models.map((m) => (
              <Pressable
                key={m}
                onPress={() => {
                  setModel(m);
                  setModels([]);
                }}
                style={{ paddingVertical: sw * SPACE.sm }}
              >
                <Text
                  style={{
                    color: m === model ? colors.red : colors.text,
                    fontFamily: fonts.regular,
                    fontSize: sw * TYPE.body,
                  }}
                >
                  {m}
                </Text>
              </Pressable>
            ))}
          </View>
        )}

        <Pressable
          onPress={async () => {
            const v = !delAfter;
            setDelAfter(v);
            await setDeleteAfter(v);
          }}
          style={{ marginTop: sw * SPACE.xl, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 16 }}
        >
          <Text style={{ flex: 1, color: colors.text, fontFamily: fonts.regular, fontSize: sw * TYPE.label, lineHeight: sw * 0.058 }}>
            Apagar o áudio depois de transcrito
          </Text>
          <Text style={{ color: delAfter ? colors.red : colors.muted, fontFamily: fonts.bold, fontSize: sw * TYPE.body }}>
            {delAfter ? 'Sim' : 'Não'}
          </Text>
        </Pressable>


        <Pressable
          onPress={() => toggleCalendar().catch(() => {})}
          style={{ marginTop: sw * SPACE.xl, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 16 }}
        >
          <Text style={{ flex: 1, color: colors.text, fontFamily: fonts.regular, fontSize: sw * TYPE.label, lineHeight: sw * 0.058 }}>
            Criar compromissos na agenda quando eu citar uma data no áudio
          </Text>
          <Text style={{ color: calAuto ? colors.red : colors.muted, fontFamily: fonts.bold, fontSize: sw * TYPE.body }}>
            {calAuto ? 'Sim' : 'Não'}
          </Text>
        </Pressable>

        {calAuto && (
          <View style={{ marginTop: sw * SPACE.md }}>
            <Pressable onPress={() => chooseCalendar().catch(() => {})} hitSlop={8}>
              <Text style={{ color: colors.muted, fontFamily: fonts.regular, fontSize: label }}>
                Agenda usada: {cals?.find((c) => c.id === calId)?.title ?? (calId ? 'escolhida' : 'automática (Google)')} · Trocar
              </Text>
            </Pressable>
            {cals && cals.length > 0 && (
              <View style={{ marginTop: sw * SPACE.sm }}>
                {cals.map((c) => (
                  <Pressable
                    key={c.id}
                    onPress={async () => {
                      setCalIdState(c.id);
                      await setCalendarId(c.id);
                      setCals(null);
                    }}
                    style={{ paddingVertical: sw * SPACE.sm }}
                  >
                    <Text style={{ color: c.id === calId ? colors.red : colors.text, fontFamily: fonts.regular, fontSize: sw * TYPE.body }}>
                      {c.title}
                      {c.account ? `  (${c.account})` : ''}
                    </Text>
                  </Pressable>
                ))}
              </View>
            )}
          </View>
        )}

        {records.length > 0 && (
          <View style={{ marginTop: sw * SPACE.lg }}>
            <Text style={{ color: colors.muted, fontFamily: fonts.regular, fontSize: label }}>Criados pelo app (toque para remover)</Text>
            {records.map((r) => (
              <Pressable key={r.id} onPress={() => removeRecord(r)} style={{ paddingVertical: sw * SPACE.sm }}>
                <Text style={{ color: colors.text, fontFamily: fonts.regular, fontSize: sw * TYPE.label }}>{r.title}</Text>
                <Text style={{ color: colors.muted, fontFamily: fonts.regular, fontSize: sw * TYPE.caption }}>
                  {r.allDay ? formatDateTime(r.startAt).slice(0, 10) : formatDateTime(r.startAt)}
                </Text>
              </Pressable>
            ))}
          </View>
        )}

        <Pressable
          onPress={() => setOrganizeAll(true)}
          style={{ marginTop: sw * SPACE.xl, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 16 }}
        >
          <Text style={{ flex: 1, color: colors.text, fontFamily: fonts.regular, fontSize: sw * TYPE.label, lineHeight: sw * 0.058 }}>
            Organizar notas existentes (citações, listas e subtítulos). Você escolhe o que aplicar.
          </Text>
          <Text style={{ color: colors.red, fontFamily: fonts.bold, fontSize: sw * TYPE.body }}>Abrir</Text>
        </Pressable>
        <RestructureDialog visible={organizeAll} blockIds="all" onClose={() => setOrganizeAll(false)} />

        <AppearanceSection />

        <View style={{ marginTop: sw * 0.09, gap: sw * SPACE.sm }}>
          {button('Testar conexão', test, busy === 'test')}
          {button('Ver modelos', fetchModels, busy === 'models', false)}
          {button('Salvar', save, false, false)}
          {button('Exportar backup', runBackup, busy === 'backup', false)}
        </View>

        {status && (
          <StateMessage kind={status.ok ? 'info' : 'error'} style={{ marginTop: sw * SPACE.lg }}>
            {status.text}
          </StateMessage>
        )}

        <Text
          style={{
            marginTop: sw * 0.09,
            color: colors.muted,
            fontFamily: fonts.regular,
            fontSize: sw * TYPE.caption,
            lineHeight: sw * 0.052,
          }}
        >
          A chave fica guardada só neste celular. Gere uma em aistudio.google.com/apikey.
        </Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { ...StyleSheet.absoluteFillObject, backgroundColor: colors.bg },
  label: { color: colors.muted, fontFamily: fonts.regular },
  row: { flexDirection: 'row', alignItems: 'center', gap: 14 },
  input: {
    color: colors.text,
    fontFamily: fonts.regular,
    borderBottomWidth: 2,
    borderBottomColor: colors.text,
    paddingVertical: 8,
    marginTop: 8,
  },
  btn: { alignItems: 'center', justifyContent: 'center', borderWidth: 2 },
});
