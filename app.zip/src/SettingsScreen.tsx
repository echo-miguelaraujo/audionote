import React, { useEffect } from 'react';
import { BackHandler, ScrollView, StyleSheet, View, useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { AppearanceSection } from './AppearanceSection';
import { AudioSection } from './AudioSection';
import { Background } from './Background';
import { BackupSection } from './BackupSection';
import { CalendarSection } from './CalendarSection';
import { GeminiSection } from './GeminiSection';
import { StockKeysSection } from './StockKeysSection';
import { NotesToolsSection } from './NotesToolsSection';
import { ScreenHeader, ScreenTitle } from './ScreenHeader';
import { SettingsGroup, Collapsible } from './SettingsGroup';
import { SyncSection } from './SyncSection';
import { UsageSection } from './UsageSection';
import { colors, SPACE } from './theme';
import { useKeyboardInset } from './useKeyboardInset';

type Props = { onClose: () => void };

/**
 * Tela de Configurações: só monta as seções, agrupadas por assunto; cada seção cuida do seu estado.
 * Chaves de API ficam recolhidas (Collapsible) porque são configuradas uma vez e depois só atrapalham.
 */
export function SettingsScreen({ onClose }: Props) {
  const { width: sw } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const kb = useKeyboardInset();

  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      onClose();
      return true;
    });
    return () => sub.remove();
  }, [onClose]);

  return (
    <View style={styles.root}>
      <Background />
      <ScreenHeader onBack={onClose} />

      <View style={{ flex: 1, paddingBottom: kb }}>
      <ScrollView
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={{
          paddingHorizontal: sw * SPACE.xl,
          paddingTop: sw * SPACE.lg,
          paddingBottom: insets.bottom + sw * 0.2,
        }}
      >
        <ScreenTitle>Configurações</ScreenTitle>

        <SettingsGroup title="Conta e sincronização">
          <SyncSection />
        </SettingsGroup>

        <SettingsGroup title="Chaves e integrações">
          <Collapsible title="Gemini" subtitle="Chave da API e modelo usados para transcrever e organizar">
            <GeminiSection />
            <UsageSection />
          </Collapsible>
          <Collapsible title="Bancos de imagens" subtitle="Chaves do Pexels e do Unsplash para o moodboard">
            <StockKeysSection />
          </Collapsible>
        </SettingsGroup>

        <SettingsGroup title="Gravação e agenda">
          <AudioSection />
          <CalendarSection />
        </SettingsGroup>

        <SettingsGroup title="Notas">
          <NotesToolsSection />
        </SettingsGroup>

        <SettingsGroup title="Aparência">
          <AppearanceSection />
        </SettingsGroup>

        <SettingsGroup title="Dados">
          <BackupSection />
        </SettingsGroup>
      </ScrollView>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { ...StyleSheet.absoluteFillObject, backgroundColor: colors.bg },
});
