import React, { useEffect, useState } from 'react';
import { Image, Modal, Pressable, ScrollView, StatusBar, Text, View } from 'react-native';
import { mediaUri } from './media';
import { SCENE_STATUS } from './SceneCard';
import { colors, fonts, HIT } from './theme';

export type ShowScene = {
  id: number;
  number: number;
  name: string;
  cover: string | null;
  status: number;
  desc: string;
  place: string;
  emotion: string;
  duration: string;
  shot: string;
  dialogue: string;
  date: string;
};

/** Modo de apresentação: as cenas em tela cheia, uma a uma, na ordem dos números. */
export function SceneShow({
  visible,
  scenes,
  u,
  onClose,
}: {
  visible: boolean;
  scenes: ShowScene[];
  u: number;
  onClose: () => void;
}) {
  const [i, setI] = useState(0);
  useEffect(() => {
    if (visible) setI(0);
  }, [visible]);
  const n = scenes.length;
  const s = scenes[Math.min(i, Math.max(0, n - 1))];
  const go = (d: number) => setI((x) => Math.min(n - 1, Math.max(0, x + d)));
  const rows: [string, string][] = s
    ? ([
        ['Local', s.place],
        ['Emoção', s.emotion],
        ['Plano', s.shot],
        ['Duração', s.duration],
        ['Data', s.date],
      ] as [string, string][]).filter(([, v]) => !!v)
    : [];
  const nav = (label: string, d: number, off: boolean) => (
    <Pressable
      onPress={() => go(d)}
      disabled={off}
      hitSlop={HIT.sm}
      accessibilityRole="button"
      accessibilityLabel={label}
      style={{ opacity: off ? 0.3 : 1, paddingVertical: u * 0.03, paddingHorizontal: u * 0.05 }}
    >
      <Text style={{ fontFamily: fonts.bold, fontSize: u * 0.05, color: colors.onDark }}>{label}</Text>
    </Pressable>
  );
  return (
    <Modal visible={visible} animationType="fade" onRequestClose={onClose} statusBarTranslucent>
      <StatusBar hidden />
      <View style={{ flex: 1, backgroundColor: colors.bg }}>
        {s ? (
          <>
            <View style={{ flex: 1.2, backgroundColor: colors.surface }}>
              {!!s.cover && <Image source={{ uri: mediaUri(s.cover) }} resizeMode="contain" style={{ flex: 1 }} />}
              <View
                style={{
                  position: 'absolute',
                  left: u * 0.04,
                  top: u * 0.08,
                  paddingHorizontal: u * 0.04,
                  height: u * 0.1,
                  borderRadius: u * 0.05,
                  backgroundColor: colors.paper,
                  justifyContent: 'center',
                }}
              >
                <Text style={{ fontFamily: fonts.bold, fontSize: u * 0.05, color: colors.onLight }}>{s.number}</Text>
              </View>
              <Pressable
                onPress={onClose}
                hitSlop={HIT.sm}
                accessibilityRole="button"
                accessibilityLabel="Fechar"
                style={{ position: 'absolute', right: u * 0.04, top: u * 0.08, padding: u * 0.03 }}
              >
                <Text style={{ fontFamily: fonts.bold, fontSize: u * 0.05, color: colors.onDark }}>Fechar</Text>
              </Pressable>
            </View>
            <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: u * 0.05, gap: u * 0.025 }}>
              <Text style={{ fontFamily: fonts.bold, fontSize: u * 0.075, color: colors.onDark }}>{s.name || `Cena ${s.number}`}</Text>
              <Text style={{ fontFamily: fonts.regular, fontSize: u * 0.04, color: s.status === 0 ? colors.mutedLight : SCENE_STATUS[s.status]?.color ?? colors.red }}>
                {SCENE_STATUS[s.status]?.label ?? 'Ideia'}
              </Text>
              {!!s.desc && <Text style={{ fontFamily: fonts.regular, fontSize: u * 0.048, color: colors.onDark }}>{s.desc}</Text>}
              {rows.map(([k, v]) => (
                <Text key={k} style={{ fontFamily: fonts.regular, fontSize: u * 0.042, color: colors.mutedLight }}>
                  <Text style={{ fontFamily: fonts.bold, color: colors.onDark }}>{k}: </Text>
                  {v}
                </Text>
              ))}
              {!!s.dialogue && (
                <Text style={{ fontFamily: fonts.regular, fontSize: u * 0.046, color: colors.onDark, fontStyle: 'italic' }}>“{s.dialogue}”</Text>
              )}
            </ScrollView>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingBottom: u * 0.06 }}>
              {nav('‹ Anterior', -1, i <= 0)}
              <Text style={{ fontFamily: fonts.regular, fontSize: u * 0.04, color: colors.mutedLight }}>
                {i + 1} / {n}
              </Text>
              {nav('Próxima ›', 1, i >= n - 1)}
            </View>
          </>
        ) : (
          <Pressable onPress={onClose} style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
            <Text style={{ color: colors.onDark, fontFamily: fonts.regular, fontSize: u * 0.045 }}>Sem cenas. Toque para fechar.</Text>
          </Pressable>
        )}
      </View>
    </Modal>
  );
}
