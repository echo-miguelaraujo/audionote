import { generateJson } from './gemini';
import { loadGeminiSettings } from './settings';

const cache = new Map<string, string>();

/**
 * Os bancos de imagem respondem melhor em inglês. Traduz o tema buscado ("praia" -> "beach") com o Gemini
 * que o app já usa. Sem chave do Gemini, sem internet ou em qualquer erro, devolve o texto original.
 */
export async function translateQuery(text: string): Promise<string> {
  const q = text.trim();
  if (!q) return q;
  const key = q.toLowerCase();
  const hit = cache.get(key);
  if (hit) return hit;
  try {
    const { apiKey, model } = await loadGeminiSettings();
    if (!apiKey.trim()) return q;
    const schema = { type: 'OBJECT', properties: { q: { type: 'STRING' } }, required: ['q'] };
    const parts = [
      {
        text:
          'Traduza este tema de busca de fotos para inglês, curto (1 a 4 palavras), como alguém digitaria num banco de imagens. ' +
          'Se já estiver em inglês, devolva igual. Responda só o JSON.\n\nTema: ' + q,
      },
    ];
    const r = await generateJson<{ q: string }>(apiKey, model, parts, schema, 8000, { kind: 'other', maxOutputTokens: 40 });
    const out = r.ok ? String(r.data?.q ?? '').trim() : '';
    if (!out || out.length > 80) return q;
    cache.set(key, out);
    return out;
  } catch {
    return q;
  }
}
