import React, { useMemo } from 'react';
import { Text, View } from 'react-native';
import { fonts } from './theme';

/**
 * Texto formatado do moodboard. O editor (WebView) produz HTML simples; aqui ele é lido e
 * desenhado com <Text> do React Native, para o texto andar, girar e dar zoom junto com a imagem.
 */

type Span = { t: string; b: boolean; i: boolean; u: boolean; s: boolean; color?: string; em: number };
type Align = 'left' | 'center' | 'right';
type Kind = 'p' | 'h1' | 'h2' | 'h3' | 'li' | 'quote';
type Blk = { kind: Kind; align: Align; spans: Span[]; bullet?: string; indent: number };
type Frame = { tag: string; b: boolean; i: boolean; u: boolean; s: boolean; color?: string; em: number };

const KIND_SCALE: Record<Kind, number> = { p: 1, h1: 2, h2: 1.5, h3: 1.25, li: 1, quote: 1 };

export const escapeHtml = (s: string): string =>
  s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

/** Textos antigos do moodboard eram puros; viram um parágrafo. */
export const asHtml = (content: string): string =>
  /^\s*</.test(content) ? content : `<p>${escapeHtml(content).replace(/\n/g, '<br>')}</p>`;

const decode = (s: string): string =>
  s
    .replace(/&nbsp;/g, ' ')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(Number(n)))
    .replace(/&amp;/g, '&');

const BLOCK_TAGS = new Set(['p', 'div', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'blockquote', 'li']);
const VOID_TAGS = new Set(['br', 'hr', 'img']);

function styleOf(attrs: string): Record<string, string> {
  const m = /style\s*=\s*"([^"]*)"/i.exec(attrs) ?? /style\s*=\s*'([^']*)'/i.exec(attrs);
  const out: Record<string, string> = {};
  if (!m) return out;
  for (const part of m[1].split(';')) {
    const i = part.indexOf(':');
    if (i < 0) continue;
    out[part.slice(0, i).trim().toLowerCase()] = part.slice(i + 1).trim().toLowerCase();
  }
  return out;
}

function alignOf(attrs: string): Align | null {
  const st = styleOf(attrs)['text-align'];
  const at = /align\s*=\s*"?(left|center|right)/i.exec(attrs)?.[1]?.toLowerCase();
  const v = st ?? at;
  return v === 'center' || v === 'right' || v === 'left' ? v : null;
}

export function parseRich(html: string): Blk[] {
  const blocks: Blk[] = [];
  const stack: Frame[] = [];
  const lists: { type: 'ul' | 'ol'; n: number }[] = [];
  let cur = null as Blk | null;

  const top = (): Frame =>
    stack.length ? stack[stack.length - 1] : { tag: '', b: false, i: false, u: false, s: false, em: 1 };

  const flush = () => {
    if (!cur) return;
    const onlyBreaks = cur.spans.every((s) => s.t === '\n');
    if (onlyBreaks) cur.spans = [];
    else {
      const last = cur.spans[cur.spans.length - 1];
      if (last && last.t === '\n') cur.spans.pop();
      const first = cur.spans[0];
      if (first) first.t = first.t.replace(/^\s+/, '');
      const l2 = cur.spans[cur.spans.length - 1];
      if (l2) l2.t = l2.t.replace(/\s+$/, '');
    }
    blocks.push(cur);
    cur = null;
  };

  const start = (kind: Kind, align: Align, extra?: Partial<Blk>) => {
    flush();
    cur = { kind, align, spans: [], indent: lists.length, ...extra };
  };

  const re = /<!--[\s\S]*?-->|<(\/?)([a-zA-Z][a-zA-Z0-9]*)\b([^>]*)>|([^<]+)/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html))) {
    if (m[4] !== undefined) {
      const text = decode(m[4]).replace(/\s+/g, ' ');
      if (!text || (!cur && !text.trim())) continue;
      if (!cur) start('p', 'left');
      const f = top();
      cur!.spans.push({ t: text, b: f.b, i: f.i, u: f.u, s: f.s, color: f.color, em: f.em });
      continue;
    }
    if (!m[2]) continue; // comentário
    const closing = m[1] === '/';
    const tag = m[2].toLowerCase();
    const attrs = m[3] ?? '';

    if (closing) {
      if (tag === 'ul' || tag === 'ol') {
        flush();
        lists.pop();
        continue;
      }
      if (BLOCK_TAGS.has(tag)) flush();
      for (let k = stack.length - 1; k >= 0; k--) {
        if (stack[k].tag === tag) {
          stack.splice(k);
          break;
        }
      }
      continue;
    }

    if (tag === 'br') {
      if (!cur) start('p', 'left');
      const f = top();
      cur!.spans.push({ t: '\n', b: f.b, i: f.i, u: f.u, s: f.s, color: f.color, em: f.em });
      continue;
    }
    if (VOID_TAGS.has(tag)) continue;
    if (tag === 'ul' || tag === 'ol') {
      flush();
      lists.push({ type: tag, n: 0 });
      continue;
    }

    const parent = top();
    const f: Frame = { ...parent, tag };
    const st = styleOf(attrs);
    if (tag === 'b' || tag === 'strong') f.b = true;
    if (tag === 'i' || tag === 'em') f.i = true;
    if (tag === 'u') f.u = true;
    if (tag === 's' || tag === 'strike' || tag === 'del') f.s = true;
    if (/^h[1-6]$/.test(tag)) f.b = true;
    if (st['font-weight'] && (st['font-weight'] === 'bold' || Number(st['font-weight']) >= 600)) f.b = true;
    if (st['font-style'] === 'italic') f.i = true;
    const deco = st['text-decoration'] ?? st['text-decoration-line'] ?? '';
    if (deco.includes('underline')) f.u = true;
    if (deco.includes('line-through')) f.s = true;
    if (st.color) f.color = st.color;
    if (tag === 'font') {
      const c = /color\s*=\s*"([^"]+)"/i.exec(attrs)?.[1];
      if (c) f.color = c;
    }
    const fs = st['font-size'];
    if (fs) {
      const n = parseFloat(fs);
      if (Number.isFinite(n) && n > 0) {
        if (fs.endsWith('em') || fs.endsWith('rem')) f.em = parent.em * n;
        else if (fs.endsWith('%')) f.em = parent.em * (n / 100);
      }
    }
    stack.push(f);

    if (BLOCK_TAGS.has(tag)) {
      const align = alignOf(attrs) ?? 'left';
      if (tag === 'li') {
        const l = lists[lists.length - 1];
        const bullet = l && l.type === 'ol' ? `${++l.n}.` : '•';
        start('li', align, { bullet, indent: Math.max(1, lists.length) });
      } else if (tag === 'h1') start('h1', align);
      else if (tag === 'h2') start('h2', align);
      else if (tag === 'h3' || /^h[4-6]$/.test(tag)) start('h3', align);
      else if (tag === 'blockquote') start('quote', align);
      else start('p', align);
    }
  }
  flush();
  return blocks;
}

/** Texto sem formatação (para saber se está vazio). */
export const plainOf = (html: string): string =>
  html
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

function fontFor(b: boolean, i: boolean): string {
  if (b && i) return fonts.boldItalic;
  if (b) return fonts.bold;
  if (i) return fonts.italic;
  return fonts.regular;
}

type Props = { html: string; base: number; width: number; color?: string };

export function RichText({ html, base, width, color = '#000' }: Props) {
  const blocks = useMemo(() => parseRich(asHtml(html)), [html]);
  return (
    // A caixa encolhe até o texto usado: `width` é só o limite máximo (a partir dele, o texto quebra a linha).
    <View style={{ maxWidth: width, alignSelf: 'flex-start' }}>
      {blocks.map((b, k) => {
        const fs = base * KIND_SCALE[b.kind];
        const heading = b.kind === 'h1' || b.kind === 'h2' || b.kind === 'h3';
        const pad = b.kind === 'li' ? b.indent * fs * 0.9 : b.kind === 'quote' ? fs * 0.7 : 0;
        return (
          <View key={k} style={{ marginTop: heading && k > 0 ? fs * 0.3 : 0, flexDirection: 'row' }}>
            {b.kind === 'li' && (
              <Text
                style={{
                  position: 'absolute',
                  left: pad - fs * 0.9,
                  fontFamily: fonts.regular,
                  fontSize: fs,
                  color,
                }}
              >
                {b.bullet}
              </Text>
            )}
            {b.kind === 'quote' && (
              <View style={{ position: 'absolute', left: 0, top: 2, bottom: 2, width: fs * 0.12, backgroundColor: color }} />
            )}
            <Text
              style={{
                flexGrow: 1,
                flexShrink: 1,
                includeFontPadding: false,
                paddingLeft: pad,
                textAlign: b.align,
                fontFamily: heading ? fonts.bold : fonts.regular,
                fontSize: fs,
                letterSpacing: -fs * (heading ? 0.035 : 0.015),
                color,
              }}
            >
              {b.spans.length === 0
                ? ' '
                : b.spans.map((s, j) => (
                    <Text
                      key={j}
                      style={{
                        fontFamily: fontFor(s.b || heading, s.i),
                        fontSize: fs * s.em,
                        color: s.color ?? color,
                        textDecorationLine:
                          s.u && s.s ? 'underline line-through' : s.u ? 'underline' : s.s ? 'line-through' : 'none',
                      }}
                    >
                      {s.t}
                    </Text>
                  ))}
            </Text>
          </View>
        );
      })}
    </View>
  );
}
