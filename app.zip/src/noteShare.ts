import { File, Paths } from 'expo-file-system';
import * as MediaLibrary from 'expo-media-library';
import * as Print from 'expo-print';
import { escapeHtml } from './note';
import { embeddedFontCss } from './fonts';
import { Free, PAGE_W, freeExportCount, freeExportPageHtml } from './freeLayout';
import { PRINT_CSS, inlineImage, prepareBody, safeFileName, shareCachedCopy } from './exportPdf';

/**
 * Compartilhar a nota em páginas 16:9 (PDF ou imagens).
 *
 * - Nota corrida: o texto corre numa tela só e é dividido em blocos 16:9 sem cortar linhas no meio.
 * - Layout livre: a página inteira é fatiada de cima para baixo em blocos 16:9.
 */

/** Tamanho lógico da página 16:9 (px de CSS). Tudo é desenhado nesta medida e escalado para a saída. */
export const SLIDE_W = 1280;
export const SLIDE_H = 720;

/** Dados de uma nota pronta para virar páginas. */
export type NotePagesInput =
  | { kind: 'flow'; title: string; body: string; cover: string | null }
  | { kind: 'free'; free: Free; toUri: (ref: string) => string };

/**
 * Ajustes do tema "slide" sobre o CSS de impressão A4: texto maior, margens de slide e nada partido ao meio.
 * `k` = tamanho da página em relação a 842 px de largura (referência do PDF).
 */
function slideCss(k: number): string {
  const px = (v: number) => `${(v * k).toFixed(2)}px`;
  return `
body{font-size:${px(18)};line-height:1.5}
h1.doc-title{font-size:${px(40)};margin:0 0 .4em}
.cover{height:${px(150)};margin:0 0 ${px(12)}}
h1{font-size:${px(30)}}h2{font-size:${px(25)}}h3{font-size:${px(21)}}h4{font-size:${px(18)}}h5{font-size:${px(14)}}
img{max-height:${px(300)};width:auto;max-width:100%;object-fit:contain}
.cols img,a.lkcard img,.vidcard img{max-height:${px(220)}}
a.lkcard.sq img{width:${px(90)};height:${px(90)}}
p,li,blockquote,.callout,.toggle,.vidcard,a.lkcard,.toc,tr,img{break-inside:avoid;page-break-inside:avoid}
h1,h2,h3,h4,h5{break-after:avoid;page-break-after:avoid}
`;
}

/** Margem interna da página 16:9, em px de CSS da página lógica de 1280 px. */
const PAD_X = 72;
const PAD_Y = 52;

/** Capa + título + corpo da nota corrida, já com imagens/vídeos/arquivos tratados para PDF. */
async function flowInner(input: Extract<NotePagesInput, { kind: 'flow' }>, inline: boolean): Promise<{ inner: string; fontCss: string }> {
  const body = await prepareBody(input.body, false, inline);
  let cover = '';
  if (input.cover) cover = inline ? await inlineImage(input.cover) : input.cover;
  const heading = input.title.trim();
  const fontCss = await embeddedFontCss(body);
  const inner =
    (cover ? `<img class="cover" src="${escapeHtml(cover)}">` : '') +
    (heading ? `<h1 class="doc-title">${escapeHtml(heading)}</h1>` : '') +
    body;
  return { inner, fontCss };
}

/** Altura (em u, para largura 1000) da página 16:9. */
export const H169 = (PAGE_W * 9) / 16;

/**
 * Layout livre: HTML de cada página de saída, com `pageW` px de largura e altura de `targetH` u.
 * Notas com páginas mantêm as suas (encaixadas sem cortar); a nota contínua é fatiada de cima para baixo.
 * Imagens locais viram base64 quando `inline`.
 */
async function freeSlices(
  input: Extract<NotePagesInput, { kind: 'free' }>,
  pageW: number,
  inline: boolean,
  targetH: number = H169
): Promise<{ slices: string[]; bg: string; fontCss: string }> {
  const { free, toUri } = input;
  const k = pageW / PAGE_W;
  const n = freeExportCount(free, targetH);

  // Imagens locais: resolvidas uma vez (e incorporadas, no PDF) para não repetir o arquivo em cada página.
  const cache = new Map<string, string>();
  for (const f of free.frames) {
    if (f.t !== 'image' || !f.src || cache.has(f.src)) continue;
    const u = toUri(f.src);
    cache.set(f.src, inline ? await inlineImage(u) : u);
  }
  const resolve = (ref: string) => cache.get(ref) ?? toUri(ref);

  const slices: string[] = [];
  for (let i = 0; i < n; i++) slices.push(freeExportPageHtml(free, resolve, k, i, targetH));
  const fontCss = await embeddedFontCss(JSON.stringify(free.frames.map((f) => f.fam ?? '')));
  return { slices, bg: free.bg, fontCss };
}

/** PDF do layout livre num formato escolhido (`targetH` em u para largura 1000). Devolve o caminho da cópia compartilhada. */
export async function exportFreePdf(title: string, input: Extract<NotePagesInput, { kind: 'free' }>, targetH: number, tag: string): Promise<string> {
  const W = PDF_W;
  const H = Math.max(100, Math.round((W * targetH) / PAGE_W));
  const { slices, fontCss } = await freeSlices(input, W, true, targetH);
  const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><style>${fontCss}
*{-webkit-print-color-adjust:exact;print-color-adjust:exact}
@page{size:${W}px ${H}px;margin:0}
html,body{margin:0;padding:0}
.pg{width:${W}px;height:${H}px;overflow:hidden;page-break-after:always;break-after:page}
.pg:last-child{page-break-after:auto;break-after:auto}
.pg>div{page-break-after:auto!important;break-after:auto!important}
img{margin:0;border-radius:0}
</style></head><body>${slices.map((x) => `<div class="pg">${x}</div>`).join('')}</body></html>`;
  const { uri } = await Print.printToFileAsync({ html, width: W, height: H });
  return shareCachedCopy(uri, `${safeFileName(title, 'Nota')}_${tag}.pdf`, 'application/pdf', 'Exportar nota em PDF', 'com.adobe.pdf');
}

// ---------------------------------------------------------------------------------------------
// PDF 16:9
// ---------------------------------------------------------------------------------------------

const PDF_W = 842;
const PDF_H = 474; // 842 x 16/9 ≈ 473,6

/** PDF com páginas 16:9 (texto selecionável). Devolve o caminho da cópia compartilhada. */
export async function exportNotePdf169(title: string, input: NotePagesInput): Promise<string> {
  let html: string;
  if (input.kind === 'flow') {
    const { inner, fontCss } = await flowInner(input, true);
    const padX = Math.round((PAD_X * PDF_W) / SLIDE_W);
    const padY = Math.round((PAD_Y * PDF_W) / SLIDE_W);
    html = `<!DOCTYPE html><html><head><meta charset="utf-8"><style>${fontCss}${PRINT_CSS}
@page{size:${PDF_W}px ${PDF_H}px;margin:${padY}px ${padX}px}
html,body{margin:0;padding:0}body{background:#fff}
${slideCss(1)}</style></head><body>${inner}</body></html>`;
  } else {
    const { slices, fontCss } = await freeSlices(input, PDF_W, true, H169);
    html = `<!DOCTYPE html><html><head><meta charset="utf-8"><style>${fontCss}
*{-webkit-print-color-adjust:exact;print-color-adjust:exact}
@page{size:${PDF_W}px ${PDF_H}px;margin:0}
html,body{margin:0;padding:0}
.pg{width:${PDF_W}px;height:${PDF_H}px;overflow:hidden;page-break-after:always;break-after:page}
.pg:last-child{page-break-after:auto;break-after:auto}
img{margin:0;border-radius:0}
</style></head><body>${slices.map((s) => `<div class="pg">${s}</div>`).join('')}</body></html>`;
  }
  const { uri } = await Print.printToFileAsync({ html, width: PDF_W, height: PDF_H });
  return shareCachedCopy(uri, `${safeFileName(title, 'Nota')}_16x9.pdf`, 'application/pdf', 'Exportar nota em PDF 16:9', 'com.adobe.pdf');
}

// ---------------------------------------------------------------------------------------------
// Imagens 16:9 (páginas desenhadas numa WebView e fotografadas uma a uma)
// ---------------------------------------------------------------------------------------------

/**
 * HTML do paginador usado na captura de imagens. A página lógica tem 1280x720 e é escalada para a largura
 * da WebView. Mensagens para o app: {type:'ready', pages:n} e {type:'shown', i}.
 * O app chama window.showPage(i) e espera 'shown' antes de fotografar.
 */
export async function buildPagerHtml(input: NotePagesInput, targetH: number = H169): Promise<string> {
  const PH = input.kind === 'free' ? Math.max(100, Math.round((SLIDE_W * targetH) / PAGE_W)) : SLIDE_H;
  let content: string;
  let fontCss: string;
  let css: string;
  let script: string;
  if (input.kind === 'flow') {
    // Imagens ficam como arquivo local (a WebView do app já abre file://), sem inflar o HTML com base64.
    const f = await flowInner(input, false);
    fontCss = f.fontCss;
    const colW = SLIDE_W - 2 * PAD_X;
    css = `${PRINT_CSS}${slideCss(SLIDE_W / PDF_W)}
#cols{position:absolute;left:0;top:0;box-sizing:border-box;height:${PH}px;width:${SLIDE_W}px;padding:${PAD_Y}px ${PAD_X}px;
column-width:${colW}px;column-gap:${2 * PAD_X}px;column-fill:auto;font-family:Roboto,Arial,sans-serif;color:#111;font-size:${((18 * SLIDE_W) / PDF_W).toFixed(2)}px;line-height:1.5}
#cols>:first-child{margin-top:0}`;
    content = `<div id="cols">${f.inner}</div>`;
    script = `
function pages(){var c=document.getElementById('cols');return Math.max(1,Math.round((c.scrollWidth+${PAD_X})/${SLIDE_W}));}
function place(i){document.getElementById('cols').style.transform='translateX('+(-i*${SLIDE_W})+'px)';}`;
  } else {
    const s = await freeSlices(input, SLIDE_W, false, targetH);
    fontCss = s.fontCss;
    css = `#cols{position:absolute;left:0;top:0;width:${SLIDE_W}px;height:${PH}px}img{margin:0;border-radius:0}`;
    content = `<div id="cols"></div>`;
    script = `
var SL=${JSON.stringify(s.slices).split('\u2028').join('\\u2028').split('\u2029').join('\\u2029')};
function pages(){return SL.length;}
function place(i){document.getElementById('cols').innerHTML=SL[i];}`;
  }
  return `<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>${fontCss}
html,body{margin:0;padding:0;background:#fff;overflow:hidden}
#stage{position:absolute;left:0;top:0;width:${SLIDE_W}px;height:${PH}px;overflow:hidden;background:#fff;transform-origin:0 0}
${css}</style></head><body><div id="stage">${content}</div>
<script>
function post(o){window.ReactNativeWebView.postMessage(JSON.stringify(o));}
var st=document.getElementById('stage');
function fit(){st.style.transform='scale('+(window.innerWidth/${SLIDE_W})+')';}
fit();window.addEventListener('resize',fit);
${script}
function settled(){
  var imgs=[].slice.call(document.images).filter(function(im){return !im.complete;});
  var waits=imgs.map(function(im){return new Promise(function(r){im.onload=im.onerror=r;});});
  var fonts=document.fonts&&document.fonts.ready?document.fonts.ready:Promise.resolve();
  return Promise.race([Promise.all(waits.concat([fonts])),new Promise(function(r){setTimeout(r,6000);})]);
}
window.showPage=function(i){
  place(i);
  settled().then(function(){requestAnimationFrame(function(){requestAnimationFrame(function(){setTimeout(function(){post({type:'shown',i:i});},120);});});});
};
settled().then(function(){setTimeout(function(){post({type:'ready',pages:pages()});},150);});
</script></body></html>`;
}

/** Apaga arquivos temporários sem reclamar se já sumiram. */
export function dropFile(uri: string): void {
  try {
    const f = new File(uri);
    if (f.exists) f.delete();
  } catch {
    // já apagado
  }
}

/** Copia uma página PNG para o cache com nome legível (ex.: Nota_16x9_02.png). */
export function namedPageCopy(title: string, i: number, total: number, tmpUri: string, tag = '16x9'): string {
  const pad = String(i + 1).padStart(String(total).length, '0');
  const dest = new File(Paths.cache, `${safeFileName(title, 'Nota')}_${tag}_${pad}.png`);
  if (dest.exists) dest.delete();
  new File(tmpUri).copy(dest);
  return dest.uri;
}

/** Salva todas as páginas na galeria (o menu de compartilhar do aparelho aceita um arquivo por vez). Apaga os temporários. */
export async function savePagesToGallery(title: string, uris: string[], tag = '16x9'): Promise<void> {
  try {
    // writeOnly: só precisa de permissão para salvar, não para ler a galeria.
    const perm = await MediaLibrary.requestPermissionsAsync(true);
    if (!perm.granted) throw new Error('Sem permissão para salvar na galeria. Libere o acesso às fotos nas configurações do aparelho.');
    for (let i = 0; i < uris.length; i++) {
      let copy = uris[i];
      try {
        copy = namedPageCopy(title, i, uris.length, uris[i], tag);
      } catch {
        // usa o nome automático
      }
      try {
        await MediaLibrary.createAssetAsync(copy);
      } finally {
        if (copy !== uris[i]) dropFile(copy);
      }
    }
  } finally {
    uris.forEach(dropFile);
  }
}
