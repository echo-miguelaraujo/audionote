import { File, Paths } from 'expo-file-system';
import * as MediaLibrary from 'expo-media-library';
import * as Print from 'expo-print';
import { escapeHtml } from './note';
import { embeddedFontCss } from './fonts';
import { Free, PAGE_W, freeToHtml } from './freeLayout';
import { PRINT_CSS, inlineImage, prepareBody, safeFileName, shareCachedCopy } from './exportPdf';

/**
 * Compartilhar a nota em páginas 16:9 (PDF ou imagens).
 *
 * - Nota corrida: o texto corre numa tela só e é dividido em blocos 16:9 sem cortar linhas no meio.
 * - Layout livre: a página inteira é fatiada de cima para baixo em blocos 16:9.
 */

/** Tamanho lógico da página 16:9 (px de CSS). Tudo é desenhado nesta medida e escalado para a saída. */
export const SLIDE_W = 1280;
export const SLIDE_H = 720;

/** Dados de uma nota pronta para virar páginas. */
export type NotePagesInput =
  | { kind: 'flow'; title: string; body: string; cover: string | null }
  | { kind: 'free'; free: Free; toUri: (ref: string) => string };

/**
 * Ajustes do tema "slide" sobre o CSS de impressão A4: texto maior, margens de slide e nada partido ao meio.
 * `k` = tamanho da página em relação a 842 px de largura (referência do PDF).
 */
function slideCss(k: number): string {
  const px = (v: number) => `${(v * k).toFixed(2)}px`;
  return `
body{font-size:${px(18)};line-height:1.5}
h1.doc-title{font-size:${px(40)};margin:0 0 .4em}
.cover{height:${px(150)};margin:0 0 ${px(12)}}
h1{font-size:${px(30)}}h2{font-size:${px(25)}}h3{font-size:${px(21)}}h4{font-size:${px(18)}}h5{font-size:${px(14)}}
img{max-height:${px(300)};width:auto;max-width:100%;object-fit:contain}
.cols img,a.lkcard img,.vidcard img{max-height:${px(220)}}
a.lkcard.sq img{width:${px(90)};height:${px(90)}}
p,li,blockquote,.callout,.toggle,.vidcard,a.lkcard,.toc,tr,img{break-inside:avoid;page-break-inside:avoid}
h1,h2,h3,h4,h5{break-after:avoid;page-break-after:avoid}
`;
}

/** Margem interna da página 16:9, em px de CSS da página lógica de 1280 px. */
const PAD_X = 72;
const PAD_Y = 52;

/** Capa + título + corpo da nota corrida, já com imagens/vídeos/arquivos tratados para PDF. */
async function flowInner(input: Extract<NotePagesInput, { kind: 'flow' }>, inline: boolean): Promise<{ inner: string; fontCss: string }> {
  const body = await prepareBody(input.body, false, inline);
  let cover = '';
  if (input.cover) cover = inline ? await inlineImage(input.cover) : input.cover;
  const heading = input.title.trim();
  const fontCss = await embeddedFontCss(body);
  const inner =
    (cover ? `<img class="cover" src="${escapeHtml(cover)}">` : '') +
    (heading ? `<h1 class="doc-title">${escapeHtml(heading)}</h1>` : '') +
    body;
  return { inner, fontCss };
}

/** Quantas fatias de 16:9 cabem na página de layout livre (a altura vem do quadro mais baixo). */
function freeSliceCount(free: Free): number {
  const sliceU = (PAGE_W * 9) / 16;
  const total = Math.max(free.h, ...free.frames.map((f) => f.y + f.h));
  return Math.max(1, Math.ceil(total / sliceU - 0.001));
}

/**
 * Layout livre: HTML de cada fatia 16:9, com `pageW` px de largura (a página de 1000 u cobre a largura toda).
 * Só entram na fatia os quadros que encostam nela; imagens locais viram base64 quando `inline`.
 */
async function freeSlices(
  input: Extract<NotePagesInput, { kind: 'free' }>,
  pageW: number,
  inline: boolean
): Promise<{ slices: string[]; bg: string; fontCss: string }> {
  const { free, toUri } = input;
  const k = pageW / PAGE_W;
  const pageH = (pageW * 9) / 16;
  const sliceU = (PAGE_W * 9) / 16;
  const n = freeSliceCount(free);

  // Imagens locais: resolvidas uma vez (e incorporadas, no PDF) para não repetir o arquivo em cada fatia.
  const cache = new Map<string, string>();
  for (const f of free.frames) {
    if (f.t !== 'image' || !f.src || cache.has(f.src)) continue;
    const u = toUri(f.src);
    cache.set(f.src, inline ? await inlineImage(u) : u);
  }
  const resolve = (ref: string) => cache.get(ref) ?? toUri(ref);

  const slices: string[] = [];
  for (let i = 0; i < n; i++) {
    const top = i * sliceU;
    const frames = free.frames
      .filter((f) => f.y < top + sliceU && f.y + f.h > top)
      .map((f) => ({ ...f, y: f.y - top }));
    const html = freeToHtml({ ...free, h: sliceU, frames }, resolve, k);
    slices.push(
      `<div style="position:relative;width:${pageW}px;height:${pageH.toFixed(2)}px;overflow:hidden;background:${escapeHtml(free.bg)}">${html}</div>`
    );
  }
  const fontCss = await embeddedFontCss(JSON.stringify(free.frames.map((f) => f.fam ?? '')));
  return { slices, bg: free.bg, fontCss };
}

// ---------------------------------------------------------------------------------------------
// PDF 16:9
// ---------------------------------------------------------------------------------------------

const PDF_W = 842;
const PDF_H = 474; // 842 x 16/9 ≈ 473,6

/** PDF com páginas 16:9 (texto selecionável). Devolve o caminho da cópia compartilhada. */
export async function exportNotePdf169(title: string, input: NotePagesInput): Promise<string> {
  let html: string;
  if (input.kind === 'flow') {
    const { inner, fontCss } = await flowInner(input, true);
    const padX = Math.round((PAD_X * PDF_W) / SLIDE_W);
    const padY = Math.round((PAD_Y * PDF_W) / SLIDE_W);
    html = `<!DOCTYPE html><html><head><meta charset="utf-8"><style>${fontCss}${PRINT_CSS}
@page{size:${PDF_W}px ${PDF_H}px;margin:${padY}px ${padX}px}
html,body{margin:0;padding:0}body{background:#fff}
${slideCss(1)}</style></head><body>${inner}</body></html>`;
  } else {
    const { slices, fontCss } = await freeSlices(input, PDF_W, true);
    html = `<!DOCTYPE html><html><head><meta charset="utf-8"><style>${fontCss}
*{-webkit-print-color-adjust:exact;print-color-adjust:exact}
@page{size:${PDF_W}px ${PDF_H}px;margin:0}
html,body{margin:0;padding:0}
.pg{width:${PDF_W}px;height:${PDF_H}px;overflow:hidden;page-break-after:always;break-after:page}
.pg:last-child{page-break-after:auto;break-after:auto}
img{margin:0;border-radius:0}
</style></head><body>${slices.map((s) => `<div class="pg">${s}</div>`).join('')}</body></html>`;
  }
  const { uri } = await Print.printToFileAsync({ html, width: PDF_W, height: PDF_H });
  return shareCachedCopy(uri, `${safeFileName(title, 'Nota')}_16x9.pdf`, 'application/pdf', 'Exportar nota em PDF 16:9', 'com.adobe.pdf');
}

// ---------------------------------------------------------------------------------------------
// Imagens 16:9 (páginas desenhadas numa WebView e fotografadas uma a uma)
// ---------------------------------------------------------------------------------------------

/**
 * HTML do paginador usado na captura de imagens. A página lógica tem 1280x720 e é escalada para a largura
 * da WebView. Mensagens para o app: {type:'ready', pages:n} e {type:'shown', i}.
 * O app chama window.showPage(i) e espera 'shown' antes de fotografar.
 */
export async function buildPagerHtml(input: NotePagesInput): Promise<string> {
  let content: string;
  let fontCss: string;
  let css: string;
  let script: string;
  if (input.kind === 'flow') {
    // Imagens ficam como arquivo local (a WebView do app já abre file://), sem inflar o HTML com base64.
    const f = await flowInner(input, false);
    fontCss = f.fontCss;
    const colW = SLIDE_W - 2 * PAD_X;
    css = `${PRINT_CSS}${slideCss(SLIDE_W / PDF_W)}
#cols{position:absolute;left:0;top:0;box-sizing:border-box;height:${SLIDE_H}px;width:${SLIDE_W}px;padding:${PAD_Y}px ${PAD_X}px;
column-width:${colW}px;column-gap:${2 * PAD_X}px;column-fill:auto;font-family:Roboto,Arial,sans-serif;color:#111;font-size:${((18 * SLIDE_W) / PDF_W).toFixed(2)}px;line-height:1.5}
#cols>:first-child{margin-top:0}`;
    content = `<div id="cols">${f.inner}</div>`;
    script = `
function pages(){var c=document.getElementById('cols');return Math.max(1,Math.round((c.scrollWidth+${PAD_X})/${SLIDE_W}));}
function place(i){document.getElementById('cols').style.transform='translateX('+(-i*${SLIDE_W})+'px)';}`;
  } else {
    const s = await freeSlices(input, SLIDE_W, false);
    fontCss = s.fontCss;
    css = `#cols{position:absolute;left:0;top:0;width:${SLIDE_W}px;height:${SLIDE_H}px}img{margin:0;border-radius:0}`;
    content = `<div id="cols"></div>`;
    script = `
var SL=${JSON.stringify(s.slices).split('\u2028').join('\\u2028').split('\u2029').join('\\u2029')};
function pages(){return SL.length;}
function place(i){document.getElementById('cols').innerHTML=SL[i];}`;
  }
  return `<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>${fontCss}
html,body{margin:0;padding:0;background:#fff;overflow:hidden}
#stage{position:absolute;left:0;top:0;width:${SLIDE_W}px;height:${SLIDE_H}px;overflow:hidden;background:#fff;transform-origin:0 0}
${css}</style></head><body><div id="stage">${content}</div>
<script>
function post(o){window.ReactNativeWebView.postMessage(JSON.stringify(o));}
var st=document.getElementById('stage');
function fit(){st.style.transform='scale('+(window.innerWidth/${SLIDE_W})+')';}
fit();window.addEventListener('resize',fit);
${script}
function settled(){
  var imgs=[].slice.call(document.images).filter(function(im){return !im.complete;});
  var waits=imgs.map(function(im){return new Promise(function(r){im.onload=im.onerror=r;});});
  var fonts=document.fonts&&document.fonts.ready?document.fonts.ready:Promise.resolve();
  return Promise.race([Promise.all(waits.concat([fonts])),new Promise(function(r){setTimeout(r,6000);})]);
}
window.showPage=function(i){
  place(i);
  settled().then(function(){requestAnimationFrame(function(){requestAnimationFrame(function(){setTimeout(function(){post({type:'shown',i:i});},120);});});});
};
settled().then(function(){setTimeout(function(){post({type:'ready',pages:pages()});},150);});
</script></body></html>`;
}

/** Apaga arquivos temporários sem reclamar se já sumiram. */
export function dropFile(uri: string): void {
  try {
    const f = new File(uri);
    if (f.exists) f.delete();
  } catch {
    // já apagado
  }
}

/** Copia uma página PNG para o cache com nome legível (ex.: Nota_16x9_02.png). */
export function namedPageCopy(title: string, i: number, total: number, tmpUri: string): string {
  const pad = String(i + 1).padStart(String(total).length, '0');
  const dest = new File(Paths.cache, `${safeFileName(title, 'Nota')}_16x9_${pad}.png`);
  if (dest.exists) dest.delete();
  new File(tmpUri).copy(dest);
  return dest.uri;
}

/** Salva todas as páginas na galeria (o menu de compartilhar do aparelho aceita um arquivo por vez). Apaga os temporários. */
export async function savePagesToGallery(title: string, uris: string[]): Promise<void> {
  try {
    // writeOnly: só precisa de permissão para salvar, não para ler a galeria.
    const perm = await MediaLibrary.requestPermissionsAsync(true);
    if (!perm.granted) throw new Error('Sem permissão para salvar na galeria. Libere o acesso às fotos nas configurações do aparelho.');
    for (let i = 0; i < uris.length; i++) {
      let copy = uris[i];
      try {
        copy = namedPageCopy(title, i, uris.length, uris[i]);
      } catch {
        // usa o nome automático
      }
      try {
        await MediaLibrary.createAssetAsync(copy);
      } finally {
        if (copy !== uris[i]) dropFile(copy);
      }
    }
  } finally {
    uris.forEach(dropFile);
  }
}
