import React, { useEffect, useState } from 'react';
import { View } from 'react-native';
import { SettingRow } from './SettingRow';
import { getDeleteAfter, setDeleteAfter } from './settings';

/** O que acontece com o áudio depois de transcrito. */
export function AudioSection() {
  const [delAfter, setDelAfter] = useState(false);

  useEffect(() => {
    getDeleteAfter().then(setDelAfter).catch(() => {});
  }, []);

  const toggle = async () => {
    const v = !delAfter;
    setDelAfter(v);
    await setDeleteAfter(v);
  };

  return (
    <View>
      <SettingRow label="Apagar o áudio depois de transcrito" checked={delAfter} onPress={() => toggle().catch(() => {})} />
    </View>
  );
}
