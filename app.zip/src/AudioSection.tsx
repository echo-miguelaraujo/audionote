import React, { useEffect, useState } from 'react';
import { Text, View, useWindowDimensions } from 'react-native';
import { SettingRow } from './SettingRow';
import { getDeleteAfter, setDeleteAfter } from './settings';
import { USAGE_LABELS, UsageKind, UsageMonth, loadUsage } from './usage';
import { colors, fonts, SPACE, TYPE } from './theme';

/** O que acontece com o áudio depois de transcrito e quanto o Gemini consumiu no mês. */
export function AudioSection() {
  const { width: sw } = useWindowDimensions();
  const [delAfter, setDelAfter] = useState(false);
  const [usage, setUsage] = useState<UsageMonth>({});

  useEffect(() => {
    getDeleteAfter().then(setDelAfter).catch(() => {});
    loadUsage().then(setUsage).catch(() => {});
  }, []);

  const toggle = async () => {
    const v = !delAfter;
    setDelAfter(v);
    await setDeleteAfter(v);
  };

  const kinds = Object.keys(usage) as UsageKind[];
  const small = { color: colors.muted, fontFamily: fonts.regular, fontSize: sw * TYPE.label };

  return (
    <View>
      <SettingRow label="Apagar o áudio depois de transcrito" checked={delAfter} onPress={() => toggle().catch(() => {})} />
      {kinds.length > 0 && (
        <View style={{ marginTop: sw * SPACE.xl }}>
          <Text style={small}>Uso de tokens neste mês</Text>
          {kinds.map((k) => {
            const u = usage[k]!;
            return (
              <Text key={k} style={[small, { marginTop: sw * SPACE.sm }]}>
                {USAGE_LABELS[k]}: {u.calls} {u.calls === 1 ? 'chamada' : 'chamadas'} · {u.input.toLocaleString('pt-BR')} entrada ·{' '}
                {(u.output + u.thoughts).toLocaleString('pt-BR')} saída
              </Text>
            );
          })}
        </View>
      )}
    </View>
  );
}
