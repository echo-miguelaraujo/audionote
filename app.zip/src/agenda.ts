import { listAgendaItems, listCalendarRecordsInRange, Category } from './db';
import { listDeviceEvents } from './calendar';
import { colors } from './theme';

export const MONTHS = [
  'janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho',
  'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro',
];
export const WEEKDAYS_SHORT = ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sáb'];
export const WEEKDAYS_LONG = [
  'domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado',
];

export const pad2 = (n: number) => String(n).padStart(2, '0');

/** "2026-10-06" (dia local), usado como chave de cada dia. */
export function dayKey(d: Date): string {
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}

export function startOfDay(d: Date): Date {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate());
}

export function addDays(d: Date, n: number): Date {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);
}

export function timeLabel(ms: number): string {
  const d = new Date(ms);
  return `${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
}

/** Dias que aparecem na grade do mês: começa no domingo da 1ª semana, termina no sábado da última. */
export function monthGrid(year: number, month: number): Date[] {
  const first = new Date(year, month, 1);
  const last = new Date(year, month + 1, 0);
  const start = addDays(first, -first.getDay());
  const end = addDays(last, 6 - last.getDay());
  const out: Date[] = [];
  for (let d = start; d <= end; d = addDays(d, 1)) out.push(d);
  return out;
}

export type AgendaEntry = {
  key: string;
  source: 'app' | 'device';
  /** id do compromisso criado no app (source = 'app'). */
  itemId?: number;
  title: string;
  startMs: number;
  allDay: boolean;
  color: string;
  categoryId?: number | null;
  notes?: string;
  /** Nota de origem, quando o compromisso foi criado a partir de um áudio. */
  blockId?: number | null;
};

export type DayMap = Map<string, AgendaEntry[]>;

function push(map: DayMap, key: string, e: AgendaEntry) {
  const list = map.get(key);
  if (list) list.push(e);
  else map.set(key, [e]);
}

/**
 * Junta tudo que existe a partir de `from` até `to`:
 *  - compromissos criados na aba Agenda;
 *  - eventos da agenda do celular (Google Agenda, Samsung…), incluindo os que o app criou a partir das notas.
 */
export async function loadEntries(from: Date, to: Date, cats: Category[]): Promise<DayMap> {
  const [items, device, records] = await Promise.all([
    listAgendaItems(from.getTime(), to.getTime()),
    listDeviceEvents(from, to),
    listCalendarRecordsInRange(from.getTime(), to.getTime()),
  ]);
  const catColor = new Map(cats.map((c) => [c.id, c.color]));
  const blockByEvent = new Map<string, number>();
  records.forEach((r) => {
    if (r.calendarEventId) blockByEvent.set(r.calendarEventId, r.blockId);
  });

  const map: DayMap = new Map();

  items.forEach((it) => {
    push(map, dayKey(new Date(it.startAt)), {
      key: `app-${it.id}`,
      source: 'app',
      itemId: it.id,
      title: it.title,
      startMs: it.startAt,
      allDay: it.allDay,
      color: (it.categoryId != null && catColor.get(it.categoryId)) || colors.red,
      categoryId: it.categoryId,
      notes: it.notes,
    });
  });

  device.forEach((ev) => {
    const common = {
      source: 'device' as const,
      title: ev.title,
      color: ev.color || colors.gray,
      blockId: blockByEvent.get(ev.id) ?? null,
    };
    if (ev.allDay) {
      // Eventos de dia inteiro vêm à meia-noite UTC; a data certa está nos campos UTC.
      const s = new Date(new Date(ev.startMs).getUTCFullYear(), new Date(ev.startMs).getUTCMonth(), new Date(ev.startMs).getUTCDate());
      const e = new Date(new Date(ev.endMs).getUTCFullYear(), new Date(ev.endMs).getUTCMonth(), new Date(ev.endMs).getUTCDate());
      let n = 0;
      for (let d = s; (d < e || n === 0) && n < 31; d = addDays(d, 1), n++) {
        push(map, dayKey(d), { ...common, key: `dev-${ev.id}-${dayKey(d)}`, startMs: d.getTime(), allDay: true });
      }
    } else {
      push(map, dayKey(new Date(ev.startMs)), { ...common, key: `dev-${ev.id}-${ev.startMs}`, startMs: ev.startMs, allDay: false });
    }
  });

  // Dia inteiro primeiro, depois por horário.
  map.forEach((list) =>
    list.sort((a, b) => (a.allDay === b.allDay ? a.startMs - b.startMs : a.allDay ? -1 : 1))
  );
  return map;
}
