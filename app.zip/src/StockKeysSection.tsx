import React, { useEffect, useState } from 'react';
import { Pressable, StyleSheet, Text, TextInput, View, useWindowDimensions } from 'react-native';
import { Button } from './Button';
import { StateMessage } from './StateMessage';
import { getSetting, setSetting } from './settings';
import { STOCK_SOURCES as ALL_SOURCES, stockExtraName, stockKeyName, testStockKey } from './stockImages';
import { colors, fonts, HIT, LEADING, SPACE, TYPE } from './theme';

type Status = { ok: boolean; text: string };

const STOCK_SOURCES = ALL_SOURCES.filter((s) => s.needsKey);

/** Chaves gratuitas dos bancos de imagem (Pexels, Unsplash) usados no moodboard. */
export function StockKeysSection() {
  const { width: sw } = useWindowDimensions();
  const [keys, setKeys] = useState<Record<string, string>>({ pexels: '', unsplash: '' });
  const [show, setShow] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState<Status | null>(null);

  useEffect(() => {
    const slots = STOCK_SOURCES.flatMap((s) => [
      { id: s.id, name: stockKeyName(s.id) },
      ...(s.extra ? [{ id: `${s.id}_${s.extra.id}`, name: stockExtraName(s.id, s.extra.id) }] : []),
    ]);
    Promise.all(slots.map((x) => getSetting(x.name)))
      .then((vals) => setKeys(Object.fromEntries(slots.map((x, i) => [x.id, vals[i] ?? '']))))
      .finally(() => setLoaded(true));
  }, []);

  const saveAll = async () => {
    for (const s of STOCK_SOURCES) {
      await setSetting(stockKeyName(s.id), (keys[s.id] ?? '').trim());
      if (s.extra) await setSetting(stockExtraName(s.id, s.extra.id), (keys[`${s.id}_${s.extra.id}`] ?? '').trim());
    }
  };

  const save = async () => {
    await saveAll();
    setStatus({ ok: true, text: 'Salvo no celular.' });
  };

  const test = async () => {
    setBusy(true);
    setStatus(null);
    const lines: string[] = [];
    let allOk = true;
    for (const s of STOCK_SOURCES) {
      if (!(keys[s.id] ?? '').trim()) continue;
      if (s.extra) await setSetting(stockExtraName(s.id, s.extra.id), (keys[`${s.id}_${s.extra.id}`] ?? '').trim());
      const r = await testStockKey(s.id, keys[s.id]);
      lines.push(r.message);
      if (!r.ok) allOk = false;
    }
    if (lines.length === 0) setStatus({ ok: false, text: 'Cole pelo menos uma chave.' });
    else {
      setStatus({ ok: allOk, text: lines.join('\n') });
      if (allOk) await saveAll();
    }
    setBusy(false);
  };

  const label = sw * TYPE.label;
  const input = sw * TYPE.subtitle;

  return (
    <View>
      <View style={[styles.row, { justifyContent: 'flex-end' }]}>
        <Pressable onPress={() => setShow((v) => !v)} hitSlop={HIT.md} accessibilityRole="button" accessibilityLabel={show ? 'Ocultar chaves' : 'Mostrar chaves'}>
          <Text style={{ color: colors.muted, fontFamily: fonts.regular, fontSize: label }}>{show ? 'Ocultar' : 'Mostrar'}</Text>
        </Pressable>
      </View>

      {STOCK_SOURCES.map((s) => (
        <View key={s.id} style={{ marginTop: sw * SPACE.md }}>
          <Text style={[styles.label, { fontSize: label }]}>{`Chave do ${s.label} (${s.keyUrl})`}</Text>
          <TextInput
            value={keys[s.id] ?? ''}
            onChangeText={(t) => setKeys((k) => ({ ...k, [s.id]: t }))}
            editable={loaded}
            secureTextEntry={!show}
            autoCapitalize="none"
            autoCorrect={false}
            autoComplete="off"
            spellCheck={false}
            accessibilityLabel={`Chave do ${s.label}`}
            placeholder="Cole a chave aqui"
            placeholderTextColor={colors.muted}
            style={[styles.input, { fontSize: input, paddingVertical: sw * SPACE.sm, marginTop: sw * SPACE.sm }]}
          />
          {s.extra && (
            <>
              <Text style={[styles.label, { fontSize: label, marginTop: sw * SPACE.md }]}>{s.extra.label}</Text>
              <TextInput
                value={keys[`${s.id}_${s.extra.id}`] ?? ''}
                onChangeText={(t) => setKeys((k) => ({ ...k, [`${s.id}_${s.extra!.id}`]: t }))}
                editable={loaded}
                autoCapitalize="none"
                autoCorrect={false}
                autoComplete="off"
                spellCheck={false}
                accessibilityLabel={s.extra.label}
                placeholder="Cole o código aqui"
                placeholderTextColor={colors.muted}
                style={[styles.input, { fontSize: input, paddingVertical: sw * SPACE.sm, marginTop: sw * SPACE.sm }]}
              />
            </>
          )}
        </View>
      ))}

      <View style={{ marginTop: sw * SPACE.xl, gap: sw * SPACE.sm }}>
        <Button label="Salvar" onPress={save} disabled={busy} />
        <Button label="Testar conexão" variant="secondary" onPress={test} loading={busy} />
      </View>

      {status && (
        <StateMessage kind={status.ok ? 'info' : 'error'} style={{ marginTop: sw * SPACE.lg }}>
          {status.text}
        </StateMessage>
      )}

      <Text style={{ marginTop: sw * SPACE.lg, color: colors.muted, fontFamily: fonts.regular, fontSize: sw * TYPE.caption, lineHeight: sw * TYPE.caption * LEADING }}>
        As chaves são gratuitas e ficam guardadas só neste celular. Com elas, o moodboard busca fotos em alta e por tema. O Openverse não precisa de chave.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  label: { color: colors.muted, fontFamily: fonts.regular },
  row: { flexDirection: 'row', alignItems: 'center' },
  input: { color: colors.text, fontFamily: fonts.regular, borderBottomWidth: 2, borderBottomColor: colors.text },
});
