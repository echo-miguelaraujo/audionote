import { Directory, File, Paths } from 'expo-file-system';

const SCHEME = 'app-media://';

function mediaDir(): Directory {
  const dir = new Directory(Paths.document, 'media');
  if (!dir.exists) dir.create({ idempotent: true, intermediates: true });
  return dir;
}

function baseUri(): string {
  const u = mediaDir().uri;
  return u.endsWith('/') ? u : `${u}/`;
}

export const mediaUri = (name: string): string => `${baseUri()}${encodeURI(name)}`;

const safeName = (s: string) =>
  s
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^A-Za-z0-9._-]+/g, '_')
    .slice(-60) || 'arquivo';

/** Copia um arquivo escolhido (imagem, vídeo, documento) para a pasta do app. Retorna o nome guardado. */
export function saveMedia(sourceUri: string, originalName?: string | null, fallbackExt = 'bin'): string {
  const fromUri = decodeURIComponent(sourceUri.split('?')[0].split('/').pop() || '');
  const base = safeName(originalName || fromUri || `arquivo.${fallbackExt}`);
  const hasExt = /\.[A-Za-z0-9]{1,6}$/.test(base);
  const name = `${Date.now().toString(36)}_${hasExt ? base : `${base}.${fallbackExt}`}`;
  new File(sourceUri).copy(new File(mediaDir(), name));
  return name;
}

/** Nome guardado (ex.: "k3_foto.jpg") -> URI que a WebView consegue abrir. */
export function mediaFile(name: string): File {
  return new File(mediaDir(), name);
}

/** Texto guardado (com app-media://) -> texto para mostrar na WebView (com o caminho real do arquivo). */
export function toWebHtml(html: string): string {
  return html.split(SCHEME).join(baseUri());
}

/** Texto da WebView -> texto para guardar (independente do caminho do app, que muda entre instalações). */
export function toStoredHtml(html: string): string {
  return html.split(baseUri()).join(SCHEME);
}

export const storedRef = (name: string): string => `${SCHEME}${encodeURI(name)}`;

/** "app-media://nome.ext" -> nome do arquivo (decodificado). */
export function nameFromRef(ref: string): string {
  return decodeURIComponent(ref.replace(SCHEME, '').replace(baseUri(), ''));
}

export function mimeFor(name: string): string {
  const ext = name.split('.').pop()?.toLowerCase() ?? '';
  const map: Record<string, string> = {
    pdf: 'application/pdf',
    png: 'image/png',
    jpg: 'image/jpeg',
    jpeg: 'image/jpeg',
    gif: 'image/gif',
    webp: 'image/webp',
    mp4: 'video/mp4',
    mov: 'video/quicktime',
    webm: 'video/webm',
    mp3: 'audio/mpeg',
    m4a: 'audio/mp4',
    txt: 'text/plain',
    csv: 'text/csv',
    doc: 'application/msword',
    docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    xls: 'application/vnd.ms-excel',
    xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    ppt: 'application/vnd.ms-powerpoint',
    pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    zip: 'application/zip',
  };
  return map[ext] ?? '*/*';
}
