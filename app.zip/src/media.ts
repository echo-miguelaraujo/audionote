import { Directory, File, Paths } from 'expo-file-system';

const SCHEME = 'app-media://';

function mediaDir(): Directory {
  const dir = new Directory(Paths.document, 'media');
  if (!dir.exists) dir.create({ idempotent: true, intermediates: true });
  return dir;
}

let cachedBase: string | null = null;
/** Caminho da pasta de mídia. Guardado: é chamado a cada imagem desenhada e não precisa tocar no disco toda vez. */
function baseUri(): string {
  if (cachedBase) return cachedBase;
  const u = mediaDir().uri;
  cachedBase = u.endsWith('/') ? u : `${u}/`;
  return cachedBase;
}

/** Foto da web: o "nome" guardado no card é o próprio endereço (http/https), não um arquivo do app. */
export const isRemote = (name: string): boolean => /^https?:\/\//i.test(name);

export const mediaUri = (name: string): string => (isRemote(name) ? name : `${baseUri()}${encodeURI(name)}`);

const safeName = (s: string) =>
  s
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^A-Za-z0-9._-]+/g, '_')
    .slice(-60) || 'arquivo';

/** Copia um arquivo escolhido (imagem, vídeo, documento) para a pasta do app. Retorna o nome guardado. */
export function saveMedia(sourceUri: string, originalName?: string | null, fallbackExt = 'bin'): string {
  const fromUri = decodeURIComponent(sourceUri.split('?')[0].split('/').pop() || '');
  const base = safeName(originalName || fromUri || `arquivo.${fallbackExt}`);
  const hasExt = /\.[A-Za-z0-9]{1,6}$/.test(base);
  const name = `${Date.now().toString(36)}_${hasExt ? base : `${base}.${fallbackExt}`}`;
  new File(sourceUri).copy(new File(mediaDir(), name));
  return name;
}

/** Nome guardado (ex.: "k3_foto.jpg") -> URI que a WebView consegue abrir. */
export function mediaFile(name: string): File {
  // Foto da web não tem arquivo: devolve um caminho que nunca existe (apagar/enviar viram "nada a fazer").
  return new File(mediaDir(), isRemote(name) ? '.remote-none' : name);
}

/** Texto guardado (com app-media://) -> texto para mostrar na WebView (com o caminho real do arquivo). */
export function toWebHtml(html: string): string {
  return html.split(SCHEME).join(baseUri());
}

/** Texto da WebView -> texto para guardar (independente do caminho do app, que muda entre instalações). */
export function toStoredHtml(html: string): string {
  return html.split(baseUri()).join(SCHEME);
}

export const storedRef = (name: string): string => `${SCHEME}${encodeURI(name)}`;

/** "app-media://nome.ext" -> nome do arquivo (decodificado). */
export function nameFromRef(ref: string): string {
  return decodeURIComponent(ref.replace(SCHEME, '').replace(baseUri(), ''));
}

export function mimeFor(name: string): string {
  const ext = name.split('.').pop()?.toLowerCase() ?? '';
  const map: Record<string, string> = {
    pdf: 'application/pdf',
    png: 'image/png',
    jpg: 'image/jpeg',
    jpeg: 'image/jpeg',
    gif: 'image/gif',
    webp: 'image/webp',
    mp4: 'video/mp4',
    mov: 'video/quicktime',
    webm: 'video/webm',
    mp3: 'audio/mpeg',
    m4a: 'audio/mp4',
    aac: 'audio/aac',
    txt: 'text/plain',
    csv: 'text/csv',
    doc: 'application/msword',
    docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    xls: 'application/vnd.ms-excel',
    xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    ppt: 'application/vnd.ms-powerpoint',
    pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    zip: 'application/zip',
  };
  return map[ext] ?? '*/*';
}

/** Apaga um arquivo da pasta media, se existir. */
export function deleteMedia(name: string): void {
  try {
    const f = mediaFile(name);
    if (f.exists) f.delete();
  } catch {
    // já não existe
  }
}

const MAX_REMOTE_IMAGE = 5 * 1024 * 1024;

/** Extensão pelos primeiros bytes (jpg, png, gif, webp). null = não é uma imagem aceita. */
function imageExtFromBytes(b: Uint8Array): string | null {
  if (b.length >= 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return 'jpg';
  if (b.length >= 4 && b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return 'png';
  if (b.length >= 4 && b[0] === 0x47 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x38) return 'gif';
  if (b.length >= 12 && b[0] === 0x52 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x46 && b[8] === 0x57 && b[9] === 0x45 && b[10] === 0x42 && b[11] === 0x50) return 'webp';
  return null;
}

/**
 * Baixa uma imagem da internet para a pasta media (nome "<tempo>_link.<ext>").
 * Devolve null se falhar, se passar de 5 MB ou se o arquivo não for uma imagem.
 */
export async function saveRemoteImage(url: string): Promise<string | null> {
  const tmp = new File(Paths.cache, `dl_${Date.now().toString(36)}.tmp`);
  try {
    const got = await File.downloadFileAsync(url, tmp);
    if (!got.exists || got.size === 0 || got.size > MAX_REMOTE_IMAGE) return null;
    const bytes = await got.bytes();
    const ext = imageExtFromBytes(bytes.slice(0, 12));
    if (!ext) return null;
    const name = `${Date.now().toString(36)}_link.${ext}`;
    got.copy(new File(mediaDir(), name));
    return name;
  } catch {
    return null;
  } finally {
    try {
      if (tmp.exists) tmp.delete();
    } catch {
      // ignora
    }
  }
}

const VIDEO_EXTS = ['mp4', 'm4v', 'mov', 'webm', '3gp', 'mkv'];
export const MAX_VIDEO_DOWNLOAD = 150 * 1024 * 1024;

/** Endereço de transmissão (HLS/DASH): toca, mas não dá para baixar como um arquivo só. */
export const isStreamUrl = (url: string): boolean => /\.(m3u8|mpd)(\?|#|$)/i.test(url);

export type VideoDownload = { ok: true; name: string } | { ok: false; reason: 'stream' | 'big' | 'fail' };

/**
 * Baixa um vídeo da internet para a pasta media (nome "<tempo>_video.<ext>").
 * Recusa transmissões (m3u8/mpd) e arquivos maiores que `maxBytes`.
 */
export async function saveRemoteVideo(url: string, maxBytes = MAX_VIDEO_DOWNLOAD): Promise<VideoDownload> {
  if (isStreamUrl(url)) return { ok: false, reason: 'stream' };
  try {
    // Pergunta o tamanho antes de baixar (nem todo servidor responde; sem resposta, confere depois).
    const head = await fetch(url, { method: 'HEAD' }).catch(() => null);
    const len = Number(head?.headers.get('content-length') ?? 0);
    if (len > maxBytes) return { ok: false, reason: 'big' };
  } catch {
    // segue sem o tamanho
  }
  const clean = url.split('?')[0].split('#')[0];
  const m = /\.([A-Za-z0-9]{2,4})$/.exec(clean);
  const ext = m && VIDEO_EXTS.includes(m[1].toLowerCase()) ? m[1].toLowerCase() : 'mp4';
  const tmp = new File(Paths.cache, `dlv_${Date.now().toString(36)}.tmp`);
  try {
    const got = await File.downloadFileAsync(url, tmp);
    if (!got.exists || got.size === 0) return { ok: false, reason: 'fail' };
    if (got.size > maxBytes) return { ok: false, reason: 'big' };
    const name = `${Date.now().toString(36)}_video.${ext}`;
    got.copy(new File(mediaDir(), name));
    return { ok: true, name };
  } catch {
    return { ok: false, reason: 'fail' };
  } finally {
    try {
      if (tmp.exists) tmp.delete();
    } catch {
      // ignora
    }
  }
}
