import React, { useEffect, useState } from 'react';
import { Pressable, ScrollView, Text, View, useWindowDimensions } from 'react-native';
import { DialogAction, SheetShell } from './DialogBase';
import { StateMessage } from './StateMessage';
import { FlatCollection, listCollectionTree } from './db';
import { colors, fonts } from './theme';

type Props = {
  visible: boolean;
  title: string;
  onCancel: () => void;
  onPick: (collectionId: number) => void;
};

/** Janela com todas as coleções (com o caminho, ex.: "Viagens › Japão") para escolher uma. */
export function CollectionPicker({ visible, title, onCancel, onPick }: Props) {
  const { width: sw, height: sh } = useWindowDimensions();
  const u = Math.min(sw, sh);
  const [list, setList] = useState<FlatCollection[] | null>(null);

  useEffect(() => {
    if (!visible) return;
    setList(null);
    listCollectionTree()
      .then(setList)
      .catch(() => setList([]));
  }, [visible]);

  return (
    <SheetShell visible={visible} onClose={onCancel} maxHeight={sh * 0.75}>
          <Text style={{ fontFamily: fonts.bold, fontSize: u * 0.05, color: colors.onLight, padding: u * 0.04 }}>{title}</Text>
          <ScrollView>
            {list === null ? (
              <StateMessage kind="loading" surface="light" centered style={{ padding: u * 0.05 }}>Carregando…</StateMessage>
            ) : list.length === 0 ? (
              <StateMessage kind="empty" centered style={{ padding: u * 0.05 }}>
                Nenhuma coleção ainda. Crie uma na aba Moodboard.
              </StateMessage>
            ) : (
              list.map((c) => (
                <Pressable
                  key={c.id}
                  accessibilityRole="button"
                  onPress={() => onPick(c.id)}
                  style={{ paddingVertical: u * 0.035, paddingHorizontal: u * 0.04, borderTopWidth: 1, borderTopColor: colors.hairline }}
                >
                  <Text numberOfLines={2} style={{ fontFamily: fonts.regular, fontSize: u * 0.042, color: colors.onLight }}>
                    {c.path}
                  </Text>
                </Pressable>
              ))
            )}
          </ScrollView>
          <View style={{ padding: u * 0.04, alignItems: 'center', borderTopWidth: 1, borderTopColor: colors.hairline }}>
            <DialogAction label="Cancelar" tone="cancel" onPress={onCancel} />
          </View>
    </SheetShell>
  );
}

