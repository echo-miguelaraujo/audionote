import React, { useEffect, useState } from 'react';
import { Modal, Pressable, ScrollView, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { FlatCollection, listCollectionTree } from './db';
import { fonts } from './theme';

type Props = {
  visible: boolean;
  title: string;
  onCancel: () => void;
  onPick: (collectionId: number) => void;
};

/** Janela com todas as coleções (com o caminho, ex.: "Viagens › Japão") para escolher uma. */
export function CollectionPicker({ visible, title, onCancel, onPick }: Props) {
  const { width: sw, height: sh } = useWindowDimensions();
  const u = Math.min(sw, sh);
  const insets = useSafeAreaInsets();
  const [list, setList] = useState<FlatCollection[] | null>(null);

  useEffect(() => {
    if (!visible) return;
    setList(null);
    listCollectionTree()
      .then(setList)
      .catch(() => setList([]));
  }, [visible]);

  return (
    <Modal visible={visible} transparent animationType="fade" statusBarTranslucent onRequestClose={onCancel}>
      <Pressable style={styles.overlay} onPress={onCancel}>
        <Pressable
          onPress={() => {}}
          style={[styles.card, { maxHeight: sh * 0.75, marginBottom: insets.bottom + u * 0.04, marginHorizontal: u * 0.04 }]}
        >
          <Text style={{ fontFamily: fonts.bold, fontSize: u * 0.05, color: '#000', padding: u * 0.04 }}>{title}</Text>
          <ScrollView>
            {list === null ? (
              <Text style={[styles.empty, { fontSize: u * 0.04 }]}>Carregando…</Text>
            ) : list.length === 0 ? (
              <Text style={[styles.empty, { fontSize: u * 0.04 }]}>Nenhuma coleção ainda. Crie uma na aba Moodboard.</Text>
            ) : (
              list.map((c) => (
                <Pressable
                  key={c.id}
                  onPress={() => onPick(c.id)}
                  style={{ paddingVertical: u * 0.035, paddingHorizontal: u * 0.04, borderTopWidth: 1, borderTopColor: '#E6E6E6' }}
                >
                  <Text numberOfLines={2} style={{ fontFamily: fonts.regular, fontSize: u * 0.042, color: '#000' }}>
                    {c.path}
                  </Text>
                </Pressable>
              ))
            )}
          </ScrollView>
          <Pressable onPress={onCancel} style={{ padding: u * 0.04, borderTopWidth: 1, borderTopColor: '#E6E6E6' }}>
            <Text style={{ fontFamily: fonts.regular, fontSize: u * 0.042, color: '#FF3030', textAlign: 'center' }}>Cancelar</Text>
          </Pressable>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  card: { backgroundColor: '#fff', borderRadius: 18, overflow: 'hidden' },
  empty: { fontFamily: fonts.regular, color: '#808080', padding: 18 },
});
