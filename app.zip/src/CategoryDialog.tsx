import React, { useEffect, useState } from 'react';
import { View, useWindowDimensions } from 'react-native';
import { Category } from './db';
import { ColorWheel } from './ColorWheel';
import { ColorChip, DialogActions, DialogInput, DialogShell, DialogTitle } from './DialogBase';
import { categoryColors, SPACE } from './theme';

type Props = {
  visible: boolean;
  /** null = criando uma nova. */
  category: Category | null;
  onCancel: () => void;
  onSave: (name: string, color: string) => void;
  onDelete: (category: Category) => void;
};

export function CategoryDialog({ visible, category, onCancel, onSave, onDelete }: Props) {
  const { width: sw } = useWindowDimensions();
  const [name, setName] = useState('');
  const [color, setColor] = useState(categoryColors[0]);

  useEffect(() => {
    if (visible) {
      setName(category?.name ?? '');
      setColor(category?.color ?? categoryColors[0]);
    }
  }, [visible, category]);

  const submit = () => {
    const n = name.trim();
    if (n) onSave(n, color);
  };

  return (
    <DialogShell visible={visible} onClose={onCancel}>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
        <DialogTitle>{category ? 'Editar categoria' : 'Criar categoria'}</DialogTitle>
        <ColorChip color={color} />
      </View>
      <DialogInput
        value={name}
        onChangeText={setName}
        maxLength={30}
        placeholder="Nome da categoria"
        onSubmitEditing={submit}
        returnKeyType="done"
      />
      <View style={{ marginTop: sw * SPACE.lg }}>
        <ColorWheel
          key={category ? `e${category.id}` : 'new'}
          initial={category?.color ?? categoryColors[0]}
          size={sw * 0.6}
          onChange={setColor}
        />
      </View>
      <DialogActions
        onCancel={onCancel}
        confirmLabel="Salvar"
        onConfirm={submit}
        extra={category ? { label: 'Excluir', onPress: () => onDelete(category) } : undefined}
      />
    </DialogShell>
  );
}
