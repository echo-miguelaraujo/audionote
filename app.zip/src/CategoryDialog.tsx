import React, { useEffect, useState } from 'react';
import { Modal, Pressable, StyleSheet, Text, TextInput, View, useWindowDimensions } from 'react-native';
import { Category } from './db';
import { ColorWheel } from './ColorWheel';
import { categoryColors, colors, fonts } from './theme';

type Props = {
  visible: boolean;
  /** null = criando uma nova. */
  category: Category | null;
  onCancel: () => void;
  onSave: (name: string, color: string) => void;
  onDelete: (category: Category) => void;
};

export function CategoryDialog({ visible, category, onCancel, onSave, onDelete }: Props) {
  const { width: sw, height: sh } = useWindowDimensions();
  const [name, setName] = useState('');
  const [color, setColor] = useState(categoryColors[0]);

  useEffect(() => {
    if (visible) {
      setName(category?.name ?? '');
      setColor(category?.color ?? categoryColors[0]);
    }
  }, [visible, category]);

  const sw2 = sw * 0.085;

  const submit = () => {
    const n = name.trim();
    if (n) onSave(n, color);
  };


  return (
    <Modal visible={visible} transparent animationType="fade" statusBarTranslucent onRequestClose={onCancel}>
      <Pressable style={[styles.overlay, { paddingTop: sh * 0.08 }]} onPress={onCancel}>
        <Pressable
          style={[styles.card, { width: sw * 0.84, borderRadius: sw * 0.074, padding: sw * 0.06 }]}
          onPress={() => {}}
        >
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
            <Text style={[styles.title, { fontSize: sw * 0.06 }]}>
              {category ? 'Editar categoria' : 'Criar categoria'}
            </Text>
            <View
              style={{ width: sw2, height: sw2, borderRadius: sw2 * 0.38, backgroundColor: color }}
            />
          </View>
          <TextInput
            value={name}
            onChangeText={setName}
            maxLength={30}
            placeholder="Nome da categoria"
            placeholderTextColor="#808080"
            onSubmitEditing={submit}
            returnKeyType="done"
            style={[styles.input, { fontSize: sw * 0.05 }]}
          />
          <View style={{ marginTop: sw * 0.05 }}>
            <ColorWheel
              key={category ? `e${category.id}` : 'new'}
              initial={category?.color ?? categoryColors[0]}
              size={sw * 0.6}
              onChange={setColor}
            />
          </View>
          <View style={styles.row}>
            {category ? (
              <Pressable onPress={() => onDelete(category)} hitSlop={12} style={{ marginRight: 'auto' }}>
                <Text style={[styles.btn, { fontSize: sw * 0.045, color: colors.red }]}>Excluir</Text>
              </Pressable>
            ) : null}
            <Pressable onPress={onCancel} hitSlop={12}>
              <Text style={[styles.btn, { fontSize: sw * 0.05, color: '#808080' }]}>Cancelar</Text>
            </Pressable>
            <Pressable onPress={submit} hitSlop={12}>
              <Text style={[styles.btn, { fontSize: sw * 0.05 }]}>Salvar</Text>
            </Pressable>
          </View>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.78)', alignItems: 'center' },
  card: { backgroundColor: '#FFFFFF' },
  title: { color: '#000', fontFamily: fonts.bold, letterSpacing: -1 },
  input: {
    color: '#000',
    fontFamily: fonts.regular,
    borderBottomWidth: 2,
    borderBottomColor: '#000',
    paddingVertical: 8,
    marginTop: 16,
  },
  swatches: { flexDirection: 'row', flexWrap: 'wrap' },
  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end', gap: 28, marginTop: 28 },
  btn: { color: '#000', fontFamily: fonts.bold },
});
