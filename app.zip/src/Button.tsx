import React from 'react';
import { ActivityIndicator, Pressable, StyleProp, Text, View, ViewStyle, useWindowDimensions } from 'react-native';
import { Icon, IconName } from './Icon';
import { colors, fonts, RADIUS, TYPE, HIT } from './theme';

/**
 * - primary: pílula branca (ação principal)
 * - secondary: contorno branco, sem preenchimento
 * - destructive: pílula vermelha
 * - dark: pílula preta, para uso sobre o quadro claro do moodboard
 */
export type ButtonVariant = 'primary' | 'secondary' | 'destructive' | 'dark';

type ButtonProps = {
  label: string;
  onPress: () => void;
  variant?: ButtonVariant;
  /** `block` ocupa a largura toda (telas e formulários); `compact` é a pílula pequena de barras de ferramentas. */
  size?: 'block' | 'compact';
  loading?: boolean;
  disabled?: boolean;
  /** Unidade de tamanho (largura da tela, ou o lado menor no moodboard). Padrão: largura da tela. */
  u?: number;
  style?: StyleProp<ViewStyle>;
};

const LOOK: Record<ButtonVariant, { bg: string; fg: string; border?: string }> = {
  primary: { bg: colors.paper, fg: colors.onLight },
  secondary: { bg: 'transparent', fg: colors.onDark, border: colors.onDark },
  destructive: { bg: colors.red, fg: colors.onDark },
  dark: { bg: colors.bg, fg: colors.onDark },
};

/**
 * Botão padrão do app. Declare fora de componentes que re-renderizam (como este arquivo já faz):
 * um botão criado dentro do render é recriado a cada frame e o toque se perde.
 */
export function Button({ label, onPress, variant = 'primary', size = 'block', loading, disabled, u, style }: ButtonProps) {
  const { width } = useWindowDimensions();
  const unit = u ?? width;
  const look = LOOK[variant];
  const compact = size === 'compact';
  const off = disabled || loading;

  return (
    <Pressable
      onPress={onPress}
      disabled={off}
      hitSlop={compact ? HIT.sm : undefined}
      accessibilityRole="button"
      accessibilityState={{ disabled: !!off, busy: !!loading }}
      style={[
        {
          backgroundColor: look.bg,
          borderColor: look.border,
          borderWidth: look.border ? 1.5 : 0,
          borderRadius: unit * (compact ? 0.08 : RADIUS.pill),
          paddingVertical: unit * (compact ? 0.026 : 0.035),
          paddingHorizontal: unit * (compact ? 0.04 : 0.06),
          alignItems: 'center',
          justifyContent: 'center',
          alignSelf: compact ? 'auto' : 'stretch',
          opacity: disabled ? 0.4 : 1,
        },
        style,
      ]}
    >
      {loading ? (
        <ActivityIndicator color={look.fg} />
      ) : (
        <Text
          style={{
            color: look.fg,
            fontFamily: compact ? fonts.regular : fonts.bold,
            fontSize: unit * (compact ? TYPE.label : TYPE.body),
          }}
        >
          {label}
        </Text>
      )}
    </Pressable>
  );
}

type IconButtonProps = {
  icon: IconName;
  onPress: () => void;
  label: string; // acessibilidade
  u?: number;
  /** `glass`: círculo branco translúcido sobre o quadro. `solid`: círculo branco opaco. */
  tone?: 'glass' | 'solid';
};

/** Botão redondo só com ícone (zoom, ajustar à tela, fechar…). */
export function IconButton({ icon, onPress, label, u, tone = 'glass' }: IconButtonProps) {
  const { width } = useWindowDimensions();
  const unit = u ?? width;
  const d = unit * 0.11;
  return (
    <Pressable
      onPress={onPress}
      hitSlop={HIT.sm}
      accessibilityRole="button"
      accessibilityLabel={label}
      style={{
        width: d,
        height: d,
        borderRadius: d / 2,
        backgroundColor: tone === 'glass' ? colors.glass : colors.paper,
        borderWidth: tone === 'glass' ? 1 : 0,
        borderColor: colors.glassLine,
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <View>
        <Icon name={icon} size={d * 0.5} color={colors.onLight} />
      </View>
    </Pressable>
  );
}
