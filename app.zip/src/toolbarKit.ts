/**
 * Barra de formatação única dos editores de texto (notas corridas, moodboard e layout livre): uma pílula branca
 * flutuante, só com ícones. O "+" (preto) abre o menu de inserir; não existe botão "Mais".
 * Aparência, botões e painéis ficam AQUI; cada editor só define onde a pílula fica na tela
 * e quais comandos ela dispara (data-c, data-p, data-l).
 */
import { icon, HtmlIconName } from './htmlIcons';

/** CSS da pílula e dos painéis (sempre brancos). Vai depois do CSS de cada editor. */
export const PILL_CSS = `
#bar,#dh{background:#fff;border:1px solid #e4e4e4;border-radius:28px;box-shadow:0 6px 22px rgba(0,0,0,.28);overflow:hidden}
#row{display:flex;gap:2px;align-items:center;overflow-x:auto;padding:5px 6px;-webkit-overflow-scrolling:touch;-webkit-mask-image:linear-gradient(to right,#000 94%,transparent);mask-image:linear-gradient(to right,#000 94%,transparent)}
#row::-webkit-scrollbar{display:none}
.b{flex:0 0 auto;min-width:40px;height:40px;padding:0;border-radius:20px;background:transparent;color:#111;border:0;font-family:inherit;font-size:16px;font-weight:700;display:flex;align-items:center;justify-content:center}
.b.on{background:#111;color:#fff}
.b.plus{background:#111;color:#fff}
.b.dim{opacity:.35}
.sep{flex:0 0 1px;height:24px;background:#e2e2e2;margin:0 4px}
#tblrow .b,#colrow .b{background:#F2F2F2;color:#111;padding:0 12px;font-size:14px;font-weight:600}
#panel,#pn{background:#fff;color:#111;border-radius:26px;box-shadow:0 6px 22px rgba(0,0,0,.28);margin:0 10px 8px;padding:12px}
#panel .ttl{color:#666}
#panel .opt{background:#F2F2F2;color:#111;border:0}
#panel .opt.on{background:#111;color:#fff}
#panel small{color:#777}
#panel .lbl,#panel .val{color:#111}
.sw{border:2px solid #ddd}
`;

export const TB_SEP = '<div class="sep"></div>';

/** Botão só com ícone. `attrs` leva o comando (ex.: `data-c="undo"`). */
export const tbBtn = (name: HtmlIconName, label: string, attrs = '', cls = ''): string =>
  `<button class="b${cls ? ' ' + cls : ''}" ${attrs} aria-label="${label}">${icon(name)}</button>`;

/** O "+" da pílula (inserir). */
export const tbPlus = tbBtn('plus', 'Inserir', 'data-p="insert"', 'plus');
