import { getSetting } from './settings';

/** Bancos de imagem gratuitos que o moodboard consegue consultar. */
export type StockSource = 'pexels' | 'unsplash' | 'openverse' | 'arena' | 'artic' | 'link' | 'flickr' | 'commons' | 'inat' | 'nasa' | 'cleveland' | 'met' | 'wellcome' | 'loc' | 'serper';

/** `needsKey: false` = funciona sem cadastro (Openverse). */
export const STOCK_SOURCES: { id: StockSource; label: string; keyUrl: string; needsKey: boolean; extra?: { id: string; label: string } }[] = [
  { id: 'unsplash', label: 'Unsplash', keyUrl: 'unsplash.com/developers', needsKey: true },
  { id: 'pexels', label: 'Pexels', keyUrl: 'pexels.com/api', needsKey: true },
  { id: 'openverse', label: 'Openverse', keyUrl: 'openverse.org', needsKey: false },
  { id: 'arena', label: 'Are.na', keyUrl: 'are.na/settings/personal-access-tokens', needsKey: true },
  { id: 'flickr', label: 'Flickr', keyUrl: 'flickr.com/services/apps/create', needsKey: true },
  { id: 'commons', label: 'Wikimedia', keyUrl: 'commons.wikimedia.org', needsKey: false },
  { id: 'artic', label: 'Art Institute', keyUrl: 'artic.edu', needsKey: false },
  { id: 'inat', label: 'iNaturalist', keyUrl: 'inaturalist.org', needsKey: false },
  { id: 'nasa', label: 'NASA', keyUrl: 'images.nasa.gov', needsKey: false },
  { id: 'cleveland', label: 'Cleveland', keyUrl: 'clevelandart.org', needsKey: false },
  { id: 'met', label: 'The Met', keyUrl: 'metmuseum.org', needsKey: false },
  { id: 'wellcome', label: 'Wellcome', keyUrl: 'wellcomecollection.org', needsKey: false },
  { id: 'loc', label: 'Library of Congress', keyUrl: 'loc.gov', needsKey: false },
  { id: 'serper', label: 'Google (Serper)', keyUrl: 'serper.dev', needsKey: true },
  /** Cosmos, Dupe e qualquer site: cola o link da foto e o app pega a imagem da página. */
  { id: 'link', label: 'Link', keyUrl: '', needsKey: false },
];

/** Bancos sem "em alta": só mostram resultado quando há um tema digitado. */
export const NO_TRENDING: StockSource[] = ['openverse', 'arena', 'artic', 'link', 'commons', 'nasa', 'cleveland', 'met', 'wellcome', 'loc', 'serper'];

/** Foto de qualquer banco, no mesmo formato. */
export type StockPhoto = {
  /** Único no app todo: "pexels:123". */
  uid: string;
  source: StockSource;
  width: number;
  height: number;
  /** Miniatura leve, para a grade de resultados e para o card quando está pequeno. */
  thumbUrl: string;
  /** Versão grande, para o card quando o usuário dá zoom. */
  fullUrl: string;
  /** Página da foto no banco (crédito). */
  pageUrl: string;
  author: string;
  authorUrl: string;
  /** Só Unsplash: endereço que precisa ser avisado quando a foto é usada. */
  downloadLocation?: string;
  /** Licença, ex.: "CC BY 2.0" (Openverse) ou "Domínio público" (Art Institute). */
  license?: string;
  /** O banco não informa o tamanho: o app mede a imagem ao adicionar ao quadro. */
  sizeUnknown?: boolean;
};

export type StockPage = { photos: StockPhoto[]; page: number; hasMore: boolean };

export type StockResult<T> = { ok: true; data: T } | { ok: false; message: string };

const KEY_PREFIX = 'stock_key_';
export const getStockKey = async (s: StockSource): Promise<string> => (await getSetting(KEY_PREFIX + s)) ?? '';
export const stockKeyName = (s: StockSource): string => KEY_PREFIX + s;
export const stockExtraName = (s: StockSource, extra: string): string => `${KEY_PREFIX}${s}_${extra}`;

const PER_PAGE = 30;
const TIMEOUT_MS = 15000;

async function getJson(
  url: string,
  headers: Record<string, string>,
  /** Mensagens específicas por status HTTP (têm prioridade sobre as genéricas abaixo). */
  statusMessages?: Partial<Record<number, string>>,
  /** Se vier, a requisição vira POST com este corpo em JSON. */
  body?: unknown,
): Promise<StockResult<any>> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
  try {
    const res = await fetch(url, body === undefined ? { headers, signal: ctrl.signal } : { method: 'POST', headers, body: JSON.stringify(body), signal: ctrl.signal });
    const custom = statusMessages?.[res.status];
    if (custom) return { ok: false, message: custom };
    if (res.status === 401 || res.status === 403) {
      return { ok: false, message: 'Chave recusada. Confira a chave em Configurações.' };
    }
    if (res.status === 429) {
      return { ok: false, message: 'Limite de uso do banco atingido. Tente de novo daqui a pouco.' };
    }
    if (!res.ok) return { ok: false, message: `O banco respondeu com erro (${res.status}).` };
    return { ok: true, data: await res.json() };
  } catch (e: any) {
    if (e?.name === 'AbortError') return { ok: false, message: 'O banco demorou demais para responder.' };
    return { ok: false, message: 'Sem conexão com a internet.' };
  } finally {
    clearTimeout(timer);
  }
}

const qs = (o: Record<string, string | number>) =>
  Object.entries(o)
    .map(([k, v]) => `${k}=${encodeURIComponent(String(v))}`)
    .join('&');

// ---------- Pexels ----------

function fromPexels(p: any): StockPhoto {
  return {
    uid: `pexels:${p.id}`,
    source: 'pexels',
    width: p.width,
    height: p.height,
    thumbUrl: p.src?.medium ?? p.src?.small,
    fullUrl: p.src?.large2x ?? p.src?.large ?? p.src?.original,
    pageUrl: p.url,
    author: p.photographer ?? 'Pexels',
    authorUrl: p.photographer_url ?? p.url,
  };
}

async function pexels(key: string, query: string, page: number): Promise<StockResult<StockPage>> {
  const q = query.trim();
  // Sem texto: as fotos selecionadas (em alta) do Pexels.
  const url = q
    ? `https://api.pexels.com/v1/search?${qs({ query: q, page, per_page: PER_PAGE })}`
    : `https://api.pexels.com/v1/curated?${qs({ page, per_page: PER_PAGE })}`;
  const r = await getJson(url, { Authorization: key });
  if (!r.ok) return r;
  const photos: StockPhoto[] = (r.data.photos ?? []).map(fromPexels);
  return { ok: true, data: { photos, page, hasMore: !!r.data.next_page } };
}

// ---------- Unsplash ----------

function fromUnsplash(p: any): StockPhoto {
  return {
    uid: `unsplash:${p.id}`,
    source: 'unsplash',
    width: p.width,
    height: p.height,
    thumbUrl: p.urls?.small ?? p.urls?.thumb,
    fullUrl: p.urls?.regular ?? p.urls?.full,
    pageUrl: p.links?.html,
    author: p.user?.name ?? 'Unsplash',
    authorUrl: p.user?.links?.html ?? p.links?.html,
    downloadLocation: p.links?.download_location,
  };
}

async function unsplash(key: string, query: string, page: number): Promise<StockResult<StockPage>> {
  const q = query.trim();
  const headers = { Authorization: `Client-ID ${key}`, 'Accept-Version': 'v1' };
  // Sem texto: as mais populares do Unsplash.
  const url = q
    ? `https://api.unsplash.com/search/photos?${qs({ query: q, page, per_page: PER_PAGE })}`
    : `https://api.unsplash.com/photos?${qs({ order_by: 'popular', page, per_page: PER_PAGE })}`;
  const r = await getJson(url, headers);
  if (!r.ok) return r;
  const list: any[] = q ? r.data.results ?? [] : r.data ?? [];
  const totalPages: number | undefined = q ? r.data.total_pages : undefined;
  return {
    ok: true,
    data: {
      photos: list.map(fromUnsplash),
      page,
      hasMore: totalPages != null ? page < totalPages : list.length >= PER_PAGE,
    },
  };
}

// ---------- Openverse (sem chave) ----------

function fromOpenverse(p: any): StockPhoto {
  const lic = p.license ? `CC ${String(p.license).toUpperCase()}${p.license_version ? ' ' + p.license_version : ''}` : undefined;
  // O Openverse entrega uma miniatura própria (até ~600px), estável e leve. O arquivo original
  // fica em servidores de terceiros, que muitas vezes bloqueiam o uso direto, por isso não é usado.
  const img = p.thumbnail ?? p.url;
  return {
    uid: `openverse:${p.id}`,
    source: 'openverse',
    width: p.width || 800,
    height: p.height || 600,
    thumbUrl: img,
    fullUrl: img,
    pageUrl: p.foreign_landing_url ?? p.url,
    author: p.creator ?? p.source ?? 'Openverse',
    authorUrl: p.creator_url ?? p.foreign_landing_url ?? p.url,
    license: lic,
    sizeUnknown: !p.width || !p.height,
  };
}

async function openverse(query: string, page: number): Promise<StockResult<StockPage>> {
  const q = query.trim();
  // O Openverse não tem "em alta": sem texto, não há o que mostrar.
  if (!q) return { ok: true, data: { photos: [], page, hasMore: false } };
  // Anônimo: no máximo 20 por página.
  const url = `https://api.openverse.org/v1/images/?${qs({ q, page, page_size: 20, mature: 'false' })}`;
  const r = await getJson(url, {});
  if (!r.ok) return r;
  const photos: StockPhoto[] = (r.data.results ?? []).map(fromOpenverse);
  return { ok: true, data: { photos, page, hasMore: page < (r.data.page_count ?? 0) } };
}

// ---------- Are.na (API v3; precisa de token pessoal) ----------
// A API v2 foi desativada: ela recusa qualquer token (aparecia como "Chave recusada").
// Na v3, a busca por texto (/v3/search) é restrita a contas Premium, mas ler o conteúdo de um
// canal (/v3/channels/{slug}/contents) funciona com qualquer token, inclusive de conta gratuita.
// Por isso o campo de busca aceita DOIS formatos:
//   - link de um canal (are.na/usuario/canal)  -> funciona em conta gratuita
//   - texto livre                              -> só em conta Premium

const ARENA_API = 'https://api.are.na/v3';

const ARENA_NEEDS_PREMIUM =
  'A busca por texto do Are.na é só para contas Premium. Na conta gratuita, cole na busca o link de um canal (are.na/usuario/canal).';

const ARENA_TOKEN_MESSAGES: Partial<Record<number, string>> = {
  401: 'Are.na recusou o token. Gere um novo em are.na/settings/personal-access-tokens e cole inteiro, sem espaços.',
  404: 'O endereço da API do Are.na mudou (404). O app precisa de atualização.',
  410: 'O endereço da API do Are.na foi desativado (410). O app precisa de atualização.',
};

const ARENA_SEARCH_MESSAGES: Partial<Record<number, string>> = { ...ARENA_TOKEN_MESSAGES, 403: ARENA_NEEDS_PREMIUM };

const ARENA_CHANNEL_MESSAGES: Partial<Record<number, string>> = {
  ...ARENA_TOKEN_MESSAGES,
  403: 'Sem permissão para ver esse canal do Are.na (ele é privado?).',
  404: 'Canal do Are.na não encontrado. Confira o link.',
};

function fromArena(b: any): StockPhoto {
  const im = b.image ?? {};
  const full = im.large?.src ?? im.src ?? im.medium?.src;
  const w = Number(im.width);
  const h = Number(im.height);
  const sized = w > 0 && h > 0;
  return {
    uid: `arena:${b.id}`,
    source: 'arena',
    width: sized ? w : 800,
    height: sized ? h : 800,
    sizeUnknown: !sized,
    thumbUrl: im.medium?.src ?? im.small?.src ?? full,
    fullUrl: full,
    pageUrl: `https://www.are.na/block/${b.id}`,
    author: b.user?.name ?? b.user?.slug ?? 'Are.na',
    authorUrl: b.user?.slug ? `https://www.are.na/${b.user.slug}` : `https://www.are.na/block/${b.id}`,
  };
}

const isArenaImage = (b: any) => b?.type === 'Image' && b.image && (b.image.large?.src || b.image.src);

/**
 * Se o texto digitado for um link de canal do Are.na, devolve o "slug" do canal.
 * Aceita https://www.are.na/usuario/canal-abc123 e o formato antigo https://www.are.na/channel/canal-abc123.
 */
function arenaChannelSlug(text: string): string | null {
  const m = text.match(/are\.na\/([^/\s?#]+)\/([^/\s?#]+)/i);
  if (!m) return null;
  if (m[1].toLowerCase() === 'block') return null; // link de bloco, não de canal
  return decodeURIComponent(m[2]);
}

async function arenaChannel(key: string, slug: string, page: number): Promise<StockResult<StockPage>> {
  const url = `${ARENA_API}/channels/${encodeURIComponent(slug)}/contents?${qs({ per: PER_PAGE, page, sort: 'created_at_desc' })}`;
  const r = await getJson(url, { Authorization: `Bearer ${key}` }, ARENA_CHANNEL_MESSAGES);
  if (!r.ok) return r;
  const photos: StockPhoto[] = (r.data.data ?? []).filter(isArenaImage).map(fromArena);
  return { ok: true, data: { photos, page, hasMore: !!r.data.meta?.has_more_pages } };
}

async function arena(key: string, query: string, page: number): Promise<StockResult<StockPage>> {
  const q = query.trim();
  if (!q) return { ok: true, data: { photos: [], page, hasMore: false } };
  const slug = arenaChannelSlug(q);
  if (slug) return arenaChannel(key, slug, page);
  const url = `${ARENA_API}/search?${qs({ query: q, type: 'Image', per: PER_PAGE, page })}`;
  const r = await getJson(url, { Authorization: `Bearer ${key}` }, ARENA_SEARCH_MESSAGES);
  if (!r.ok) return r;
  const photos: StockPhoto[] = (r.data.data ?? []).filter(isArenaImage).map(fromArena);
  return { ok: true, data: { photos, page, hasMore: !!r.data.meta?.has_more_pages } };
}

/**
 * Testa o token. Conta gratuita que só não tem a busca por texto conta como OK
 * (o token funciona; o app usa links de canal), para a chave poder ser salva.
 */
async function arenaCheck(key: string): Promise<{ ok: boolean; message: string }> {
  const me = await getJson(`${ARENA_API}/me`, { Authorization: `Bearer ${key}` }, ARENA_TOKEN_MESSAGES);
  if (!me.ok) return { ok: false, message: me.message };
  const r = await arena(key, 'art', 1);
  if (r.ok) return { ok: true, message: 'Are.na: conexão ok (busca por texto e canais).' };
  if (r.message === ARENA_NEEDS_PREMIUM) {
    return { ok: true, message: 'Are.na: token válido. Conta gratuita: use o link de um canal na busca (a busca por texto é Premium).' };
  }
  return { ok: false, message: `Token válido, mas a busca falhou. ${r.message}` };
}

// ---------- Wikimedia Commons (sem chave) ----------

const plain = (html: string) =>
  html.replace(/<[^>]*>/g, '').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').trim();

async function commons(query: string, page: number): Promise<StockResult<StockPage>> {
  const q = query.trim();
  if (!q) return { ok: true, data: { photos: [], page, hasMore: false } };
  const url =
    `https://commons.wikimedia.org/w/api.php?` +
    qs({
      action: 'query', format: 'json', origin: '*', generator: 'search', gsrnamespace: 6,
      gsrsearch: `${q} filetype:bitmap`, gsrlimit: 30, gsroffset: (page - 1) * 30,
      prop: 'imageinfo', iiprop: 'url|size|extmetadata', iiurlwidth: 500,
    });
  const r = await getJson(url, {});
  if (!r.ok) return r;
  const pages: any[] = Object.values(r.data.query?.pages ?? {});
  pages.sort((a, b) => (a.index ?? 0) - (b.index ?? 0));
  const photos: StockPhoto[] = [];
  for (const p of pages) {
    const ii = p.imageinfo?.[0];
    if (!ii?.thumburl) continue;
    const meta = ii.extmetadata ?? {};
    const artist = meta.Artist?.value ? plain(String(meta.Artist.value)) : '';
    // Versão grande: a miniatura de 500px vira 1280px (tamanho padrão) se o original for maior.
    const full = ii.width >= 1280 ? String(ii.thumburl).replace(/\/500px-/, '/1280px-') : ii.url;
    photos.push({
      uid: `commons:${p.pageid}`,
      source: 'commons',
      width: ii.width || 800,
      height: ii.height || 800,
      sizeUnknown: !ii.width || !ii.height,
      thumbUrl: ii.thumburl,
      fullUrl: full,
      pageUrl: ii.descriptionurl,
      author: artist && artist.length < 80 ? artist : 'Wikimedia Commons',
      authorUrl: ii.descriptionurl,
      license: meta.LicenseShortName?.value ? plain(String(meta.LicenseShortName.value)) : undefined,
    });
  }
  return { ok: true, data: { photos, page, hasMore: !!r.data.continue } };
}

// ---------- Flickr (chave gratuita; só fotos com licença livre) ----------

const FLICKR_LICENSES: Record<string, string> = {
  '1': 'CC BY-NC-SA 2.0', '2': 'CC BY-NC 2.0', '3': 'CC BY-NC-ND 2.0', '4': 'CC BY 2.0', '5': 'CC BY-SA 2.0',
  '6': 'CC BY-ND 2.0', '7': 'Sem direitos conhecidos', '8': 'Governo dos EUA', '9': 'CC0', '10': 'Domínio público',
};

function fromFlickr(p: any): StockPhoto {
  const full = p.url_l ?? p.url_m;
  const w = Number(p.url_l ? p.width_l : p.width_m) || 0;
  const h = Number(p.url_l ? p.height_l : p.height_m) || 0;
  const page = `https://www.flickr.com/photos/${p.owner}/${p.id}`;
  return {
    uid: `flickr:${p.id}`,
    source: 'flickr',
    width: w || 800,
    height: h || 800,
    sizeUnknown: !w || !h,
    thumbUrl: p.url_m ?? full,
    fullUrl: full,
    pageUrl: page,
    author: p.ownername ?? 'Flickr',
    authorUrl: `https://www.flickr.com/photos/${p.owner}/`,
    license: FLICKR_LICENSES[String(p.license)],
  };
}

async function flickr(key: string, query: string, page: number): Promise<StockResult<StockPage>> {
  const q = query.trim();
  const base = { api_key: key, format: 'json', nojsoncallback: 1, per_page: PER_PAGE, page, extras: 'url_m,url_l,owner_name,license' };
  // Sem texto: as fotos "interessantes" do dia. Com texto: busca só em fotos de licença livre.
  const url = q
    ? `https://www.flickr.com/services/rest/?${qs({ ...base, method: 'flickr.photos.search', text: q, sort: 'interestingness-desc', media: 'photos', safe_search: 1, license: '1,2,3,4,5,6,7,8,9,10' })}`
    : `https://www.flickr.com/services/rest/?${qs({ ...base, method: 'flickr.interestingness.getList' })}`;
  const r = await getJson(url, {});
  if (!r.ok) return r;
  if (r.data.stat !== 'ok') {
    const bad = [95, 100, 105, 112].includes(Number(r.data.code));
    return { ok: false, message: bad ? 'Chave do Flickr recusada. Confira em Configurações.' : `O Flickr devolveu um erro (${r.data.message ?? r.data.code}).` };
  }
  const list: any[] = r.data.photos?.photo ?? [];
  return {
    ok: true,
    data: { photos: list.filter((p) => p.url_m).map(fromFlickr), page, hasMore: page < (r.data.photos?.pages ?? 0) },
  };
}

// ---------- Art Institute of Chicago (domínio público, sem chave) ----------

async function artic(query: string, page: number): Promise<StockResult<StockPage>> {
  const q = query.trim();
  if (!q) return { ok: true, data: { photos: [], page, hasMore: false } };
  const fields = 'id,title,artist_display,image_id,thumbnail';
  const url =
    `https://api.artic.edu/api/v1/artworks/search?${qs({ q, page, limit: PER_PAGE, fields })}` +
    `&query[term][is_public_domain]=true`;
  const r = await getJson(url, {});
  if (!r.ok) return r;
  const iiif: string = r.data.config?.iiif_url ?? 'https://www.artic.edu/iiif/2';
  const photos: StockPhoto[] = (r.data.data ?? [])
    .filter((a: any) => a.image_id)
    .map((a: any): StockPhoto => ({
      uid: `artic:${a.id}`,
      source: 'artic',
      width: a.thumbnail?.width || 800,
      height: a.thumbnail?.height || 800,
      sizeUnknown: !a.thumbnail?.width,
      thumbUrl: `${iiif}/${a.image_id}/full/400,/0/default.jpg`,
      fullUrl: `${iiif}/${a.image_id}/full/843,/0/default.jpg`,
      pageUrl: `https://www.artic.edu/artworks/${a.id}`,
      author: String(a.artist_display ?? a.title ?? 'Art Institute of Chicago').split('\n')[0],
      authorUrl: `https://www.artic.edu/artworks/${a.id}`,
      license: 'Domínio público',
    }));
  return { ok: true, data: { photos, page, hasMore: page < (r.data.pagination?.total_pages ?? 0) } };
}

// ---------- iNaturalist (sem chave) ----------

async function inat(query: string, page: number): Promise<StockResult<StockPage>> {
  const q = query.trim();
  const url = `https://api.inaturalist.org/v1/observations?${qs({
    photos: 'true', quality_grade: 'research', order_by: 'votes', per_page: PER_PAGE, page,
    photo_license: 'cc0,cc-by,cc-by-sa,cc-by-nc,cc-by-nd,cc-by-nc-sa,cc-by-nc-nd', ...(q ? { q } : {}),
  })}`;
  const r = await getJson(url, {});
  if (!r.ok) return r;
  const photos: StockPhoto[] = [];
  for (const o of r.data.results ?? []) {
    const ph = o.photos?.[0];
    if (!ph?.url) continue;
    photos.push({
      uid: `inat:${o.id}`, source: 'inat', width: 800, height: 800, sizeUnknown: true,
      thumbUrl: String(ph.url).replace('square', 'medium'),
      fullUrl: String(ph.url).replace('square', 'large'),
      pageUrl: o.uri ?? `https://www.inaturalist.org/observations/${o.id}`,
      author: o.user?.login ?? 'iNaturalist', authorUrl: o.uri ?? 'https://www.inaturalist.org',
      license: ph.license_code ? String(ph.license_code).toUpperCase().replace(/-/g, ' ') : undefined,
    });
  }
  return { ok: true, data: { photos, page, hasMore: page * PER_PAGE < (r.data.total_results ?? 0) } };
}

// ---------- NASA (sem chave, domínio público) ----------

async function nasa(query: string, page: number): Promise<StockResult<StockPage>> {
  const q = query.trim();
  if (!q) return { ok: true, data: { photos: [], page, hasMore: false } };
  const r = await getJson(`https://images-api.nasa.gov/search?${qs({ q, media_type: 'image', page, page_size: PER_PAGE })}`, {});
  if (!r.ok) return r;
  const items: any[] = r.data.collection?.items ?? [];
  const photos: StockPhoto[] = [];
  for (const it of items) {
    const d = it.data?.[0];
    const img = it.links?.find((l: any) => l.render === 'image')?.href;
    if (!d || !img) continue;
    photos.push({
      uid: `nasa:${d.nasa_id}`, source: 'nasa', width: 800, height: 800, sizeUnknown: true,
      thumbUrl: img, fullUrl: img,
      pageUrl: `https://images.nasa.gov/details/${encodeURIComponent(d.nasa_id)}`,
      author: d.photographer ?? d.center ?? 'NASA', authorUrl: `https://images.nasa.gov/details/${encodeURIComponent(d.nasa_id)}`,
      license: 'Domínio público (NASA)',
    });
  }
  const hasNext = (r.data.collection?.links ?? []).some((l: any) => l.rel === 'next');
  return { ok: true, data: { photos, page, hasMore: hasNext } };
}

// ---------- Cleveland Museum of Art (sem chave, CC0) ----------

async function cleveland(query: string, page: number): Promise<StockResult<StockPage>> {
  const q = query.trim();
  if (!q) return { ok: true, data: { photos: [], page, hasMore: false } };
  const skip = (page - 1) * PER_PAGE;
  const r = await getJson(`https://openaccess-api.clevelandmuseum.org/api/artworks/?${qs({ q, has_image: 1, cc0: 1, limit: PER_PAGE, skip })}`, {});
  if (!r.ok) return r;
  const photos: StockPhoto[] = [];
  for (const a of r.data.data ?? []) {
    const web = a.images?.web;
    if (!web?.url) continue;
    photos.push({
      uid: `cleveland:${a.id}`, source: 'cleveland', width: Number(web.width) || 800, height: Number(web.height) || 800, sizeUnknown: !web.width,
      thumbUrl: web.url, fullUrl: web.url, pageUrl: a.url ?? 'https://www.clevelandart.org',
      author: a.creators?.[0]?.description ? String(a.creators[0].description).split('(')[0].trim() : a.title ?? 'Cleveland Museum of Art',
      authorUrl: a.url ?? 'https://www.clevelandart.org', license: 'CC0',
    });
  }
  return { ok: true, data: { photos, page, hasMore: skip + PER_PAGE < (r.data.info?.total ?? 0) } };
}

// ---------- The Met (sem chave, domínio público) ----------

const metIds = new Map<string, number[]>();

async function met(query: string, page: number): Promise<StockResult<StockPage>> {
  const q = query.trim();
  if (!q) return { ok: true, data: { photos: [], page, hasMore: false } };
  let ids = metIds.get(q.toLowerCase());
  if (!ids || page === 1) {
    const s = await getJson(`https://collectionapi.metmuseum.org/public/collection/v1/search?${qs({ hasImages: 'true', isPublicDomain: 'true', q })}`, {});
    if (!s.ok) return s;
    ids = (s.data.objectIDs as number[] | null) ?? [];
    metIds.set(q.toLowerCase(), ids);
  }
  const slice = ids.slice((page - 1) * PER_PAGE, page * PER_PAGE);
  const objs = await Promise.all(slice.map((id) => getJson(`https://collectionapi.metmuseum.org/public/collection/v1/objects/${id}`, {})));
  const photos: StockPhoto[] = [];
  for (const o of objs) {
    if (!o.ok || !o.data?.isPublicDomain || !o.data?.primaryImageSmall) continue;
    const d = o.data;
    photos.push({
      uid: `met:${d.objectID}`, source: 'met', width: 800, height: 800, sizeUnknown: true,
      thumbUrl: d.primaryImageSmall, fullUrl: d.primaryImageSmall,
      pageUrl: d.objectURL ?? 'https://www.metmuseum.org', author: d.artistDisplayName || d.title || 'The Met',
      authorUrl: d.objectURL ?? 'https://www.metmuseum.org', license: 'Domínio público',
    });
  }
  return { ok: true, data: { photos, page, hasMore: page * PER_PAGE < ids.length } };
}

// ---------- Wellcome Collection (sem chave) ----------

async function wellcome(query: string, page: number): Promise<StockResult<StockPage>> {
  const q = query.trim();
  if (!q) return { ok: true, data: { photos: [], page, hasMore: false } };
  const r = await getJson(`https://api.wellcomecollection.org/catalogue/v2/images?${qs({ query: q, page, pageSize: PER_PAGE })}`, {});
  if (!r.ok) return r;
  const photos: StockPhoto[] = [];
  for (const it of r.data.results ?? []) {
    const info: string | undefined = it.locations?.find((l: any) => String(l.url).endsWith('/info.json'))?.url;
    const thumb: string | undefined = info ? info.replace('/info.json', '/full/500,/0/default.jpg') : it.thumbnail?.url;
    if (!thumb) continue;
    const works = it.source?.id;
    photos.push({
      uid: `wellcome:${it.id}`, source: 'wellcome', width: 800, height: 800, sizeUnknown: true,
      thumbUrl: thumb, fullUrl: info ? info.replace('/info.json', '/full/1000,/0/default.jpg') : thumb,
      pageUrl: works ? `https://wellcomecollection.org/works/${works}` : 'https://wellcomecollection.org',
      author: it.source?.title ? String(it.source.title).slice(0, 70) : 'Wellcome Collection',
      authorUrl: works ? `https://wellcomecollection.org/works/${works}` : 'https://wellcomecollection.org',
      license: it.locations?.[0]?.license?.label ?? it.thumbnail?.license?.label,
    });
  }
  return { ok: true, data: { photos, page, hasMore: page < (r.data.totalPages ?? 0) } };
}

// ---------- Library of Congress (sem chave; direitos variam por foto) ----------

async function loc(query: string, page: number): Promise<StockResult<StockPage>> {
  const q = query.trim();
  if (!q) return { ok: true, data: { photos: [], page, hasMore: false } };
  const r = await getJson(`https://www.loc.gov/photos/?${qs({ q, fo: 'json', c: PER_PAGE, sp: page })}`, {});
  if (!r.ok) return r;
  const fix = (u: string) => (u.startsWith('//') ? `https:${u}` : u.replace(/^http:/, 'https:'));
  const photos: StockPhoto[] = [];
  for (const it of r.data.results ?? []) {
    const imgs: string[] = Array.isArray(it.image_url) ? it.image_url.filter(Boolean) : [];
    if (imgs.length === 0 || !it.id) continue;
    const link = String(it.id).startsWith('http') ? String(it.id) : String(it.url ?? 'https://www.loc.gov');
    photos.push({
      uid: `loc:${it.id}`, source: 'loc', width: 800, height: 800, sizeUnknown: true,
      thumbUrl: fix(imgs[0]), fullUrl: fix(imgs[Math.min(2, imgs.length - 1)]),
      pageUrl: link, author: it.contributor?.[0] ? String(it.contributor[0]).slice(0, 60) : 'Library of Congress', authorUrl: link,
      license: 'Direitos variam',
    });
  }
  return { ok: true, data: { photos, page, hasMore: !!r.data.pagination?.next } };
}

// ---------- Google Imagens via Serper (serper.dev) ----------
// A API oficial do Google (Custom Search) foi fechada para novos cadastros e responde 403 em projetos novos.
// O Serper devolve os resultados do Google Imagens em JSON (teste gratuito de 2.500 consultas, sem cartão).
// Dica: dá para filtrar por site na própria busca, ex.: "praia site:pinterest.com".

const SERPER_URL = 'https://google.serper.dev/images';
const SERPER_PER_PAGE = 10; // até 10 resultados por consulta: a consulta mais barata do plano
const SERPER_MAX_PAGES = 10;

const SERPER_MESSAGES: Partial<Record<number, string>> = {
  400: 'O Serper recusou a consulta (400). Confira se ainda há créditos gratuitos no painel de serper.dev.',
  401: 'O Serper recusou a chave. Copie de serper.dev/api-key, inteira e sem espaços.',
  403: 'O Serper recusou a chave. Copie de serper.dev/api-key, inteira e sem espaços.',
};

async function serper(key: string, query: string, page: number): Promise<StockResult<StockPage>> {
  const q = query.trim();
  if (!q || page > SERPER_MAX_PAGES) return { ok: true, data: { photos: [], page, hasMore: false } };
  const r = await getJson(
    SERPER_URL,
    { 'X-API-KEY': key, 'Content-Type': 'application/json' },
    SERPER_MESSAGES,
    { q, num: SERPER_PER_PAGE, page },
  );
  if (!r.ok) return r;
  const items: any[] = Array.isArray(r.data?.images) ? r.data.images : [];
  const photos: StockPhoto[] = [];
  for (const it of items) {
    const full: string | undefined = it.imageUrl ?? it.thumbnailUrl;
    if (!full) continue;
    // A miniatura fica hospedada no Google (sempre carrega); a foto original pode estar num site que bloqueia o uso direto.
    const thumb: string = it.thumbnailUrl ?? full;
    const w = Number(it.imageWidth) || Number(it.thumbnailWidth);
    const h = Number(it.imageHeight) || Number(it.thumbnailHeight);
    const sized = w > 0 && h > 0;
    const page_ = it.link ?? it.googleUrl ?? full;
    photos.push({
      uid: `serper:${full}`,
      source: 'serper',
      width: sized ? w : 800,
      height: sized ? h : 800,
      sizeUnknown: !sized,
      thumbUrl: thumb,
      fullUrl: full,
      pageUrl: page_,
      author: it.source ?? it.domain ?? 'Google',
      authorUrl: page_,
      license: 'Direitos desconhecidos',
    });
  }
  return { ok: true, data: { photos, page, hasMore: items.length >= SERPER_PER_PAGE && page < SERPER_MAX_PAGES } };
}

// ---------- API única ----------

/** Busca num banco. `query` vazio devolve o que está em alta no banco. */
export async function searchStock(source: StockSource, query: string, page = 1): Promise<StockResult<StockPage>> {
  if (source === 'openverse') return openverse(query, page);
  if (source === 'artic') return artic(query, page);
  if (source === 'commons') return commons(query, page);
  if (source === 'link') return { ok: true, data: { photos: [], page, hasMore: false } };
  if (source === 'inat') return inat(query, page);
  if (source === 'nasa') return nasa(query, page);
  if (source === 'cleveland') return cleveland(query, page);
  if (source === 'met') return met(query, page);
  if (source === 'wellcome') return wellcome(query, page);
  if (source === 'loc') return loc(query, page);
  const key = (await getStockKey(source)).trim();
  if (!key) return { ok: false, message: `Falta a chave do ${labelOf(source)}. Cadastre em Configurações.` };
  if (source === 'arena') return arena(key, query, page);
  if (source === 'flickr') return flickr(key, query, page);
  if (source === 'serper') return serper(key, query, page);
  return source === 'pexels' ? pexels(key, query, page) : unsplash(key, query, page);
}

/** Testa uma chave (ainda não salva) com uma busca mínima. */
export async function testStockKey(source: StockSource, key: string): Promise<{ ok: boolean; message: string }> {
  if (source === 'openverse') {
    const r = await openverse('flower', 1);
    return r.ok ? { ok: true, message: 'Openverse: conexão ok.' } : { ok: false, message: r.message };
  }
  if (source === 'link') return { ok: true, message: 'Link: não precisa de chave.' };
  if (['inat', 'nasa', 'cleveland', 'met', 'wellcome', 'loc'].includes(source)) {
    const r = await searchStock(source, 'flower', 1);
    return r.ok ? { ok: true, message: `${labelOf(source)}: conexão ok.` } : { ok: false, message: r.message };
  }
  if (source === 'commons') {
    const r = await commons('flower', 1);
    return r.ok ? { ok: true, message: 'Wikimedia: conexão ok.' } : { ok: false, message: r.message };
  }
  if (source === 'artic') {
    const r = await artic('flower', 1);
    return r.ok ? { ok: true, message: 'Art Institute: conexão ok.' } : { ok: false, message: r.message };
  }
  const k = key.trim();
  if (!k) return { ok: false, message: 'Cole a chave primeiro.' };
  if (source === 'flickr') {
    const r = await flickr(k, '', 1);
    return r.ok ? { ok: true, message: 'Flickr: conexão ok.' } : { ok: false, message: r.message };
  }
  if (source === 'arena') {
    return arenaCheck(k);
  }
  if (source === 'serper') {
    const r = await serper(k, 'flower', 1);
    return r.ok ? { ok: true, message: 'Google (Serper): conexão ok.' } : { ok: false, message: r.message };
  }
  const r = source === 'pexels'
    ? await getJson(`https://api.pexels.com/v1/curated?per_page=1`, { Authorization: k })
    : await getJson(`https://api.unsplash.com/photos?per_page=1`, { Authorization: `Client-ID ${k}` });
  return r.ok ? { ok: true, message: `${labelOf(source)}: conexão ok.` } : { ok: false, message: r.message };
}

/**
 * Unsplash exige avisar o banco quando uma foto é usada. Chamado no bloco de importação.
 * Falhar aqui nunca deve impedir o uso da imagem.
 */
export async function reportStockUse(photo: StockPhoto): Promise<void> {
  if (photo.source !== 'unsplash' || !photo.downloadLocation) return;
  const key = (await getStockKey('unsplash')).trim();
  if (!key) return;
  try {
    await fetch(photo.downloadLocation, { headers: { Authorization: `Client-ID ${key}` } });
  } catch {}
}

/** Bancos prontos para uso agora: os sem chave e os que já têm chave salva. */
export async function availableSources(): Promise<StockSource[]> {
  const out: StockSource[] = [];
  for (const s of STOCK_SOURCES) {
    if (!s.needsKey) out.push(s.id);
    else if ((await getStockKey(s.id)).trim() && (!s.extra || ((await getSetting(stockExtraName(s.id, s.extra.id))) ?? '').trim())) out.push(s.id);
  }
  return out;
}

export const labelOf = (s: StockSource): string => STOCK_SOURCES.find((x) => x.id === s)!.label;
