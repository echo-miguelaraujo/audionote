import { getSetting } from './settings';

/** Bancos de imagem gratuitos que o moodboard consegue consultar. */
export type StockSource = 'pexels' | 'unsplash' | 'openverse';

/** `needsKey: false` = funciona sem cadastro (Openverse). */
export const STOCK_SOURCES: { id: StockSource; label: string; keyUrl: string; needsKey: boolean }[] = [
  { id: 'unsplash', label: 'Unsplash', keyUrl: 'unsplash.com/developers', needsKey: true },
  { id: 'pexels', label: 'Pexels', keyUrl: 'pexels.com/api', needsKey: true },
  { id: 'openverse', label: 'Openverse', keyUrl: 'openverse.org', needsKey: false },
];

/** Foto de qualquer banco, no mesmo formato. */
export type StockPhoto = {
  /** Único no app todo: "pexels:123". */
  uid: string;
  source: StockSource;
  width: number;
  height: number;
  /** Miniatura leve, para a grade de resultados e para o card quando está pequeno. */
  thumbUrl: string;
  /** Versão grande, para o card quando o usuário dá zoom. */
  fullUrl: string;
  /** Página da foto no banco (crédito). */
  pageUrl: string;
  author: string;
  authorUrl: string;
  /** Só Unsplash: endereço que precisa ser avisado quando a foto é usada. */
  downloadLocation?: string;
  /** Só Openverse: licença Creative Commons, ex.: "CC BY 2.0". */
  license?: string;
};

export type StockPage = { photos: StockPhoto[]; page: number; hasMore: boolean };

export type StockResult<T> = { ok: true; data: T } | { ok: false; message: string };

const KEY_PREFIX = 'stock_key_';
export const getStockKey = async (s: StockSource): Promise<string> => (await getSetting(KEY_PREFIX + s)) ?? '';
export const stockKeyName = (s: StockSource): string => KEY_PREFIX + s;

const PER_PAGE = 30;
const TIMEOUT_MS = 15000;

async function getJson(url: string, headers: Record<string, string>): Promise<StockResult<any>> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
  try {
    const res = await fetch(url, { headers, signal: ctrl.signal });
    if (res.status === 401 || res.status === 403) {
      return { ok: false, message: 'Chave recusada. Confira a chave em Configurações.' };
    }
    if (res.status === 429) {
      return { ok: false, message: 'Limite de uso do banco atingido. Tente de novo daqui a pouco.' };
    }
    if (!res.ok) return { ok: false, message: `O banco respondeu com erro (${res.status}).` };
    return { ok: true, data: await res.json() };
  } catch (e: any) {
    if (e?.name === 'AbortError') return { ok: false, message: 'O banco demorou demais para responder.' };
    return { ok: false, message: 'Sem conexão com a internet.' };
  } finally {
    clearTimeout(timer);
  }
}

const qs = (o: Record<string, string | number>) =>
  Object.entries(o)
    .map(([k, v]) => `${k}=${encodeURIComponent(String(v))}`)
    .join('&');

// ---------- Pexels ----------

function fromPexels(p: any): StockPhoto {
  return {
    uid: `pexels:${p.id}`,
    source: 'pexels',
    width: p.width,
    height: p.height,
    thumbUrl: p.src?.medium ?? p.src?.small,
    fullUrl: p.src?.large2x ?? p.src?.large ?? p.src?.original,
    pageUrl: p.url,
    author: p.photographer ?? 'Pexels',
    authorUrl: p.photographer_url ?? p.url,
  };
}

async function pexels(key: string, query: string, page: number): Promise<StockResult<StockPage>> {
  const q = query.trim();
  // Sem texto: as fotos selecionadas (em alta) do Pexels.
  const url = q
    ? `https://api.pexels.com/v1/search?${qs({ query: q, page, per_page: PER_PAGE })}`
    : `https://api.pexels.com/v1/curated?${qs({ page, per_page: PER_PAGE })}`;
  const r = await getJson(url, { Authorization: key });
  if (!r.ok) return r;
  const photos: StockPhoto[] = (r.data.photos ?? []).map(fromPexels);
  return { ok: true, data: { photos, page, hasMore: !!r.data.next_page } };
}

// ---------- Unsplash ----------

function fromUnsplash(p: any): StockPhoto {
  return {
    uid: `unsplash:${p.id}`,
    source: 'unsplash',
    width: p.width,
    height: p.height,
    thumbUrl: p.urls?.small ?? p.urls?.thumb,
    fullUrl: p.urls?.regular ?? p.urls?.full,
    pageUrl: p.links?.html,
    author: p.user?.name ?? 'Unsplash',
    authorUrl: p.user?.links?.html ?? p.links?.html,
    downloadLocation: p.links?.download_location,
  };
}

async function unsplash(key: string, query: string, page: number): Promise<StockResult<StockPage>> {
  const q = query.trim();
  const headers = { Authorization: `Client-ID ${key}`, 'Accept-Version': 'v1' };
  // Sem texto: as mais populares do Unsplash.
  const url = q
    ? `https://api.unsplash.com/search/photos?${qs({ query: q, page, per_page: PER_PAGE })}`
    : `https://api.unsplash.com/photos?${qs({ order_by: 'popular', page, per_page: PER_PAGE })}`;
  const r = await getJson(url, headers);
  if (!r.ok) return r;
  const list: any[] = q ? r.data.results ?? [] : r.data ?? [];
  const totalPages: number | undefined = q ? r.data.total_pages : undefined;
  return {
    ok: true,
    data: {
      photos: list.map(fromUnsplash),
      page,
      hasMore: totalPages != null ? page < totalPages : list.length >= PER_PAGE,
    },
  };
}

// ---------- Openverse (sem chave) ----------

function fromOpenverse(p: any): StockPhoto {
  const lic = p.license ? `CC ${String(p.license).toUpperCase()}${p.license_version ? ' ' + p.license_version : ''}` : undefined;
  // O Openverse entrega uma miniatura própria (até ~600px), estável e leve. O arquivo original
  // fica em servidores de terceiros, que muitas vezes bloqueiam o uso direto, por isso não é usado.
  const img = p.thumbnail ?? p.url;
  return {
    uid: `openverse:${p.id}`,
    source: 'openverse',
    width: p.width || 800,
    height: p.height || 600,
    thumbUrl: img,
    fullUrl: img,
    pageUrl: p.foreign_landing_url ?? p.url,
    author: p.creator ?? p.source ?? 'Openverse',
    authorUrl: p.creator_url ?? p.foreign_landing_url ?? p.url,
    license: lic,
  };
}

async function openverse(query: string, page: number): Promise<StockResult<StockPage>> {
  const q = query.trim();
  // O Openverse não tem "em alta": sem texto, não há o que mostrar.
  if (!q) return { ok: true, data: { photos: [], page, hasMore: false } };
  // Anônimo: no máximo 20 por página.
  const url = `https://api.openverse.org/v1/images/?${qs({ q, page, page_size: 20, mature: 'false' })}`;
  const r = await getJson(url, {});
  if (!r.ok) return r;
  const photos: StockPhoto[] = (r.data.results ?? []).map(fromOpenverse);
  return { ok: true, data: { photos, page, hasMore: page < (r.data.page_count ?? 0) } };
}

// ---------- API única ----------

/** Busca num banco. `query` vazio devolve o que está em alta no banco. */
export async function searchStock(source: StockSource, query: string, page = 1): Promise<StockResult<StockPage>> {
  if (source === 'openverse') return openverse(query, page);
  const key = (await getStockKey(source)).trim();
  if (!key) return { ok: false, message: `Falta a chave do ${labelOf(source)}. Cadastre em Configurações.` };
  return source === 'pexels' ? pexels(key, query, page) : unsplash(key, query, page);
}

/** Testa uma chave (ainda não salva) com uma busca mínima. */
export async function testStockKey(source: StockSource, key: string): Promise<{ ok: boolean; message: string }> {
  if (source === 'openverse') {
    const r = await openverse('flower', 1);
    return r.ok ? { ok: true, message: 'Openverse: conexão ok.' } : { ok: false, message: r.message };
  }
  const k = key.trim();
  if (!k) return { ok: false, message: 'Cole a chave primeiro.' };
  const r = source === 'pexels'
    ? await getJson(`https://api.pexels.com/v1/curated?per_page=1`, { Authorization: k })
    : await getJson(`https://api.unsplash.com/photos?per_page=1`, { Authorization: `Client-ID ${k}` });
  return r.ok ? { ok: true, message: `${labelOf(source)}: conexão ok.` } : { ok: false, message: r.message };
}

/**
 * Unsplash exige avisar o banco quando uma foto é usada. Chamado no bloco de importação.
 * Falhar aqui nunca deve impedir o uso da imagem.
 */
export async function reportStockUse(photo: StockPhoto): Promise<void> {
  if (photo.source !== 'unsplash' || !photo.downloadLocation) return;
  const key = (await getStockKey('unsplash')).trim();
  if (!key) return;
  try {
    await fetch(photo.downloadLocation, { headers: { Authorization: `Client-ID ${key}` } });
  } catch {}
}

/** Bancos prontos para uso agora: os sem chave e os que já têm chave salva. */
export async function availableSources(): Promise<StockSource[]> {
  const out: StockSource[] = [];
  for (const s of STOCK_SOURCES) {
    if (!s.needsKey || (await getStockKey(s.id)).trim()) out.push(s.id);
  }
  return out;
}

export const labelOf = (s: StockSource): string => STOCK_SOURCES.find((x) => x.id === s)!.label;
