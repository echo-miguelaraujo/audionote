import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Button } from './Button';
import { Icon } from './Icon';
import { colors, fonts } from './theme';

type Props = {
  u: number;
  insetsTop: number;
  insetsBottom: number;
  /** Legenda do item em foco (null = sem legenda). */
  caption: string | null;
  /** Esta tela foi aberta por mergulho: mostra "‹" para subir um nível. */
  canGoBack: boolean;
  /** Item em foco é uma coleção: mostra "Entrar". */
  canEnter: boolean;
  /** Há item/visão anterior e próximo(a) na sequência da apresentação. */
  canPrev: boolean;
  canNext: boolean;
  onPrev: () => void;
  onNext: () => void;
  onExit: () => void;
  onBack: () => void;
  onEnter: () => void;
};

/**
 * Única interface visível na tela cheia: legenda em faixa no rodapé, botão "Entrar" e o ✕ (e "‹") discretos.
 * Os botões de canto somem sozinhos; um toque no canto os traz de volta.
 */
export function PresentationOverlay({ u, insetsTop, insetsBottom, caption, canGoBack, canEnter, canPrev, canNext, onPrev, onNext, onExit, onBack, onEnter }: Props) {
  const [shown, setShown] = useState(true);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const reveal = useCallback(() => {
    setShown(true);
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setShown(false), 3500);
  }, []);

  useEffect(() => {
    reveal();
    return () => {
      if (timer.current) clearTimeout(timer.current);
    };
  }, [reveal]);

  const hit = u * 0.16;
  const cornerBtn = {
    width: u * 0.11,
    height: u * 0.11,
    borderRadius: u * 0.055,
    backgroundColor: 'rgba(0,0,0,0.35)',
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
  };

  const navBtn = {
    width: u * 0.14,
    height: u * 0.14,
    borderRadius: u * 0.07,
    backgroundColor: 'rgba(0,0,0,0.55)',
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
  };

  return (
    <View style={StyleSheet.absoluteFill} pointerEvents="box-none">
      {/* Cantos: quando os botões estão escondidos, o toque no canto só os traz de volta. */}
      <View style={{ position: 'absolute', top: insetsTop, right: 0, width: hit, height: hit }}>
        {shown ? (
          <Pressable onPress={onExit} hitSlop={10} style={{ margin: u * 0.025, alignSelf: 'flex-end' }}>
            <View style={cornerBtn}>
              <Icon name="close" size={u * 0.055} />
            </View>
          </Pressable>
        ) : (
          <Pressable onPress={reveal} style={StyleSheet.absoluteFill} />
        )}
      </View>
      {canGoBack && (
        <View style={{ position: 'absolute', top: insetsTop, left: 0, width: hit, height: hit }}>
          {shown ? (
            <Pressable onPress={onBack} hitSlop={10} style={{ margin: u * 0.025 }}>
              <View style={cornerBtn}>
                <Icon name="chevron-left" size={u * 0.06} />
              </View>
            </Pressable>
          ) : (
            <Pressable onPress={reveal} style={StyleSheet.absoluteFill} />
          )}
        </View>
      )}

      <View style={{ position: 'absolute', left: 0, right: 0, bottom: 0 }} pointerEvents="box-none">
        {/* Linha de navegação: ‹ anterior | Entrar (se for coleção) | próximo › */}
        <View
          pointerEvents="box-none"
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
            paddingHorizontal: u * 0.04,
            marginBottom: caption ? u * 0.03 : insetsBottom + u * 0.05,
          }}
        >
          <Pressable onPress={onPrev} disabled={!canPrev} hitSlop={10} style={{ opacity: canPrev ? 1 : 0.25 }}>
            <View style={navBtn}>
              <Icon name="chevron-left" size={u * 0.08} />
            </View>
          </Pressable>
          {canEnter ? (
            <Button size="compact" variant="destructive" label="Entrar" u={u} onPress={onEnter} />
          ) : (
            <View />
          )}
          <Pressable onPress={onNext} disabled={!canNext} hitSlop={10} style={{ opacity: canNext ? 1 : 0.25 }}>
            <View style={navBtn}>
              <Icon name="chevron-right" size={u * 0.08} />
            </View>
          </Pressable>
        </View>
        {!!caption && (
          <View
            pointerEvents="none"
            style={{
              backgroundColor: 'rgba(0,0,0,0.72)',
              paddingHorizontal: u * 0.06,
              paddingTop: u * 0.04,
              paddingBottom: insetsBottom + u * 0.04,
            }}
          >
            <Text style={{ color: colors.onDark, fontFamily: fonts.regular, fontSize: u * 0.05, lineHeight: u * 0.07, textAlign: 'center' }}>
              {caption}
            </Text>
          </View>
        )}
      </View>
    </View>
  );
}
