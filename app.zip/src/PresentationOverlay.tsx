import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { fonts } from './theme';

type Props = {
  u: number;
  insetsTop: number;
  insetsBottom: number;
  /** Legenda do item em foco (null = sem legenda). */
  caption: string | null;
  /** Esta tela foi aberta por mergulho: mostra "‹" para subir um nível. */
  canGoBack: boolean;
  /** Item em foco é uma coleção: mostra "Entrar". */
  canEnter: boolean;
  onExit: () => void;
  onBack: () => void;
  onEnter: () => void;
};

/**
 * Única interface visível na tela cheia: legenda em faixa no rodapé, botão "Entrar" e o ✕ (e "‹") discretos.
 * Os botões de canto somem sozinhos; um toque no canto os traz de volta.
 */
export function PresentationOverlay({ u, insetsTop, insetsBottom, caption, canGoBack, canEnter, onExit, onBack, onEnter }: Props) {
  const [shown, setShown] = useState(true);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const reveal = useCallback(() => {
    setShown(true);
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setShown(false), 3500);
  }, []);

  useEffect(() => {
    reveal();
    return () => {
      if (timer.current) clearTimeout(timer.current);
    };
  }, [reveal]);

  const hit = u * 0.16;
  const cornerBtn = {
    width: u * 0.11,
    height: u * 0.11,
    borderRadius: u * 0.055,
    backgroundColor: 'rgba(0,0,0,0.35)',
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
  };

  return (
    <View style={StyleSheet.absoluteFill} pointerEvents="box-none">
      {/* Cantos: quando os botões estão escondidos, o toque no canto só os traz de volta. */}
      <View style={{ position: 'absolute', top: insetsTop, right: 0, width: hit, height: hit }}>
        {shown ? (
          <Pressable onPress={onExit} hitSlop={10} style={{ margin: u * 0.025, alignSelf: 'flex-end' }}>
            <View style={cornerBtn}>
              <Text style={{ color: '#fff', fontSize: u * 0.055, fontFamily: fonts.bold }}>✕</Text>
            </View>
          </Pressable>
        ) : (
          <Pressable onPress={reveal} style={StyleSheet.absoluteFill} />
        )}
      </View>
      {canGoBack && (
        <View style={{ position: 'absolute', top: insetsTop, left: 0, width: hit, height: hit }}>
          {shown ? (
            <Pressable onPress={onBack} hitSlop={10} style={{ margin: u * 0.025 }}>
              <View style={cornerBtn}>
                <Text style={{ color: '#fff', fontSize: u * 0.07, fontFamily: fonts.bold, marginTop: -u * 0.008 }}>‹</Text>
              </View>
            </Pressable>
          ) : (
            <Pressable onPress={reveal} style={StyleSheet.absoluteFill} />
          )}
        </View>
      )}

      <View style={{ position: 'absolute', left: 0, right: 0, bottom: 0 }} pointerEvents="box-none">
        {canEnter && (
          <Pressable
            onPress={onEnter}
            hitSlop={12}
            style={{
              alignSelf: 'center',
              backgroundColor: '#FF3030',
              borderRadius: u * 0.08,
              paddingHorizontal: u * 0.07,
              paddingVertical: u * 0.03,
              marginBottom: caption ? u * 0.03 : insetsBottom + u * 0.05,
            }}
          >
            <Text style={{ color: '#fff', fontFamily: fonts.bold, fontSize: u * 0.045 }}>Entrar ›</Text>
          </Pressable>
        )}
        {!!caption && (
          <View
            pointerEvents="none"
            style={{
              backgroundColor: 'rgba(0,0,0,0.72)',
              paddingHorizontal: u * 0.06,
              paddingTop: u * 0.04,
              paddingBottom: insetsBottom + u * 0.04,
            }}
          >
            <Text style={{ color: '#fff', fontFamily: fonts.regular, fontSize: u * 0.05, lineHeight: u * 0.07, textAlign: 'center' }}>
              {caption}
            </Text>
          </View>
        )}
      </View>
    </View>
  );
}
