import React, { useEffect, useRef, useState } from 'react';
import { Animated, Easing, Pressable, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Glass } from './Background';
import { colors, fonts } from './theme';

export type Tab = 'rec' | 'lib' | 'mood' | 'agenda';

type Props = { active: Tab; onChange: (t: Tab) => void; dimmed?: boolean };

const TABS: { id: Tab; text: string }[] = [
  { id: 'rec', text: 'Gravação' },
  { id: 'lib', text: 'Biblioteca' },
  { id: 'mood', text: 'Moodboard' },
  { id: 'agenda', text: 'Agenda' },
];

/** Barra inferior em carrossel: a aba atual fica sempre no centro da tela, em negrito; as vizinhas aparecem (cinza) dos lados. */
export function TabBar({ active, onChange, dimmed }: Props) {
  const { width: sw } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const size = sw * 0.043;
  const light = active === 'mood'; // moodboard tem fundo branco: letras escuras, sem vidro
  const W = light ? sw : sw * 0.92;
  const H = size * 2.2;
  const gap = sw * 0.07;

  const [lay, setLay] = useState<Partial<Record<Tab, { x: number; w: number }>>>({});
  const tx = useRef(new Animated.Value(0)).current;
  const placed = useRef(false);

  useEffect(() => {
    const l = lay[active];
    if (!l) return;
    const to = W / 2 - (l.x + l.w / 2);
    if (!placed.current) {
      placed.current = true;
      tx.setValue(to);
      return;
    }
    Animated.timing(tx, { toValue: to, duration: 220, easing: Easing.out(Easing.cubic), useNativeDriver: true }).start();
  }, [active, lay, W, tx]);

  return (
    <View
      style={[styles.bar, { paddingBottom: insets.bottom + 14, opacity: dimmed ? 0.3 : 1 }]}
      pointerEvents={dimmed ? 'none' : 'auto'}
    >
      <Glass
        style={{
          width: W,
          height: H,
          borderRadius: sw * 0.1,
          overflow: 'hidden',
          ...(light ? { backgroundColor: 'transparent', borderWidth: 0 } : null),
        }}
      >
        <Animated.View
          style={{
            position: 'absolute',
            left: 0,
            top: 0,
            bottom: 0,
            flexDirection: 'row',
            alignItems: 'center',
            transform: [{ translateX: tx }],
          }}
        >
          {TABS.map((t, i) => (
            <Pressable
              key={t.id}
              onPress={() => onChange(t.id)}
              hitSlop={{ top: 14, bottom: 14, left: gap / 2, right: gap / 2 }}
              onLayout={(e) => {
                const { x, width } = e.nativeEvent.layout;
                setLay((p) => (p[t.id] && Math.abs(p[t.id]!.x - x) < 0.5 && Math.abs(p[t.id]!.w - width) < 0.5 ? p : { ...p, [t.id]: { x, w: width } }));
              }}
              style={{ marginRight: i < TABS.length - 1 ? gap : 0 }}
            >
              <Text
                numberOfLines={1}
                style={{
                  fontSize: size,
                  letterSpacing: -size * 0.04,
                  color: active === t.id ? (light ? '#000' : colors.text) : colors.gray,
                  fontFamily: active === t.id ? fonts.bold : fonts.regular,
                }}
              >
                {t.text}
              </Text>
            </Pressable>
          ))}
        </Animated.View>
      </Glass>
    </View>
  );
}

const styles = StyleSheet.create({
  bar: {
    alignItems: 'center',
    paddingTop: 10,
    backgroundColor: 'transparent',
  },
});
