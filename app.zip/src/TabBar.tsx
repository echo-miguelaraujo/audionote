import React from 'react';
import { Pressable, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Glass } from './Background';
import { colors, fonts } from './theme';

export type Tab = 'rec' | 'lib' | 'agenda';

type Props = { active: Tab; onChange: (t: Tab) => void; dimmed?: boolean };

export function TabBar({ active, onChange, dimmed }: Props) {
  const { width: sw } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const size = sw * 0.052;

  const label = (t: Tab, text: string) => (
    <Pressable onPress={() => onChange(t)} hitSlop={14}>
      <Text
        style={{
          fontSize: size,
          fontFamily: fonts.regular,
          letterSpacing: -size * 0.04,
          color: active === t ? colors.text : colors.gray,
        }}
      >
        {text}
      </Text>
    </Pressable>
  );

  return (
    <View
      style={[styles.bar, { paddingBottom: insets.bottom + 14, opacity: dimmed ? 0.3 : 1 }]}
      pointerEvents={dimmed ? 'none' : 'auto'}
    >
      <Glass
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          gap: sw * 0.055,
          paddingHorizontal: sw * 0.06,
          paddingVertical: sw * 0.028,
          borderRadius: sw * 0.1,
        }}
      >
        {label('rec', 'Gravação')}
        {label('lib', 'Biblioteca')}
        {label('agenda', 'Agenda')}
      </Glass>
    </View>
  );
}

const styles = StyleSheet.create({
  bar: {
    alignItems: 'center',
    paddingTop: 10,
    backgroundColor: 'transparent',
  },
});
