import React from 'react';
import { Pressable, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Glass } from './Background';
import { colors, fonts } from './theme';

export type Tab = 'rec' | 'lib' | 'mood' | 'agenda';

type Props = { active: Tab; onChange: (t: Tab) => void; dimmed?: boolean };

export function TabBar({ active, onChange, dimmed }: Props) {
  const { width: sw } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const size = sw * 0.043;
  const light = active === 'mood'; // moodboard tem fundo branco: letras escuras, sem vidro

  const label = (t: Tab, text: string) => (
    <Pressable onPress={() => onChange(t)} hitSlop={14}>
      <Text
        style={{
          fontSize: size,
          letterSpacing: -size * 0.04,
          color: active === t ? (light ? '#000' : colors.text) : colors.gray,
          fontFamily: active === t && light ? fonts.bold : fonts.regular,
        }}
      >
        {text}
      </Text>
    </Pressable>
  );

  return (
    <View
      style={[styles.bar, { paddingBottom: insets.bottom + 14, opacity: dimmed ? 0.3 : 1 }]}
      pointerEvents={dimmed ? 'none' : 'auto'}
    >
      <Glass
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          gap: sw * 0.04,
          paddingHorizontal: sw * 0.05,
          paddingVertical: sw * 0.028,
          borderRadius: sw * 0.1,
          ...(light ? { backgroundColor: 'transparent', borderWidth: 0 } : null),
        }}
      >
        {label('rec', 'Gravação')}
        {label('lib', 'Biblioteca')}
        {label('mood', 'Moodboard')}
        {label('agenda', 'Agenda')}
      </Glass>
    </View>
  );
}

const styles = StyleSheet.create({
  bar: {
    alignItems: 'center',
    paddingTop: 10,
    backgroundColor: 'transparent',
  },
});
