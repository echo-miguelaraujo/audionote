import React, { useEffect, useRef } from 'react';
import { Animated, PanResponder, Pressable, Text, View, useWindowDimensions } from 'react-native';
import { colors, fonts, TYPE, SPACE } from './theme';

type Props = {
  text: string;
  onUndo: () => void;
  onDismiss: () => void;
  /** Tempo até sumir sozinho. */
  durationMs?: number;
  bottom: number;
};

/** Aviso "Gravação salva · Desfazer": some em 10 s ou ao arrastar para o lado. */
export function UndoToast({ text, onUndo, onDismiss, durationMs = 10000, bottom }: Props) {
  const { width: sw } = useWindowDimensions();
  const x = useRef(new Animated.Value(0)).current;
  const bar = useRef(new Animated.Value(1)).current;
  const gone = useRef(false);

  const dismiss = (dir: number) => {
    if (gone.current) return;
    gone.current = true;
    Animated.timing(x, { toValue: dir * sw, duration: 180, useNativeDriver: true }).start(onDismiss);
  };
  const dismissRef = useRef(dismiss);
  dismissRef.current = dismiss;

  useEffect(() => {
    const a = Animated.timing(bar, { toValue: 0, duration: durationMs, useNativeDriver: false });
    a.start(({ finished }) => {
      if (finished) dismissRef.current(1);
    });
    return () => a.stop();
  }, [bar, durationMs]);

  const pan = useRef(
    PanResponder.create({
      onMoveShouldSetPanResponder: (_, g) => Math.abs(g.dx) > 8 && Math.abs(g.dx) > Math.abs(g.dy),
      onPanResponderMove: (_, g) => x.setValue(g.dx),
      onPanResponderRelease: (_, g) => {
        if (Math.abs(g.dx) > sw * 0.25) dismissRef.current(g.dx > 0 ? 1 : -1);
        else Animated.spring(x, { toValue: 0, useNativeDriver: true }).start();
      },
    })
  ).current;

  return (
    <Animated.View
      {...pan.panHandlers}
      style={{
        position: 'absolute',
        left: sw * 0.05,
        right: sw * 0.05,
        bottom,
        transform: [{ translateX: x }],
        backgroundColor: colors.surface,
        borderRadius: sw * 0.035,
        overflow: 'hidden',
      }}
    >
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: sw * SPACE.md }}>
        <Text style={{ color: colors.text, fontFamily: fonts.regular, fontSize: sw * TYPE.label }}>{text}</Text>
        <Pressable onPress={onUndo} hitSlop={14}>
          <Text style={{ color: colors.red, fontFamily: fonts.bold, fontSize: sw * TYPE.label }}>Desfazer</Text>
        </Pressable>
      </View>
      <Animated.View
        style={{
          height: 2,
          backgroundColor: colors.red,
          width: bar.interpolate({ inputRange: [0, 1], outputRange: ['0%', '100%'] }),
        }}
      />
    </Animated.View>
  );
}
