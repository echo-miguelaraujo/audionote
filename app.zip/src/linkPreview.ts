import { Image } from 'react-native';
import { mediaUri, saveRemoteImage } from './media';

/** Conteúdo (JSON) de um item kind='link'. */
export type LinkData = {
  v: 1;
  url: string;
  title: string;
  desc: string;
  site: string;
  /** Nome do arquivo da miniatura em media. null = sem miniatura. */
  img: string | null;
  /** Proporção largura/altura da capa (1 = quadrada, como álbum do Spotify). */
  ar: number;
  fetchedAt: number | null;
  /** true quando o usuário trocou/removeu a miniatura: "Atualizar prévia" não mexe em img. */
  custom: boolean;
};

const MOBILE_UA =
  'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36';

export const DEFAULT_AR = 16 / 9;

/** Limita a proporção da capa (muito vertical/larga é cortada) e "gruda" nas comuns: 1:1 e 16:9. */
export function normalizeAr(r: number): number {
  if (!Number.isFinite(r) || r <= 0) return DEFAULT_AR;
  const c = Math.min(2, Math.max(0.8, r));
  if (Math.abs(c - 1) < 0.06) return 1;
  if (Math.abs(c - DEFAULT_AR) < 0.12) return DEFAULT_AR;
  return c;
}

/** Domínio sem "www.". */
export function domainOf(url: string): string {
  const m = /^https?:\/\/([^/?#:]+)/i.exec(url.trim());
  return (m ? m[1] : url).toLowerCase().replace(/^www\./, '');
}

/** Leitura segura do JSON do cartão. Inválido → dados mínimos (url vazia). */
export function parseLink(content: string): LinkData {
  try {
    const j = JSON.parse(content);
    if (j && typeof j.url === 'string') {
      return {
        v: 1,
        url: j.url,
        title: typeof j.title === 'string' ? j.title : '',
        desc: typeof j.desc === 'string' ? j.desc : '',
        site: typeof j.site === 'string' ? j.site : domainOf(j.url),
        img: typeof j.img === 'string' && j.img ? j.img : null,
        ar: typeof j.ar === 'number' ? normalizeAr(j.ar) : DEFAULT_AR,
        fetchedAt: typeof j.fetchedAt === 'number' ? j.fetchedAt : null,
        custom: j.custom === true,
      };
    }
  } catch {
    // cai no padrão
  }
  return { v: 1, url: '', title: '', desc: '', site: '', img: null, ar: DEFAULT_AR, fetchedAt: null, custom: false };
}

export const stringifyLink = (d: LinkData): string => JSON.stringify(d);

export const newLinkData = (url: string): LinkData => ({
  v: 1,
  url,
  title: domainOf(url),
  desc: '',
  site: domainOf(url),
  img: null,
  ar: DEFAULT_AR,
  fetchedAt: null,
  custom: false,
});

/** Só http/https; "www.x.com" vira "https://www.x.com". Sem espaços. Inválido → null. */
export function normalizeUrl(raw: string): string | null {
  let s = raw.trim();
  if (!s || /\s/.test(s)) return null;
  if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(s)) {
    if (/^[^/.]+\.[^/]{2,}/.test(s) || /^www\./i.test(s)) s = `https://${s}`;
    else return null;
  }
  if (!/^https?:\/\//i.test(s)) return null;
  const host = domainOf(s);
  if (!/^[a-z0-9.-]+$/i.test(host) || !host.includes('.')) {
    if (host !== 'localhost') return null;
  }
  return s;
}

/** Primeira URL http(s) dentro de um texto (ex.: o que o Compartilhar manda). */
export function extractUrl(text: string): string | null {
  const m = /https?:\/\/[^\s<>"']+/i.exec(text);
  return m ? normalizeUrl(m[0].replace(/[).,;]+$/, '')) : null;
}

/** Hosts locais/privados não são buscados. */
export function isBlockedHost(url: string): boolean {
  const h = domainOf(url);
  if (h === 'localhost' || h.endsWith('.local')) return true;
  if (/^127\./.test(h) || /^10\./.test(h) || /^192\.168\./.test(h) || /^0\./.test(h) || /^169\.254\./.test(h)) return true;
  const m = /^172\.(\d+)\./.exec(h);
  return !!m && Number(m[1]) >= 16 && Number(m[1]) <= 31;
}

const ENTITIES: Record<string, string> = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ' };
function decodeEntities(s: string): string {
  return s
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCodePoint(parseInt(h, 16)))
    .replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(Number(d)))
    .replace(/&([a-z]+);/gi, (m, n) => ENTITIES[n.toLowerCase()] ?? m);
}

function attrs(tag: string): Record<string, string> {
  const out: Record<string, string> = {};
  for (const m of tag.matchAll(/([a-zA-Z_:][-a-zA-Z0-9_:.]*)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'>]+))/g)) {
    out[m[1].toLowerCase()] = decodeEntities(m[2] ?? m[3] ?? m[4] ?? '').trim();
  }
  return out;
}

const clip = (s: string, n: number) => {
  const t = s.replace(/\s+/g, ' ').trim();
  return t.length > n ? `${t.slice(0, n - 1)}…` : t;
};

function resolveUrl(base: string, ref: string): string | null {
  try {
    return new URL(ref, base).toString();
  } catch {
    return null;
  }
}

/** Id do vídeo em links do YouTube (watch, youtu.be, shorts, embed, live). null = não é vídeo. */
export function youtubeId(url: string): string | null {
  try {
    const u = new URL(url);
    const h = u.hostname.toLowerCase().replace(/^(www|m|music)\./, '');
    let id: string | null = null;
    if (h === 'youtu.be') id = u.pathname.split('/')[1] || null;
    else if (h === 'youtube.com' || h === 'youtube-nocookie.com') {
      if (u.pathname === '/watch') id = u.searchParams.get('v');
      else {
        const m = /^\/(?:shorts|embed|live|v)\/([^/?#]+)/.exec(u.pathname);
        id = m ? m[1] : null;
      }
    }
    return id && /^[\w-]{6,15}$/.test(id) ? id : null;
  } catch {
    return null;
  }
}

export type PreviewText = { title: string; desc: string; site: string; imageUrl: string | null };

/** Resultado parcial de um provedor com API pública (oEmbed etc.). O que faltar vem da página HTML. */
type Partial3 = {
  title?: string;
  desc?: string;
  site?: string;
  imageUrl?: string | null;
  /** Usado só se nem o provedor nem a página trouxerem descrição. */
  fallbackDesc?: string;
  /** A descrição da página só vale se bater com isto (evita textos genéricos de "carregue o app"). */
  descMustMatch?: RegExp;
};

/** Lê título, descrição, site e URL da imagem do começo de um HTML. */
export function parseHtmlPreview(html: string, pageUrl: string): PreviewText {
  const meta: Record<string, string> = {};
  let imageSrc = '';
  for (const m of html.matchAll(/<meta\b[^>]*>/gi)) {
    const a = attrs(m[0]);
    const key = (a.property || a.name || '').toLowerCase();
    if (key && a.content && !(key in meta)) meta[key] = a.content;
  }
  for (const m of html.matchAll(/<link\b[^>]*>/gi)) {
    const a = attrs(m[0]);
    if ((a.rel || '').toLowerCase() === 'image_src' && a.href) imageSrc = a.href;
  }
  const t = /<title[^>]*>([\s\S]*?)<\/title>/i.exec(html);
  const title = meta['og:title'] || meta['twitter:title'] || (t ? decodeEntities(t[1]) : '');
  const desc = meta['og:description'] || meta['twitter:description'] || meta['description'] || '';
  const img = meta['og:image'] || meta['og:image:secure_url'] || meta['twitter:image'] || imageSrc;
  return {
    title: clip(title, 120),
    desc: clip(desc, 200),
    site: clip(meta['og:site_name'] || domainOf(pageUrl), 60),
    imageUrl: img ? resolveUrl(pageUrl, img) : null,
  };
}

const FB_BOT = 'facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)';
const TW_BOT = 'Twitterbot/1.0';

const hostIs = (h: string, ...names: string[]) => names.some((n) => h === n || h.endsWith(`.${n}`));

/** Redes que só mostram as tags de prévia para o robô de link delas. */
function botUaFor(host: string): string | null {
  if (hostIs(host, 'instagram.com', 'facebook.com', 'fb.watch', 'threads.net', 'threads.com')) return FB_BOT;
  if (hostIs(host, 'x.com', 'twitter.com')) return TW_BOT;
  return null;
}

async function getJson(url: string, ms = 8000): Promise<any | null> {
  const c = new AbortController();
  const t = setTimeout(() => c.abort(), ms);
  try {
    const r = await fetch(url, { signal: c.signal, headers: { Accept: 'application/json', 'User-Agent': MOBILE_UA } });
    if (!r.ok) return null;
    return await r.json();
  } catch {
    return null;
  } finally {
    clearTimeout(t);
  }
}

type Page = { kind: 'html'; html: string; finalUrl: string } | { kind: 'image'; finalUrl: string };

/** Busca a página (HTML até ~200 KB). Se o link for direto para uma imagem, devolve kind 'image'. */
async function getPage(url: string, ua: string): Promise<Page | null> {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 8000);
  try {
    const res = await fetch(url, {
      signal: ctl.signal,
      headers: {
        'User-Agent': ua,
        'Accept-Language': 'pt-BR,pt;q=0.9,en;q=0.5',
        Accept: 'text/html,application/xhtml+xml,image/*;q=0.8',
      },
    });
    if (!res.ok) return null;
    const finalUrl = res.url || url;
    if (isBlockedHost(finalUrl)) return null;
    const ct = res.headers.get('content-type') ?? '';
    if (/^image\//i.test(ct)) {
      ctl.abort();
      return { kind: 'image', finalUrl };
    }
    if (!/text\/html/i.test(ct)) return null;
    return { kind: 'html', html: (await res.text()).slice(0, 200_000), finalUrl };
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

const SPOTIFY_KINDS: Record<string, string> = {
  track: 'Música',
  album: 'Álbum',
  playlist: 'Playlist',
  artist: 'Artista',
  episode: 'Episódio',
  show: 'Podcast',
};

const enc = encodeURIComponent;

/**
 * Plataformas com API pública de prévia (oEmbed e afins): trazem a capa certa, sem depender
 * das tags da página (que muitas vezes só aparecem para navegador de verdade).
 */
async function providerPreview(url: string): Promise<Partial3 | null> {
  let u: URL;
  try {
    u = new URL(url);
  } catch {
    return null;
  }
  const h = u.hostname.toLowerCase();

  if (hostIs(h, 'spotify.com')) {
    const k = /\/(track|album|playlist|artist|episode|show)\/\w+/.exec(u.pathname)?.[1];
    if (!k) return null;
    const j = await getJson(`https://open.spotify.com/oembed?url=${enc(url)}`);
    if (!j || (!j.title && !j.thumbnail_url)) return null;
    return {
      title: clip(String(j.title ?? ''), 120),
      site: 'Spotify',
      imageUrl: typeof j.thumbnail_url === 'string' ? j.thumbnail_url : null,
      fallbackDesc: SPOTIFY_KINDS[k],
      // a página traz "Artista · Música · Ano"; um texto genérico não serve
      descMustMatch: /·/,
    };
  }
  if (hostIs(h, 'soundcloud.com')) {
    const j = await getJson(`https://soundcloud.com/oembed?format=json&url=${enc(url)}`);
    if (!j) return null;
    return { title: clip(String(j.title ?? ''), 120), desc: clip(String(j.author_name ?? ''), 200), site: 'SoundCloud', imageUrl: j.thumbnail_url ?? null };
  }
  if (hostIs(h, 'vimeo.com')) {
    const j = await getJson(`https://vimeo.com/api/oembed.json?width=1000&url=${enc(url)}`);
    if (!j) return null;
    return { title: clip(String(j.title ?? ''), 120), desc: clip(String(j.author_name ?? ''), 200), site: 'Vimeo', imageUrl: j.thumbnail_url ?? null };
  }
  if (hostIs(h, 'dailymotion.com', 'dai.ly')) {
    const j = await getJson(`https://www.dailymotion.com/services/oembed?format=json&url=${enc(url)}`);
    if (!j) return null;
    return { title: clip(String(j.title ?? ''), 120), desc: clip(String(j.author_name ?? ''), 200), site: 'Dailymotion', imageUrl: j.thumbnail_url ?? null };
  }
  if (hostIs(h, 'tiktok.com')) {
    const j = await getJson(`https://www.tiktok.com/oembed?url=${enc(url)}`);
    if (!j) return null;
    return { title: clip(String(j.title ?? ''), 120), desc: clip(String(j.author_name ?? ''), 200), site: 'TikTok', imageUrl: j.thumbnail_url ?? null };
  }
  if (hostIs(h, 'flickr.com', 'flic.kr')) {
    const j = await getJson(`https://www.flickr.com/services/oembed/?format=json&url=${enc(url)}`);
    if (!j) return null;
    return { title: clip(String(j.title ?? ''), 120), desc: clip(String(j.author_name ?? ''), 200), site: 'Flickr', imageUrl: j.thumbnail_url ?? j.url ?? null };
  }
  if (hostIs(h, 'mixcloud.com')) {
    const j = await getJson(`https://app.mixcloud.com/oembed/?format=json&url=${enc(url)}`);
    if (!j) return null;
    return { title: clip(String(j.title ?? ''), 120), desc: clip(String(j.author_name ?? ''), 200), site: 'Mixcloud', imageUrl: j.image ?? j.thumbnail_url ?? null };
  }
  if (hostIs(h, 'youtube.com', 'youtu.be')) {
    // vídeos já são tratados pelo id; aqui entram playlists e afins
    const j = await getJson(`https://www.youtube.com/oembed?format=json&url=${enc(url)}`);
    if (!j) return null;
    return { title: clip(String(j.title ?? ''), 120), desc: clip(String(j.author_name ?? ''), 200), site: 'YouTube', imageUrl: j.thumbnail_url ?? null };
  }
  const wiki = /^([a-z-]{2,12})\.(?:m\.)?wikipedia\.org$/.exec(h);
  if (wiki) {
    const t = /^\/wiki\/([^?#]+)/.exec(u.pathname)?.[1];
    if (!t) return null;
    let title = t;
    try {
      title = decodeURIComponent(t);
    } catch {
      // usa como veio
    }
    const j = await getJson(`https://${wiki[1]}.wikipedia.org/api/rest_v1/page/summary/${enc(title)}`);
    if (!j || j.type === 'https://mediawiki.org/wiki/HyperSwitch/errors/not_found') return null;
    return {
      title: clip(String(j.title ?? ''), 120),
      desc: clip(String(j.extract ?? ''), 200),
      site: 'Wikipédia',
      imageUrl: j.thumbnail?.source ?? j.originalimage?.source ?? null,
    };
  }
  return null;
}

/** Ajustes de imagem por CDN: a Apple manda a capa em 1200×630 com borda; pedimos a arte quadrada. */
function tweakImage(src: string | null): string | null {
  if (!src) return null;
  if (/mzstatic\.com\/image\/thumb\//i.test(src)) {
    return src.replace(/\/\d+x\d+[a-z]{0,3}(?:-\d+)?\.(?:png|jpe?g|webp)$/i, '/600x600bb.jpg');
  }
  return src;
}

const fileNameOf = (url: string): string => {
  try {
    return decodeURIComponent(new URL(url).pathname.split('/').pop() || '') || domainOf(url);
  } catch {
    return domainOf(url);
  }
};

/**
 * Prévia de um link: título, descrição, site e URL da capa. null = sem prévia (offline, bloqueio...).
 * Ordem: YouTube → API da plataforma (Spotify, SoundCloud, Vimeo, TikTok...) → tags da página
 * (com o "robô de link" das redes que só mostram a prévia para ele) → imagem direta.
 */
export async function fetchPreviewText(url: string): Promise<PreviewText | null> {
  if (!/^https?:\/\//i.test(url) || isBlockedHost(url)) return null;
  const yt = youtubeId(url);
  if (yt) {
    const thumb = `https://img.youtube.com/vi/${yt}/hqdefault.jpg`;
    const j = await getJson(`https://www.youtube.com/oembed?format=json&url=${enc(`https://www.youtube.com/watch?v=${yt}`)}`);
    return {
      title: j ? clip(String(j.title ?? ''), 120) : '',
      desc: j ? clip(String(j.author_name ?? ''), 200) : '',
      site: 'YouTube',
      imageUrl: thumb,
    };
  }

  const host = domainOf(url);
  let part = await providerPreview(url);
  if (part && part.title && part.imageUrl && part.desc) {
    return { title: part.title, desc: part.desc, site: part.site || domainOf(url), imageUrl: tweakImage(part.imageUrl) };
  }

  const firstUa = botUaFor(host) ?? MOBILE_UA;
  let page = await getPage(url, firstUa);
  let html = page?.kind === 'html' ? parseHtmlPreview(page.html, page.finalUrl) : null;
  if (page?.kind === 'html' && !html?.imageUrl && firstUa === MOBILE_UA) {
    // sem capa para o navegador: muitos sites mostram para o robô de link
    const p2 = await getPage(url, FB_BOT);
    const h2 = p2?.kind === 'html' ? parseHtmlPreview(p2.html, p2.finalUrl) : null;
    if (p2 && h2?.imageUrl) {
      page = p2;
      html = h2;
    }
  }
  if (page?.kind === 'image') {
    return { title: clip(fileNameOf(page.finalUrl), 120), desc: '', site: domainOf(page.finalUrl), imageUrl: page.finalUrl };
  }
  // link curto (spotify.link, on.soundcloud.com, vm.tiktok.com...): o destino pode ter provedor
  if (!part && page && domainOf(page.finalUrl) !== host) part = await providerPreview(page.finalUrl);
  if (!part && !page) return null;

  const htmlDesc = html && (!part?.descMustMatch || part.descMustMatch.test(html.desc)) ? html.desc : '';
  return {
    title: clip(part?.title || html?.title || '', 120),
    desc: clip(part?.desc || htmlDesc || part?.fallbackDesc || '', 200),
    site: part?.site || html?.site || host,
    imageUrl: tweakImage(part?.imageUrl || html?.imageUrl || null),
  };
}

/** Descobre a proporção (largura/altura) de uma imagem já salva. null = não deu para medir. */
function imageAspect(uri: string): Promise<number | null> {
  return new Promise((resolve) => {
    const t = setTimeout(() => resolve(null), 4000);
    Image.getSize(
      uri,
      (w, h) => {
        clearTimeout(t);
        resolve(w > 0 && h > 0 ? w / h : null);
      },
      () => {
        clearTimeout(t);
        resolve(null);
      }
    );
  });
}

/** Baixa a capa para a pasta do app e mede a proporção. null = não foi possível (o cartão fica sem capa). */
export async function saveCover(imageUrl: string | null): Promise<{ img: string; ar: number } | null> {
  if (!imageUrl || !/^https?:\/\//i.test(imageUrl) || isBlockedHost(imageUrl)) return null;
  const saved = await saveRemoteImage(imageUrl);
  if (!saved) return null;
  return { img: saved, ar: normalizeAr((await imageAspect(mediaUri(saved))) ?? DEFAULT_AR) };
}

/**
 * Busca a prévia e devolve o conteúdo novo. Respeita `custom`: se o usuário mexeu na miniatura, ela fica como está.
 * `oldImg` (arquivo antigo, se foi substituído) vem em `replacedImg` para o chamador apagar.
 * Sem prévia: devolve os dados antigos e `ok: false`.
 */
export async function refreshLinkData(
  cur: LinkData
): Promise<{ data: LinkData; ok: boolean; replacedImg: string | null }> {
  const p = await fetchPreviewText(cur.url);
  if (!p) return { data: cur, ok: false, replacedImg: null };
  let img = cur.img;
  let ar = cur.ar;
  let replacedImg: string | null = null;
  if (!cur.custom) {
    const cover = await saveCover(p.imageUrl);
    if (cover) {
      replacedImg = cur.img;
      img = cover.img;
      ar = cover.ar;
    }
  }
  return {
    data: { ...cur, title: p.title || cur.title, desc: p.desc, site: p.site, img, ar, fetchedAt: Date.now() },
    ok: true,
    replacedImg,
  };
}
