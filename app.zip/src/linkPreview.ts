import { saveRemoteImage } from './media';

/** Conteúdo (JSON) de um item kind='link'. */
export type LinkData = {
  v: 1;
  url: string;
  title: string;
  desc: string;
  site: string;
  /** Nome do arquivo da miniatura em media. null = sem miniatura. */
  img: string | null;
  fetchedAt: number | null;
  /** true quando o usuário trocou/removeu a miniatura: "Atualizar prévia" não mexe em img. */
  custom: boolean;
};

const MOBILE_UA =
  'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36';

/** Domínio sem "www.". */
export function domainOf(url: string): string {
  const m = /^https?:\/\/([^/?#:]+)/i.exec(url.trim());
  return (m ? m[1] : url).toLowerCase().replace(/^www\./, '');
}

/** Leitura segura do JSON do cartão. Inválido → dados mínimos (url vazia). */
export function parseLink(content: string): LinkData {
  try {
    const j = JSON.parse(content);
    if (j && typeof j.url === 'string') {
      return {
        v: 1,
        url: j.url,
        title: typeof j.title === 'string' ? j.title : '',
        desc: typeof j.desc === 'string' ? j.desc : '',
        site: typeof j.site === 'string' ? j.site : domainOf(j.url),
        img: typeof j.img === 'string' && j.img ? j.img : null,
        fetchedAt: typeof j.fetchedAt === 'number' ? j.fetchedAt : null,
        custom: j.custom === true,
      };
    }
  } catch {
    // cai no padrão
  }
  return { v: 1, url: '', title: '', desc: '', site: '', img: null, fetchedAt: null, custom: false };
}

export const stringifyLink = (d: LinkData): string => JSON.stringify(d);

export const newLinkData = (url: string): LinkData => ({
  v: 1,
  url,
  title: domainOf(url),
  desc: '',
  site: domainOf(url),
  img: null,
  fetchedAt: null,
  custom: false,
});

/** Só http/https; "www.x.com" vira "https://www.x.com". Sem espaços. Inválido → null. */
export function normalizeUrl(raw: string): string | null {
  let s = raw.trim();
  if (!s || /\s/.test(s)) return null;
  if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(s)) {
    if (/^[^/.]+\.[^/]{2,}/.test(s) || /^www\./i.test(s)) s = `https://${s}`;
    else return null;
  }
  if (!/^https?:\/\//i.test(s)) return null;
  const host = domainOf(s);
  if (!/^[a-z0-9.-]+$/i.test(host) || !host.includes('.')) {
    if (host !== 'localhost') return null;
  }
  return s;
}

/** Primeira URL http(s) dentro de um texto (ex.: o que o Compartilhar manda). */
export function extractUrl(text: string): string | null {
  const m = /https?:\/\/[^\s<>"']+/i.exec(text);
  return m ? normalizeUrl(m[0].replace(/[).,;]+$/, '')) : null;
}

/** Hosts locais/privados não são buscados. */
export function isBlockedHost(url: string): boolean {
  const h = domainOf(url);
  if (h === 'localhost' || h.endsWith('.local')) return true;
  if (/^127\./.test(h) || /^10\./.test(h) || /^192\.168\./.test(h) || /^0\./.test(h) || /^169\.254\./.test(h)) return true;
  const m = /^172\.(\d+)\./.exec(h);
  return !!m && Number(m[1]) >= 16 && Number(m[1]) <= 31;
}

const ENTITIES: Record<string, string> = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ' };
function decodeEntities(s: string): string {
  return s
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCodePoint(parseInt(h, 16)))
    .replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(Number(d)))
    .replace(/&([a-z]+);/gi, (m, n) => ENTITIES[n.toLowerCase()] ?? m);
}

function attrs(tag: string): Record<string, string> {
  const out: Record<string, string> = {};
  for (const m of tag.matchAll(/([a-zA-Z_:][-a-zA-Z0-9_:.]*)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'>]+))/g)) {
    out[m[1].toLowerCase()] = decodeEntities(m[2] ?? m[3] ?? m[4] ?? '').trim();
  }
  return out;
}

const clip = (s: string, n: number) => {
  const t = s.replace(/\s+/g, ' ').trim();
  return t.length > n ? `${t.slice(0, n - 1)}…` : t;
};

function resolveUrl(base: string, ref: string): string | null {
  try {
    return new URL(ref, base).toString();
  } catch {
    return null;
  }
}

export type PreviewText = { title: string; desc: string; site: string; imageUrl: string | null };

/** Lê título, descrição, site e URL da imagem do começo de um HTML. */
export function parseHtmlPreview(html: string, pageUrl: string): PreviewText {
  const meta: Record<string, string> = {};
  let imageSrc = '';
  for (const m of html.matchAll(/<meta\b[^>]*>/gi)) {
    const a = attrs(m[0]);
    const key = (a.property || a.name || '').toLowerCase();
    if (key && a.content && !(key in meta)) meta[key] = a.content;
  }
  for (const m of html.matchAll(/<link\b[^>]*>/gi)) {
    const a = attrs(m[0]);
    if ((a.rel || '').toLowerCase() === 'image_src' && a.href) imageSrc = a.href;
  }
  const t = /<title[^>]*>([\s\S]*?)<\/title>/i.exec(html);
  const title = meta['og:title'] || meta['twitter:title'] || (t ? decodeEntities(t[1]) : '');
  const desc = meta['og:description'] || meta['twitter:description'] || meta['description'] || '';
  const img = meta['og:image'] || meta['og:image:secure_url'] || meta['twitter:image'] || imageSrc;
  return {
    title: clip(title, 120),
    desc: clip(desc, 200),
    site: clip(meta['og:site_name'] || domainOf(pageUrl), 60),
    imageUrl: img ? resolveUrl(pageUrl, img) : null,
  };
}

/** Busca o HTML (até ~200 KB) e extrai o texto da prévia. null = sem prévia (offline, bloqueio, não é HTML...). */
export async function fetchPreviewText(url: string): Promise<PreviewText | null> {
  if (!/^https?:\/\//i.test(url) || isBlockedHost(url)) return null;
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 8000);
  try {
    const res = await fetch(url, {
      signal: ctl.signal,
      headers: { 'User-Agent': MOBILE_UA, 'Accept-Language': 'pt-BR,pt;q=0.9,en;q=0.5', Accept: 'text/html,application/xhtml+xml' },
    });
    if (!res.ok) return null;
    if (!/text\/html/i.test(res.headers.get('content-type') ?? '')) return null;
    const html = (await res.text()).slice(0, 200_000);
    const finalUrl = res.url || url;
    if (isBlockedHost(finalUrl)) return null;
    return parseHtmlPreview(html, finalUrl);
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Busca a prévia e devolve o conteúdo novo. Respeita `custom`: se o usuário mexeu na miniatura, ela fica como está.
 * `oldImg` (arquivo antigo, se foi substituído) vem em `replacedImg` para o chamador apagar.
 * Sem prévia: devolve os dados antigos e `ok: false`.
 */
export async function refreshLinkData(
  cur: LinkData
): Promise<{ data: LinkData; ok: boolean; replacedImg: string | null }> {
  const p = await fetchPreviewText(cur.url);
  if (!p) return { data: cur, ok: false, replacedImg: null };
  let img = cur.img;
  let replacedImg: string | null = null;
  if (!cur.custom && p.imageUrl && /^https?:\/\//i.test(p.imageUrl) && !isBlockedHost(p.imageUrl)) {
    const saved = await saveRemoteImage(p.imageUrl);
    if (saved) {
      replacedImg = cur.img;
      img = saved;
    }
  }
  return {
    data: { ...cur, title: p.title || cur.title, desc: p.desc, site: p.site, img, fetchedAt: Date.now() },
    ok: true,
    replacedImg,
  };
}
