/**
 * Editor de texto livre do moodboard: mesmas ferramentas das notas (tipo de texto, negrito,
 * itálico, sublinhado, cor, tamanho, listas), mas sem a estrutura de documento (sem capa,
 * título fixo, tabelas). Fala com o React Native por mensagens e recebe comandos por
 * funções globais (window.initText).
 */
import { colors } from './theme';
import { ICON_CSS, icon } from './htmlIcons';

export const MOOD_EDITOR_HTML = String.raw`<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<style>
:root{--red:${colors.red};--gray:${colors.muted};--line:#E2E2E2;--panel:#F4F4F5}
${ICON_CSS}
*{box-sizing:border-box}
html,body{margin:0;background:#fff;color:#000;font-family:Roboto,"Segoe UI",system-ui,sans-serif;-webkit-text-size-adjust:100%}
body{padding:14px 18px 130px 18px;font-size:22px;line-height:1.35;letter-spacing:-0.01em;word-wrap:break-word;overflow-wrap:anywhere}
#doc{min-height:60vh;outline:none;caret-color:var(--red)}
#doc:empty:before{content:attr(data-ph);color:#b5b5b5}
::selection{background:rgba(255,48,48,.3)}
p,div{margin:.25em 0}
h1,h2,h3{font-weight:800;letter-spacing:-0.035em;line-height:1.12;margin:.5em 0 .2em}
h1{font-size:2em}h2{font-size:1.5em}h3{font-size:1.25em}
ul,ol{margin:.3em 0;padding-left:1.3em}
#bar{position:fixed;left:0;right:0;bottom:0;background:#fff;border-top:1px solid var(--line);z-index:20}
#row{display:flex;gap:6px;overflow-x:auto;padding:8px 10px;-webkit-overflow-scrolling:touch}
#row::-webkit-scrollbar{display:none}
.b{flex:0 0 auto;min-width:42px;height:42px;padding:0 10px;border-radius:21px;background:var(--panel);color:#000;font-size:17px;font-weight:700;display:flex;align-items:center;justify-content:center;border:0;font-family:inherit}
.b.on{background:#000;color:#fff}
.sep{flex:0 0 1px;background:#ddd;margin:6px 2px}
#panel{display:none;position:fixed;left:0;right:0;bottom:58px;max-height:46%;overflow-y:auto;background:var(--panel);border-radius:18px 18px 0 0;padding:12px 12px 8px;z-index:19;box-shadow:0 -8px 24px rgba(0,0,0,.18)}
#panel.show{display:block}
#panel .grid{display:flex;flex-wrap:wrap;gap:8px}
#panel .opt{background:#fff;border-radius:12px;padding:11px 14px;font-size:16px;font-weight:600;color:#000;border:1px solid var(--line)}
#panel .row{display:flex;align-items:center;gap:10px;margin-bottom:10px}
#panel .lbl{flex:1;font-size:16px;font-weight:600}
#panel .val{min-width:58px;text-align:center;font-size:16px;font-weight:700}
#panel .row .opt{min-width:52px;text-align:center;font-size:20px;padding:8px 14px}
#panel .ttl{color:var(--gray);font-size:13px;font-weight:700;margin:2px 2px 8px}
.sw{width:42px;height:42px;border-radius:21px;border:2px solid #d0d0d0}
</style>
</head>
<body>
<div id="doc" contenteditable="true" spellcheck="true" data-ph="Escreva aqui"></div>
<div id="panel"></div>
<div id="bar"><div id="row">
  <button class="b" data-c="undo" aria-label="Desfazer">${icon('undo')}</button>
  <button class="b" data-c="redo" aria-label="Refazer">${icon('redo')}</button>
  <div class="sep"></div>
  <button class="b" data-p="block" id="bBlock">Aa</button>
  <button class="b" data-c="bold" id="bB"><b>B</b></button>
  <button class="b" data-c="italic" id="bI"><i>I</i></button>
  <button class="b" data-c="underline" id="bU"><u>U</u></button>
  <button class="b" data-c="strikeThrough" id="bS"><s>S</s></button>
  <button class="b" data-p="color">A●</button>
  <button class="b" data-p="size" aria-label="Tamanho">${icon('size')}</button>
  <button class="b" data-p="space">Espaço</button>
  <div class="sep"></div>
  <button class="b" data-c="justifyLeft">Esq.</button>
  <button class="b" data-c="justifyCenter">Centro</button>
  <button class="b" data-c="justifyRight">Dir.</button>
  <div class="sep"></div>
  <button class="b" data-c="insertUnorderedList" aria-label="Lista">${icon('ul')}</button>
  <button class="b" data-c="insertOrderedList" aria-label="Lista numerada">${icon('ol')}</button>
</div></div>
<script>
(function(){
var RN=window.ReactNativeWebView;
function post(o){try{RN.postMessage(JSON.stringify(o));}catch(e){}}
function $(id){return document.getElementById(id);}
var doc=$('doc'),panel=$('panel'),lastRange=null,saveT=null,openName=null;
try{document.execCommand('defaultParagraphSeparator',false,'p');}catch(e){}
function sel(){return window.getSelection();}
function inDoc(n){return n&&(n===doc||doc.contains(n));}
function elOf(n){return n&&n.nodeType===1?n:(n?n.parentNode:doc);}
function saveSel(){var s=sel();if(s&&s.rangeCount){var r=s.getRangeAt(0);if(inDoc(r.commonAncestorContainer))lastRange=r.cloneRange();}}
function restoreSel(){
  var s=sel();
  if(s&&s.rangeCount&&inDoc(s.getRangeAt(0).commonAncestorContainer))return;
  doc.focus();
  if(lastRange){s.removeAllRanges();s.addRange(lastRange);}
  else{var r=document.createRange();r.selectNodeContents(doc);r.collapse(false);s.removeAllRanges();s.addRange(r);}
}
function cleanHtml(){
  var h=doc.innerHTML;
  if(!doc.textContent.trim()&&!doc.querySelector('li'))return '';
  return h;
}
function changed(){clearTimeout(saveT);saveT=setTimeout(function(){post({type:'change',html:cleanHtml()});},250);}
window.flushNow=function(){clearTimeout(saveT);post({type:'change',html:cleanHtml()});};
doc.addEventListener('input',changed);

var BLOCKS=[['Título','h1'],['Subtítulo','h2'],['Título pequeno','h3'],['Parágrafo','p']];
var COLORS=['#000000','#4A4A4A','#808080','#BDBDBD','#FFFFFF','#FF3030','#FF7A1A','#FFC21A','#C3FF6B','#32B450','#00B3A4','#4DA3FF','#0055FF','#7A4DFF','#B24DFF','#FF4FA3','#8B5A2B','#D9C3A5'];
var PAL=[];
var SIZES=[['Pequeno',0.75],['Normal',1],['Grande',1.4],['Maior',1.9],['Enorme',2.6]];
function closePanel(){panel.className='';panel.innerHTML='';openName=null;}
function openPanel(name){
  if(openName===name){closePanel();return;}
  openName=name;var h='',i;
  if(name==='block'){
    h='<div class="ttl">Tipo de texto</div><div class="grid">';
    for(i=0;i<BLOCKS.length;i++)h+='<div class="opt" data-blk="'+BLOCKS[i][1]+'">'+BLOCKS[i][0]+'</div>';
    h+='</div>';
  }else if(name==='color'){
    h='<div class="ttl">Cor do texto</div>';
    if(PAL.length){h+='<div class="ttl" style="margin-top:4px">Paleta do quadro</div><div class="grid">';
      for(i=0;i<PAL.length;i++)h+='<div class="sw" data-col="'+PAL[i]+'" style="background:'+PAL[i]+'"></div>';
      h+='</div><div class="ttl" style="margin-top:12px">Cores</div>';}
    h+='<div class="grid">';
    for(i=0;i<COLORS.length;i++)h+='<div class="sw" data-col="'+COLORS[i]+'" style="background:'+COLORS[i]+'"></div>';
    h+='</div>';
  }else if(name==='size'){
    h='<div class="ttl">Tamanho (sem seleção, vale para o parágrafo todo)</div>';
    h+='<div class="grid"><div class="opt" data-step="0.85">A− menor</div><div class="opt" data-step="1.18">A+ maior</div></div>';
    h+='<div class="ttl" style="margin-top:12px">Tamanhos prontos</div><div class="grid">';
    for(i=0;i<SIZES.length;i++)h+='<div class="opt" data-sz="'+SIZES[i][1]+'">'+SIZES[i][0]+'</div>';
    h+='</div>';
  }
  else if(name==='space'){
    h='<div class="ttl">Espaçamento (vale para os parágrafos selecionados; sem seleção, o parágrafo do cursor)</div>';
    h+='<div class="row"><span class="lbl">Entre linhas</span><div class="opt" data-sp="lh-">−</div><span class="val" id="vLH"></span><div class="opt" data-sp="lh+">+</div></div>';
    h+='<div class="row"><span class="lbl">Entre letras</span><div class="opt" data-sp="ls-">−</div><span class="val" id="vLS"></span><div class="opt" data-sp="ls+">+</div></div>';
    h+='<div class="grid" style="margin-top:4px"><div class="opt" data-sp="reset">Voltar ao padrão</div></div>';
  }
  panel.innerHTML=h;panel.className='show';
  if(name==='space')refreshSpace();
}
var BLOCK_RE=/^(P|H[1-6]|DIV|LI|BLOCKQUOTE)$/;
function blockOf(n){n=elOf(n);while(n&&n!==doc){if(BLOCK_RE.test(n.tagName))return n;n=n.parentNode;}return doc;}
function px(el){return parseFloat(getComputedStyle(el).fontSize)||16;}
function applySize(mode,f){
  restoreSel();
  var s=sel();
  if(!s.rangeCount)return;
  var r=s.getRangeAt(0);
  if(s.isCollapsed){
    var blk=blockOf(r.startContainer);
    if(blk===doc)return;
    var rr=document.createRange();rr.selectNodeContents(blk);s.removeAllRanges();s.addRange(rr);r=rr;
  }
  var startEl=elOf(r.startContainer);
  var target=mode==='step'?px(startEl)*f:px(blockOf(startEl))*f;
  target=Math.max(8,Math.min(200,target));
  document.execCommand('styleWithCSS',false,true);
  document.execCommand('fontSize',false,'7');
  var made=doc.querySelectorAll('span[style*="xxx-large"],font[size="7"]');
  for(var i=0;i<made.length;i++){
    var el=made[i];
    if(el.tagName==='FONT'){
      var sp=document.createElement('span');
      while(el.firstChild)sp.appendChild(el.firstChild);
      el.parentNode.replaceChild(sp,el);el=sp;
    }
    var inner=el.querySelectorAll('[style*="font-size"]');
    for(var k=0;k<inner.length;k++){inner[k].style.fontSize='';if(!inner[k].getAttribute('style'))inner[k].removeAttribute('style');}
    var parentPx=px(el.parentNode.nodeType===1?el.parentNode:doc);
    var em=target/parentPx;
    if(Math.abs(em-1)<0.02){
      el.style.fontSize='';
      if(!el.getAttribute('style')){while(el.firstChild)el.parentNode.insertBefore(el.firstChild,el);el.parentNode.removeChild(el);}
    }else el.style.fontSize=(Math.round(em*1000)/1000)+'em';
  }
  document.execCommand('styleWithCSS',false,false);
  changed();updateState();
}
var ANY_BLOCK='p,div,h1,h2,h3,h4,h5,h6,li,blockquote';
function spaceBlocks(){
  restoreSel();
  var s=sel();if(!s.rangeCount)return [];
  var r=s.getRangeAt(0);
  if(s.isCollapsed){var b=blockOf(r.startContainer);return b===doc?[]:[b];}
  var out=[],all=doc.querySelectorAll(ANY_BLOCK);
  for(var i=0;i<all.length;i++){
    var el=all[i];
    if(el.querySelector(ANY_BLOCK))continue;
    try{if(r.intersectsNode(el))out.push(el);}catch(e){}
  }
  if(!out.length){var b2=blockOf(r.startContainer);if(b2!==doc)out.push(b2);}
  return out;
}
function lhOf(el){var cs=getComputedStyle(el),f=px(el),v=parseFloat(cs.lineHeight);return isNaN(v)?1.2:v/f;}
function lsOf(el){var cs=getComputedStyle(el),f=px(el),v=parseFloat(cs.letterSpacing);return isNaN(v)?0:v/f;}
function refreshSpace(){
  var b=spaceBlocks()[0],a=$('vLH'),c=$('vLS');
  if(!b||!a||!c)return;
  a.textContent=lhOf(b).toFixed(2);
  c.textContent=lsOf(b).toFixed(2);
}
function spacing(op){
  var bl=spaceBlocks();
  for(var i=0;i<bl.length;i++){
    var el=bl[i];
    if(op==='reset'){
      el.style.lineHeight='';el.style.letterSpacing='';
      if(!el.getAttribute('style'))el.removeAttribute('style');
    }else if(op==='lh-'||op==='lh+'){
      var lh=Math.max(0.8,Math.min(3,lhOf(el)+(op==='lh+'?0.1:-0.1)));
      el.style.lineHeight=String(Math.round(lh*100)/100);
    }else if(op==='ls-'||op==='ls+'){
      var ls=Math.max(-0.1,Math.min(0.6,lsOf(el)+(op==='ls+'?0.02:-0.02)));
      el.style.letterSpacing=(Math.round(ls*1000)/1000)+'em';
    }
  }
  changed();refreshSpace();
}
function command(c){
  restoreSel();
  if(c==='undo'||c==='redo'){document.execCommand(c);}
  else{
    // Alinhamento e cor usam style; o resto gera <b>, <i>, <u>, <strike>.
    document.execCommand('styleWithCSS',false,/^justify/.test(c));
    document.execCommand(c);
    document.execCommand('styleWithCSS',false,false);
  }
  changed();updateState();
}
function setBlock(tag){
  restoreSel();
  document.execCommand('formatBlock',false,tag);
  changed();updateState();
}
function updateState(){
  var st=function(c){try{return document.queryCommandState(c);}catch(e){return false;}};
  $('bB').classList.toggle('on',st('bold'));
  $('bI').classList.toggle('on',st('italic'));
  $('bU').classList.toggle('on',st('underline'));
  $('bS').classList.toggle('on',st('strikeThrough'));
  var s=sel(),lab='Aa';
  if(s&&s.rangeCount&&inDoc(s.anchorNode)){
    var b=blockOf(s.anchorNode);
    if(b&&b.tagName==='H1')lab='Título';else if(b&&b.tagName==='H2')lab='Subt.';else if(b&&b.tagName==='H3')lab='T3';
  }
  $('bBlock').textContent=lab;
}
document.addEventListener('selectionchange',function(){saveSel();updateState();});
$('bar').addEventListener('mousedown',function(e){e.preventDefault();});
panel.addEventListener('mousedown',function(e){e.preventDefault();});
$('bar').addEventListener('click',function(e){
  var t=e.target.closest?e.target.closest('[data-c],[data-p]'):null;if(!t)return;
  if(t.dataset.c){closePanel();command(t.dataset.c);}
  else if(t.dataset.p)openPanel(t.dataset.p);
});
panel.addEventListener('click',function(e){
  var t=e.target;
  if(t.dataset.blk){setBlock(t.dataset.blk);closePanel();}
  else if(t.dataset.sp){spacing(t.dataset.sp);}
  else if(t.dataset.step){applySize('step',parseFloat(t.dataset.step));}
  else if(t.dataset.sz){applySize('preset',parseFloat(t.dataset.sz));closePanel();}
  else if(t.dataset.col){
    restoreSel();
    document.execCommand('styleWithCSS',false,true);
    document.execCommand('foreColor',false,t.dataset.col);
    document.execCommand('styleWithCSS',false,false);
    changed();closePanel();
  }
});
window.initText=function(p){
  PAL=((p&&p.palette)||[]).filter(function(c){return /^#[0-9A-Fa-f]{6}$/.test(c)}).slice(0,40);
  doc.innerHTML=(p&&p.html)||'';
  if(!doc.firstElementChild&&!doc.textContent){doc.innerHTML='<p><br></p>';}
  doc.focus();
  var r=document.createRange();r.selectNodeContents(doc);r.collapse(false);
  var s=sel();s.removeAllRanges();s.addRange(r);
  updateState();
};
post({type:'ready'});
})();
</script>
</body>
</html>`;
