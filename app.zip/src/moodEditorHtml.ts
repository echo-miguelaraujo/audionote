/**
 * Editor de texto livre do moodboard: mesmas ferramentas das notas (tipo de texto, negrito,
 * itálico, sublinhado, cor, tamanho, listas), mas sem a estrutura de documento (sem capa,
 * título fixo, tabelas). Fala com o React Native por mensagens e recebe comandos por
 * funções globais (window.initText).
 */
import { colors } from './theme';
import { ICON_CSS, icon, iconMap } from './htmlIcons';
import { PILL_CSS, TB_SEP, tbBtn } from './toolbarKit';

export const MOOD_EDITOR_HTML = String.raw`<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<style>
:root{--red:${colors.red};--gray:${colors.muted};--line:#E2E2E2;--panel:#F4F4F5}
${ICON_CSS}
*{box-sizing:border-box}
html,body{margin:0;background:#fff;color:#000;font-family:Roboto,"Segoe UI",system-ui,sans-serif;-webkit-text-size-adjust:100%}
body{padding:14px 18px 130px 18px;font-size:22px;line-height:1.35;letter-spacing:-0.01em;word-wrap:break-word;overflow-wrap:anywhere}
#doc{min-height:60vh;outline:none;caret-color:var(--red)}
/* modo "no cartão": fundo transparente e o texto vira um cartão branco na posição do cartão do quadro */
html.inline,html.inline body{background:transparent;height:100%}
html.inline body{padding:0}
html.inline #doc{position:absolute;left:var(--ax,16px);top:var(--ay,80px);width:var(--aw,calc(100% - 32px));min-height:56px;box-sizing:border-box;background:#fff;border-radius:10px;padding:12px;box-shadow:0 8px 28px rgba(0,0,0,.3);font-size:20px}
#doc:empty:before{content:attr(data-ph);color:#b5b5b5}
::selection{background:rgba(255,48,48,.3)}
p,div{margin:.25em 0}
h1,h2,h3{font-weight:800;letter-spacing:-0.035em;line-height:1.12;margin:.5em 0 .2em}
h1{font-size:2em}h2{font-size:1.5em}h3{font-size:1.25em}
ul,ol{margin:.3em 0;padding-left:1.3em}
#bar{position:fixed;left:0;right:0;bottom:0;background:#fff;border-top:1px solid var(--line);z-index:20}
#row{display:flex;gap:6px;overflow-x:auto;padding:8px 10px;-webkit-overflow-scrolling:touch}
#row::-webkit-scrollbar{display:none}
.b{flex:0 0 auto;min-width:42px;height:42px;padding:0 10px;border-radius:21px;background:var(--panel);color:#000;font-size:17px;font-weight:700;display:flex;align-items:center;justify-content:center;border:0;font-family:inherit}
.b.on{background:#000;color:#fff}
.sep{flex:0 0 1px;background:#ddd;margin:6px 2px}
#panel{display:none;position:fixed;left:0;right:0;bottom:58px;max-height:46%;overflow-y:auto;background:var(--panel);border-radius:18px 18px 0 0;padding:12px 12px 8px;z-index:19;box-shadow:0 -8px 24px rgba(0,0,0,.18)}
#panel.show{display:block}
#panel .grid{display:flex;flex-wrap:wrap;gap:8px}
#panel .opt{background:#fff;border-radius:12px;padding:11px 14px;font-size:16px;font-weight:600;color:#000;border:1px solid var(--line)}
#panel .row{display:flex;align-items:center;gap:10px;margin-bottom:10px}
#panel .lbl{flex:1;font-size:16px;font-weight:600}
#panel .val{min-width:58px;text-align:center;font-size:16px;font-weight:700}
#panel .row .opt{min-width:52px;text-align:center;font-size:20px;padding:8px 14px}
#panel .ttl{color:var(--gray);font-size:13px;font-weight:700;margin:2px 2px 8px}
.sw{width:42px;height:42px;border-radius:21px;border:2px solid #d0d0d0}
${PILL_CSS}
#bar{position:fixed;left:10px;right:10px;bottom:8px;z-index:20}
#panel{position:fixed;left:10px;right:10px;bottom:66px;margin:0}
.sw{width:42px;height:42px;border-radius:21px}
</style>
</head>
<body>
<div id="doc" contenteditable="true" spellcheck="true" data-ph="Escreva aqui"></div>
<div id="panel"></div>
<div id="bar"><div id="row">
  ${tbBtn('undo', 'Desfazer', 'data-c="undo"')}
  ${tbBtn('redo', 'Refazer', 'data-c="redo"')}
  ${TB_SEP}
  ${tbBtn('heading', 'Tipo de texto', 'data-p="block" id="bBlock"')}
  ${tbBtn('type', 'Fonte', 'data-p="font" id="bFont"')}
  ${tbBtn('size', 'Tamanho', 'data-p="size"')}
  ${tbBtn('palette', 'Cor do texto', 'data-p="color"')}
  ${TB_SEP}
  ${tbBtn('underline', 'Sublinhado', 'data-c="underline" id="bU"')}
  ${tbBtn('para', 'Parágrafo', 'data-p="space"')}
  ${tbBtn('ul', 'Lista', 'data-c="insertUnorderedList"')}
  ${tbBtn('ol', 'Lista numerada', 'data-c="insertOrderedList"')}
</div></div>
<script>
(function(){
var RN=window.ReactNativeWebView;
function post(o){try{RN.postMessage(JSON.stringify(o));}catch(e){}}
function $(id){return document.getElementById(id);}
var doc=$('doc'),panel=$('panel'),lastRange=null,saveT=null,openName=null;
try{document.execCommand('defaultParagraphSeparator',false,'p');}catch(e){}
function sel(){return window.getSelection();}
function inDoc(n){return n&&(n===doc||doc.contains(n));}
function elOf(n){return n&&n.nodeType===1?n:(n?n.parentNode:doc);}
function saveSel(){var s=sel();if(s&&s.rangeCount){var r=s.getRangeAt(0);if(inDoc(r.commonAncestorContainer))lastRange=r.cloneRange();}}
function restoreSel(){
  var s=sel();
  if(s&&s.rangeCount&&inDoc(s.getRangeAt(0).commonAncestorContainer))return;
  doc.focus();
  if(lastRange){s.removeAllRanges();s.addRange(lastRange);}
  else{var r=document.createRange();r.selectNodeContents(doc);r.collapse(false);s.removeAllRanges();s.addRange(r);}
}
function cleanHtml(){
  var h=doc.innerHTML;
  if(!doc.textContent.trim()&&!doc.querySelector('li'))return '';
  return h;
}
function changed(){clearTimeout(saveT);saveT=setTimeout(function(){post({type:'change',html:cleanHtml()});},250);}
window.flushNow=function(){clearTimeout(saveT);post({type:'change',html:cleanHtml()});};
doc.addEventListener('input',changed);

var BLOCKS=[['Título','h1'],['Subtítulo','h2'],['Título pequeno','h3'],['Parágrafo','p']];
var COLORS=['#000000','#4A4A4A','#808080','#BDBDBD','#FFFFFF','#FF3030','#FF7A1A','#FFC21A','#C3FF6B','#32B450','#00B3A4','#4DA3FF','#0055FF','#7A4DFF','#B24DFF','#FF4FA3','#8B5A2B','#D9C3A5'];
var PAL=[];
var SIZES=[['Pequeno',0.75],['Normal',1],['Grande',1.4],['Maior',1.9],['Enorme',2.6]];
function closePanel(){panel.className='';panel.innerHTML='';openName=null;}
var IC=${iconMap(['alignL','alignC','alignR','palette'])};
function openPanel(name){
  if(openName===name){closePanel();return;}
  openName=name;var h='',i;
  if(name==='block'){
    h='<div class="ttl">Tipo de texto</div><div class="grid">';
    for(i=0;i<BLOCKS.length;i++)h+='<div class="opt" data-blk="'+BLOCKS[i][1]+'">'+BLOCKS[i][0]+'</div>';
    h+='</div>';
  }else if(name==='color'){
    h='<div class="ttl">Cor do texto</div>';
    if(PAL.length){h+='<div class="ttl" style="margin-top:4px">Paleta do quadro</div><div class="grid">';
      for(i=0;i<PAL.length;i++)h+='<div class="sw" data-col="'+PAL[i]+'" style="background:'+PAL[i]+'"></div>';
      h+='</div><div class="ttl" style="margin-top:12px">Cores</div>';}
    h+='<div class="grid">';
    for(i=0;i<COLORS.length;i++)h+='<div class="sw" data-col="'+COLORS[i]+'" style="background:'+COLORS[i]+'"></div>';
    h+='</div>';
  }else if(name==='size'){
    h='<div class="ttl">Tamanho (sem seleção, vale para o parágrafo todo)</div>';
    h+='<div class="grid"><div class="opt" data-step="0.85" aria-label="Menor">A−</div><div class="opt" data-step="1.18" aria-label="Maior">A+</div></div>';
    h+='<div class="ttl" style="margin-top:12px">Tamanhos prontos</div><div class="grid">';
    for(i=0;i<SIZES.length;i++)h+='<div class="opt" data-sz="'+SIZES[i][1]+'">'+SIZES[i][0]+'</div>';
    h+='</div>';
  }
  else if(name==='font'){
    h='<div class="ttl">Fonte (sem seleção, vale para o parágrafo todo)</div>';
    h+='<div class="ttl" style="margin-top:4px">Minhas fontes</div><div class="grid"><div class="opt" data-fnt="">Padrão</div>';
    for(i=0;i<FONTS.length;i++)h+='<div class="opt" data-fnt="'+FONTS[i]+'" style="font-family:\''+FONTS[i]+'\'">'+FONTS[i]+'</div>';
    h+='</div><div class="grid" style="margin-top:12px"><div class="opt" data-fntget="1">+ Buscar no Google Fonts</div></div>';
  }
  else if(name==='space'){
    var al=(blockOf(lastRange?lastRange.startContainer:doc).style||{}).textAlign||'left';
    h='<div class="ttl">Alinhamento</div><div class="grid">';
    h+='<div class="opt'+(al==='left'?' on':'')+'" data-al="Left" aria-label="Esquerda">'+IC.alignL+'</div>';
    h+='<div class="opt'+(al==='center'?' on':'')+'" data-al="Center" aria-label="Centro">'+IC.alignC+'</div>';
    h+='<div class="opt'+(al==='right'?' on':'')+'" data-al="Right" aria-label="Direita">'+IC.alignR+'</div></div>';
    h+='<div class="ttl" style="margin-top:12px">Espaçamento (vale para os parágrafos selecionados; sem seleção, o parágrafo do cursor)</div>';
    h+='<div class="row"><span class="lbl">Entre linhas</span><div class="opt" data-sp="lh-">−</div><span class="val" id="vLH"></span><div class="opt" data-sp="lh+">+</div></div>';
    h+='<div class="row"><span class="lbl">Entre letras</span><div class="opt" data-sp="ls-">−</div><span class="val" id="vLS"></span><div class="opt" data-sp="ls+">+</div></div>';
    h+='<div class="grid" style="margin-top:4px"><div class="opt" data-sp="reset">Voltar ao padrão</div></div>';
  }
  panel.innerHTML=h;panel.className='show sub';
  if(name==='space')refreshSpace();
}
var BLOCK_RE=/^(P|H[1-6]|DIV|LI|BLOCKQUOTE)$/;
function blockOf(n){n=elOf(n);while(n&&n!==doc){if(BLOCK_RE.test(n.tagName))return n;n=n.parentNode;}return doc;}
function px(el){return parseFloat(getComputedStyle(el).fontSize)||16;}
function applySize(mode,f){
  restoreSel();
  var s=sel();
  if(!s.rangeCount)return;
  var r=s.getRangeAt(0);
  if(s.isCollapsed){
    var blk=blockOf(r.startContainer);
    if(blk===doc)return;
    var rr=document.createRange();rr.selectNodeContents(blk);s.removeAllRanges();s.addRange(rr);r=rr;
  }
  var startEl=elOf(r.startContainer);
  var target=mode==='step'?px(startEl)*f:px(blockOf(startEl))*f;
  target=Math.max(8,Math.min(200,target));
  document.execCommand('styleWithCSS',false,true);
  document.execCommand('fontSize',false,'7');
  var made=doc.querySelectorAll('span[style*="xxx-large"],font[size="7"]');
  for(var i=0;i<made.length;i++){
    var el=made[i];
    if(el.tagName==='FONT'){
      var sp=document.createElement('span');
      while(el.firstChild)sp.appendChild(el.firstChild);
      el.parentNode.replaceChild(sp,el);el=sp;
    }
    var inner=el.querySelectorAll('[style*="font-size"]');
    for(var k=0;k<inner.length;k++){inner[k].style.fontSize='';if(!inner[k].getAttribute('style'))inner[k].removeAttribute('style');}
    var parentPx=px(el.parentNode.nodeType===1?el.parentNode:doc);
    var em=target/parentPx;
    if(Math.abs(em-1)<0.02){
      el.style.fontSize='';
      if(!el.getAttribute('style')){while(el.firstChild)el.parentNode.insertBefore(el.firstChild,el);el.parentNode.removeChild(el);}
    }else el.style.fontSize=(Math.round(em*1000)/1000)+'em';
  }
  document.execCommand('styleWithCSS',false,false);
  changed();updateState();
}
/* Fontes do Google Fonts baixadas no aparelho (Minhas fontes): o app manda o CSS e a lista. */
var FONTS=[];
window.setFonts=function(p){
  var st=document.getElementById('gfonts');
  if(!st){st=document.createElement('style');st.id='gfonts';document.head.appendChild(st);}
  st.textContent=(p&&p.css)||'';
  FONTS=((p&&p.list)||[]).filter(function(n){return /^[A-Za-z0-9][A-Za-z0-9 ]{0,59}$/.test(n);});
  if(openName==='font'){openName=null;openPanel('font');}
};
function dropFamily(el){
  el.style.fontFamily='';
  if(!el.getAttribute('style'))el.removeAttribute('style');
  if(el.tagName==='SPAN'&&!el.attributes.length){var pr=el.parentNode;while(el.firstChild)pr.insertBefore(el.firstChild,el);pr.removeChild(el);}
}
/* Aplica a fonte (ou "Padrão", name vazio) ao trecho selecionado (sem seleção: ao parágrafo do cursor). */
function applyFont(name){
  restoreSel();
  var s=sel();
  if(!s.rangeCount)return;
  var r=s.getRangeAt(0);
  if(s.isCollapsed){
    var blk=blockOf(r.startContainer);
    if(blk===doc)return;
    var rr=document.createRange();rr.selectNodeContents(blk);s.removeAllRanges();s.addRange(rr);r=rr;
  }
  if(name&&FONTS.indexOf(name)<0)return;
  var MK='__gfont__';
  document.execCommand('styleWithCSS',false,true);
  document.execCommand('fontName',false,MK);
  var made=doc.querySelectorAll('span[style*="'+MK+'"],font[face="'+MK+'"]');
  for(var i=0;i<made.length;i++){
    var el=made[i];
    if(el.tagName==='FONT'){
      var sp=document.createElement('span');
      while(el.firstChild)sp.appendChild(el.firstChild);
      el.parentNode.replaceChild(sp,el);el=sp;
    }
    var inner=el.querySelectorAll('[style*="font-family"]');
    for(var k=0;k<inner.length;k++)dropFamily(inner[k]);
    if(name)el.style.fontFamily="'"+name+"'";else dropFamily(el);
  }
  document.execCommand('styleWithCSS',false,false);
  changed();updateState();
}
var ANY_BLOCK='p,div,h1,h2,h3,h4,h5,h6,li,blockquote';
function spaceBlocks(){
  restoreSel();
  var s=sel();if(!s.rangeCount)return [];
  var r=s.getRangeAt(0);
  if(s.isCollapsed){var b=blockOf(r.startContainer);return b===doc?[]:[b];}
  var out=[],all=doc.querySelectorAll(ANY_BLOCK);
  for(var i=0;i<all.length;i++){
    var el=all[i];
    if(el.querySelector(ANY_BLOCK))continue;
    try{if(r.intersectsNode(el))out.push(el);}catch(e){}
  }
  if(!out.length){var b2=blockOf(r.startContainer);if(b2!==doc)out.push(b2);}
  return out;
}
function lhOf(el){var cs=getComputedStyle(el),f=px(el),v=parseFloat(cs.lineHeight);return isNaN(v)?1.2:v/f;}
function lsOf(el){var cs=getComputedStyle(el),f=px(el),v=parseFloat(cs.letterSpacing);return isNaN(v)?0:v/f;}
function refreshSpace(){
  var b=spaceBlocks()[0],a=$('vLH'),c=$('vLS');
  if(!b||!a||!c)return;
  a.textContent=lhOf(b).toFixed(2);
  c.textContent=lsOf(b).toFixed(2);
}
function spacing(op){
  var bl=spaceBlocks();
  for(var i=0;i<bl.length;i++){
    var el=bl[i];
    if(op==='reset'){
      el.style.lineHeight='';el.style.letterSpacing='';
      if(!el.getAttribute('style'))el.removeAttribute('style');
    }else if(op==='lh-'||op==='lh+'){
      var lh=Math.max(0.8,Math.min(3,lhOf(el)+(op==='lh+'?0.1:-0.1)));
      el.style.lineHeight=String(Math.round(lh*100)/100);
    }else if(op==='ls-'||op==='ls+'){
      var ls=Math.max(-0.1,Math.min(0.6,lsOf(el)+(op==='ls+'?0.02:-0.02)));
      el.style.letterSpacing=(Math.round(ls*1000)/1000)+'em';
    }
  }
  changed();refreshSpace();
}
function command(c){
  restoreSel();
  if(c==='undo'||c==='redo'){document.execCommand(c);}
  else{
    // Alinhamento e cor usam style; o resto gera <b>, <i>, <u>, <strike>.
    document.execCommand('styleWithCSS',false,/^justify/.test(c));
    document.execCommand(c);
    document.execCommand('styleWithCSS',false,false);
  }
  changed();updateState();
}
function setBlock(tag){
  restoreSel();
  document.execCommand('formatBlock',false,tag);
  changed();updateState();
}
function updateState(){
  var st=function(c){try{return document.queryCommandState(c);}catch(e){return false;}};
  $('bU').classList.toggle('on',st('underline'));
  var s=sel(),lab='Aa';
  if(s&&s.rangeCount&&inDoc(s.anchorNode)){
    var b=blockOf(s.anchorNode);
    if(b&&b.tagName==='H1')lab='Título';else if(b&&b.tagName==='H2')lab='Subt.';else if(b&&b.tagName==='H3')lab='T3';
  }
  $('bBlock').classList.toggle('on',lab!=='Aa');
}
document.addEventListener('selectionchange',function(){saveSel();updateState();});
$('bar').addEventListener('mousedown',function(e){e.preventDefault();});
panel.addEventListener('mousedown',function(e){e.preventDefault();});
$('bar').addEventListener('click',function(e){
  var t=e.target.closest?e.target.closest('[data-c],[data-p]'):null;if(!t)return;
  if(t.dataset.c){closePanel();command(t.dataset.c);}
  else if(t.dataset.p)openPanel(t.dataset.p);
});
panel.addEventListener('click',function(e){
  var t=e.target;
  if(t.dataset.blk){setBlock(t.dataset.blk);closePanel();}
  else if(t.dataset.fntget){saveSel();closePanel();post({type:'openFonts'});}
  else if(t.dataset.fnt!==undefined){applyFont(t.dataset.fnt);closePanel();}
  else if(t.dataset.al){restoreSel&&restoreSel();command('justify'+t.dataset.al);closePanel();}
  else if(t.dataset.sp){spacing(t.dataset.sp);}
  else if(t.dataset.step){applySize('step',parseFloat(t.dataset.step));}
  else if(t.dataset.sz){applySize('preset',parseFloat(t.dataset.sz));closePanel();}
  else if(t.dataset.col){
    restoreSel();
    document.execCommand('styleWithCSS',false,true);
    document.execCommand('foreColor',false,t.dataset.col);
    document.execCommand('styleWithCSS',false,false);
    changed();closePanel();
  }
});
document.addEventListener('click',function(e){
  if(!document.documentElement.classList.contains('inline'))return;
  if(e.target.closest&&e.target.closest('#doc,#bar,#panel'))return;
  post({type:'outside'});
});
window.initText=function(p){
  if(p&&p.anchor){var de=document.documentElement;de.classList.add('inline');de.style.setProperty('--ax',p.anchor.x+'px');de.style.setProperty('--ay',p.anchor.y+'px');de.style.setProperty('--aw',p.anchor.w+'px');}
  PAL=((p&&p.palette)||[]).filter(function(c){return /^#[0-9A-Fa-f]{6}$/.test(c)}).slice(0,40);
  doc.innerHTML=(p&&p.html)||'';
  if(!doc.firstElementChild&&!doc.textContent){doc.innerHTML='<p><br></p>';}
  doc.focus();
  var r=document.createRange();r.selectNodeContents(doc);r.collapse(false);
  var s=sel();s.removeAllRanges();s.addRange(r);
  updateState();
};
post({type:'ready'});
})();
</script>
</body>
</html>`;
