import { PixelRatio, View } from 'react-native';
import React from 'react';
import { captureRef } from 'react-native-view-shot';
import { File } from 'expo-file-system';
import { exportBoardPdf, safeFileName, shareCachedCopy } from './exportPdf';

/** Lado maior máximo da imagem exportada, em pixels. */
export const MAX_EXPORT_PX = 4096;

/** Escala da captura: a densidade da tela, limitada para o lado maior não passar de 4096 px. */
export function exportScale(wPx: number, hPx: number): number {
  return Math.min(PixelRatio.get(), MAX_EXPORT_PX / Math.max(1, wPx, hPx));
}

/** Tira a foto da camada de exportação (PNG, fundo transparente). Devolve o arquivo temporário e o tamanho final. */
export async function captureLayer(
  ref: React.RefObject<View | null>,
  wPx: number,
  hPx: number
): Promise<{ uri: string; w: number; h: number }> {
  const scale = exportScale(wPx, hPx);
  const w = Math.max(1, Math.round(wPx * scale));
  const h = Math.max(1, Math.round(hPx * scale));
  const uri = await captureRef(ref, { format: 'png', result: 'tmpfile', quality: 1, width: w, height: h });
  return { uri, w, h };
}

/** Lado maior, em pixels, das imagens 16:9 / 9:16 (Full HD). */
export const FRAME_HD_PX = 1920;

/** Foto da camada com tamanho final exato (ex.: 1920x1080), para postar em redes sociais. */
export async function captureLayerSized(
  ref: React.RefObject<View | null>,
  w: number,
  h: number
): Promise<{ uri: string; w: number; h: number }> {
  const uri = await captureRef(ref, { format: 'png', result: 'tmpfile', quality: 1, width: w, height: h });
  return { uri, w, h };
}

let lastShared: string[] = [];

/** Apaga o que foi compartilhado na exportação anterior (o menu de compartilhar ainda precisa do arquivo quando abre). */
function cleanPrevious(): void {
  for (const p of lastShared) {
    try {
      const f = new File(p);
      if (f.exists) f.delete();
    } catch {
      // já apagado
    }
  }
  lastShared = [];
}

function dropTemp(uri: string): void {
  try {
    const f = new File(uri);
    if (f.exists) f.delete();
  } catch {
    // ignora
  }
}

/** Compartilha o PNG com o nome do quadro e apaga o temporário da captura. */
export async function sharePng(baseName: string, tmpUri: string): Promise<void> {
  cleanPrevious();
  try {
    const copy = await shareCachedCopy(tmpUri, `${safeFileName(baseName, 'Quadro')}.png`, 'image/png', 'Exportar imagem', 'public.png');
    lastShared.push(copy);
  } finally {
    dropTemp(tmpUri);
  }
}

/** Gera o PDF a partir do PNG da captura, compartilha e apaga o temporário. */
export async function sharePdf(baseName: string, tmpUri: string, w: number, h: number): Promise<void> {
  cleanPrevious();
  try {
    lastShared.push(await exportBoardPdf(baseName, tmpUri, w, h));
  } finally {
    dropTemp(tmpUri);
  }
}
