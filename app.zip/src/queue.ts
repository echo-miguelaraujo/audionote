import { AudioItem, commitTranscribed, getNoteJson, getTranscriptText, listPendingAudios, setAudioState, setTranscriptText } from './db';
import { organizeIdeas, transcribeAudio, GemError } from './gemini';
import { applyOrganizer, emptyNote, parseNote } from './note';
import { getDeleteAfter, loadGeminiSettings } from './settings';
import { audioBase64, audioFileExists, audioFileSize, removeAudioFile } from './storage';

/** Limite do envio direto (o Gemini aceita ~20 MB por pedido, e o base64 aumenta o tamanho). */
const MAX_INLINE_BYTES = 14 * 1024 * 1024;

let running = false;
let editingBlock: number | null = null;
const listeners = new Set<() => void>();

export function subscribeQueue(fn: () => void): () => void {
  listeners.add(fn);
  return () => {
    listeners.delete(fn);
  };
}

function emit() {
  listeners.forEach((fn) => {
    try {
      fn();
    } catch {}
  });
}

/** Enquanto uma nota está sendo editada, a fila não mexe nela (evita sobrescrever o que você digita). */
export function setEditingBlock(id: number | null) {
  editingBlock = id;
}

type Outcome = 'done' | 'deferred' | 'failed' | 'stop';

async function fail(a: AudioItem, e: GemError): Promise<Outcome> {
  const retry = e.retryAfterMs ?? 30 * 60 * 1000;
  await setAudioState(a.id, 'pending', e.message, Date.now() + retry);
  emit();
  // Sem internet, cota esgotada ou chave ruim: não adianta insistir nos outros agora.
  return e.kind === 'network' || e.kind === 'quota' || e.kind === 'auth' || e.kind === 'model' || e.kind === 'server'
    ? 'stop'
    : 'failed';
}

async function processOne(a: AudioItem, apiKey: string, model: string): Promise<Outcome> {
  // 1) Texto do áudio (guardado assim que obtido, para nunca precisar reenviar o áudio).
  let text = await getTranscriptText(a.id);
  if (text === null) {
    if (!a.fileName || !audioFileExists(a.fileName)) {
      await setAudioState(a.id, 'error', 'Arquivo de áudio não encontrado.', null);
      emit();
      return 'failed';
    }
    if (audioFileSize(a.fileName) > MAX_INLINE_BYTES) {
      await setAudioState(a.id, 'error', 'Áudio longo demais para enviar (máx. ~25 min).', null);
      emit();
      return 'failed';
    }
    const b64 = await audioBase64(a.fileName);
    const r = await transcribeAudio(apiKey, model, b64);
    if (!r.ok) return fail(a, r.error);
    text = r.data;
    await setTranscriptText(a.id, text);
  }
  if (!text.trim()) {
    await setAudioState(a.id, 'error', 'Nenhuma fala detectada neste áudio.', null);
    emit();
    return 'failed';
  }

  // 2) Nota em edição: espera para depois, sem marcar erro.
  if (editingBlock === a.blockId) return 'deferred';

  // 3) Organiza em tópicos e grava tudo numa transação.
  const note = parseNote(await getNoteJson(a.blockId)) ?? emptyNote();
  const org = await organizeIdeas(apiKey, model, note, text);
  if (!org.ok) return fail(a, org.error);
  if (!Array.isArray(org.data?.placements)) {
    return fail(a, { kind: 'parse', message: 'Resposta do Gemini em formato inesperado.', retryAfterMs: 5 * 60 * 1000 });
  }
  const merged = applyOrganizer(note, org.data);
  const del = await getDeleteAfter();
  await commitTranscribed(a.id, a.blockId, JSON.stringify(merged), del);
  // Só apaga o arquivo depois que a transcrição e a nota já foram salvas.
  if (del) removeAudioFile(a.fileName);
  emit();
  return 'done';
}

/** Processa a fila. `force` ignora o tempo de espera das tentativas anteriores. */
export async function processQueue(force = false): Promise<void> {
  if (running) return;
  running = true;
  try {
    const { apiKey, model } = await loadGeminiSettings();
    if (!apiKey.trim()) return;
    const items = await listPendingAudios();
    const blocked = new Set<number>();
    for (const a of items) {
      if (blocked.has(a.blockId)) continue; // mantém a ordem dentro de cada nota
      if (!force && a.nextRetryAt && a.nextRetryAt > Date.now()) {
        blocked.add(a.blockId);
        continue;
      }
      let out: Outcome;
      try {
        out = await processOne(a, apiKey, model);
      } catch (e) {
        await setAudioState(a.id, 'pending', `Erro inesperado: ${String(e).slice(0, 120)}`, Date.now() + 10 * 60 * 1000);
        emit();
        out = 'failed';
      }
      if (out === 'stop') break;
      if (out !== 'done') blocked.add(a.blockId);
    }
  } finally {
    running = false;
    emit();
  }
}
