import {
  AudioItem,
  commitTranscribed,
  deleteAudio,
  deleteQueueItem,
  getBlock,
  getNoteJson,
  getTranscript,
  listNoSpeechAudios,
  listPendingAudios,
  setAudioState,
  setTranscript,
} from './db';
import { createEventsFor } from './calendar';
import { transcribeAudio, GemError } from './gemini';
import { appendSections, emptyNote, noteHeadings, parseNote } from './note';
import { getDeleteAfter, loadGeminiSettings } from './settings';
import { audioBase64, audioFileExists, audioFileSize, removeAudioFile } from './storage';

/** Limite do envio direto (o Gemini aceita ~20 MB por pedido, e o base64 aumenta o tamanho). */
const MAX_INLINE_BYTES = 14 * 1024 * 1024;

let running = false;
let editingBlock: number | null = null;
let openBlock: number | null = null;
const listeners = new Set<() => void>();

export function subscribeQueue(fn: () => void): () => void {
  listeners.add(fn);
  return () => {
    listeners.delete(fn);
  };
}

/** Avisa as telas que a fila mudou (ex.: um item foi apagado). */
export function notifyQueue() {
  emit();
}

function emit() {
  listeners.forEach((fn) => {
    try {
      fn();
    } catch {}
  });
}

/** Enquanto uma nota está sendo editada, a fila não mexe nela (evita sobrescrever o que você digita). */
export function setEditingBlock(id: number | null) {
  editingBlock = id;
}

/** Nota que está aberta na tela: se ela ficar vazia, não é apagada debaixo do usuário. */
export function setOpenBlock(id: number | null) {
  openBlock = id;
}

/** Áudio sem fala é excluído sozinho. A nota vazia que sobrar também, a menos que esteja aberta. */
async function dropNoSpeech(id: number, blockId: number) {
  if (openBlock === blockId || editingBlock === blockId) await deleteAudio(id);
  else await deleteQueueItem(id);
}

type Outcome = 'done' | 'deferred' | 'failed' | 'stop';

async function fail(a: AudioItem, e: GemError): Promise<Outcome> {
  const retry = e.retryAfterMs ?? 30 * 60 * 1000;
  await setAudioState(a.id, 'pending', e.message, Date.now() + retry);
  emit();
  // Sem internet, cota esgotada ou chave ruim: não adianta insistir nos outros agora.
  return e.kind === 'network' || e.kind === 'quota' || e.kind === 'auth' || e.kind === 'model' || e.kind === 'server'
    ? 'stop'
    : 'failed';
}

async function processOne(a: AudioItem, apiKey: string, model: string): Promise<Outcome> {
  // 1) Texto do áudio + compromissos (guardados assim que obtidos, para nunca precisar reenviar o áudio).
  let tr = await getTranscript(a.id);
  if (tr === null) {
    if (!a.fileName || !audioFileExists(a.fileName)) {
      await setAudioState(a.id, 'error', 'Arquivo de áudio não encontrado.', null);
      emit();
      return 'failed';
    }
    if (audioFileSize(a.fileName) > MAX_INLINE_BYTES) {
      await setAudioState(a.id, 'error', 'Áudio longo demais para enviar (máx. ~25 min).', null);
      emit();
      return 'failed';
    }
    const b64 = await audioBase64(a.fileName);
    const known = parseNote(await getNoteJson(a.blockId)) ?? emptyNote();
    const r = await transcribeAudio(apiKey, model, b64, a.createdAt, noteHeadings(known));
    if (!r.ok) return fail(a, r.error);
    tr = r.data;
    await setTranscript(a.id, tr);
  }
  if (!tr.text.trim()) {
    await dropNoSpeech(a.id, a.blockId);
    emit();
    return 'done';
  }

  // 2) Nota em edição: espera para depois, sem marcar erro.
  if (editingBlock === a.blockId) return 'deferred';

  // 3) Acrescenta o texto fiel ao fim da nota (sem IA reescrevendo) e grava tudo numa transação.
  const note = parseNote(await getNoteJson(a.blockId)) ?? emptyNote();
  let merged = appendSections(note, tr.sections?.length ? tr.sections : [{ heading: '', text: tr.text }]);
  // Título automático: só se a nota ainda não tem título (nunca sobrescreve o seu).
  if (!merged.title.trim() && tr.title?.trim()) merged = { ...merged, title: tr.title.trim() };
  const del = await getDeleteAfter();
  const applied = await commitTranscribed(a.id, a.blockId, JSON.stringify(merged), del);
  if (!applied) return 'done'; // a gravação foi apagada da fila no meio do caminho
  // Só apaga o arquivo depois que a transcrição e a nota já foram salvas.
  if (del) removeAudioFile(a.fileName);

  // 4) Agenda: compromissos com data viram eventos. Falha aqui nunca desfaz a transcrição.
  if (tr.events.length > 0) {
    try {
      const blk = await getBlock(a.blockId);
      await createEventsFor(a.id, a.blockId, blk?.noteTitle || blk?.name || 'Nota', tr.events);
    } catch {
      // a nota já está salva; o compromisso pode ser criado manualmente
    }
  }
  emit();
  return 'done';
}

/** Processa a fila. `force` ignora o tempo de espera das tentativas anteriores. */
export async function processQueue(force = false): Promise<void> {
  if (running) return;
  running = true;
  try {
    // Limpa o que ficou marcado como "nenhuma fala" em versões anteriores.
    try {
      const old = await listNoSpeechAudios();
      for (const o of old) await dropNoSpeech(o.id, o.blockId);
      if (old.length > 0) emit();
    } catch {}
    const { apiKey, model } = await loadGeminiSettings();
    if (!apiKey.trim()) return;
    const items = await listPendingAudios();
    const blocked = new Set<number>();
    for (const a of items) {
      if (blocked.has(a.blockId)) continue; // mantém a ordem dentro de cada nota
      if (!force && a.nextRetryAt && a.nextRetryAt > Date.now()) {
        blocked.add(a.blockId);
        continue;
      }
      let out: Outcome;
      try {
        out = await processOne(a, apiKey, model);
      } catch (e) {
        await setAudioState(a.id, 'pending', `Erro inesperado: ${String(e).slice(0, 120)}`, Date.now() + 10 * 60 * 1000);
        emit();
        out = 'failed';
      }
      if (out === 'stop') break;
      if (out !== 'done') blocked.add(a.blockId);
    }
  } finally {
    running = false;
    emit();
  }
}
