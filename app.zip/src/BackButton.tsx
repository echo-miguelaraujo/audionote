import React from 'react';
import { Pressable, View } from 'react-native';
import { colors } from './theme';

type Props = {
  onPress: () => void;
  /** Unidade de tamanho: a largura da tela (ou o lado menor, como no moodboard). */
  u: number;
};

/**
 * Botão de voltar padrão do app: o chevron vermelho do moodboard.
 * Use este em toda tela para manter o mesmo visual; só o tamanho (u) se adapta.
 */
export function BackButton({ onPress, u }: Props) {
  return (
    <Pressable onPress={onPress} hitSlop={18} style={{ width: u * 0.12, height: u * 0.1, justifyContent: 'center' }}>
      <View
        style={{
          width: u * 0.05,
          height: u * 0.05,
          borderLeftWidth: u * 0.012,
          borderBottomWidth: u * 0.012,
          borderColor: colors.red,
          transform: [{ rotate: '45deg' }],
          marginLeft: u * 0.015,
        }}
      />
    </Pressable>
  );
}
