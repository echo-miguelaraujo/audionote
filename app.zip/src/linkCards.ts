import { LINK_CARD, MoodItem, addMoodItem, listMoodItems, updateMoodItem } from './db';
import { boxOf } from './boardGeometry';
import { LinkData, newLinkData, parseLink, refreshLinkData, stringifyLink } from './linkPreview';
import { deleteMedia } from './media';

const WORLD_W = 5;
const WORLD_H = 8;
const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));

/** Cria o cartão na hora (domínio como título, "carregando"). `at` = centro desejado; sem ele, vai abaixo do último item. */
export async function createLinkCard(
  collectionId: number,
  url: string,
  at?: { x: number; y: number }
): Promise<MoodItem> {
  const w = LINK_CARD.w;
  const h = LINK_CARD.hNoImg;
  let x: number;
  let y: number;
  if (at) {
    x = clamp(at.x - w / 2, 0, WORLD_W - w);
    y = clamp(at.y - h / 2, 0, WORLD_H - h);
  } else {
    const items = await listMoodItems(collectionId);
    if (items.length === 0) {
      x = (WORLD_W - w) / 2;
      y = WORLD_H / 2 - h / 2;
    } else {
      const bottom = Math.max(...items.map((i) => i.y + boxOf(i).h));
      x = (WORLD_W - w) / 2;
      y = clamp(bottom + 0.1, 0, WORLD_H - h);
    }
  }
  return addMoodItem({
    collectionId,
    kind: 'link',
    content: stringifyLink(newLinkData(url)),
    x,
    y,
    w,
    h,
    rot: 0,
    bold: false,
  });
}

export const linkHeight = (d: LinkData): number => (d.img ? LINK_CARD.h : LINK_CARD.hNoImg);

/**
 * Busca a prévia e grava no item. Devolve o conteúdo e a altura novos (para a tela atualizar),
 * ou null se o item sumiu. Sem prévia: marca fetchedAt = 0 ("sem prévia").
 */
export async function refreshLinkCard(
  id: number,
  content: string
): Promise<{ content: string; h: number; ok: boolean }> {
  const cur = parseLink(content);
  const r = await refreshLinkData(cur);
  const data: LinkData = r.ok ? r.data : { ...cur, fetchedAt: 0 };
  const next = stringifyLink(data);
  const h = linkHeight(data);
  await updateMoodItem(id, { content: next, h });
  if (r.replacedImg) deleteMedia(r.replacedImg);
  return { content: next, h, ok: r.ok };
}
