import React, { useEffect, useMemo, useRef } from 'react';
import { Animated, Easing, StyleSheet, View } from 'react-native';

type Props = {
  /** Diâmetro do botão. A aura nasce de dentro dele e se expande para fora. */
  size: number;
  /** true = aura aberta; false = retraída para dentro do botão. */
  expanded: boolean;
  /** true = em movimento (gravando); false = parada (pausada). */
  moving: boolean;
  /** Volume do microfone (0 a 1): a aura "respira" com a voz. */
  level?: Animated.Value;
};

// Cada camada é um anel de "poeira" que gira e respira num ritmo próprio.
// Só as camadas animam (driver nativo); os pontos de dentro são fixos, então é barato.
const LAYERS = [
  { n: 90, spin: 38000, dir: 1, breathe: 3200, amp: 0.05 },
  { n: 90, spin: 26000, dir: -1, breathe: 4100, amp: 0.07 },
  { n: 80, spin: 52000, dir: 1, breathe: 2700, amp: 0.09 },
  { n: 70, spin: 31000, dir: -1, breathe: 3600, amp: 0.06 },
  { n: 60, spin: 45000, dir: 1, breathe: 5000, amp: 0.11 },
];

type Dot = { x: number; y: number; d: number; o: number };

function buildDots(size: number): Dot[][] {
  const R = size / 2;
  let seed = 7;
  const rnd = () => {
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  return LAYERS.map((L) =>
    Array.from({ length: L.n }, () => {
      const a = rnd() * Math.PI * 2;
      const k = Math.pow(rnd(), 1.8); // mais denso perto do botão, esparso na borda
      const r = R * (0.97 + 0.55 * k);
      const d = 1 + rnd() * rnd() * 2.6;
      return {
        x: R + Math.cos(a) * r - d / 2,
        y: R + Math.sin(a) * r - d / 2,
        d,
        o: Math.max(0.25, 1 - k * 0.65) * (0.6 + rnd() * 0.4),
      };
    })
  );
}

export const Aura = React.memo(function Aura({ size, expanded, moving, level }: Props) {
  const dots = useMemo(() => buildDots(size), [size]);
  const expand = useRef(new Animated.Value(0)).current;
  const spins = useRef(LAYERS.map(() => new Animated.Value(0))).current;
  const breaths = useRef(LAYERS.map(() => new Animated.Value(0))).current;

  // Expande para fora / retrai para dentro do botão.
  useEffect(() => {
    Animated.timing(expand, {
      toValue: expanded ? 1 : 0,
      duration: expanded ? 1000 : 650,
      easing: expanded ? Easing.out(Easing.cubic) : Easing.in(Easing.cubic),
      useNativeDriver: true,
    }).start();
  }, [expanded, expand]);

  // Movimento contínuo enquanto grava.
  useEffect(() => {
    if (!moving) return;
    const loops = [
      ...LAYERS.map((L, i) =>
        Animated.loop(
          Animated.timing(spins[i], {
            toValue: 1,
            duration: L.spin,
            easing: Easing.linear,
            useNativeDriver: true,
          })
        )
      ),
      ...LAYERS.map((L, i) =>
        Animated.loop(
          Animated.sequence([
            Animated.timing(breaths[i], {
              toValue: 1,
              duration: L.breathe / 2,
              easing: Easing.inOut(Easing.sin),
              useNativeDriver: true,
            }),
            Animated.timing(breaths[i], {
              toValue: 0,
              duration: L.breathe / 2,
              easing: Easing.inOut(Easing.sin),
              useNativeDriver: true,
            }),
          ])
        )
      ),
    ];
    loops.forEach((l) => l.start());
    return () => loops.forEach((l) => l.stop());
  }, [moving, spins, breaths]);

  const baseGrow = expand.interpolate({ inputRange: [0, 1], outputRange: [0.55, 1] });
  const voice = useRef(new Animated.Value(0)).current;
  const grow = level
    ? Animated.multiply(baseGrow, (level ?? voice).interpolate({ inputRange: [0, 1], outputRange: [1, 1.14] }))
    : baseGrow;
  const fade = expand.interpolate({ inputRange: [0, 0.35, 1], outputRange: [0, 0.8, 1] });

  return (
    <View pointerEvents="none" style={[styles.wrap, { width: size, height: size }]}>
      {LAYERS.map((L, i) => (
        <Animated.View
          key={i}
          style={{
            position: 'absolute',
            left: 0,
            top: 0,
            width: size,
            height: size,
            opacity: fade,
            transform: [
              {
                rotate: spins[i].interpolate({
                  inputRange: [0, 1],
                  outputRange: L.dir > 0 ? ['0deg', '360deg'] : ['0deg', '-360deg'],
                }),
              },
              {
                scale: Animated.multiply(
                  grow,
                  breaths[i].interpolate({ inputRange: [0, 1], outputRange: [1, 1 + L.amp] })
                ),
              },
            ],
          }}
        >
          {dots[i].map((p, j) => (
            <View
              key={j}
              style={{
                position: 'absolute',
                left: p.x,
                top: p.y,
                width: p.d,
                height: p.d,
                borderRadius: p.d / 2,
                backgroundColor: '#FFFFFF',
                opacity: p.o,
              }}
            />
          ))}
        </Animated.View>
      ))}
    </View>
  );
});

const styles = StyleSheet.create({
  wrap: { position: 'absolute', left: 0, top: 0 },
});
