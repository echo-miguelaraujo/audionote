import React, { useState } from 'react';
import { Pressable, ScrollView, Text, View, useWindowDimensions } from 'react-native';
import { DialogActions, DialogInput, DialogShell, DialogTitle } from './DialogBase';
import { Icon } from './Icon';
import { colors, fonts, SPACE, TYPE } from './theme';
import { DEFAULT_STATUSES, SceneStatusDef, STATUS_COLORS } from './sceneStatus';

type Props = {
  visible: boolean;
  initial: SceneStatusDef[];
  onCancel: () => void;
  onSave: (l: SceneStatusDef[]) => void;
  /** Abre a escolha de outro projeto para copiar a lista dele. */
  onCopyFrom: () => void;
};

/** Edita os status das cenas do projeto: nome, cor, ordem; criar, apagar, copiar de outro projeto. */
export function SceneStatusDialog({ visible, initial, onCancel, onSave, onCopyFrom }: Props) {
  const { width: sw, height: sh } = useWindowDimensions();
  const [list, setList] = useState<SceneStatusDef[]>(initial);
  React.useEffect(() => {
    if (visible) setList(initial);
  }, [visible, initial]);
  const set = (i: number, p: Partial<SceneStatusDef>) => setList((l) => l.map((s, k) => (k === i ? { ...s, ...p } : s)));
  const move = (i: number, d: number) =>
    setList((l) => {
      const j = i + d;
      if (j < 0 || j >= l.length) return l;
      const a = [...l];
      [a[i], a[j]] = [a[j], a[i]];
      return a;
    });
  const nextColor = (c: string | null) => STATUS_COLORS[(STATUS_COLORS.indexOf(c) + 1) % STATUS_COLORS.length];
  const ic = sw * 0.055;
  const valid = list.length > 0 && list.every((s) => s.label.trim());
  return (
    <DialogShell visible={visible} onClose={onCancel} keyboard maxHeight={sh * 0.85}>
      <DialogTitle>Status das cenas</DialogTitle>
      <Text style={{ color: colors.subtle, fontFamily: fonts.regular, fontSize: sw * TYPE.caption, marginTop: sw * 0.01 }}>
        A ordem é a do fluxo: tocar no check da cena avança para o próximo.
      </Text>
      <ScrollView style={{ maxHeight: sh * 0.45, marginTop: sw * SPACE.md }} keyboardShouldPersistTaps="handled">
        {list.map((s, i) => (
          <View key={i} style={{ flexDirection: 'row', alignItems: 'center', gap: sw * SPACE.sm, marginBottom: sw * SPACE.sm }}>
            <Pressable accessibilityRole="button" accessibilityLabel="Trocar cor" onPress={() => set(i, { color: nextColor(s.color) })} hitSlop={8}>
              <View style={{ width: ic, height: ic, borderRadius: ic / 2, backgroundColor: s.color ?? colors.red }} />
            </Pressable>
            <View style={{ flex: 1 }}>
              <DialogInput value={s.label} onChangeText={(t) => set(i, { label: t })} placeholder="Nome do status" maxLength={24} />
            </View>
            <Pressable accessibilityRole="button" accessibilityLabel="Subir" onPress={() => move(i, -1)} hitSlop={8} style={{ opacity: i === 0 ? 0.25 : 1 }}>
              <Icon name="arrowU" size={ic} color={colors.onLight} />
            </Pressable>
            <Pressable accessibilityRole="button" accessibilityLabel="Descer" onPress={() => move(i, 1)} hitSlop={8} style={{ opacity: i === list.length - 1 ? 0.25 : 1 }}>
              <Icon name="arrowD" size={ic} color={colors.onLight} />
            </Pressable>
            <Pressable accessibilityRole="button" accessibilityLabel="Apagar" onPress={() => setList((l) => l.filter((_, k) => k !== i))} hitSlop={8} style={{ opacity: list.length <= 1 ? 0.25 : 1 }} disabled={list.length <= 1}>
              <Icon name="trash" size={ic} color={colors.red} />
            </Pressable>
          </View>
        ))}
      </ScrollView>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: sw * SPACE.lg, marginVertical: sw * SPACE.md }}>
        <Pressable accessibilityRole="button" onPress={() => setList((l) => [...l, { label: '', color: null }])}>
          <Text style={{ color: colors.red, fontFamily: fonts.bold, fontSize: sw * TYPE.body }}>+ Novo status</Text>
        </Pressable>
        <Pressable accessibilityRole="button" onPress={onCopyFrom}>
          <Text style={{ color: colors.red, fontFamily: fonts.bold, fontSize: sw * TYPE.body }}>Copiar de outro projeto</Text>
        </Pressable>
        <Pressable accessibilityRole="button" onPress={() => setList(DEFAULT_STATUSES)}>
          <Text style={{ color: colors.subtle, fontFamily: fonts.bold, fontSize: sw * TYPE.body }}>Padrão</Text>
        </Pressable>
      </View>
      <DialogActions onCancel={onCancel} confirmLabel="Salvar" confirmDisabled={!valid} onConfirm={() => onSave(list.map((s) => ({ ...s, label: s.label.trim() })))} />
    </DialogShell>
  );
}
