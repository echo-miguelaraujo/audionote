/**
 * Layout livre da nota (estilo diagramação): caixas de texto, imagens e formas posicionadas na página.
 * Convive com a nota corrida: o texto em HTML (`html`) continua guardado na nota; `free` é uma segunda
 * visualização, escolhida por `layout: 'free'`. Dá para voltar para a nota corrida a qualquer momento.
 *
 * Unidades: a página tem 1000 u de largura (qualquer tela); x, y, w, h e tamanho da fonte (fs) são em u.
 * Assim o desenho fica igual em telas de tamanhos diferentes, como numa página de InDesign.
 */
import { colors } from './theme';

const escapeHtml = (s: string): string =>
  s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

export const PAGE_W = 1000;

export type FrameKind = 'text' | 'image' | 'shape' | 'link';

/** Link dentro do texto de uma caixa: trecho [s, e) de `txt` apontando para `url`. */
export type TextLink = { s: number; e: number; url: string };

export type Frame = {
  id: string;
  t: FrameKind;
  x: number;
  y: number;
  w: number;
  h: number;
  /** Papel na página: título, corpo, legenda, número grande. Ajuda os modelos a reencaixar o conteúdo. */
  role?: 'h' | 'b' | 'c' | 'n';
  // ----- texto -----
  txt?: string;
  /** Links no meio do texto (offsets sobre `txt`, ordenados e sem sobreposição). */
  lks?: TextLink[];
  fs?: number;
  fw?: number;
  it?: boolean;
  col?: string;
  /** Alinhamento: esquerda, centro, direita, justificado. */
  al?: 'l' | 'c' | 'r' | 'j';
  /** Entrelinha (multiplicador). */
  lh?: number;
  /** Espaço entre letras, em em. */
  ls?: number;
  up?: boolean;
  /** Família: sans, serifada, mono. */
  ff?: 's' | 'f' | 'm';
  /** Fonte de "Minhas fontes" (Google Fonts baixadas): vale no lugar de `ff` quando existe. */
  fam?: string;
  /** Respiro interno da caixa de texto, em u (a caixa continua do mesmo tamanho). */
  pad?: number;
  /** Comportamento da caixa: altura automática, altura fixa (corta o que passar) ou encolher a fonte para caber. */
  beh?: 'auto' | 'fixed' | 'fit';
  /** Tamanho máximo da fonte quando a caixa ajusta a fonte para caber. */
  fm?: number;
  // ----- imagem -----
  src?: string;
  /** Preencher a caixa (corta) ou caber inteira. */
  fit?: 'cover' | 'contain';
  /** Ponto de foco do recorte, 0–100. */
  px?: number;
  py?: number;
  // ----- imagem / forma -----
  fill?: string;
  /** Raio dos cantos em u (500 = círculo/pílula). */
  rad?: number;
  lock?: boolean;
  /** Grupo: caixas com o mesmo gid se movem e redimensionam juntas. */
  gid?: string;
  // ----- link (card com prévia; a capa fica em `src`, o fundo do card em `fill`) -----
  url?: string;
  /** Título, descrição e site da prévia. */
  lt?: string;
  ld?: string;
  lsite?: string;
  /** Proporção (largura / altura) da capa. */
  ar?: number;
  /** Estado da prévia. */
  lst?: 'loading' | 'ok' | 'fail';
};

/** `m`: margem da página em u (guias e "Com margem"); `grid`: mostrar a grade de apoio ao editar. */
/** `sync`: foto das duas versões na última sincronização (ver layoutSync.ts). */
export type FreeSync = { fl: string[]; fi: string[]; rl: string[]; ri: string[]; t: string; fk?: string[]; rk?: string[] };
/** `pr`: formato das páginas (chave de PAGE_SIZES); sem `pr` a nota é uma página contínua. `np`: quantas páginas. */
export type Free = { v: 1; bg: string; h: number; frames: Frame[]; m?: number; grid?: boolean; sync?: FreeSync; pr?: string; np?: number };

/** Formatos de página. A largura é sempre 1000 u; `h` é a altura em u. */
export type PageSize = { key: string; name: string; h: number };
export const PAGE_SIZES: PageSize[] = [
  { key: 'p45', name: '4:5 retrato', h: 1250 },
  { key: 'a4', name: 'A4 retrato', h: 1414 },
  { key: 'p34', name: '3:4 retrato', h: 1333 },
  { key: 'sq', name: 'Quadrada 1:1', h: 1000 },
  { key: 'p916', name: '9:16 (story)', h: 1778 },
  { key: 'w43', name: '4:3 paisagem', h: 750 },
  { key: 'w169', name: '16:9 paisagem', h: 562.5 },
];
export const DEFAULT_PAGE = 'p45';
export const pageSize = (key?: string): PageSize | undefined => (key ? PAGE_SIZES.find((x) => x.key === key) : undefined);
const bottomOf = (free: Free) => Math.max(0, ...free.frames.map((f) => f.y + f.h));
/** Quantas páginas a nota tem (0 se for contínua). */
export function freePageCount(free: Free): number {
  const ph = pageSize(free.pr)?.h;
  if (!ph) return 0;
  return Math.max(free.np || 1, Math.ceil(bottomOf(free) / ph - 0.001));
}
/** Posição y que não deixa uma caixa de altura `h` cruzar a divisa entre páginas (se ela cabe numa página). */
export function fitY(free: Free, y: number, h: number): number {
  const ph = pageSize(free.pr)?.h;
  if (!ph || h > ph) return y;
  const i = Math.floor(y / ph);
  return y + h > (i + 1) * ph + 0.5 ? (i + 1) * ph + Math.min(60, (ph - h) / 2) : y;
}


/** Só endereços que o app sabe abrir (evita `javascript:` e parecidos). */
export const safeUrl = (u: unknown): string => (typeof u === 'string' && /^(https?:|mailto:|tel:)/i.test(u.trim()) ? u.trim().slice(0, 1000) : '');

/** Valida, ordena e remove sobreposições dos links de um texto. */
export function cleanLks(txt: string, raw: unknown): TextLink[] {
  if (!Array.isArray(raw)) return [];
  const out: TextLink[] = [];
  for (const l of raw) {
    if (!l || typeof l !== 'object') continue;
    const url = safeUrl((l as any).url);
    const s = Math.max(0, Math.round(num((l as any).s, -1)));
    const e = Math.min(txt.length, Math.round(num((l as any).e, -1)));
    if (url && s < e && txt.slice(s, e).trim()) out.push({ s, e, url });
  }
  out.sort((a, b) => a.s - b.s);
  const res: TextLink[] = [];
  for (const l of out) if (!res.length || l.s >= res[res.length - 1].e) res.push(l);
  return res;
}

/**
 * Reposiciona os links depois que o texto mudou de `a` para `b`: o que está antes da região editada
 * fica, o que está depois desloca, e o que foi apagado ou reescrito por dentro encolhe ou some.
 */
export function adjustLks(lks: TextLink[] | undefined, a: string, b: string): TextLink[] | undefined {
  if (!lks || !lks.length || a === b) return lks;
  const m = Math.min(a.length, b.length);
  let p = 0;
  while (p < m && a.charCodeAt(p) === b.charCodeAt(p)) p++;
  let q = 0;
  while (q < m - p && a.charCodeAt(a.length - 1 - q) === b.charCodeAt(b.length - 1 - q)) q++;
  const aEnd = a.length - q;
  const cEnd = b.length - q;
  const delta = b.length - a.length;
  const out: TextLink[] = [];
  for (const l of lks) {
    const s = l.s >= aEnd ? l.s + delta : l.s <= p ? l.s : cEnd;
    const e = l.e <= p ? l.e : l.e >= aEnd ? l.e + delta : p;
    if (e > s && b.slice(s, e).trim()) out.push({ s, e: Math.min(e, b.length), url: l.url });
  }
  return out;
}

/** Texto dividido em pedaços, cada um com o link que o cobre (se houver). */
export function lkSegments(txt: string, lks?: TextLink[]): { t: string; url?: string }[] {
  const segs: { t: string; url?: string }[] = [];
  let at = 0;
  for (const l of lks ?? []) {
    if (l.s > at) segs.push({ t: txt.slice(at, l.s) });
    segs.push({ t: txt.slice(l.s, l.e), url: l.url });
    at = l.e;
  }
  if (at < txt.length) segs.push({ t: txt.slice(at) });
  return segs;
}

/** Chave de um link para comparar as duas versões da nota: trecho (espaços normalizados) + endereço. */
export const lkKey = (text: string, url: string): string => `${text.replace(/\s+/g, ' ').trim()}\u0001${url}`;
export const frameLkKeys = (f: Frame): string[] => (f.txt ? (f.lks ?? []).map((l) => lkKey(f.txt!.slice(l.s, l.e), l.url)) : []);

export const emptyFree = (): Free => ({ v: 1, bg: '#FFFFFF', h: 1250, frames: [], pr: DEFAULT_PAGE, np: 1 });

const num = (v: unknown, d: number) => (typeof v === 'number' && Number.isFinite(v) ? v : d);

export function parseFree(raw: any): Free | undefined {
  if (!raw || typeof raw !== 'object' || !Array.isArray(raw.frames)) return undefined;
  const frames: Frame[] = [];
  for (const f of raw.frames) {
    if (!f || typeof f !== 'object' || !['text', 'image', 'shape', 'link'].includes(f.t)) continue;
    const fr: Frame = { ...f, id: String(f.id ?? ''), x: num(f.x, 0), y: num(f.y, 0), w: num(f.w, 100), h: num(f.h, 100) };
    if (f.t === 'text' && typeof f.txt === 'string') {
      const lks = cleanLks(f.txt, f.lks);
      if (lks.length) fr.lks = lks;
      else delete fr.lks;
    } else delete fr.lks;
    frames.push(fr);
  }
  const out: Free = { v: 1, bg: typeof raw.bg === 'string' ? raw.bg : '#FFFFFF', h: num(raw.h, 1500), frames };
  if (typeof raw.m === 'number' && Number.isFinite(raw.m)) out.m = Math.min(200, Math.max(0, raw.m));
  if (raw.grid === true) out.grid = true;
  if (typeof raw.pr === 'string' && pageSize(raw.pr)) {
    out.pr = raw.pr;
    if (typeof raw.np === 'number' && Number.isFinite(raw.np)) out.np = Math.min(200, Math.max(1, Math.round(raw.np)));
  }
  const sy = raw.sync;
  const arr = (v: unknown): string[] => (Array.isArray(v) ? v.map(String) : []);
  if (sy && typeof sy === 'object') out.sync = { fl: arr(sy.fl), fi: arr(sy.fi), rl: arr(sy.rl), ri: arr(sy.ri), t: typeof sy.t === 'string' ? sy.t : '', ...(Array.isArray(sy.fk) ? { fk: arr(sy.fk) } : {}), ...(Array.isArray(sy.rk) ? { rk: arr(sy.rk) } : {}) };
  return out;
}

const byReading = (a: Frame, b: Frame) => a.y - b.y || a.x - b.x;

/** Texto da página (para busca e prévia), na ordem de leitura. */
export function freeText(free: Free | undefined): string {
  if (!free) return '';
  return free.frames
    .filter((f) => f.t === 'text' && (f.txt ?? '').trim())
    .sort(byReading)
    .map((f) => (f.txt ?? '').trim())
    .join('\n');
}

export const freeHasContent = (free: Free | undefined): boolean =>
  !!free && free.frames.some((f) => (f.t === 'text' && (f.txt ?? '').trim()) || (f.t === 'image' && f.src) || (f.t === 'link' && f.url));

/** Título da nota no modo livre: a primeira linha do primeiro texto de papel "título" (ou do maior texto). */
export function freeTitle(free: Free | undefined): string {
  if (!free) return '';
  const texts = free.frames.filter((f) => f.t === 'text' && (f.txt ?? '').trim());
  const h = texts.filter((f) => f.role === 'h').sort(byReading)[0] ?? [...texts].sort((a, b) => (b.fs ?? 0) - (a.fs ?? 0))[0];
  return h ? (h.txt ?? '').split('\n')[0].trim().slice(0, 120) : '';
}

const newId = () => `f${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;

/** Acrescenta caixas de texto no fim da página (transcrições que chegam com a nota em layout livre). */
export function appendTextFrames(free: Free, texts: { heading?: string; text: string }[]): Free {
  let y = Math.max(0, ...free.frames.map((f) => f.y + f.h)) + 40;
  const frames = [...free.frames];
  for (const t of texts) {
    const txt = [t.heading?.trim(), t.text.trim()].filter(Boolean).join('\n');
    if (!txt) continue;
    const h = Math.max(120, Math.ceil(txt.length / 38) * 38 + 40);
    y = fitY(free, y, h);
    frames.push({ id: newId(), t: 'text', role: 'b', x: 80, y, w: 840, h, txt, fs: 30, fw: 400, col: '#111111', al: 'l', lh: 1.4, beh: 'auto', ff: 's' });
    y += h + 30;
  }
  return { ...free, frames, h: Math.max(free.h, y + 80) };
}

/** Conteúdo da nota corrida em partes simples (título, texto, imagens) para montar a primeira página livre. */
export type SeedLink = { url: string; title: string; desc: string; site: string; img: string; state: string };

export function seedFromFlow(title: string, text: string, html: string): { title: string; text: string; images: string[]; links: SeedLink[]; tlinks: { text: string; url: string }[] } {
  const un = (v: string) => v.replace(/&quot;/g, '"').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
  const cardRe = /<a\b[^>]*class="[^"]*\blkcard\b[^"]*"[^>]*>[\s\S]*?<\/a>/gi;
  const span = (c: string, cls: string) => {
    const m = new RegExp(`<span class="${cls}">([\\s\\S]*?)</span>`, 'i').exec(c);
    return m ? un(m[1].replace(/<[^>]+>/g, '')) : '';
  };
  const links: SeedLink[] = [...html.matchAll(cardRe)].map((m) => {
    const href = /\bhref="([^"]*)"/i.exec(m[0]);
    const st = /\bdata-state="([^"]*)"/i.exec(m[0]);
    const img = /<img\b[^>]*\bsrc="([^"]+)"/i.exec(m[0]);
    return { url: href ? un(href[1]) : '', title: span(m[0], 'lk-t'), desc: span(m[0], 'lk-d'), site: span(m[0], 'lk-s'), img: img ? un(img[1]) : '', state: st ? st[1] : 'loading' };
  }).filter((l) => l.url);
  // a capa de um card não é uma imagem da nota
  const images = [...html.replace(cardRe, '').matchAll(/<img\b[^>]*\bsrc="([^"]+)"/gi)].map((m) => m[1]);
  // links no meio do texto (fora dos cards): trecho + endereço, na ordem em que aparecem
  const tlinks: { text: string; url: string }[] = [];
  for (const m of html.replace(cardRe, '').matchAll(/<a\b([^>]*)>([\s\S]*?)<\/a>/gi)) {
    const href = /\bhref="([^"]*)"/i.exec(m[1]);
    const url = href ? safeUrl(un(href[1])) : '';
    const t = un(m[2].replace(/<[^>]+>/g, '')).replace(/\s+/g, ' ').trim();
    if (url && t) tlinks.push({ text: t, url });
  }
  return { title, text, images, links, tlinks };
}

const lum = (hex: string): number => {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex || '');
  if (!m) return 1;
  const n = parseInt(m[1], 16);
  return (0.2126 * ((n >> 16) & 255) + 0.7152 * ((n >> 8) & 255) + 0.0722 * (n & 255)) / 255;
};
/** Fundo padrão de um card de link: claro em página clara, escuro em página escura. */
export const linkFill = (f: Frame, pageBg: string): string => f.fill || (lum(pageBg) < 0.45 ? '#2A2A2C' : '#F2F2F2');

/** Cor dos links no texto (a cor de destaque do app). */
export const LINK_INK = colors.red;

const SAFE_FAMILY = /^[A-Za-z0-9][A-Za-z0-9 ]{0,59}$/;
const FONT: Record<string, string> = {
  s: 'Roboto,Arial,sans-serif',
  f: 'Georgia,"Times New Roman",serif',
  m: '"Courier New",monospace',
};

/** HTML das caixas que aparecem na faixa [top, top + range) da página, com y relativo a `top`. `k` = pixels por u. */
function framesHtml(free: Free, toUri: (ref: string) => string, k: number, top: number, range: number): string {
  const px = (v: number) => `${(v * k).toFixed(2)}px`;
  return free.frames
    .map((f, i) => ({ f, i }))
    .filter(({ f }) => f.y < top + range && f.y + f.h > top)
    .map(({ f, i }) => {
      const box = `position:absolute;box-sizing:border-box;left:${px(f.x)};top:${px(f.y - top)};width:${px(f.w)};height:${px(f.h)};z-index:${i};`;
      if (f.t === 'shape') {
        return `<div style="${box}background:${escapeHtml(f.fill ?? '#000')};border-radius:${px(f.rad ?? 0)}"></div>`;
      }
      if (f.t === 'image') {
        if (!f.src) return '';
        const uri = toUri(f.src);
        return (
          `<div style="${box}overflow:hidden;border-radius:${px(f.rad ?? 0)};background:${escapeHtml(f.fill ?? 'transparent')}">` +
          `<img src="${escapeHtml(uri)}" style="width:100%;height:100%;margin:0;border-radius:0;object-fit:${f.fit ?? 'cover'};object-position:${f.px ?? 50}% ${f.py ?? 50}%"></div>`
        );
      }
      if (f.t === 'link') {
        if (!f.url) return '';
        const fill = linkFill(f, free.bg);
        const dark = lum(fill) < 0.45;
        const ink = dark ? '#FFFFFF' : '#111111';
        const sub = dark ? '#B5B5BA' : '#6B6B70';
        const sq = !!f.src && (f.ar ?? 0) > 0.85 && (f.ar ?? 0) < 1.2;
        const ar = Math.min(2.4, Math.max(1, f.ar || 1.91));
        const img = f.src
          ? `<img src="${escapeHtml(toUri(f.src))}" style="display:block;margin:0;border-radius:0;object-fit:cover;${sq ? `width:${px(f.h)};height:${px(f.h)};flex:none` : `width:100%;height:${px(f.w / ar)}`}">`
          : '';
        const clamp = (n: number) => `display:-webkit-box;-webkit-line-clamp:${n};-webkit-box-orient:vertical;overflow:hidden;`;
        return (
          `<div style="${box}overflow:hidden;border-radius:${px(f.rad ?? 24)};background:${escapeHtml(fill)};color:${ink};display:flex;flex-direction:${sq ? 'row' : 'column'};font-family:${FONT.s}">` +
          img +
          `<div style="padding:${px(24)} ${px(28)};min-width:0;flex:1">` +
          `<div style="${clamp(2)}font-size:${px(38)};font-weight:700;line-height:1.25">${escapeHtml(f.lt || f.lsite || f.url)}</div>` +
          (f.ld ? `<div style="${clamp(2)}font-size:${px(30)};line-height:1.3;color:${sub};margin-top:${px(8)}">${escapeHtml(f.ld)}</div>` : '') +
          `<div style="font-size:${px(26)};color:${sub};margin-top:${px(10)};white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escapeHtml(f.lsite || f.url)}</div>` +
          `</div></div>`
        );
      }
      const st =
        `font-size:${px(f.fs ?? 32)};font-weight:${f.fw ?? 400};font-style:${f.it ? 'italic' : 'normal'};` +
        `color:${escapeHtml(f.col ?? '#111')};text-align:${{ l: 'left', c: 'center', r: 'right', j: 'justify' }[f.al ?? 'l']};` +
        `line-height:${f.lh ?? 1.3};letter-spacing:${f.ls ?? 0}em;text-transform:${f.up ? 'uppercase' : 'none'};` +
        `font-family:${f.fam && SAFE_FAMILY.test(f.fam) ? `'${f.fam}',${FONT[f.ff ?? 's']}` : FONT[f.ff ?? 's']};` +
        `padding:${px(f.pad ?? 0)};white-space:pre-wrap;overflow:hidden;`;
      const inner = lkSegments(f.txt ?? '', f.lks)
        .map((g) => (g.url ? `<a href="${escapeHtml(g.url)}" style="color:${LINK_INK};text-decoration:underline">${escapeHtml(g.t)}</a>` : escapeHtml(g.t)))
        .join('');
      return `<div style="${box}${st}">${inner}</div>`;
    })
    .join('');
}

/** Uma página de saída: faixa da nota (largura 1000 u, altura `srcH`) encaixada, sem cortar, numa página de altura `outH`. */
function pageBox(free: Free, toUri: (ref: string) => string, k: number, top: number, srcH: number, outH: number): string {
  const px = (v: number) => `${(v * k).toFixed(2)}px`;
  const sc = Math.min(1, outH / srcH);
  const dx = (PAGE_W - PAGE_W * sc) / 2;
  const dy = (outH - srcH * sc) / 2;
  return (
    `<div style="position:relative;width:${px(PAGE_W)};height:${px(outH)};background:${escapeHtml(free.bg)};overflow:hidden;page-break-after:always;break-after:page">` +
    `<div style="position:absolute;left:${px(dx)};top:${px(dy)};width:${px(PAGE_W * sc)};height:${px(srcH * sc)};overflow:hidden">` +
    framesHtml(free, toUri, k * sc, top, srcH) +
    `</div></div>`
  );
}

/** Páginas de saída para um tamanho escolhido (`targetH`, em u): notas com páginas mantêm as suas; a contínua é fatiada. */
export function freeExportCount(free: Free, targetH: number): number {
  const n = freePageCount(free);
  if (n) return n;
  return Math.max(1, Math.ceil(Math.max(free.h, bottomOf(free)) / targetH - 0.001));
}
export function freeExportPageHtml(free: Free, toUri: (ref: string) => string, k: number, i: number, targetH: number): string {
  const ph = pageSize(free.pr)?.h;
  return pageBox(free, toUri, k, i * (ph ?? targetH), ph ?? targetH, targetH);
}

/** Página em HTML posicionado (para o PDF em documento). `k` = pixels por u. */
export function freeToHtml(free: Free, toUri: (ref: string) => string, k = 0.6): string {
  const ph = pageSize(free.pr)?.h;
  if (ph) return Array.from({ length: freePageCount(free) }, (_, i) => pageBox(free, toUri, k, i * ph, ph, ph)).join('');
  const px = (v: number) => `${(v * k).toFixed(2)}px`;
  const h = Math.max(free.h, ...free.frames.map((f) => f.y + f.h));
  return `<div style="position:relative;width:${px(PAGE_W)};height:${px(h)};background:${escapeHtml(free.bg)};overflow:hidden">${framesHtml(free, toUri, k, 0, 1e9)}</div>`;
}
