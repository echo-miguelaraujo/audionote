/**
 * Layout livre da nota (estilo diagramação): caixas de texto, imagens e formas posicionadas na página.
 * Convive com a nota corrida: o texto em HTML (`html`) continua guardado na nota; `free` é uma segunda
 * visualização, escolhida por `layout: 'free'`. Dá para voltar para a nota corrida a qualquer momento.
 *
 * Unidades: a página tem 1000 u de largura (qualquer tela); x, y, w, h e tamanho da fonte (fs) são em u.
 * Assim o desenho fica igual em telas de tamanhos diferentes, como numa página de InDesign.
 */
const escapeHtml = (s: string): string =>
  s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

export const PAGE_W = 1000;

export type FrameKind = 'text' | 'image' | 'shape';

export type Frame = {
  id: string;
  t: FrameKind;
  x: number;
  y: number;
  w: number;
  h: number;
  /** Papel na página: título, corpo, legenda, número grande. Ajuda os modelos a reencaixar o conteúdo. */
  role?: 'h' | 'b' | 'c' | 'n';
  // ----- texto -----
  txt?: string;
  fs?: number;
  fw?: number;
  it?: boolean;
  col?: string;
  /** Alinhamento: esquerda, centro, direita, justificado. */
  al?: 'l' | 'c' | 'r' | 'j';
  /** Entrelinha (multiplicador). */
  lh?: number;
  /** Espaço entre letras, em em. */
  ls?: number;
  up?: boolean;
  /** Família: sans, serifada, mono. */
  ff?: 's' | 'f' | 'm';
  /** Fonte de "Minhas fontes" (Google Fonts baixadas): vale no lugar de `ff` quando existe. */
  fam?: string;
  /** Respiro interno da caixa de texto, em u (a caixa continua do mesmo tamanho). */
  pad?: number;
  /** Comportamento da caixa: altura automática, altura fixa (corta o que passar) ou encolher a fonte para caber. */
  beh?: 'auto' | 'fixed' | 'fit';
  /** Tamanho máximo da fonte quando a caixa ajusta a fonte para caber. */
  fm?: number;
  // ----- imagem -----
  src?: string;
  /** Preencher a caixa (corta) ou caber inteira. */
  fit?: 'cover' | 'contain';
  /** Ponto de foco do recorte, 0–100. */
  px?: number;
  py?: number;
  // ----- imagem / forma -----
  fill?: string;
  /** Raio dos cantos em u (500 = círculo/pílula). */
  rad?: number;
  lock?: boolean;
};

/** `m`: margem da página em u (guias e "Com margem"); `grid`: mostrar a grade de apoio ao editar. */
/** `sync`: foto das duas versões na última sincronização (ver layoutSync.ts). */
export type FreeSync = { fl: string[]; fi: string[]; rl: string[]; ri: string[]; t: string };
export type Free = { v: 1; bg: string; h: number; frames: Frame[]; m?: number; grid?: boolean; sync?: FreeSync };

export const emptyFree = (): Free => ({ v: 1, bg: '#FFFFFF', h: 1500, frames: [] });

const num = (v: unknown, d: number) => (typeof v === 'number' && Number.isFinite(v) ? v : d);

export function parseFree(raw: any): Free | undefined {
  if (!raw || typeof raw !== 'object' || !Array.isArray(raw.frames)) return undefined;
  const frames: Frame[] = [];
  for (const f of raw.frames) {
    if (!f || typeof f !== 'object' || !['text', 'image', 'shape'].includes(f.t)) continue;
    frames.push({ ...f, id: String(f.id ?? ''), x: num(f.x, 0), y: num(f.y, 0), w: num(f.w, 100), h: num(f.h, 100) });
  }
  const out: Free = { v: 1, bg: typeof raw.bg === 'string' ? raw.bg : '#FFFFFF', h: num(raw.h, 1500), frames };
  if (typeof raw.m === 'number' && Number.isFinite(raw.m)) out.m = Math.min(200, Math.max(0, raw.m));
  if (raw.grid === true) out.grid = true;
  const sy = raw.sync;
  const arr = (v: unknown): string[] => (Array.isArray(v) ? v.map(String) : []);
  if (sy && typeof sy === 'object') out.sync = { fl: arr(sy.fl), fi: arr(sy.fi), rl: arr(sy.rl), ri: arr(sy.ri), t: typeof sy.t === 'string' ? sy.t : '' };
  return out;
}

const byReading = (a: Frame, b: Frame) => a.y - b.y || a.x - b.x;

/** Texto da página (para busca e prévia), na ordem de leitura. */
export function freeText(free: Free | undefined): string {
  if (!free) return '';
  return free.frames
    .filter((f) => f.t === 'text' && (f.txt ?? '').trim())
    .sort(byReading)
    .map((f) => (f.txt ?? '').trim())
    .join('\n');
}

export const freeHasContent = (free: Free | undefined): boolean =>
  !!free && free.frames.some((f) => (f.t === 'text' && (f.txt ?? '').trim()) || (f.t === 'image' && f.src));

/** Título da nota no modo livre: a primeira linha do primeiro texto de papel "título" (ou do maior texto). */
export function freeTitle(free: Free | undefined): string {
  if (!free) return '';
  const texts = free.frames.filter((f) => f.t === 'text' && (f.txt ?? '').trim());
  const h = texts.filter((f) => f.role === 'h').sort(byReading)[0] ?? [...texts].sort((a, b) => (b.fs ?? 0) - (a.fs ?? 0))[0];
  return h ? (h.txt ?? '').split('\n')[0].trim().slice(0, 120) : '';
}

const newId = () => `f${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;

/** Acrescenta caixas de texto no fim da página (transcrições que chegam com a nota em layout livre). */
export function appendTextFrames(free: Free, texts: { heading?: string; text: string }[]): Free {
  let y = Math.max(0, ...free.frames.map((f) => f.y + f.h)) + 40;
  const frames = [...free.frames];
  for (const t of texts) {
    const txt = [t.heading?.trim(), t.text.trim()].filter(Boolean).join('\n');
    if (!txt) continue;
    const h = Math.max(120, Math.ceil(txt.length / 38) * 38 + 40);
    frames.push({ id: newId(), t: 'text', role: 'b', x: 80, y, w: 840, h, txt, fs: 30, fw: 400, col: '#111111', al: 'l', lh: 1.4, beh: 'auto', ff: 's' });
    y += h + 30;
  }
  return { ...free, frames, h: Math.max(free.h, y + 80) };
}

/** Conteúdo da nota corrida em partes simples (título, texto, imagens) para montar a primeira página livre. */
export function seedFromFlow(title: string, text: string, html: string): { title: string; text: string; images: string[] } {
  const images = [...html.matchAll(/<img\b[^>]*\bsrc="([^"]+)"/gi)].map((m) => m[1]);
  return { title, text, images };
}

const SAFE_FAMILY = /^[A-Za-z0-9][A-Za-z0-9 ]{0,59}$/;
const FONT: Record<string, string> = {
  s: 'Roboto,Arial,sans-serif',
  f: 'Georgia,"Times New Roman",serif',
  m: '"Courier New",monospace',
};

/** Página em HTML posicionado (para o PDF). `k` = pixels por u. */
export function freeToHtml(free: Free, toUri: (ref: string) => string, k = 0.6): string {
  const px = (v: number) => `${(v * k).toFixed(2)}px`;
  const body = [...free.frames]
    .map((f, i) => ({ f, i }))
    .map(({ f, i }) => {
      const box = `position:absolute;box-sizing:border-box;left:${px(f.x)};top:${px(f.y)};width:${px(f.w)};height:${px(f.h)};z-index:${i};`;
      if (f.t === 'shape') {
        return `<div style="${box}background:${escapeHtml(f.fill ?? '#000')};border-radius:${px(f.rad ?? 0)}"></div>`;
      }
      if (f.t === 'image') {
        if (!f.src) return '';
        const uri = toUri(f.src);
        return (
          `<div style="${box}overflow:hidden;border-radius:${px(f.rad ?? 0)};background:${escapeHtml(f.fill ?? 'transparent')}">` +
          `<img src="${escapeHtml(uri)}" style="width:100%;height:100%;margin:0;border-radius:0;object-fit:${f.fit ?? 'cover'};object-position:${f.px ?? 50}% ${f.py ?? 50}%"></div>`
        );
      }
      const st =
        `font-size:${px(f.fs ?? 32)};font-weight:${f.fw ?? 400};font-style:${f.it ? 'italic' : 'normal'};` +
        `color:${escapeHtml(f.col ?? '#111')};text-align:${{ l: 'left', c: 'center', r: 'right', j: 'justify' }[f.al ?? 'l']};` +
        `line-height:${f.lh ?? 1.3};letter-spacing:${f.ls ?? 0}em;text-transform:${f.up ? 'uppercase' : 'none'};` +
        `font-family:${f.fam && SAFE_FAMILY.test(f.fam) ? `'${f.fam}',${FONT[f.ff ?? 's']}` : FONT[f.ff ?? 's']};` +
        `padding:${px(f.pad ?? 0)};white-space:pre-wrap;overflow:hidden;`;
      return `<div style="${box}${st}">${escapeHtml(f.txt ?? '')}</div>`;
    })
    .join('');
  const h = Math.max(free.h, ...free.frames.map((f) => f.y + f.h));
  return `<div style="position:relative;width:${px(PAGE_W)};height:${px(h)};background:${escapeHtml(free.bg)};overflow:hidden">${body}</div>`;
}
