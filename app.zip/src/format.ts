const two = (n: number) => String(n).padStart(2, '0');

/** HH:MM:SS */
export function formatTimer(ms: number): string {
  const total = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  return `${two(h)}:${two(m)}:${two(s)}`;
}

/** MM:SS:mmm (minutos, segundos e milésimos) */
export function formatTimerMs(ms: number): string {
  const t = Math.max(0, Math.floor(ms));
  const m = Math.floor(t / 60000);
  const s = Math.floor((t % 60000) / 1000);
  return `${two(m)}:${two(s)}:${String(t % 1000).padStart(3, '0')}`;
}

/** M:SS ou H:MM:SS, para durações curtas */
export function formatDuration(ms: number): string {
  const total = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  return h > 0 ? `${h}:${two(m)}:${two(s)}` : `${m}:${two(s)}`;
}

/** dd/mm/aaaa */
export function formatDate(ms: number): string {
  const d = new Date(ms);
  return `${two(d.getDate())}/${two(d.getMonth() + 1)}/${d.getFullYear()}`;
}

export function formatDateTime(ms: number): string {
  const d = new Date(ms);
  return `${formatDate(ms)} ${two(d.getHours())}:${two(d.getMinutes())}`;
}
