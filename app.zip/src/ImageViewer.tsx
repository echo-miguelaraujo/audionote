import React, { useMemo, useRef } from 'react';
import { Animated, Image, Modal, PanResponder, StatusBar, View, useWindowDimensions } from 'react-native';
import { mediaUri } from './media';

type Touch = { pageX: number; pageY: number };
const dist = (t: Touch[]) => Math.hypot(t[0].pageX - t[1].pageX, t[0].pageY - t[1].pageY);

/**
 * Imagem inteira em tela cheia, fundo preto. Pinça para aproximar (até 5×); com zoom, um dedo arrasta;
 * sem zoom, arrastar para baixo ou tocar fecha.
 */
export function ImageViewer({ uri, onClose }: { uri: string; onClose: () => void }) {
  const { width: sw, height: sh } = useWindowDimensions();
  const s = useRef(new Animated.Value(1)).current;
  const x = useRef(new Animated.Value(0)).current;
  const y = useRef(new Animated.Value(0)).current;
  const cur = useRef({ s: 1, x: 0, y: 0 });
  const g = useRef({ d: 0, s: 1, x: 0, y: 0, moved: false, pinch: false });

  const pan = useMemo(
    () =>
      PanResponder.create({
        onStartShouldSetPanResponder: () => true,
        onMoveShouldSetPanResponder: () => true,
        onPanResponderGrant: (e) => {
          const t = e.nativeEvent.touches as Touch[];
          g.current = { d: t.length > 1 ? dist(t) : 0, s: cur.current.s, x: cur.current.x, y: cur.current.y, moved: false, pinch: t.length > 1 };
        },
        onPanResponderMove: (e, st) => {
          const t = e.nativeEvent.touches as Touch[];
          const c = g.current;
          if (t.length > 1) {
            if (!c.pinch) {
              c.pinch = true;
              c.d = dist(t);
              c.s = cur.current.s;
            }
            c.moved = true;
            cur.current.s = Math.max(1, Math.min(5, (c.s * dist(t)) / c.d));
            s.setValue(cur.current.s);
            return;
          }
          if (c.pinch) return;
          if (Math.abs(st.dx) + Math.abs(st.dy) > 6) c.moved = true;
          if (cur.current.s > 1) {
            const lim = (sw * (cur.current.s - 1)) / 2;
            const limY = (sh * (cur.current.s - 1)) / 2;
            cur.current.x = Math.max(-lim, Math.min(lim, c.x + st.dx));
            cur.current.y = Math.max(-limY, Math.min(limY, c.y + st.dy));
            x.setValue(cur.current.x);
            y.setValue(cur.current.y);
          } else {
            cur.current.y = Math.max(0, st.dy);
            y.setValue(cur.current.y);
          }
        },
        onPanResponderRelease: (_, st) => {
          const c = g.current;
          if (cur.current.s <= 1.02) {
            if (!c.moved || st.dy > 120) return onClose();
            cur.current = { s: 1, x: 0, y: 0 };
            Animated.parallel([
              Animated.spring(s, { toValue: 1, useNativeDriver: true }),
              Animated.spring(x, { toValue: 0, useNativeDriver: true }),
              Animated.spring(y, { toValue: 0, useNativeDriver: true }),
            ]).start();
          }
        },
      }),
    [onClose, s, sh, sw, x, y]
  );

  return (
    <Modal visible transparent animationType="fade" onRequestClose={onClose} statusBarTranslucent>
      <StatusBar hidden />
      <View style={{ flex: 1, backgroundColor: '#000' }} {...pan.panHandlers}>
        <Animated.View style={{ width: sw, height: sh, transform: [{ translateX: x }, { translateY: y }, { scale: s }] }}>
          <Image source={{ uri: mediaUri(uri) }} resizeMode="contain" style={{ width: sw, height: sh }} />
        </Animated.View>
      </View>
    </Modal>
  );
}
