import React from 'react';
import { ScrollView, Pressable, Text, View, useWindowDimensions } from 'react-native';
import { SheetShell } from './DialogBase';
import { Icon, IconName } from './Icon';
import { colors, fonts, SPACE, TYPE } from './theme';

/**
 * Ícone padrão de cada ação, pela chave. Assim todo menu do app ganha ícone sem cada tela precisar
 * escolher um; `icon` no item sobrepõe, e ação em vermelho (`danger`) cai na lixeira.
 */
const ACTION_ICONS: Record<string, IconName> = {
  fav: 'star', find: 'search', outline: 'list', free: 'canvas', flow: 'align', present: 'present', statuses: 'todo', linkMode: 'link', multi: 'select', pdfShoot: 'pdf', link: 'link', unlink: 'link',
  share: 'share', mexport: 'export', download: 'download', gallery: 'images', pdf: 'pdf', pdfA4: 'pdf', pdf169: 'pdf',
  pdfFree: 'pdf', png: 'image', img169: 'image', imgFree: 'image', h169: 'image', v916: 'image', photo: 'image',
  video: 'video', 'web-video': 'video', 'web-photo': 'globe', 'web-browse': 'globe', pinterest: 'pin', link: 'link',
  editLink: 'link', backlinks: 'link', edit: 'pencil', name: 'type', desc: 'align', caption: 'chat', dialogue: 'chatText',
  emotion: 'smiley', shot: 'film', tags: 'tag', color: 'palette', palette: 'palette', mpal: 'palette', lock: 'lock',
  copyTo: 'copy', moveTo: 'folder', collection: 'folder', refresh: 'refresh', preview: 'eye', tasks: 'todo',
  suggest: 'sparkle', fromText: 'sparkle', tpl: 'bookmark', date: 'calendar', duration: 'timer', place: 'mapPin',
  note: 'note', text: 'type', hook: 'arrowR', transition: 'arrowR', grid: 'canvas', all: 'select', selected: 'select',
  screen: 'device', front: 'layers', thumb: 'image', poster: 'image', asis: 'text', clear: 'close', dropThumb: 'trash',
  delete: 'trash', del: 'trash', remove: 'trash',
};

export type ActionItem = {
  key: string;
  label: string;
  icon?: IconName;
  /** `danger` pinta de vermelho (remover, excluir). */
  tone?: 'default' | 'danger';
  /** Linha desativada: aparece apagada e não responde ao toque. */
  disabled?: boolean;
  /** Título de seção: aparece acima da linha quando muda em relação à linha anterior. */
  group?: string;
  onPress: () => void;
};

type Props = {
  visible: boolean;
  onClose: () => void;
  /** Linha pequena no topo (ex.: o nome do item). Opcional. */
  title?: string;
  items: ActionItem[];
};

/**
 * Menu de ações que sobe de baixo. Use no lugar de botões soltos: o que é raro vai aqui,
 * o que é frequente fica na tela. Fecha sozinho ao tocar numa linha, depois chama `onPress`.
 */
export function ActionMenu({ visible, onClose, title, items }: Props) {
  const { width: sw, height: sh } = useWindowDimensions();
  const rowH = sw * 0.13;
  const iconOf = (it: ActionItem): IconName | undefined => it.icon ?? ACTION_ICONS[it.key] ?? (it.tone === 'danger' ? 'trash' : undefined);
  const hasIcons = items.some((it) => !!iconOf(it));

  return (
    <SheetShell visible={visible} onClose={onClose} maxHeight={sh * 0.7}>
      {title ? (
        <Text
          numberOfLines={1}
          style={{
            color: colors.subtle,
            fontFamily: fonts.regular,
            fontSize: sw * TYPE.caption,
            paddingTop: sw * SPACE.lg,
            paddingHorizontal: sw * SPACE.xl,
          }}
        >
          {title}
        </Text>
      ) : null}
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingVertical: sw * SPACE.sm, paddingHorizontal: sw * SPACE.xl }}
      >
        {items.map((it, i) => {
          const fg = it.tone === 'danger' ? colors.red : colors.onLight;
          const ic = iconOf(it);
          const showGroup = !!it.group && it.group !== items[i - 1]?.group;
          return (
            <React.Fragment key={it.key}>
            {showGroup ? (
              <Text style={{ color: colors.subtle, fontFamily: fonts.regular, fontSize: sw * TYPE.caption, paddingTop: i === 0 ? sw * SPACE.sm : sw * SPACE.lg, paddingBottom: sw * SPACE.sm }}>
                {it.group}
              </Text>
            ) : null}
            <Pressable
              disabled={it.disabled}
              accessibilityRole="button"
              onPress={() => {
                onClose();
                it.onPress();
              }}
              style={{
                height: rowH,
                flexDirection: 'row',
                alignItems: 'center',
                gap: sw * SPACE.md,
                opacity: it.disabled ? 0.35 : 1,
                borderTopWidth: i === 0 || showGroup ? 0 : 1,
                borderTopColor: colors.hairline,
              }}
            >
              {hasIcons ? (
                <View style={{ width: sw * 0.06, height: sw * 0.06 }}>
                  {ic ? <Icon name={ic} size={sw * 0.06} color={fg} /> : null}
                </View>
              ) : null}
              <Text numberOfLines={1} style={{ flex: 1, color: fg, fontFamily: fonts.bold, fontSize: sw * TYPE.body }}>
                {it.label}
              </Text>
            </Pressable>
            </React.Fragment>
          );
        })}
      </ScrollView>
    </SheetShell>
  );
}
