import React from 'react';
import { ScrollView, Pressable, Text, View, useWindowDimensions } from 'react-native';
import { SheetShell } from './DialogBase';
import { Icon, IconName } from './Icon';
import { colors, fonts, SPACE, TYPE } from './theme';

export type ActionItem = {
  key: string;
  label: string;
  icon?: IconName;
  /** `danger` pinta de vermelho (remover, excluir). */
  tone?: 'default' | 'danger';
  /** Linha desativada: aparece apagada e não responde ao toque. */
  disabled?: boolean;
  /** Título de seção: aparece acima da linha quando muda em relação à linha anterior. */
  group?: string;
  onPress: () => void;
};

type Props = {
  visible: boolean;
  onClose: () => void;
  /** Linha pequena no topo (ex.: o nome do item). Opcional. */
  title?: string;
  items: ActionItem[];
};

/**
 * Menu de ações que sobe de baixo. Use no lugar de botões soltos: o que é raro vai aqui,
 * o que é frequente fica na tela. Fecha sozinho ao tocar numa linha, depois chama `onPress`.
 */
export function ActionMenu({ visible, onClose, title, items }: Props) {
  const { width: sw, height: sh } = useWindowDimensions();
  const rowH = sw * 0.13;

  return (
    <SheetShell visible={visible} onClose={onClose} maxHeight={sh * 0.7}>
      {title ? (
        <Text
          numberOfLines={1}
          style={{
            color: colors.subtle,
            fontFamily: fonts.regular,
            fontSize: sw * TYPE.caption,
            paddingTop: sw * SPACE.lg,
            paddingHorizontal: sw * SPACE.xl,
          }}
        >
          {title}
        </Text>
      ) : null}
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingVertical: sw * SPACE.sm, paddingHorizontal: sw * SPACE.xl }}
      >
        {items.map((it, i) => {
          const fg = it.tone === 'danger' ? colors.red : colors.onLight;
          const showGroup = !!it.group && it.group !== items[i - 1]?.group;
          return (
            <React.Fragment key={it.key}>
            {showGroup ? (
              <Text style={{ color: colors.subtle, fontFamily: fonts.regular, fontSize: sw * TYPE.caption, paddingTop: i === 0 ? sw * SPACE.sm : sw * SPACE.lg, paddingBottom: sw * SPACE.sm }}>
                {it.group}
              </Text>
            ) : null}
            <Pressable
              disabled={it.disabled}
              accessibilityRole="button"
              onPress={() => {
                onClose();
                it.onPress();
              }}
              style={{
                height: rowH,
                flexDirection: 'row',
                alignItems: 'center',
                gap: sw * SPACE.md,
                opacity: it.disabled ? 0.35 : 1,
                borderTopWidth: i === 0 || showGroup ? 0 : 1,
                borderTopColor: colors.hairline,
              }}
            >
              {it.icon ? (
                <View>
                  <Icon name={it.icon} size={sw * 0.06} color={fg} />
                </View>
              ) : null}
              <Text numberOfLines={1} style={{ flex: 1, color: fg, fontFamily: fonts.bold, fontSize: sw * TYPE.body }}>
                {it.label}
              </Text>
            </Pressable>
            </React.Fragment>
          );
        })}
      </ScrollView>
    </SheetShell>
  );
}
