import { getDb } from './db';

export const DEFAULT_MODEL = 'gemini-3.1-flash-lite';

const KEY_API = 'gemini_api_key';
const KEY_MODEL = 'gemini_model';

async function getSetting(key: string): Promise<string | null> {
  const db = await getDb();
  const row = await db.getFirstAsync<{ value: string }>(
    `SELECT value FROM meta WHERE key = ?`,
    key
  );
  return row ? row.value : null;
}

async function setSetting(key: string, value: string): Promise<void> {
  const db = await getDb();
  if (value === '') {
    await db.runAsync(`DELETE FROM meta WHERE key = ?`, key);
  } else {
    await db.runAsync(`INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)`, key, value);
  }
}

export type GeminiSettings = { apiKey: string; model: string };

export async function loadGeminiSettings(): Promise<GeminiSettings> {
  const [apiKey, model] = await Promise.all([getSetting(KEY_API), getSetting(KEY_MODEL)]);
  return { apiKey: apiKey ?? '', model: model ?? DEFAULT_MODEL };
}

export async function saveGeminiSettings(s: GeminiSettings): Promise<void> {
  await setSetting(KEY_API, s.apiKey.trim());
  await setSetting(KEY_MODEL, s.model.trim() || DEFAULT_MODEL);
}

const KEY_DELETE_AFTER = 'delete_audio_after';

export async function getDeleteAfter(): Promise<boolean> {
  return (await getSetting(KEY_DELETE_AFTER)) === '1';
}

export async function setDeleteAfter(v: boolean): Promise<void> {
  await setSetting(KEY_DELETE_AFTER, v ? '1' : '');
}
