import { getDb } from './db';

export const DEFAULT_MODEL = 'gemini-3.1-flash-lite';

const KEY_API = 'gemini_api_key';
const KEY_MODEL = 'gemini_model';

async function getSetting(key: string): Promise<string | null> {
  const db = await getDb();
  const row = await db.getFirstAsync<{ value: string }>(
    `SELECT value FROM meta WHERE key = ?`,
    key
  );
  return row ? row.value : null;
}

async function setSetting(key: string, value: string): Promise<void> {
  const db = await getDb();
  if (value === '') {
    await db.runAsync(`DELETE FROM meta WHERE key = ?`, key);
  } else {
    await db.runAsync(`INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)`, key, value);
  }
}

export type GeminiSettings = { apiKey: string; model: string };

export async function loadGeminiSettings(): Promise<GeminiSettings> {
  const [apiKey, model] = await Promise.all([getSetting(KEY_API), getSetting(KEY_MODEL)]);
  return { apiKey: apiKey ?? '', model: model ?? DEFAULT_MODEL };
}

export async function saveGeminiSettings(s: GeminiSettings): Promise<void> {
  await setSetting(KEY_API, s.apiKey.trim());
  await setSetting(KEY_MODEL, s.model.trim() || DEFAULT_MODEL);
}

const KEY_DELETE_AFTER = 'delete_audio_after';

export async function getDeleteAfter(): Promise<boolean> {
  return (await getSetting(KEY_DELETE_AFTER)) === '1';
}

export async function setDeleteAfter(v: boolean): Promise<void> {
  await setSetting(KEY_DELETE_AFTER, v ? '1' : '');
}

// ---------- Agenda ----------
const KEY_CAL_AUTO = 'calendar_auto';
const KEY_CAL_ID = 'calendar_id';

/** Criar compromissos na agenda automaticamente (ligado por padrão). */
export async function getCalendarAuto(): Promise<boolean> {
  return (await getSetting(KEY_CAL_AUTO)) !== '0';
}

export async function setCalendarAuto(v: boolean): Promise<void> {
  await setSetting(KEY_CAL_AUTO, v ? '' : '0');
}

export async function getCalendarId(): Promise<string | null> {
  return getSetting(KEY_CAL_ID);
}

export async function setCalendarId(id: string): Promise<void> {
  await setSetting(KEY_CAL_ID, id);
}

// ---------- Zoom das notas ----------
const KEY_NOTE_SCALE = 'note_scale';

/** Fator de tamanho geral das notas (1 = padrão), ajustado com o gesto de pinça. */
export async function getNoteScale(): Promise<number> {
  const v = parseFloat((await getSetting(KEY_NOTE_SCALE)) ?? '');
  return Number.isFinite(v) && v >= 0.6 && v <= 2.6 ? v : 1;
}

export async function setNoteScale(v: number): Promise<void> {
  await setSetting(KEY_NOTE_SCALE, String(Math.round(v * 1000) / 1000));
}

// ---------- Fundo (gradientes + vidro) ----------
const KEY_BG = 'bg_theme';

/** Texto JSON com o tema do fundo escolhido (ou null se nunca mudou). */
export async function getBgTheme(): Promise<string | null> {
  return getSetting(KEY_BG);
}

export async function setBgTheme(json: string): Promise<void> {
  await setSetting(KEY_BG, json);
}

// ---------- Biblioteca: ordem e visualização (lembradas) ----------
const KEY_LIB_SORT = 'library_sort';
const KEY_LIB_DIR = 'library_sort_dir';
const KEY_LIB_VIEW = 'library_view';

export type LibrarySort = 'edited' | 'created' | 'name';
export type LibraryView = 'list' | 'grid';

export async function getLibraryOrder(): Promise<{ key: LibrarySort; dir: 'asc' | 'desc' }> {
  const [k, d] = await Promise.all([getSetting(KEY_LIB_SORT), getSetting(KEY_LIB_DIR)]);
  const key: LibrarySort = k === 'edited' || k === 'name' ? k : 'created';
  const dir = d === 'asc' || d === 'desc' ? d : key === 'name' ? 'asc' : 'desc';
  return { key, dir };
}

export async function setLibraryOrder(key: LibrarySort, dir: 'asc' | 'desc'): Promise<void> {
  await setSetting(KEY_LIB_SORT, key);
  await setSetting(KEY_LIB_DIR, dir);
}

export async function getLibraryView(): Promise<LibraryView> {
  return (await getSetting(KEY_LIB_VIEW)) === 'grid' ? 'grid' : 'list';
}

export async function setLibraryView(v: LibraryView): Promise<void> {
  await setSetting(KEY_LIB_VIEW, v);
}

// ---------- Editor de notas: últimas cores personalizadas ----------
const KEY_RECENT_COLORS = 'note_recent_colors';

export async function getRecentColors(): Promise<string[]> {
  try {
    const arr = JSON.parse((await getSetting(KEY_RECENT_COLORS)) ?? '[]');
    return Array.isArray(arr) ? arr.filter((c): c is string => typeof c === 'string' && /^#[0-9A-F]{6}$/.test(c)).slice(0, 3) : [];
  } catch {
    return [];
  }
}

/** Guarda a cor como a mais recente (até 3, sem repetir) e devolve a lista nova. */
export async function pushRecentColor(hex: string): Promise<string[]> {
  const h = hex.toUpperCase();
  const list = [h, ...(await getRecentColors()).filter((c) => c !== h)].slice(0, 3);
  await setSetting(KEY_RECENT_COLORS, JSON.stringify(list));
  return list;
}
