import React, { useMemo } from 'react';
import { StyleSheet, View } from 'react-native';
import { WebView } from 'react-native-webview';

type Props = {
  /** Cor inicial (#RRGGBB). Mudar este valor depois de montado não reposiciona a roda. */
  initial: string;
  size: number;
  onChange: (hex: string) => void;
};

// Roda de cores: ângulo = matiz, distância do centro = saturação, barra embaixo = brilho.
// Desenhada num canvas dentro de um WebView, para não precisar de biblioteca nativa nova.
const buildHtml = (initial: string) => `<!DOCTYPE html><html><head>
<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
<style>
html,body{margin:0;padding:0;background:transparent;overflow:hidden;touch-action:none;-webkit-user-select:none;user-select:none}
#w{display:block;margin:0 auto}
#v{display:block;width:80%;margin:14px auto 0;-webkit-appearance:none;appearance:none;height:26px;border-radius:13px;outline:none}
#v::-webkit-slider-thumb{-webkit-appearance:none;width:30px;height:30px;border-radius:15px;background:#fff;border:3px solid #000}
</style></head><body>
<canvas id="w"></canvas>
<input id="v" type="range" min="0" max="100" value="100">
<script>
var c=document.getElementById('w'),x=c.getContext('2d'),v=document.getElementById('v');
var S=Math.floor(Math.min(window.innerWidth,window.innerHeight-60));
var dpr=window.devicePixelRatio||1;
c.width=S*dpr;c.height=S*dpr;c.style.width=S+'px';c.style.height=S+'px';
var R=S*dpr/2,H=0,Sat=1,V=1;
function hsv2rgb(h,s,v){var f=function(n){var k=(n+h/60)%6;return v-v*s*Math.max(0,Math.min(k,4-k,1))};return[f(5),f(3),f(1)].map(function(a){return Math.round(a*255)})}
function hex(){var r=hsv2rgb(H,Sat,V);return '#'+r.map(function(a){return ('0'+a.toString(16)).slice(-2)}).join('').toUpperCase()}
function rgb2hsv(r,g,b){r/=255;g/=255;b/=255;var m=Math.max(r,g,b),n=Math.min(r,g,b),d=m-n,h=0;
if(d){if(m==r)h=((g-b)/d)%6;else if(m==g)h=(b-r)/d+2;else h=(r-g)/d+4;h*=60;if(h<0)h+=360}
return[h,m?d/m:0,m]}
function drawWheel(){
var img=x.createImageData(c.width,c.height),d=img.data;
for(var j=0;j<c.height;j++)for(var i=0;i<c.width;i++){
var dx=i-R,dy=j-R,r=Math.sqrt(dx*dx+dy*dy),p=(j*c.width+i)*4;
if(r>R-1){d[p+3]=0;continue}
var h=(Math.atan2(dy,dx)*180/Math.PI+360)%360,rgb=hsv2rgb(h,r/R,V);
d[p]=rgb[0];d[p+1]=rgb[1];d[p+2]=rgb[2];d[p+3]=255}
x.putImageData(img,0,0);
var mx=R+Math.cos(H*Math.PI/180)*Sat*R,my=R+Math.sin(H*Math.PI/180)*Sat*R;
x.lineWidth=3*dpr;x.strokeStyle='#fff';x.beginPath();x.arc(mx,my,11*dpr,0,7);x.stroke();
x.strokeStyle='#000';x.lineWidth=1.5*dpr;x.beginPath();x.arc(mx,my,13.5*dpr,0,7);x.stroke();
var full=hsv2rgb(H,Sat,1);v.style.background='linear-gradient(to right,#000,rgb('+full.join(',')+'))'}
var pend=false;
function send(){if(pend)return;pend=true;requestAnimationFrame(function(){pend=false;
window.ReactNativeWebView.postMessage(hex())})}
function pick(e){var t=e.touches?e.touches[0]:e,b=c.getBoundingClientRect(),
dx=(t.clientX-b.left)*dpr-R,dy=(t.clientY-b.top)*dpr-R,r=Math.sqrt(dx*dx+dy*dy);
H=(Math.atan2(dy,dx)*180/Math.PI+360)%360;Sat=Math.min(1,r/R);drawWheel();send()}
var down=false;
c.addEventListener('pointerdown',function(e){down=true;c.setPointerCapture(e.pointerId);pick(e)});
c.addEventListener('pointermove',function(e){if(down)pick(e)});
c.addEventListener('pointerup',function(){down=false});
c.addEventListener('pointercancel',function(){down=false});
v.addEventListener('input',function(){V=v.value/100;drawWheel();send()});
var init=document.location.hash;
var m=/^#?([0-9a-f]{6})$/i.exec('${initial}');
if(m){var n=parseInt(m[1],16),a=rgb2hsv(n>>16&255,n>>8&255,n&255);H=a[0];Sat=a[1];V=a[2];v.value=Math.round(V*100)}
drawWheel();
</script></body></html>`;

export function ColorWheel({ initial, size, onChange }: Props) {
  const html = useMemo(() => buildHtml(initial), []); // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <View style={{ width: size, height: size + 60, alignSelf: 'center' }}>
      <WebView
        originWhitelist={['*']}
        source={{ html }}
        onMessage={(e) => onChange(e.nativeEvent.data)}
        scrollEnabled={false}
        overScrollMode="never"
        bounces={false}
        javaScriptEnabled
        androidLayerType="hardware"
        style={styles.web}
        containerStyle={styles.web}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  web: { flex: 1, backgroundColor: 'transparent' },
});
