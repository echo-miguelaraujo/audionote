import React, { useCallback, useEffect, useState } from 'react';
import { Button } from './Button';
import { ScreenHeader, ScreenTitle } from './ScreenHeader';
import { StateMessage } from './StateMessage';
import { appAlert, appError } from './dialog';
import {
  ActivityIndicator,
  BackHandler,
  Pressable,
  ScrollView,
  Text,
  View,
  useWindowDimensions,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { QueueItem, deleteQueueItem, listQueue, requeueAudio } from './db';
import { notifyQueue, processQueue, subscribeQueue } from './queue';
import { loadGeminiSettings } from './settings';
import { colors, fonts, TYPE, SPACE, HIT, LEADING, tracking } from './theme';

type Props = { onClose: () => void };

function when(ms: number | null): string {
  if (!ms) return '';
  const diff = ms - Date.now();
  if (diff <= 0) return 'nova tentativa em instantes';
  const min = Math.ceil(diff / 60000);
  return min <= 1 ? 'nova tentativa em ~1 min' : `nova tentativa em ~${min} min`;
}

export function QueueScreen({ onClose }: Props) {
  const { width: sw } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const [items, setItems] = useState<QueueItem[] | null>(null);
  const [hasKey, setHasKey] = useState(true);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    setItems(await listQueue());
    setHasKey(!!(await loadGeminiSettings()).apiKey.trim());
  }, []);

  useEffect(() => {
    load().catch(() => setItems([]));
    return subscribeQueue(() => {
      load().catch(() => {});
    });
  }, [load]);

  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      onClose();
      return true;
    });
    return () => sub.remove();
  }, [onClose]);

  const runNow = async () => {
    setBusy(true);
    try {
      await processQueue(true);
    } finally {
      setBusy(false);
      load().catch(() => {});
    }
  };

  const retry = async (id: number) => {
    await requeueAudio(id);
    await load();
    runNow();
  };

  const remove = (it: QueueItem) =>
    appAlert(
      'Excluir da fila?',
      `"${it.blockName} · ${it.audioName}" será apagada e não será transcrita.`,
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Excluir',
          style: 'destructive',
          onPress: async () => {
            try {
              await deleteQueueItem(it.id);
            } catch (e) {
              appError('Não foi possível apagar', e);
            }
            await load().catch(() => {});
            notifyQueue(); // atualiza o contador e a Biblioteca
          },
        },
      ]
    );

  return (
    <View style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: colors.bg, paddingTop: 0 }}>
      <ScreenHeader onBack={onClose} />
      <ScrollView contentContainerStyle={{ paddingHorizontal: sw * SPACE.xl, paddingTop: sw * SPACE.lg, paddingBottom: insets.bottom + sw * 0.2 }}>
        <ScreenTitle>Fila</ScreenTitle>
        <Text style={{ color: colors.muted, fontFamily: fonts.regular, fontSize: sw * TYPE.label, marginTop: sw * SPACE.sm, lineHeight: sw * TYPE.label * LEADING }}>
          Gravações esperando transcrição. Elas são processadas sozinhas quando houver internet e cota.
        </Text>

        {!hasKey && (
          <StateMessage kind="error" size={TYPE.body} style={{ marginTop: sw * SPACE.lg }}>
            Falta a chave do Gemini. Cole em Configurações (círculo branco na tela de Gravação).
          </StateMessage>
        )}

        <Button
          label="Processar agora"
          onPress={runNow}
          loading={busy}
          disabled={!hasKey}
          style={{ marginTop: sw * SPACE.lg }}
        />

        {items !== null && items.length === 0 && (
          <StateMessage kind="empty" style={{ marginTop: sw * SPACE.xl }}>
            Nada pendente.
          </StateMessage>
        )}

        {(items ?? []).map((it) => (
          <View key={it.id} style={{ marginTop: sw * SPACE.xl }}>
            <Text style={{ color: colors.text, fontFamily: fonts.bold, fontSize: sw * TYPE.subtitle, letterSpacing: tracking(sw * TYPE.subtitle, 0.03) }}>
              {it.blockName} · {it.audioName}
            </Text>
            <Text
              style={{
                color: it.status === 'error' ? colors.red : colors.muted,
                fontFamily: fonts.regular,
                fontSize: sw * TYPE.label,
                marginTop: sw * SPACE.xs,
                lineHeight: sw * 0.055,
              }}
            >
              {it.status === 'error'
                ? it.lastError ?? 'Erro'
                : it.lastError
                ? `${it.lastError} ${when(it.nextRetryAt)}`
                : 'Aguardando transcrição'}
            </Text>
            <View style={{ flexDirection: 'row', gap: sw * SPACE.xl, marginTop: sw * SPACE.sm }}>
              {it.status === 'error' && (
                <Pressable onPress={() => retry(it.id)} hitSlop={HIT.md} accessibilityRole="button">
                  <Text style={{ color: colors.text, fontFamily: fonts.bold, fontSize: sw * TYPE.label }}>Tentar de novo</Text>
                </Pressable>
              )}
              <Pressable onPress={() => remove(it)} hitSlop={HIT.md} accessibilityRole="button">
                <Text style={{ color: colors.red, fontFamily: fonts.bold, fontSize: sw * TYPE.label }}>Apagar</Text>
              </Pressable>
            </View>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}
