import React, { useCallback, useEffect, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  BackHandler,
  Pressable,
  ScrollView,
  Text,
  View,
  useWindowDimensions,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { QueueItem, deleteQueueItem, listQueue, requeueAudio } from './db';
import { notifyQueue, processQueue, subscribeQueue } from './queue';
import { loadGeminiSettings } from './settings';
import { colors, fonts } from './theme';

type Props = { onClose: () => void };

function when(ms: number | null): string {
  if (!ms) return '';
  const diff = ms - Date.now();
  if (diff <= 0) return 'nova tentativa em instantes';
  const min = Math.ceil(diff / 60000);
  return min <= 1 ? 'nova tentativa em ~1 min' : `nova tentativa em ~${min} min`;
}

export function QueueScreen({ onClose }: Props) {
  const { width: sw } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const [items, setItems] = useState<QueueItem[] | null>(null);
  const [hasKey, setHasKey] = useState(true);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    setItems(await listQueue());
    setHasKey(!!(await loadGeminiSettings()).apiKey.trim());
  }, []);

  useEffect(() => {
    load().catch(() => setItems([]));
    return subscribeQueue(() => {
      load().catch(() => {});
    });
  }, [load]);

  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      onClose();
      return true;
    });
    return () => sub.remove();
  }, [onClose]);

  const runNow = async () => {
    setBusy(true);
    try {
      await processQueue(true);
    } finally {
      setBusy(false);
      load().catch(() => {});
    }
  };

  const retry = async (id: number) => {
    await requeueAudio(id);
    await load();
    runNow();
  };

  const remove = (it: QueueItem) =>
    Alert.alert(
      'Apagar da fila?',
      `"${it.blockName} · ${it.audioName}" será apagada e não será transcrita.`,
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Apagar',
          style: 'destructive',
          onPress: async () => {
            try {
              await deleteQueueItem(it.id);
            } catch (e) {
              Alert.alert('Não foi possível apagar', String(e));
            }
            await load().catch(() => {});
            notifyQueue(); // atualiza o contador e a Biblioteca
          },
        },
      ]
    );

  return (
    <View style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: colors.bg, paddingTop: insets.top + sw * 0.06 }}>
      <Pressable onPress={onClose} hitSlop={16} style={{ paddingHorizontal: sw * 0.07 }}>
        <Text style={{ color: colors.gray, fontFamily: fonts.regular, fontSize: sw * 0.052 }}>← Voltar</Text>
      </Pressable>
      <ScrollView contentContainerStyle={{ paddingHorizontal: sw * 0.07, paddingTop: sw * 0.06, paddingBottom: insets.bottom + sw * 0.2 }}>
        <Text style={{ color: colors.text, fontFamily: fonts.black, fontSize: sw * 0.11, letterSpacing: -sw * 0.11 * 0.04 }}>
          Fila
        </Text>
        <Text style={{ color: colors.gray, fontFamily: fonts.regular, fontSize: sw * 0.042, marginTop: 6, lineHeight: sw * 0.058 }}>
          Gravações esperando transcrição. Elas são processadas sozinhas quando houver internet e cota.
        </Text>

        {!hasKey && (
          <Text style={{ color: colors.red, fontFamily: fonts.regular, fontSize: sw * 0.042, marginTop: sw * 0.05, lineHeight: sw * 0.058 }}>
            Falta a chave do Gemini. Cole em Configurações (círculo branco na tela de Gravação).
          </Text>
        )}

        <Pressable
          onPress={runNow}
          disabled={busy || !hasKey}
          style={{
            marginTop: sw * 0.06,
            backgroundColor: colors.text,
            borderRadius: sw * 0.07,
            paddingVertical: sw * 0.035,
            alignItems: 'center',
            opacity: busy || !hasKey ? 0.4 : 1,
          }}
        >
          {busy ? (
            <ActivityIndicator color="#000" />
          ) : (
            <Text style={{ color: '#000', fontFamily: fonts.bold, fontSize: sw * 0.045 }}>Processar agora</Text>
          )}
        </Pressable>

        {items !== null && items.length === 0 && (
          <Text style={{ color: colors.gray, fontFamily: fonts.light, fontSize: sw * 0.048, marginTop: sw * 0.08 }}>
            Nada pendente. 
          </Text>
        )}

        {(items ?? []).map((it) => (
          <View key={it.id} style={{ marginTop: sw * 0.07 }}>
            <Text style={{ color: colors.text, fontFamily: fonts.bold, fontSize: sw * 0.055, letterSpacing: -0.5 }}>
              {it.blockName} · {it.audioName}
            </Text>
            <Text
              style={{
                color: it.status === 'error' ? colors.red : colors.gray,
                fontFamily: fonts.regular,
                fontSize: sw * 0.04,
                marginTop: 2,
                lineHeight: sw * 0.055,
              }}
            >
              {it.status === 'error'
                ? it.lastError ?? 'Erro'
                : it.lastError
                ? `${it.lastError} ${when(it.nextRetryAt)}`
                : 'Aguardando transcrição'}
            </Text>
            <View style={{ flexDirection: 'row', gap: sw * 0.07, marginTop: 6 }}>
              {it.status === 'error' && (
                <Pressable onPress={() => retry(it.id)} hitSlop={10}>
                  <Text style={{ color: colors.text, fontFamily: fonts.bold, fontSize: sw * 0.042 }}>Tentar de novo</Text>
                </Pressable>
              )}
              <Pressable onPress={() => remove(it)} hitSlop={10}>
                <Text style={{ color: colors.red, fontFamily: fonts.bold, fontSize: sw * 0.042 }}>Apagar</Text>
              </Pressable>
            </View>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}
