import { getNoteJson, listBlocks, saveNoteJson } from './db';
import { generateJson } from './gemini';
import { escapeHtml, noteDisplayTitle, parseNote } from './note';
import { notifyQueue } from './queue';
import { loadGeminiSettings } from './settings';

/**
 * Reorganização de notas existentes: a IA PROPÕE mudanças (citação, lista, subtítulo) e o app só
 * aplica as que o usuário permitir. O texto nunca é reescrito: citações e itens são trechos exatos
 * do parágrafo original; o único texto novo são os subtítulos.
 */

export type ProposalKind = 'quote' | 'list' | 'heading';

export type Proposal = {
  id: string;
  blockId: number;
  noteTitle: string;
  kind: ProposalKind;
  /** Posição do parágrafo (só contam os parágrafos simples <p>texto</p>). */
  paragraph: number;
  /** Início do parágrafo no momento da análise, para conferir que a nota não mudou. */
  fingerprint: string;
  label: string;
  /** Trecho que será afetado (prévia). */
  preview: string;
  quote?: string;
  listKind?: 'ul' | 'ol';
  items?: string[];
  heading?: string;
};

// ---------- parágrafos simples ----------

type Para = { index: number; start: number; end: number; text: string };

const unesc = (s: string): string =>
  s.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&');

/** Parágrafos <p>texto</p> sem formatação interna (os únicos que o app mexe com segurança). */
function plainParagraphs(html: string): Para[] {
  const out: Para[] = [];
  const re = /<p>([^<]*)<\/p>/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html))) {
    const text = unesc(m[1]).replace(/\s+/g, ' ').trim();
    if (text) out.push({ index: out.length, start: m.index, end: m.index + m[0].length, text });
  }
  return out;
}

const fp = (t: string) => t.slice(0, 60);

// ---------- pedido ao Gemini ----------

const PROMPT =
  'Você organiza notas pessoais em português do Brasil (pregações, estudos, anotações) SEM reescrever nada. ' +
  'Recebe parágrafos numerados e devolve SUGESTÕES de melhoria de estrutura, de três tipos:\n\n' +
  '1. "quote" (citação): quando o parágrafo contém um texto que a pessoa LEU ou CITOU literalmente (versículo bíblico lido, trecho de livro, frase de alguém). ' +
  '"quote" deve ser um trecho EXATO, copiado letra por letra do parágrafo, só com o texto citado (sem a frase que o introduz). Simples menção a um texto, sem as palavras dele, não é citação.\n' +
  '2. "list" (pontos): quando o parágrafo apresenta pontos bem definidos e reconhecíveis (os pontos de uma mensagem, motivos, passos, características). ' +
  '"items" são os pontos, cada um um trecho EXATO do parágrafo, na ordem em que aparecem, sem os marcadores falados ("primeiro", "o segundo ponto é"). ' +
  '"list_kind" é "ol" se a pessoa numerou ou ordenou os pontos, senão "ul". Mínimo 2 itens. Na dúvida, não sugira.\n' +
  '3. "heading" (subtítulo): quando começa um assunto ou subtópico novo e específico. "paragraph" é o parágrafo ANTES do qual o subtítulo entra e "heading" é um subtítulo curto e específico (2 a 5 palavras, sem ponto final). ' +
  'A pessoa quer achar cada parte de um texto grande: em notas longas, sugira de 3 a 4 subtítulos ao longo do texto, no mínimo (mais se houver mais assuntos), distribuídos de forma a não deixar mais de 3 ou 4 parágrafos seguidos sem subtítulo. ' +
  'Não repita subtítulos que a nota já tem (aparecem como [título]); conte os que já existem e sugira só os que faltam, sem colocar dois subtítulos colados.\n\n' +
  'Regras: "paragraph" é o número entre colchetes. No máximo UMA sugestão "quote" ou "list" por parágrafo. Não invente texto. ' +
  'Seja criterioso: sugira só o que melhora de verdade a leitura. Se não houver nada, devolva a lista vazia. Em "reason", uma frase curta dizendo por que.';

const SCHEMA = {
  type: 'OBJECT',
  properties: {
    suggestions: {
      type: 'ARRAY',
      items: {
        type: 'OBJECT',
        properties: {
          type: { type: 'STRING' },
          paragraph: { type: 'INTEGER' },
          quote: { type: 'STRING' },
          list_kind: { type: 'STRING' },
          items: { type: 'ARRAY', items: { type: 'STRING' } },
          heading: { type: 'STRING' },
          reason: { type: 'STRING' },
        },
        required: ['type', 'paragraph'],
      },
    },
  },
  required: ['suggestions'],
};

const CHUNK_CHARS = 28000;

function findSeq(text: string, items: string[]): number[] | null {
  const pos: number[] = [];
  let from = 0;
  for (const it of items) {
    const i = text.indexOf(it.trim(), from);
    if (i < 0 || !it.trim()) return null;
    pos.push(i);
    from = i + it.trim().length;
  }
  return pos;
}

const short = (t: string, n = 140) => (t.length > n ? `${t.slice(0, n).trim()}…` : t);

function clean(raw: any, blockId: number, noteTitle: string, paras: Para[]): Proposal[] {
  const out: Proposal[] = [];
  const usedText = new Set<number>();
  const usedHead = new Set<number>();
  for (const s of Array.isArray(raw) ? raw : []) {
    const idx = Number(s?.paragraph);
    const para = paras[idx];
    if (!para) continue;
    const base = { blockId, noteTitle, paragraph: idx, fingerprint: fp(para.text) };
    const id = `${blockId}:${out.length}`;
    if (s.type === 'quote') {
      const q = typeof s.quote === 'string' ? s.quote.trim() : '';
      if (!q || usedText.has(idx) || !para.text.includes(q)) continue;
      usedText.add(idx);
      out.push({ ...base, id, kind: 'quote', label: 'Virar citação', preview: short(q), quote: q });
    } else if (s.type === 'list') {
      const items: string[] = (Array.isArray(s.items) ? s.items : []).filter((x: unknown) => typeof x === 'string');
      if (items.length < 2 || usedText.has(idx) || !findSeq(para.text, items)) continue;
      usedText.add(idx);
      const ordered = s.list_kind === 'ol';
      out.push({
        ...base,
        id,
        kind: 'list',
        label: `Virar lista ${ordered ? 'numerada' : 'com marcadores'} (${items.length} pontos)`,
        preview: items.map((x, i) => `${ordered ? `${i + 1}.` : '•'} ${short(x, 70)}`).join('\n'),
        listKind: ordered ? 'ol' : 'ul',
        items,
      });
    } else if (s.type === 'heading') {
      const h = typeof s.heading === 'string' ? s.heading.trim().replace(/[.\s]+$/, '') : '';
      if (!h || usedHead.has(idx)) continue;
      usedHead.add(idx);
      out.push({ ...base, id, kind: 'heading', label: `Novo subtítulo: ${h}`, preview: short(para.text, 90), heading: h });
    }
  }
  return out;
}

/** Analisa uma nota e devolve as sugestões (nada é alterado). */
export async function proposeForNote(
  blockId: number,
  apiKey: string,
  model: string
): Promise<{ ok: true; proposals: Proposal[] } | { ok: false; message: string }> {
  const note = parseNote(await getNoteJson(blockId));
  if (!note) return { ok: true, proposals: [] };
  const paras = plainParagraphs(note.html);
  if (paras.length === 0) return { ok: true, proposals: [] };
  const title = noteDisplayTitle(note) || 'Nota';

  // Linhas numeradas, com os títulos existentes intercalados como [título].
  const heads = Array.from(note.html.matchAll(/<h[1-5][^>]*>([\s\S]*?)<\/h[1-5]>/gi)).map((m) => ({
    pos: m.index ?? 0,
    text: unesc(m[1].replace(/<[^>]+>/g, '')).trim(),
  }));
  const lines: { chars: number; text: string; paraIndex: number }[] = [];
  let h = 0;
  for (const p of paras) {
    while (h < heads.length && heads[h].pos < p.start) {
      lines.push({ chars: heads[h].text.length, text: `[título] ${heads[h].text}`, paraIndex: -1 });
      h++;
    }
    lines.push({ chars: p.text.length, text: `[${p.index}] ${p.text}`, paraIndex: p.index });
  }
  const chunks: string[] = [];
  let cur = '';
  for (const l of lines) {
    if (cur && cur.length + l.text.length > CHUNK_CHARS && l.paraIndex >= 0) {
      chunks.push(cur);
      cur = '';
    }
    cur += l.text + '\n\n';
  }
  if (cur) chunks.push(cur);

  const raw: any[] = [];
  for (const c of chunks) {
    const r = await generateJson<{ suggestions?: unknown }>(
      apiKey,
      model,
      [{ text: `${PROMPT}\n\nNOTA: ${title}\n\n${c}` }],
      SCHEMA,
      120000
    );
    if (!r.ok) return { ok: false, message: r.error.message };
    if (Array.isArray(r.data?.suggestions)) raw.push(...(r.data.suggestions as any[]));
  }
  return { ok: true, proposals: clean(raw, blockId, title, paras) };
}

export type AnalyzeResult = { proposals: Proposal[]; analyzed: number; failed: string | null };

/** Analisa várias notas (ou todas), uma de cada vez. Para no primeiro erro de rede/cota. */
export async function proposeForNotes(
  blockIds: number[] | 'all',
  onProgress?: (done: number, total: number) => void
): Promise<AnalyzeResult> {
  const { apiKey, model } = await loadGeminiSettings();
  if (!apiKey.trim()) return { proposals: [], analyzed: 0, failed: 'Coloque a chave do Gemini em Configurações.' };
  const ids = blockIds === 'all' ? (await listBlocks()).map((b) => b.id) : blockIds;
  const proposals: Proposal[] = [];
  let analyzed = 0;
  for (const id of ids) {
    onProgress?.(analyzed, ids.length);
    const r = await proposeForNote(id, apiKey, model);
    if (!r.ok) return { proposals, analyzed, failed: r.message };
    proposals.push(...r.proposals);
    analyzed++;
  }
  onProgress?.(analyzed, ids.length);
  return { proposals, analyzed, failed: null };
}

// ---------- aplicar o que foi permitido ----------

function applyToHtml(html: string, props: Proposal[]): { html: string; applied: Set<string> } {
  const paras = plainParagraphs(html);
  const applied = new Set<string>();
  const byPara = new Map<number, Proposal[]>();
  for (const p of props) byPara.set(p.paragraph, [...(byPara.get(p.paragraph) ?? []), p]);
  // De trás para frente, para as posições anteriores continuarem valendo.
  const order = [...byPara.keys()].sort((x, y) => y - x);
  for (const idx of order) {
    const para = paras[idx];
    if (!para) continue;
    const group = (byPara.get(idx) ?? []).filter((p) => fp(para.text) === p.fingerprint); // nota mudou: não mexe
    if (group.length === 0) continue;
    const text = para.text;
    // Parágrafo sobrando: tira pontuação solta nas pontas e descarta se não sobrou nenhuma palavra.
    const pHtml = (t: string, trail = false) => {
      const c = trail ? t.replace(/^[\s.,;]+/, '').trim() : t.replace(/[,;\s]+$/, '').trim();
      return /[\p{L}\p{N}]/u.test(c) ? `<p>${escapeHtml(c)}</p>` : '';
    };
    let body: string | null = null; // substituição do próprio parágrafo (citação ou lista)
    let head = '';
    const done: string[] = [];

    for (const p of group) {
      if (p.kind === 'heading' && p.heading) {
        head = `<h2>${escapeHtml(p.heading)}</h2>`;
        done.push(p.id);
      } else if (body === null && p.kind === 'quote' && p.quote) {
        const i = text.indexOf(p.quote);
        if (i < 0) continue;
        body = pHtml(text.slice(0, i)) + `<blockquote>${escapeHtml(p.quote)}</blockquote>` + pHtml(text.slice(i + p.quote.length), true);
        done.push(p.id);
      } else if (body === null && p.kind === 'list' && p.items) {
        const pos = findSeq(text, p.items);
        if (!pos) continue;
        const items = p.items.map((x) => x.trim());
        const lis = items.map((it, k) => {
          let t = it;
          if (k < items.length - 1) {
            const gap = text.slice(pos[k] + it.length, pos[k + 1]).trim();
            if (gap.length > 40) t = `${it} ${gap}`; // conversa longa entre pontos: não perde texto
          }
          return `<li>${escapeHtml(t.replace(/[,;]+$/, '').trim())}</li>`;
        });
        const last = pos[items.length - 1] + items[items.length - 1].length;
        const tag = p.listKind === 'ol' ? 'ol' : 'ul';
        body = pHtml(text.slice(0, pos[0])) + `<${tag}>${lis.join('')}</${tag}>` + pHtml(text.slice(last), true);
        done.push(p.id);
      }
    }
    if (done.length === 0) continue;
    const repl = head + (body ?? html.slice(para.start, para.end));
    html = html.slice(0, para.start) + repl + html.slice(para.end);
    done.forEach((id) => applied.add(id));
  }
  return { html, applied };
}

/** Aplica só as sugestões permitidas. Devolve quantas foram aplicadas e quantas foram puladas. */
export async function applyProposals(allowed: Proposal[]): Promise<{ applied: number; skipped: number }> {
  const byNote = new Map<number, Proposal[]>();
  for (const p of allowed) byNote.set(p.blockId, [...(byNote.get(p.blockId) ?? []), p]);
  let applied = 0;
  for (const [blockId, props] of byNote) {
    const note = parseNote(await getNoteJson(blockId));
    if (!note) continue;
    const r = applyToHtml(note.html, props);
    if (r.applied.size === 0) continue;
    await saveNoteJson(blockId, JSON.stringify({ ...note, html: r.html }));
    applied += r.applied.size;
  }
  notifyQueue(); // a nota aberta recarrega
  return { applied, skipped: allowed.length - applied };
}
