import { getNoteJson, listBlocks, saveNoteJson } from './db';
import { generateJson } from './gemini';
import { escapeHtml, htmlToText, noteDisplayTitle, parseNote } from './note';
import { notifyQueue } from './queue';
import { getSetting, loadGeminiSettings, setSetting } from './settings';

/**
 * Reorganização de notas existentes: a IA PROPÕE mudanças (citação, lista, subtítulo) e o app só
 * aplica as que o usuário permitir. O texto nunca é reescrito: citações e itens são trechos exatos
 * do parágrafo original; o único texto novo são os subtítulos.
 */

export type ProposalKind = 'quote' | 'list' | 'heading' | 'todo' | 'custom';

/** O que a IA faz: organizar o texto (citação, lista, subtítulo) ou achar tarefas ditas pela pessoa. */
export type SuggestMode = 'organize' | 'tasks' | 'custom';

export type Proposal = {
  id: string;
  blockId: number;
  noteTitle: string;
  kind: ProposalKind;
  /** Posição do parágrafo (só contam os parágrafos simples <p>texto</p>). */
  paragraph: number;
  /** Início do parágrafo no momento da análise, para conferir que a nota não mudou. */
  fingerprint: string;
  label: string;
  /** Trecho que será afetado (prévia). */
  preview: string;
  quote?: string;
  listKind?: 'ul' | 'ol' | 'todo';
  items?: string[];
  heading?: string;
  /** Pedido livre: HTML novo (já limpo) que substitui `original` (a nota toda ou só o trecho escolhido). */
  html?: string;
  original?: string;
  whole?: boolean;
};

// ---------- parágrafos simples ----------

type Para = { index: number; start: number; end: number; text: string };

const unesc = (s: string): string =>
  s.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&');

/** Parágrafos <p>texto</p> sem formatação interna (os únicos que o app mexe com segurança). */
function plainParagraphs(html: string): Para[] {
  const out: Para[] = [];
  const re = /<p>([^<]*)<\/p>/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html))) {
    const text = unesc(m[1]).replace(/\s+/g, ' ').trim();
    if (text) out.push({ index: out.length, start: m.index, end: m.index + m[0].length, text });
  }
  return out;
}

const PROMPT_VERSION = 2;
function hashStr(t: string): string {
  let h = 5381;
  for (let i = 0; i < t.length; i++) h = ((h << 5) + h + t.charCodeAt(i)) | 0;
  return `${t.length}:${h}`;
}

const fp = (t: string) => t.slice(0, 60);

// ---------- pedido ao Gemini ----------

const PROMPT =
  'Você organiza notas pessoais em português do Brasil (pregações, estudos, anotações) SEM reescrever nada. ' +
  'Recebe parágrafos numerados e devolve SUGESTÕES de melhoria de estrutura, de três tipos:\n\n' +
  '1. "quote" (citação): quando o parágrafo contém um texto que a pessoa LEU ou CITOU literalmente (versículo bíblico lido, trecho de livro, frase de alguém). ' +
  '"quote" é o texto citado (sem a frase que o introduz), dado só pelo começo e pelo fim: {"start": primeiras 4 a 6 palavras, "end": últimas 4 a 6 palavras}, copiadas letra por letra do parágrafo. Simples menção a um texto, sem as palavras dele, não é citação.\n' +
  '2. "list" (pontos): quando o parágrafo apresenta pontos bem definidos e reconhecíveis (os pontos de uma mensagem, motivos, passos, características). ' +
  '"items" são os pontos, na ordem em que aparecem, sem os marcadores falados ("primeiro", "o segundo ponto é"). Cada ponto é {"start","end"}: primeiras e últimas 4 a 6 palavras dele, copiadas letra por letra do parágrafo (ponto curto: o trecho todo nos dois). ' +
  '"list_kind" é "ol" se a pessoa numerou ou ordenou os pontos, senão "ul". Mínimo 2 itens. Na dúvida, não sugira.\n' +
  '3. "heading" (subtítulo): quando começa um assunto ou subtópico novo e específico. "paragraph" é o parágrafo ANTES do qual o subtítulo entra e "heading" é um subtítulo curto e específico (2 a 5 palavras, sem ponto final). ' +
  'A pessoa quer achar cada parte de um texto grande: em notas longas, sugira de 3 a 4 subtítulos ao longo do texto, no mínimo (mais se houver mais assuntos), distribuídos de forma a não deixar mais de 3 ou 4 parágrafos seguidos sem subtítulo. ' +
  'Não repita subtítulos que a nota já tem (aparecem como [título]); conte os que já existem e sugira só os que faltam, sem colocar dois subtítulos colados.\n\n' +
  'Regras: "paragraph" é o número entre colchetes. No máximo UMA sugestão "quote" ou "list" por parágrafo. Não invente texto. ' +
  'Seja criterioso: sugira só o que melhora de verdade a leitura. Se não houver nada, devolva a lista vazia.';

/** A IA devolve só o começo e o fim do trecho (menos tokens de saída); o app recorta o texto exato do parágrafo. */
const SPAN_SCHEMA = {
  type: 'OBJECT',
  properties: { start: { type: 'STRING' }, end: { type: 'STRING' } },
  required: ['start', 'end'],
};

const SCHEMA = {
  type: 'OBJECT',
  properties: {
    suggestions: {
      type: 'ARRAY',
      items: {
        type: 'OBJECT',
        properties: {
          type: { type: 'STRING' },
          paragraph: { type: 'INTEGER' },
          quote: SPAN_SCHEMA,
          list_kind: { type: 'STRING' },
          items: { type: 'ARRAY', items: SPAN_SCHEMA },
          heading: { type: 'STRING' },
        },
        required: ['type', 'paragraph'],
      },
    },
  },
  required: ['suggestions'],
};

const TASKS_PROMPT =
  'Você ajuda a achar TAREFAS em notas pessoais em português do Brasil, SEM reescrever nada. ' +
  'Recebe parágrafos numerados. Sugira transformar em lista de tarefas os parágrafos em que a pessoa DISSE ações ou pendências que ela mesma pretende fazer ' +
  '(por exemplo \"preciso ligar para\", \"tenho que\", \"não esquecer de\", \"vou enviar\"). ' +
  'Cada sugestão é do tipo \"todo\", com \"paragraph\" (o número entre colchetes) e \"items\": cada item é o MENOR trecho do parágrafo que expresse uma ação, na ordem em que aparece, dado como {\"start\",\"end\"}: primeiras e últimas 4 a 6 palavras dele, copiadas letra por letra (trecho curto: o trecho todo nos dois). ' +
  'Não invente tarefas, não acrescente palavras, não use datas que a pessoa não disse. No máximo UMA sugestão por parágrafo, com pelo menos 1 item. ' +
  'Opiniões, relatos, explicações e ideias gerais não são tarefas. Na dúvida, não sugira. Se não houver nenhuma tarefa, devolva a lista vazia.';

const CHUNK_CHARS = 28000;
const RESTRUCTURE_OUTPUT_BUDGET = 12000;

function findSeq(text: string, items: string[]): number[] | null {
  const pos: number[] = [];
  let from = 0;
  for (const it of items) {
    const i = text.indexOf(it.trim(), from);
    if (i < 0 || !it.trim()) return null;
    pos.push(i);
    from = i + it.trim().length;
  }
  return pos;
}

/** Âncora {start,end} -> trecho exato do texto, a partir de `from`. Aceita também texto direto. */
function resolveSpan(text: string, a: any, from = 0): { text: string; end: number } | null {
  if (typeof a === 'string') {
    const t = a.trim();
    const i = t ? text.indexOf(t, from) : -1;
    return i < 0 ? null : { text: t, end: i + t.length };
  }
  const st = typeof a?.start === 'string' ? a.start.trim() : '';
  const en = typeof a?.end === 'string' && a.end.trim() ? a.end.trim() : st;
  if (!st) return null;
  const i = text.indexOf(st, from);
  if (i < 0) return null;
  const k = text.indexOf(en, i);
  if (k < 0) return null;
  const j = Math.max(k + en.length, i + st.length);
  return { text: text.slice(i, j), end: j };
}

function resolveItems(text: string, raw: unknown): string[] {
  const out: string[] = [];
  let from = 0;
  for (const a of Array.isArray(raw) ? raw : []) {
    const r = resolveSpan(text, a, from);
    if (!r) return [];
    out.push(r.text);
    from = r.end;
  }
  return out;
}

const short = (t: string, n = 140) => (t.length > n ? `${t.slice(0, n).trim()}…` : t);

function clean(raw: any, blockId: number, noteTitle: string, paras: Para[], scope: Set<number> | null): Proposal[] {
  const out: Proposal[] = [];
  const usedText = new Set<number>();
  const usedHead = new Set<number>();
  for (const s of Array.isArray(raw) ? raw : []) {
    const idx = Number(s?.paragraph);
    const para = paras[idx];
    if (!para || (scope && !scope.has(idx))) continue;
    const base = { blockId, noteTitle, paragraph: idx, fingerprint: fp(para.text) };
    const id = `${blockId}:${out.length}`;
    if (s.type === 'quote') {
      const q = resolveSpan(para.text, s.quote)?.text ?? '';
      if (!q || usedText.has(idx) || !para.text.includes(q)) continue;
      usedText.add(idx);
      out.push({ ...base, id, kind: 'quote', label: 'Virar citação', preview: short(q), quote: q });
    } else if (s.type === 'list') {
      const items = resolveItems(para.text, s.items);
      if (items.length < 2 || usedText.has(idx) || !findSeq(para.text, items)) continue;
      usedText.add(idx);
      const ordered = s.list_kind === 'ol';
      out.push({
        ...base,
        id,
        kind: 'list',
        label: `Virar lista ${ordered ? 'numerada' : 'com marcadores'} (${items.length} pontos)`,
        preview: items.map((x, i) => `${ordered ? `${i + 1}.` : '•'} ${short(x, 70)}`).join('\n'),
        listKind: ordered ? 'ol' : 'ul',
        items,
      });
    } else if (s.type === 'todo') {
      const items = resolveItems(para.text, s.items);
      if (items.length < 1 || usedText.has(idx) || !findSeq(para.text, items)) continue;
      usedText.add(idx);
      out.push({
        ...base,
        id,
        kind: 'todo',
        label: `Virar lista de tarefas (${items.length} ${items.length === 1 ? 'tarefa' : 'tarefas'})`,
        preview: items.map((x) => `☐ ${short(x, 70)}`).join('\n'),
        listKind: 'todo',
        items,
      });
    } else if (s.type === 'heading') {
      const h = typeof s.heading === 'string' ? s.heading.trim().replace(/[.\s]+$/, '') : '';
      if (!h || usedHead.has(idx)) continue;
      usedHead.add(idx);
      out.push({ ...base, id, kind: 'heading', label: `Novo subtítulo: ${h}`, preview: short(para.text, 90), heading: h });
    }
  }
  return out;
}

/** Analisa uma nota e devolve as sugestões (nada é alterado). */
export async function proposeForNote(
  blockId: number,
  apiKey: string,
  model: string,
  opts: { mode?: SuggestMode; selection?: string } = {}
): Promise<{ ok: true; proposals: Proposal[] } | { ok: false; message: string }> {
  const mode: SuggestMode = opts.mode ?? 'organize';
  const note = parseNote(await getNoteJson(blockId));
  if (!note) return { ok: true, proposals: [] };
  const paras = plainParagraphs(note.html);
  if (paras.length === 0) return { ok: true, proposals: [] };
  const title = noteDisplayTitle(note) || 'Nota';
  const mode0: SuggestMode = opts.mode ?? 'organize';
  // Nota curta não tem o que organizar. Nota que já deu zero sugestões e não mudou: não gasta de novo.
  if (mode0 === 'organize' && !opts.selection && paras.reduce((n, p) => n + p.text.length, 0) < 300) return { ok: true, proposals: [] };
  const noneKey = `restructure_none_${blockId}_${mode0}`;
  const stamp = hashStr(`${PROMPT_VERSION}|${title}|${note.html}`);
  if (!opts.selection && (await getSetting(noneKey)) === stamp) return { ok: true, proposals: [] };

  // Com um trecho selecionado, só os parágrafos que ele toca entram na análise.
  const sel = (opts.selection ?? '').replace(/\s+/g, ' ').trim();
  const scope: Set<number> | null = sel
    ? new Set(
        paras
          .filter(
            (p) =>
              sel.includes(p.text) ||
              p.text.includes(sel) ||
              p.text.includes(sel.slice(0, 40)) ||
              p.text.includes(sel.slice(-40))
          )
          .map((p) => p.index)
      )
    : null;
  if (scope && scope.size === 0) return { ok: true, proposals: [] };
  const target = scope ? paras.filter((p) => scope.has(p.index)) : paras;

  // Linhas numeradas, com os títulos existentes intercalados como [título].
  const heads = Array.from(note.html.matchAll(/<h[1-5][^>]*>([\s\S]*?)<\/h[1-5]>/gi)).map((m) => ({
    pos: m.index ?? 0,
    text: unesc(m[1].replace(/<[^>]+>/g, '')).trim(),
  }));
  const lines: { chars: number; text: string; paraIndex: number }[] = [];
  let h = 0;
  for (const p of target) {
    while (h < heads.length && heads[h].pos < p.start) {
      lines.push({ chars: heads[h].text.length, text: `[título] ${heads[h].text}`, paraIndex: -1 });
      h++;
    }
    lines.push({ chars: p.text.length, text: `[${p.index}] ${p.text}`, paraIndex: p.index });
  }
  const chunks: string[] = [];
  let cur = '';
  for (const l of lines) {
    if (cur && cur.length + l.text.length > CHUNK_CHARS && l.paraIndex >= 0) {
      chunks.push(cur);
      cur = '';
    }
    cur += l.text + '\n\n';
  }
  if (cur) chunks.push(cur);

  const raw: any[] = [];
  for (const c of chunks) {
    const r = await generateJson<{ suggestions?: unknown }>(
      apiKey,
      model,
      [{ text: `${mode === 'tasks' ? TASKS_PROMPT : PROMPT}\n\nNOTA: ${title}\n\n${c}` }],
      SCHEMA,
      120000,
      { kind: 'restructure', maxOutputTokens: RESTRUCTURE_OUTPUT_BUDGET }
    );
    if (!r.ok) return { ok: false, message: r.error.message };
    if (Array.isArray(r.data?.suggestions)) raw.push(...(r.data.suggestions as any[]));
  }
  const proposals = clean(raw, blockId, title, paras, scope);
  if (!opts.selection) await setSetting(noneKey, proposals.length === 0 ? stamp : '').catch(() => {});
  return { ok: true, proposals };
}

export type AnalyzeResult = { proposals: Proposal[]; analyzed: number; failed: string | null };

/** Analisa várias notas (ou todas), uma de cada vez. Para no primeiro erro de rede/cota. */
export async function proposeForNotes(
  blockIds: number[] | 'all',
  onProgress?: (done: number, total: number) => void,
  opts: { mode?: SuggestMode; selection?: string } = {}
): Promise<AnalyzeResult> {
  const { apiKey, model } = await loadGeminiSettings();
  if (!apiKey.trim()) return { proposals: [], analyzed: 0, failed: 'Coloque a chave do Gemini em Configurações.' };
  const ids = blockIds === 'all' ? (await listBlocks()).map((b) => b.id) : blockIds;
  const proposals: Proposal[] = [];
  let analyzed = 0;
  for (const id of ids) {
    onProgress?.(analyzed, ids.length);
    const r = await proposeForNote(id, apiKey, model, opts);
    if (!r.ok) return { proposals, analyzed, failed: r.message };
    proposals.push(...r.proposals);
    analyzed++;
  }
  onProgress?.(analyzed, ids.length);
  return { proposals, analyzed, failed: null };
}


// ---------- pedido livre do usuário ----------

const CUSTOM_PROMPT =
  'Você edita notas pessoais em português do Brasil conforme o PEDIDO da pessoa. Recebe o HTML da nota (ou de um trecho dela) e devolve o HTML novo, ' +
  'em {\"html\": \"...\"}. Faça exatamente o que foi pedido, nada além disso. ' +
  'Regras: não invente fatos, nomes ou informações que não estejam no texto; só tire ou resuma conteúdo se o pedido mandar. ' +
  'Mantenha o idioma e o jeito de falar da pessoa, a menos que o pedido diga outra coisa. ' +
  'Marcadores como [[BLOCO_3]] representam imagens, arquivos ou cartões: copie-os exatamente, cada um uma vez, no lugar certo; nunca os apague nem os altere. ' +
  'Use SÓ estas tags: p, h1, h2, h3, h4, h5, blockquote, ul, ol, li, strong, em, u, s, br, hr, a (com href), table, thead, tbody, tr, th, td. ' +
  'Lista de tarefas: <ul class=\"todo\"><li data-done=\"false\">tarefa</li></ul>. ' +
  'Tabela: <table><tbody><tr><th>…</th></tr><tr><td>…</td></tr></tbody></table>, com a primeira linha de <th>. ' +
  'Exemplo: um diálogo vira tabela com colunas como \"Quem fala\" e \"Fala\" (e outras que o pedido ou o contexto sugerirem). ' +
  'Não use markdown, não use blocos de código, não escreva explicações fora do JSON.';

const CUSTOM_SCHEMA = {
  type: 'OBJECT',
  properties: { html: { type: 'STRING' } },
  required: ['html'],
};

const SAFE_TAGS = new Set([
  'p', 'h1', 'h2', 'h3', 'h4', 'h5', 'blockquote', 'ul', 'ol', 'li', 'strong', 'b', 'em', 'i', 'u', 's', 'strike',
  'br', 'hr', 'a', 'table', 'thead', 'tbody', 'tr', 'th', 'td', 'span',
]);

/** Limpa o HTML devolvido pela IA: só tags conhecidas, sem scripts nem atributos perigosos. */
function sanitizeAiHtml(raw: string): string {
  let h = raw
    .replace(/^\s*```(?:html)?/i, '')
    .replace(/```\s*$/, '')
    .replace(/<(script|style|iframe|object|embed)[\s\S]*?<\/\1\s*>/gi, '')
    .replace(/<!--[\s\S]*?-->/g, '');
  h = h.replace(/<\/?([a-zA-Z][a-zA-Z0-9]*)\b([^>]*)>/g, (m, name: string, attrs: string) => {
    const tag = name.toLowerCase();
    if (!SAFE_TAGS.has(tag)) return '';
    if (m.startsWith('</')) return `</${tag}>`;
    let out = `<${tag}`;
    if (tag === 'a') {
      const href = /href\s*=\s*"([^"]*)"/i.exec(attrs)?.[1] ?? /href\s*=\s*'([^']*)'/i.exec(attrs)?.[1];
      if (href && /^(https?:|mailto:)/i.test(href.trim())) out += ` href="${href.trim().replace(/"/g, '&quot;')}"`;
    } else if (tag === 'ul' && /class\s*=\s*["']?[^>]*\btodo\b/i.test(attrs)) {
      out += ' class="todo"';
    } else if (tag === 'li' && /data-done\s*=\s*["']?(true|false)/i.test(attrs)) {
      out += ` data-done="${/data-done\s*=\s*["']?true/i.test(attrs) ? 'true' : 'false'}"`;
    } else if (tag === 'span') {
      const st = /style\s*=\s*"([^"]*)"/i.exec(attrs)?.[1];
      if (st) {
        const safe = st.replace(/[^\w\s#%.,;:()-]/g, '');
        if (!/url\s*\(|expression/i.test(safe)) out += ` style="${safe}"`;
      }
    }
    return out + (m.endsWith('/>') ? '/>' : '>');
  });
  return h.trim();
}

/** Troca imagens, arquivos e cartões por marcadores, para a IA não ver (nem estragar) esses blocos. */
function protectBlocks(html: string): { text: string; map: string[] } {
  const map: string[] = [];
  const hold = (chunk: string) => {
    map.push(chunk);
    return `[[BLOCO_${map.length - 1}]]`;
  };
  let t = html;
  const inner = /<div\b[^>]*>(?:(?!<div\b)[\s\S])*?<\/div>/i;
  for (let guard = 0; guard < 500 && inner.test(t); guard++) t = t.replace(inner, hold);
  t = t
    .replace(/<a\b[^>]*class="[^"]*\blkcard\b[^"]*"[^>]*>[\s\S]*?<\/a>/gi, hold)
    .replace(/<span\b[^>]*class="[^"]*\bfilechip\b[^"]*"[^>]*>(?:(?!<span\b)[\s\S])*?<\/span>/gi, hold)
    .replace(/<(video|audio)\b[\s\S]*?<\/\1>/gi, hold)
    .replace(/<img\b[^>]*>/gi, hold);
  return { text: t, map };
}

function restoreBlocks(html: string, map: string[]): string {
  const seen = new Set<number>();
  const back = (t: string): string =>
    t.replace(/\[\[BLOCO_(\d+)\]\]/g, (_m, n: string) => {
      const i = Number(n);
      if (!map[i] || seen.has(i)) return '';
      seen.add(i);
      return back(map[i]);
    });
  let out = back(html);
  // Bloco que a IA esqueceu volta no fim: nada se perde.
  map.forEach((chunk, i) => {
    if (!seen.has(i) && !map.some((o, j) => j !== i && o.includes(`[[BLOCO_${i}]]`))) {
      seen.add(i);
      out += back(chunk);
    }
  });
  return out;
}

/**
 * Pedido livre: a IA reescreve a nota (ou só o trecho selecionado) como a pessoa pediu.
 * Nada é salvo aqui; o resultado volta como UMA sugestão para a pessoa ver e permitir.
 */
export async function proposeCustom(
  blockId: number,
  request: string,
  selection = ''
): Promise<{ proposals: Proposal[]; failed: string | null; empty?: string }> {
  const { apiKey, model } = await loadGeminiSettings();
  if (!apiKey.trim()) return { proposals: [], failed: 'Coloque a chave do Gemini em Configurações.' };
  const note = parseNote(await getNoteJson(blockId));
  if (!note || !note.html.trim()) return { proposals: [], failed: null, empty: 'A nota está vazia.' };
  const title = noteDisplayTitle(note) || 'Nota';

  // Com trecho selecionado: só os parágrafos que ele toca (e o que há entre eles) vão para a IA.
  let original = note.html;
  let whole = true;
  const sel = selection.replace(/\s+/g, ' ').trim();
  if (sel) {
    const hit = plainParagraphs(note.html).filter(
      (p) => sel.includes(p.text) || p.text.includes(sel) || p.text.includes(sel.slice(0, 40)) || p.text.includes(sel.slice(-40))
    );
    if (hit.length > 0) {
      original = note.html.slice(hit[0].start, hit[hit.length - 1].end);
      whole = false;
    }
  }

  const { text, map } = protectBlocks(original);
  const scopeNote = whole && sel ? `\n\nAplique o pedido SOMENTE a este trecho da nota e deixe o resto igual: «${sel.slice(0, 600)}»` : '';
  const r = await generateJson<{ html?: unknown }>(
    apiKey,
    model,
    [{ text: `${CUSTOM_PROMPT}\n\nNOTA: ${title}\n\nPEDIDO: ${request.trim()}${scopeNote}\n\nHTML:\n${text}` }],
    CUSTOM_SCHEMA,
    180000,
    { kind: 'restructure', maxOutputTokens: 30000 }
  );
  if (!r.ok) return { proposals: [], failed: r.error.message };
  const clean = sanitizeAiHtml(typeof r.data?.html === 'string' ? r.data.html : '');
  const html = restoreBlocks(clean, map);
  if (!htmlToText(clean).trim() && map.length === 0) {
    return { proposals: [], failed: 'A IA não devolveu nada para esse pedido. Tente explicar de outro jeito.' };
  }
  if (html.replace(/\s+/g, '') === original.replace(/\s+/g, '')) {
    return { proposals: [], failed: null, empty: 'A IA não achou nada para mudar com esse pedido.' };
  }
  const ask = request.trim().replace(/\s+/g, ' ');
  return {
    proposals: [
      {
        id: `${blockId}:custom`,
        blockId,
        noteTitle: title,
        kind: 'custom',
        paragraph: 0,
        fingerprint: '',
        label: `${whole ? 'Aplicar na nota' : 'Aplicar no trecho'}: ${short(ask, 80)}`,
        preview: short(htmlToText(clean), 300),
        html,
        original,
        whole,
      },
    ],
    failed: null,
  };
}

// ---------- aplicar o que foi permitido ----------

function applyToHtml(html: string, props: Proposal[]): { html: string; applied: Set<string> } {
  const paras = plainParagraphs(html);
  const applied = new Set<string>();
  const byPara = new Map<number, Proposal[]>();
  for (const p of props) byPara.set(p.paragraph, [...(byPara.get(p.paragraph) ?? []), p]);
  // De trás para frente, para as posições anteriores continuarem valendo.
  const order = [...byPara.keys()].sort((x, y) => y - x);
  for (const idx of order) {
    const para = paras[idx];
    if (!para) continue;
    const group = (byPara.get(idx) ?? []).filter((p) => fp(para.text) === p.fingerprint); // nota mudou: não mexe
    if (group.length === 0) continue;
    const text = para.text;
    // Parágrafo sobrando: tira pontuação solta nas pontas e descarta se não sobrou nenhuma palavra.
    const pHtml = (t: string, trail = false) => {
      const c = trail ? t.replace(/^[\s.,;]+/, '').trim() : t.replace(/[,;\s]+$/, '').trim();
      return /[\p{L}\p{N}]/u.test(c) ? `<p>${escapeHtml(c)}</p>` : '';
    };
    let body: string | null = null; // substituição do próprio parágrafo (citação ou lista)
    let head = '';
    const done: string[] = [];

    for (const p of group) {
      if (p.kind === 'heading' && p.heading) {
        head = `<h2>${escapeHtml(p.heading)}</h2>`;
        done.push(p.id);
      } else if (body === null && p.kind === 'quote' && p.quote) {
        const i = text.indexOf(p.quote);
        if (i < 0) continue;
        body = pHtml(text.slice(0, i)) + `<blockquote>${escapeHtml(p.quote)}</blockquote>` + pHtml(text.slice(i + p.quote.length), true);
        done.push(p.id);
      } else if (body === null && (p.kind === 'list' || p.kind === 'todo') && p.items) {
        const pos = findSeq(text, p.items);
        if (!pos) continue;
        const items = p.items.map((x) => x.trim());
        const lis = items.map((it, k) => {
          let t = it;
          if (k < items.length - 1) {
            const gap = text.slice(pos[k] + it.length, pos[k + 1]).trim();
            if (gap.length > 40) t = `${it} ${gap}`; // conversa longa entre pontos: não perde texto
          }
          const li = escapeHtml(t.replace(/[,;.]+$/, '').trim());
          return p.kind === 'todo' ? `<li data-done="false">${li}</li>` : `<li>${li}</li>`;
        });
        const last = pos[items.length - 1] + items[items.length - 1].length;
        const tag = p.listKind === 'ol' ? 'ol' : 'ul';
        const open = p.kind === 'todo' ? '<ul class="todo">' : `<${tag}>`;
        body = pHtml(text.slice(0, pos[0])) + `${open}${lis.join('')}</${tag}>` + pHtml(text.slice(last), true);
        done.push(p.id);
      }
    }
    if (done.length === 0) continue;
    const repl = head + (body ?? html.slice(para.start, para.end));
    html = html.slice(0, para.start) + repl + html.slice(para.end);
    done.forEach((id) => applied.add(id));
  }
  return { html, applied };
}

/** Aplica só as sugestões permitidas. Devolve quantas foram aplicadas e quantas foram puladas. */
export async function applyProposals(allowed: Proposal[]): Promise<{ applied: number; skipped: number }> {
  const byNote = new Map<number, Proposal[]>();
  for (const p of allowed) byNote.set(p.blockId, [...(byNote.get(p.blockId) ?? []), p]);
  let applied = 0;
  for (const [blockId, all] of byNote) {
    const note = parseNote(await getNoteJson(blockId));
    if (!note) continue;
    const customs = all.filter((p) => p.kind === 'custom' && p.html !== undefined && p.original !== undefined);
    if (customs.length > 0) {
      const c = customs[0];
      let next: string | null = null;
      if (c.whole) next = note.html === c.original ? c.html! : null;
      else {
        const i = note.html.indexOf(c.original!);
        next = i < 0 ? null : note.html.slice(0, i) + c.html! + note.html.slice(i + c.original!.length);
      }
      if (next !== null) {
        await saveNoteJson(blockId, JSON.stringify({ ...note, html: next }));
        applied += 1;
      }
      continue;
    }
    const props = all;
    const r = applyToHtml(note.html, props);
    if (r.applied.size === 0) continue;
    await saveNoteJson(blockId, JSON.stringify({ ...note, html: r.html }));
    applied += r.applied.size;
  }
  notifyQueue(); // a nota aberta recarrega
  return { applied, skipped: allowed.length - applied };
}
