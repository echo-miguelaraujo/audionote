import { getNoteJson, listBlocks, saveNoteJson } from './db';
import { generateJson } from './gemini';
import { escapeHtml, noteDisplayTitle, parseNote } from './note';
import { notifyQueue } from './queue';
import { getSetting, loadGeminiSettings, setSetting } from './settings';

/**
 * Reorganização de notas existentes: a IA PROPÕE mudanças (citação, lista, subtítulo) e o app só
 * aplica as que o usuário permitir. O texto nunca é reescrito: citações e itens são trechos exatos
 * do parágrafo original; o único texto novo são os subtítulos.
 */

export type ProposalKind = 'quote' | 'list' | 'heading' | 'todo';

/** O que a IA faz: organizar o texto (citação, lista, subtítulo) ou achar tarefas ditas pela pessoa. */
export type SuggestMode = 'organize' | 'tasks';

export type Proposal = {
  id: string;
  blockId: number;
  noteTitle: string;
  kind: ProposalKind;
  /** Posição do parágrafo (só contam os parágrafos simples <p>texto</p>). */
  paragraph: number;
  /** Início do parágrafo no momento da análise, para conferir que a nota não mudou. */
  fingerprint: string;
  label: string;
  /** Trecho que será afetado (prévia). */
  preview: string;
  quote?: string;
  listKind?: 'ul' | 'ol' | 'todo';
  items?: string[];
  heading?: string;
};

// ---------- parágrafos simples ----------

type Para = { index: number; start: number; end: number; text: string };

const unesc = (s: string): string =>
  s.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&');

/** Parágrafos <p>texto</p> sem formatação interna (os únicos que o app mexe com segurança). */
function plainParagraphs(html: string): Para[] {
  const out: Para[] = [];
  const re = /<p>([^<]*)<\/p>/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html))) {
    const text = unesc(m[1]).replace(/\s+/g, ' ').trim();
    if (text) out.push({ index: out.length, start: m.index, end: m.index + m[0].length, text });
  }
  return out;
}

const PROMPT_VERSION = 2;
function hashStr(t: string): string {
  let h = 5381;
  for (let i = 0; i < t.length; i++) h = ((h << 5) + h + t.charCodeAt(i)) | 0;
  return `${t.length}:${h}`;
}

const fp = (t: string) => t.slice(0, 60);

// ---------- pedido ao Gemini ----------

const PROMPT =
  'Você organiza notas pessoais em português do Brasil (pregações, estudos, anotações) SEM reescrever nada. ' +
  'Recebe parágrafos numerados e devolve SUGESTÕES de melhoria de estrutura, de três tipos:\n\n' +
  '1. "quote" (citação): quando o parágrafo contém um texto que a pessoa LEU ou CITOU literalmente (versículo bíblico lido, trecho de livro, frase de alguém). ' +
  '"quote" é o texto citado (sem a frase que o introduz), dado só pelo começo e pelo fim: {"start": primeiras 4 a 6 palavras, "end": últimas 4 a 6 palavras}, copiadas letra por letra do parágrafo. Simples menção a um texto, sem as palavras dele, não é citação.\n' +
  '2. "list" (pontos): quando o parágrafo apresenta pontos bem definidos e reconhecíveis (os pontos de uma mensagem, motivos, passos, características). ' +
  '"items" são os pontos, na ordem em que aparecem, sem os marcadores falados ("primeiro", "o segundo ponto é"). Cada ponto é {"start","end"}: primeiras e últimas 4 a 6 palavras dele, copiadas letra por letra do parágrafo (ponto curto: o trecho todo nos dois). ' +
  '"list_kind" é "ol" se a pessoa numerou ou ordenou os pontos, senão "ul". Mínimo 2 itens. Na dúvida, não sugira.\n' +
  '3. "heading" (subtítulo): quando começa um assunto ou subtópico novo e específico. "paragraph" é o parágrafo ANTES do qual o subtítulo entra e "heading" é um subtítulo curto e específico (2 a 5 palavras, sem ponto final). ' +
  'A pessoa quer achar cada parte de um texto grande: em notas longas, sugira de 3 a 4 subtítulos ao longo do texto, no mínimo (mais se houver mais assuntos), distribuídos de forma a não deixar mais de 3 ou 4 parágrafos seguidos sem subtítulo. ' +
  'Não repita subtítulos que a nota já tem (aparecem como [título]); conte os que já existem e sugira só os que faltam, sem colocar dois subtítulos colados.\n\n' +
  'Regras: "paragraph" é o número entre colchetes. No máximo UMA sugestão "quote" ou "list" por parágrafo. Não invente texto. ' +
  'Seja criterioso: sugira só o que melhora de verdade a leitura. Se não houver nada, devolva a lista vazia.';

/** A IA devolve só o começo e o fim do trecho (menos tokens de saída); o app recorta o texto exato do parágrafo. */
const SPAN_SCHEMA = {
  type: 'OBJECT',
  properties: { start: { type: 'STRING' }, end: { type: 'STRING' } },
  required: ['start', 'end'],
};

const SCHEMA = {
  type: 'OBJECT',
  properties: {
    suggestions: {
      type: 'ARRAY',
      items: {
        type: 'OBJECT',
        properties: {
          type: { type: 'STRING' },
          paragraph: { type: 'INTEGER' },
          quote: SPAN_SCHEMA,
          list_kind: { type: 'STRING' },
          items: { type: 'ARRAY', items: SPAN_SCHEMA },
          heading: { type: 'STRING' },
        },
        required: ['type', 'paragraph'],
      },
    },
  },
  required: ['suggestions'],
};

const TASKS_PROMPT =
  'Você ajuda a achar TAREFAS em notas pessoais em português do Brasil, SEM reescrever nada. ' +
  'Recebe parágrafos numerados. Sugira transformar em lista de tarefas os parágrafos em que a pessoa DISSE ações ou pendências que ela mesma pretende fazer ' +
  '(por exemplo \"preciso ligar para\", \"tenho que\", \"não esquecer de\", \"vou enviar\"). ' +
  'Cada sugestão é do tipo \"todo\", com \"paragraph\" (o número entre colchetes) e \"items\": cada item é o MENOR trecho do parágrafo que expresse uma ação, na ordem em que aparece, dado como {\"start\",\"end\"}: primeiras e últimas 4 a 6 palavras dele, copiadas letra por letra (trecho curto: o trecho todo nos dois). ' +
  'Não invente tarefas, não acrescente palavras, não use datas que a pessoa não disse. No máximo UMA sugestão por parágrafo, com pelo menos 1 item. ' +
  'Opiniões, relatos, explicações e ideias gerais não são tarefas. Na dúvida, não sugira. Se não houver nenhuma tarefa, devolva a lista vazia.';

const CHUNK_CHARS = 28000;
const RESTRUCTURE_OUTPUT_BUDGET = 12000;

function findSeq(text: string, items: string[]): number[] | null {
  const pos: number[] = [];
  let from = 0;
  for (const it of items) {
    const i = text.indexOf(it.trim(), from);
    if (i < 0 || !it.trim()) return null;
    pos.push(i);
    from = i + it.trim().length;
  }
  return pos;
}

/** Âncora {start,end} -> trecho exato do texto, a partir de `from`. Aceita também texto direto. */
function resolveSpan(text: string, a: any, from = 0): { text: string; end: number } | null {
  if (typeof a === 'string') {
    const t = a.trim();
    const i = t ? text.indexOf(t, from) : -1;
    return i < 0 ? null : { text: t, end: i + t.length };
  }
  const st = typeof a?.start === 'string' ? a.start.trim() : '';
  const en = typeof a?.end === 'string' && a.end.trim() ? a.end.trim() : st;
  if (!st) return null;
  const i = text.indexOf(st, from);
  if (i < 0) return null;
  const k = text.indexOf(en, i);
  if (k < 0) return null;
  const j = Math.max(k + en.length, i + st.length);
  return { text: text.slice(i, j), end: j };
}

function resolveItems(text: string, raw: unknown): string[] {
  const out: string[] = [];
  let from = 0;
  for (const a of Array.isArray(raw) ? raw : []) {
    const r = resolveSpan(text, a, from);
    if (!r) return [];
    out.push(r.text);
    from = r.end;
  }
  return out;
}

const short = (t: string, n = 140) => (t.length > n ? `${t.slice(0, n).trim()}…` : t);

function clean(raw: any, blockId: number, noteTitle: string, paras: Para[], scope: Set<number> | null): Proposal[] {
  const out: Proposal[] = [];
  const usedText = new Set<number>();
  const usedHead = new Set<number>();
  for (const s of Array.isArray(raw) ? raw : []) {
    const idx = Number(s?.paragraph);
    const para = paras[idx];
    if (!para || (scope && !scope.has(idx))) continue;
    const base = { blockId, noteTitle, paragraph: idx, fingerprint: fp(para.text) };
    const id = `${blockId}:${out.length}`;
    if (s.type === 'quote') {
      const q = resolveSpan(para.text, s.quote)?.text ?? '';
      if (!q || usedText.has(idx) || !para.text.includes(q)) continue;
      usedText.add(idx);
      out.push({ ...base, id, kind: 'quote', label: 'Virar citação', preview: short(q), quote: q });
    } else if (s.type === 'list') {
      const items = resolveItems(para.text, s.items);
      if (items.length < 2 || usedText.has(idx) || !findSeq(para.text, items)) continue;
      usedText.add(idx);
      const ordered = s.list_kind === 'ol';
      out.push({
        ...base,
        id,
        kind: 'list',
        label: `Virar lista ${ordered ? 'numerada' : 'com marcadores'} (${items.length} pontos)`,
        preview: items.map((x, i) => `${ordered ? `${i + 1}.` : '•'} ${short(x, 70)}`).join('\n'),
        listKind: ordered ? 'ol' : 'ul',
        items,
      });
    } else if (s.type === 'todo') {
      const items = resolveItems(para.text, s.items);
      if (items.length < 1 || usedText.has(idx) || !findSeq(para.text, items)) continue;
      usedText.add(idx);
      out.push({
        ...base,
        id,
        kind: 'todo',
        label: `Virar lista de tarefas (${items.length} ${items.length === 1 ? 'tarefa' : 'tarefas'})`,
        preview: items.map((x) => `☐ ${short(x, 70)}`).join('\n'),
        listKind: 'todo',
        items,
      });
    } else if (s.type === 'heading') {
      const h = typeof s.heading === 'string' ? s.heading.trim().replace(/[.\s]+$/, '') : '';
      if (!h || usedHead.has(idx)) continue;
      usedHead.add(idx);
      out.push({ ...base, id, kind: 'heading', label: `Novo subtítulo: ${h}`, preview: short(para.text, 90), heading: h });
    }
  }
  return out;
}

/** Analisa uma nota e devolve as sugestões (nada é alterado). */
export async function proposeForNote(
  blockId: number,
  apiKey: string,
  model: string,
  opts: { mode?: SuggestMode; selection?: string } = {}
): Promise<{ ok: true; proposals: Proposal[] } | { ok: false; message: string }> {
  const mode: SuggestMode = opts.mode ?? 'organize';
  const note = parseNote(await getNoteJson(blockId));
  if (!note) return { ok: true, proposals: [] };
  const paras = plainParagraphs(note.html);
  if (paras.length === 0) return { ok: true, proposals: [] };
  const title = noteDisplayTitle(note) || 'Nota';
  const mode0: SuggestMode = opts.mode ?? 'organize';
  // Nota curta não tem o que organizar. Nota que já deu zero sugestões e não mudou: não gasta de novo.
  if (mode0 === 'organize' && !opts.selection && paras.reduce((n, p) => n + p.text.length, 0) < 300) return { ok: true, proposals: [] };
  const noneKey = `restructure_none_${blockId}_${mode0}`;
  const stamp = hashStr(`${PROMPT_VERSION}|${title}|${note.html}`);
  if (!opts.selection && (await getSetting(noneKey)) === stamp) return { ok: true, proposals: [] };

  // Com um trecho selecionado, só os parágrafos que ele toca entram na análise.
  const sel = (opts.selection ?? '').replace(/\s+/g, ' ').trim();
  const scope: Set<number> | null = sel
    ? new Set(
        paras
          .filter(
            (p) =>
              sel.includes(p.text) ||
              p.text.includes(sel) ||
              p.text.includes(sel.slice(0, 40)) ||
              p.text.includes(sel.slice(-40))
          )
          .map((p) => p.index)
      )
    : null;
  if (scope && scope.size === 0) return { ok: true, proposals: [] };
  const target = scope ? paras.filter((p) => scope.has(p.index)) : paras;

  // Linhas numeradas, com os títulos existentes intercalados como [título].
  const heads = Array.from(note.html.matchAll(/<h[1-5][^>]*>([\s\S]*?)<\/h[1-5]>/gi)).map((m) => ({
    pos: m.index ?? 0,
    text: unesc(m[1].replace(/<[^>]+>/g, '')).trim(),
  }));
  const lines: { chars: number; text: string; paraIndex: number }[] = [];
  let h = 0;
  for (const p of target) {
    while (h < heads.length && heads[h].pos < p.start) {
      lines.push({ chars: heads[h].text.length, text: `[título] ${heads[h].text}`, paraIndex: -1 });
      h++;
    }
    lines.push({ chars: p.text.length, text: `[${p.index}] ${p.text}`, paraIndex: p.index });
  }
  const chunks: string[] = [];
  let cur = '';
  for (const l of lines) {
    if (cur && cur.length + l.text.length > CHUNK_CHARS && l.paraIndex >= 0) {
      chunks.push(cur);
      cur = '';
    }
    cur += l.text + '\n\n';
  }
  if (cur) chunks.push(cur);

  const raw: any[] = [];
  for (const c of chunks) {
    const r = await generateJson<{ suggestions?: unknown }>(
      apiKey,
      model,
      [{ text: `${mode === 'tasks' ? TASKS_PROMPT : PROMPT}\n\nNOTA: ${title}\n\n${c}` }],
      SCHEMA,
      120000,
      { kind: 'restructure', maxOutputTokens: RESTRUCTURE_OUTPUT_BUDGET }
    );
    if (!r.ok) return { ok: false, message: r.error.message };
    if (Array.isArray(r.data?.suggestions)) raw.push(...(r.data.suggestions as any[]));
  }
  const proposals = clean(raw, blockId, title, paras, scope);
  if (!opts.selection) await setSetting(noneKey, proposals.length === 0 ? stamp : '').catch(() => {});
  return { ok: true, proposals };
}

export type AnalyzeResult = { proposals: Proposal[]; analyzed: number; failed: string | null };

/** Analisa várias notas (ou todas), uma de cada vez. Para no primeiro erro de rede/cota. */
export async function proposeForNotes(
  blockIds: number[] | 'all',
  onProgress?: (done: number, total: number) => void,
  opts: { mode?: SuggestMode; selection?: string } = {}
): Promise<AnalyzeResult> {
  const { apiKey, model } = await loadGeminiSettings();
  if (!apiKey.trim()) return { proposals: [], analyzed: 0, failed: 'Coloque a chave do Gemini em Configurações.' };
  const ids = blockIds === 'all' ? (await listBlocks()).map((b) => b.id) : blockIds;
  const proposals: Proposal[] = [];
  let analyzed = 0;
  for (const id of ids) {
    onProgress?.(analyzed, ids.length);
    const r = await proposeForNote(id, apiKey, model, opts);
    if (!r.ok) return { proposals, analyzed, failed: r.message };
    proposals.push(...r.proposals);
    analyzed++;
  }
  onProgress?.(analyzed, ids.length);
  return { proposals, analyzed, failed: null };
}

// ---------- aplicar o que foi permitido ----------

function applyToHtml(html: string, props: Proposal[]): { html: string; applied: Set<string> } {
  const paras = plainParagraphs(html);
  const applied = new Set<string>();
  const byPara = new Map<number, Proposal[]>();
  for (const p of props) byPara.set(p.paragraph, [...(byPara.get(p.paragraph) ?? []), p]);
  // De trás para frente, para as posições anteriores continuarem valendo.
  const order = [...byPara.keys()].sort((x, y) => y - x);
  for (const idx of order) {
    const para = paras[idx];
    if (!para) continue;
    const group = (byPara.get(idx) ?? []).filter((p) => fp(para.text) === p.fingerprint); // nota mudou: não mexe
    if (group.length === 0) continue;
    const text = para.text;
    // Parágrafo sobrando: tira pontuação solta nas pontas e descarta se não sobrou nenhuma palavra.
    const pHtml = (t: string, trail = false) => {
      const c = trail ? t.replace(/^[\s.,;]+/, '').trim() : t.replace(/[,;\s]+$/, '').trim();
      return /[\p{L}\p{N}]/u.test(c) ? `<p>${escapeHtml(c)}</p>` : '';
    };
    let body: string | null = null; // substituição do próprio parágrafo (citação ou lista)
    let head = '';
    const done: string[] = [];

    for (const p of group) {
      if (p.kind === 'heading' && p.heading) {
        head = `<h2>${escapeHtml(p.heading)}</h2>`;
        done.push(p.id);
      } else if (body === null && p.kind === 'quote' && p.quote) {
        const i = text.indexOf(p.quote);
        if (i < 0) continue;
        body = pHtml(text.slice(0, i)) + `<blockquote>${escapeHtml(p.quote)}</blockquote>` + pHtml(text.slice(i + p.quote.length), true);
        done.push(p.id);
      } else if (body === null && (p.kind === 'list' || p.kind === 'todo') && p.items) {
        const pos = findSeq(text, p.items);
        if (!pos) continue;
        const items = p.items.map((x) => x.trim());
        const lis = items.map((it, k) => {
          let t = it;
          if (k < items.length - 1) {
            const gap = text.slice(pos[k] + it.length, pos[k + 1]).trim();
            if (gap.length > 40) t = `${it} ${gap}`; // conversa longa entre pontos: não perde texto
          }
          const li = escapeHtml(t.replace(/[,;.]+$/, '').trim());
          return p.kind === 'todo' ? `<li data-done="false">${li}</li>` : `<li>${li}</li>`;
        });
        const last = pos[items.length - 1] + items[items.length - 1].length;
        const tag = p.listKind === 'ol' ? 'ol' : 'ul';
        const open = p.kind === 'todo' ? '<ul class="todo">' : `<${tag}>`;
        body = pHtml(text.slice(0, pos[0])) + `${open}${lis.join('')}</${tag}>` + pHtml(text.slice(last), true);
        done.push(p.id);
      }
    }
    if (done.length === 0) continue;
    const repl = head + (body ?? html.slice(para.start, para.end));
    html = html.slice(0, para.start) + repl + html.slice(para.end);
    done.forEach((id) => applied.add(id));
  }
  return { html, applied };
}

/** Aplica só as sugestões permitidas. Devolve quantas foram aplicadas e quantas foram puladas. */
export async function applyProposals(allowed: Proposal[]): Promise<{ applied: number; skipped: number }> {
  const byNote = new Map<number, Proposal[]>();
  for (const p of allowed) byNote.set(p.blockId, [...(byNote.get(p.blockId) ?? []), p]);
  let applied = 0;
  for (const [blockId, props] of byNote) {
    const note = parseNote(await getNoteJson(blockId));
    if (!note) continue;
    const r = applyToHtml(note.html, props);
    if (r.applied.size === 0) continue;
    await saveNoteJson(blockId, JSON.stringify({ ...note, html: r.html }));
    applied += r.applied.size;
  }
  notifyQueue(); // a nota aberta recarrega
  return { applied, skipped: allowed.length - applied };
}
