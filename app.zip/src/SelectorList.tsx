import React, {
  forwardRef,
  useCallback,
  useEffect,
  useImperativeHandle,
  useMemo,
  useRef,
  useState,
} from 'react';
import {
  Animated,
  LayoutChangeEvent,
  Pressable,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
} from 'react-native';
import { colors, fonts } from './theme';

export type SelItem = { id: number; title: string; subtitle: string; color?: string | null };

export type SelectorHandle = {
  scrollToIndex: (index: number, animated?: boolean) => void;
};

type Props = {
  data: SelItem[];
  initialIndex?: number;
  emptyText: string;
  onFocusIndex: (index: number) => void;
  onPressFocused: (item: SelItem, index: number) => void;
  onLongPressFocused: (item: SelItem, index: number) => void;
};

const DIM_SCALE = 0.88;

export const SelectorList = forwardRef<SelectorHandle, Props>(function SelectorList(
  { data, initialIndex = 0, emptyText, onFocusIndex, onPressFocused, onLongPressFocused },
  ref
) {
  const { width: sw } = useWindowDimensions();
  const itemH = Math.round(sw * 0.2);
  const textW = sw * 0.88;
  const padLeft = sw * 0.106; // espaço à esquerda para a barrinha da categoria
  const dimTx = -textW * ((1 - DIM_SCALE) / 2) + sw * 0.003; // itens apagados alinham com o focado
  const titleSize = sw * 0.072;
  const subSize = sw * 0.046;

  const [h, setH] = useState(0);
  const scrollY = useRef(new Animated.Value(0)).current;
  const listRef = useRef<any>(null);
  const lastIdx = useRef(initialIndex);
  const dataRef = useRef(data);
  dataRef.current = data;
  const onFocusRef = useRef(onFocusIndex);
  onFocusRef.current = onFocusIndex;
  const didInitialScroll = useRef(false);

  const scrollToIndex = useCallback(
    (index: number, animated = true) => {
      const i = Math.max(0, Math.min(index, dataRef.current.length - 1));
      listRef.current?.scrollToOffset({ offset: i * itemH, animated });
    },
    [itemH]
  );

  useImperativeHandle(ref, () => ({ scrollToIndex }), [scrollToIndex]);

  useEffect(() => {
    if (h > 0 && data.length > 0 && !didInitialScroll.current) {
      didInitialScroll.current = true;
      const t = setTimeout(() => scrollToIndex(initialIndex, false), 50);
      return () => clearTimeout(t);
    }
  }, [h, data.length, initialIndex, scrollToIndex]);

  const onScroll = useMemo(
    () =>
      Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], {
        useNativeDriver: true,
        listener: (e: any) => {
          const max = Math.max(0, dataRef.current.length - 1);
          const i = Math.max(0, Math.min(max, Math.round(e.nativeEvent.contentOffset.y / itemH)));
          if (i !== lastIdx.current) {
            lastIdx.current = i;
            onFocusRef.current(i);
          }
        },
      }),
    [scrollY, itemH]
  );

  const renderItem = ({ item, index }: { item: SelItem; index: number }) => {
    const input = [(index - 1) * itemH, index * itemH, (index + 1) * itemH];
    const scale = scrollY.interpolate({
      inputRange: input,
      outputRange: [DIM_SCALE, 1, DIM_SCALE],
      extrapolate: 'clamp',
    });
    const opacity = scrollY.interpolate({
      inputRange: input,
      outputRange: [0.2, 1, 0.2],
      extrapolate: 'clamp',
    });
    const tx = scrollY.interpolate({
      inputRange: input,
      outputRange: [dimTx, 0, dimTx],
      extrapolate: 'clamp',
    });
    return (
      <Pressable
        style={{ height: itemH, paddingLeft: padLeft, justifyContent: 'center' }}
        onPress={() => {
          if (index === lastIdx.current) onPressFocused(item, index);
          else scrollToIndex(index, true);
        }}
        onLongPress={() => {
          if (index === lastIdx.current) onLongPressFocused(item, index);
        }}
      >
        <Animated.View
          style={{ width: textW, opacity, transform: [{ translateX: tx }, { scale }] }}
        >
          {item.color ? (
            <View
              style={{
                position: 'absolute',
                left: -sw * 0.03,
                top: 0,
                bottom: 0,
                width: sw * 0.014,
                borderRadius: sw * 0.007,
                backgroundColor: item.color,
              }}
            />
          ) : null}
          <Text
            numberOfLines={1}
            style={{
              color: colors.text,
              fontFamily: fonts.bold,
              fontSize: titleSize,
              lineHeight: titleSize * 1.12,
              letterSpacing: -titleSize * 0.045,
            }}
          >
            {item.title}
          </Text>
          <Text
            numberOfLines={1}
            style={{
              color: colors.text,
              fontFamily: fonts.light,
              fontSize: subSize,
              lineHeight: subSize * 1.2,
              letterSpacing: -subSize * 0.03,
            }}
          >
            {item.subtitle}
          </Text>
        </Animated.View>
      </Pressable>
    );
  };

  return (
    <View style={styles.flex} onLayout={(e: LayoutChangeEvent) => setH(e.nativeEvent.layout.height)}>
      {h > 0 && (
        <Animated.FlatList
          ref={listRef}
          data={data}
          keyExtractor={(it: SelItem) => String(it.id)}
          renderItem={renderItem as any}
          getItemLayout={(_: any, index: number) => ({
            length: itemH,
            offset: itemH * index,
            index,
          })}
          onScroll={onScroll}
          scrollEventThrottle={16}
          snapToInterval={itemH}
          snapToAlignment="start"
          decelerationRate="fast"
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingVertical: Math.max(0, (h - itemH) / 2) }}
        />
      )}
      {data.length === 0 && (
        <View style={styles.empty} pointerEvents="none">
          <Text style={styles.emptyText}>{emptyText}</Text>
        </View>
      )}
    </View>
  );
});

const styles = StyleSheet.create({
  flex: { flex: 1 },
  empty: {
    ...StyleSheet.absoluteFillObject,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 40,
  },
  emptyText: {
    color: colors.gray,
    fontFamily: fonts.light,
    fontSize: 18,
    textAlign: 'center',
  },
});
