import React, { useState } from 'react';
import { Modal, Pressable, Text, View, useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors, fonts, TYPE } from './theme';

export type MenuItem = {
  key: string;
  label: string;
  /** Texto pequeno à direita (ex.: nº de coleções vinculadas). */
  hint?: string;
  /** Destaca o item em vermelho (estado ativo). */
  active?: boolean;
  disabled?: boolean;
  onPress: () => void;
};

/** Botão "⋯" (três pontos desenhados com Views, iguais em qualquer aparelho). */
export function MoreButton({ onPress, badge }: { onPress: () => void; badge?: boolean }) {
  const { width: sw } = useWindowDimensions();
  const dot = sw * 0.011;
  return (
    <Pressable
      onPress={onPress}
      hitSlop={14}
      accessibilityRole="button"
      accessibilityLabel="Mais opções"
      style={{ flexDirection: 'row', alignItems: 'center', gap: dot * 1.1, paddingHorizontal: sw * 0.01 }}
    >
      {[0, 1, 2].map((i) => (
        <View
          key={i}
          style={{ width: dot, height: dot, borderRadius: dot / 2, backgroundColor: badge ? colors.red : colors.onDark }}
        />
      ))}
    </Pressable>
  );
}

/**
 * Menu suspenso do topo direito: some ao tocar fora, fecha ao escolher um item.
 * Padrão dos apps de notas: poucas ações à vista, o resto agrupado aqui.
 */
export function OverflowMenu({
  visible,
  onClose,
  items,
}: {
  visible: boolean;
  onClose: () => void;
  items: MenuItem[];
}) {
  const { width: sw } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const [pressed, setPressed] = useState<string | null>(null);

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose} statusBarTranslucent>
      <Pressable style={{ flex: 1 }} onPress={onClose} accessibilityLabel="Fechar menu">
        <View
          style={{
            position: 'absolute',
            top: insets.top + sw * 0.13,
            right: sw * 0.04,
            minWidth: sw * 0.56,
            backgroundColor: colors.surface,
            borderRadius: 16,
            borderWidth: 1,
            borderColor: colors.lineDark,
            paddingVertical: 6,
            elevation: 12,
            shadowColor: '#000',
            shadowOpacity: 0.6,
            shadowRadius: 18,
            shadowOffset: { width: 0, height: 8 },
          }}
        >
          {items.map((it) => (
            <Pressable
              key={it.key}
              disabled={it.disabled}
              onPressIn={() => setPressed(it.key)}
              onPressOut={() => setPressed(null)}
              onPress={() => {
                onClose();
                it.onPress();
              }}
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: sw * 0.04,
                paddingVertical: sw * 0.035,
                paddingHorizontal: sw * 0.05,
                backgroundColor: pressed === it.key ? '#2A2A2C' : 'transparent',
                opacity: it.disabled ? 0.4 : 1,
              }}
            >
              <Text
                style={{
                  color: it.active ? colors.red : colors.onDark,
                  fontFamily: fonts.bold,
                  fontSize: sw * TYPE.body,
                  letterSpacing: -0.4,
                }}
              >
                {it.label}
              </Text>
              {!!it.hint && (
                <Text style={{ color: colors.red, fontFamily: fonts.bold, fontSize: sw * TYPE.caption }}>{it.hint}</Text>
              )}
            </Pressable>
          ))}
        </View>
      </Pressable>
    </Modal>
  );
}
