import React, { useState } from 'react';
import { Pressable, Text, View, useWindowDimensions } from 'react-native';
import { Icon } from './Icon';
import { colors, fonts, LEADING, MIN_TOUCH, SPACE, TYPE } from './theme';

/**
 * Grupo das Configurações: título pequeno em cima e, embaixo, os itens separados por uma linha fina.
 * Cada filho direto vira um item (filhos vazios são ignorados).
 */
export function SettingsGroup({ title, children }: { title: string; children: React.ReactNode }) {
  const { width: sw } = useWindowDimensions();
  const items = React.Children.toArray(children);
  if (items.length === 0) return null;

  return (
    <View style={{ marginTop: sw * SPACE.xl }}>
      <Text
        accessibilityRole="header"
        style={{ color: colors.muted, fontFamily: fonts.bold, fontSize: sw * TYPE.caption, letterSpacing: 1, textTransform: 'uppercase' }}
      >
        {title}
      </Text>
      <View style={{ marginTop: sw * SPACE.sm, borderTopWidth: 1, borderTopColor: colors.lineDark }}>
        {items.map((child, i) => (
          <View
            key={i}
            style={{
              paddingVertical: sw * SPACE.md,
              borderTopWidth: i === 0 ? 0 : 1,
              borderTopColor: colors.lineDark,
            }}
          >
            {child}
          </View>
        ))}
      </View>
    </View>
  );
}

type CollapsibleProps = {
  title: string;
  /** Uma linha explicando para que serve; aparece mesmo com a seção fechada. */
  subtitle?: string;
  children: React.ReactNode;
};

/**
 * Seção que começa fechada: só título e subtítulo. Ao tocar, mostra o conteúdo.
 * O conteúdo continua montado quando fechado, então o que foi digitado não se perde.
 */
export function Collapsible({ title, subtitle, children }: CollapsibleProps) {
  const { width: sw } = useWindowDimensions();
  const [open, setOpen] = useState(false);

  return (
    <View>
      <Pressable
        onPress={() => setOpen((v) => !v)}
        accessibilityRole="button"
        accessibilityLabel={title}
        accessibilityState={{ expanded: open }}
        style={{ minHeight: MIN_TOUCH, flexDirection: 'row', alignItems: 'center', gap: sw * SPACE.md }}
      >
        <View style={{ flex: 1 }}>
          <Text style={{ color: colors.text, fontFamily: fonts.regular, fontSize: sw * TYPE.body }}>{title}</Text>
          {!!subtitle && (
            <Text
              style={{
                marginTop: sw * SPACE.xs,
                color: colors.muted,
                fontFamily: fonts.regular,
                fontSize: sw * TYPE.caption,
                lineHeight: sw * TYPE.caption * LEADING,
              }}
            >
              {subtitle}
            </Text>
          )}
        </View>
        <Icon name={open ? 'minus' : 'plus'} size={sw * 0.05} color={colors.muted} />
      </Pressable>
      <View style={{ display: open ? 'flex' : 'none', marginTop: sw * SPACE.md }}>{children}</View>
    </View>
  );
}
