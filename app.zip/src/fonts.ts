import { useSyncExternalStore } from 'react';
import { Directory, File, Paths } from 'expo-file-system';
import * as Font from 'expo-font';
import { getSetting, setSetting } from './settings';

/**
 * Fontes do Google Fonts guardadas no aparelho ("Minhas fontes").
 *
 * - Os arquivos .ttf ficam em Documents/fonts; a lista fica na tabela `meta` (só deste aparelho).
 * - Nas WebViews dos editores (notas e texto do moodboard) a fonte entra por @font-face (`webFonts`).
 * - No quadro (React Native) a fonte é registrada com expo-font (`nativeFontName`).
 * - Nos textos fica só `font-family:'Nome da fonte'`; em outro aparelho sem a fonte, cai na fonte padrão.
 */

export type FontFace = { weight: 400 | 700; italic: boolean; file: string };
export type SavedFont = { family: string; faces: FontFace[] };

const KEY = 'fonts_v1';
/** O CSS do Google só devolve .ttf (arquivo inteiro, sem recortes de alfabeto) para navegadores antigos. */
const OLD_UA =
  'Mozilla/5.0 (Linux; U; Android 4.0.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30';

let saved: SavedFont[] = [];
let version = 0;
let initPromise: Promise<void> | null = null;
const listeners = new Set<() => void>();
/** família -> nome registrado no expo-font por variação (r, b, i, bi). */
const nativeNames = new Map<string, Partial<Record<'r' | 'b' | 'i' | 'bi', string>>>();

function notify() {
  version++;
  listeners.forEach((l) => l());
}

export function subscribeFonts(cb: () => void): () => void {
  listeners.add(cb);
  return () => {
    listeners.delete(cb);
  };
}

/** Re-renderiza o componente quando a lista de fontes (ou o carregamento delas) muda. */
export function useFontsVersion(): number {
  return useSyncExternalStore(subscribeFonts, () => version);
}

export function useSavedFonts(): SavedFont[] {
  useFontsVersion();
  return saved;
}

export const listFonts = (): SavedFont[] => saved;

function fontsDir(): Directory {
  const dir = new Directory(Paths.document, 'fonts');
  if (!dir.exists) dir.create({ idempotent: true, intermediates: true });
  return dir;
}

function fileUri(name: string): string {
  const u = fontsDir().uri;
  return `${u.endsWith('/') ? u : `${u}/`}${name}`;
}

const slugOf = (family: string) => family.replace(/[^A-Za-z0-9]+/g, '_');
const keyOf = (f: FontFace): 'r' | 'b' | 'i' | 'bi' => (f.weight === 700 ? (f.italic ? 'bi' : 'b') : f.italic ? 'i' : 'r');

/** Nome de família seguro: o Google só usa letras, números e espaços. */
export const isValidFamily = (s: string): boolean => /^[A-Za-z0-9][A-Za-z0-9 ]{0,59}$/.test(s);

/**
 * Endereço do Google Fonts -> nome da família, quando for a página de uma fonte
 * (ex.: https://fonts.google.com/specimen/Roboto+Slab?query=roboto). Outras páginas: null.
 */
export function familyFromUrl(url: string): string | null {
  const m = /^https?:\/\/fonts\.google\.com\/specimen\/([^/?#]+)/i.exec(url);
  if (!m) return null;
  try {
    const name = decodeURIComponent(m[1].replace(/\+/g, ' ')).trim();
    return isValidFamily(name) ? name : null;
  } catch {
    return null;
  }
}

async function persist() {
  await setSetting(KEY, saved.length ? JSON.stringify(saved) : '');
}

async function registerNative(f: SavedFont) {
  const names: Partial<Record<'r' | 'b' | 'i' | 'bi', string>> = {};
  const map: Record<string, { uri: string }> = {};
  for (const face of f.faces) {
    const k = keyOf(face);
    const name = `gf_${slugOf(f.family)}_${k}`;
    names[k] = name;
    map[name] = { uri: fileUri(face.file) };
  }
  try {
    await Font.loadAsync(map);
    nativeNames.set(f.family, names);
  } catch {
    // arquivo corrompido: o texto cai na fonte padrão
  }
}

/** Lê a lista guardada e registra as fontes no app. Chame uma vez ao abrir. */
export function initFonts(): Promise<void> {
  if (!initPromise) {
    initPromise = (async () => {
      try {
        const raw = await getSetting(KEY);
        const list: SavedFont[] = raw ? JSON.parse(raw) : [];
        const dir = fontsDir();
        saved = list.filter(
          (f) =>
            f &&
            isValidFamily(f.family) &&
            Array.isArray(f.faces) &&
            f.faces.length > 0 &&
            f.faces.every((x) => x && /^[\w.-]+\.ttf$/.test(x.file) && new File(dir, x.file).exists)
        );
        notify();
        for (const f of saved) await registerNative(f);
      } catch {
        // sem fontes salvas
      }
      notify();
    })();
  }
  return initPromise;
}

/** Nome para usar em `fontFamily` do React Native (ou undefined se a fonte não está neste aparelho). */
export function nativeFontName(family: string, bold: boolean, italic: boolean): string | undefined {
  const n = nativeNames.get(family);
  if (!n) return undefined;
  const order = bold && italic ? ['bi', 'i', 'b', 'r'] : bold ? ['b', 'r'] : italic ? ['i', 'r'] : ['r'];
  for (const k of order) {
    const v = n[k as 'r'];
    if (v) return v;
  }
  return n.r ?? n.b ?? n.i ?? n.bi;
}

/** CSS (@font-face) e nomes das fontes salvas, para as WebViews. */
export function webFonts(): { css: string; list: string[] } {
  const css = saved
    .flatMap((f) =>
      f.faces.map(
        (x) =>
          `@font-face{font-family:'${f.family}';font-style:${x.italic ? 'italic' : 'normal'};font-weight:${x.weight};src:url('${fileUri(x.file)}') format('truetype');font-display:swap}`
      )
    )
    .join('\n');
  return { css, list: saved.map((f) => f.family) };
}

/** Texto da mensagem para o editor: `window.setFonts(...)`. */
export function setFontsScript(): string {
  const p = JSON.stringify(webFonts()).split('\u2028').join('\\u2028').split('\u2029').join('\\u2029');
  return `window.setFonts&&window.setFonts(${p});true;`;
}

/** @font-face com os arquivos embutidos (base64), só das famílias usadas no HTML — para o PDF da nota. */
export async function embeddedFontCss(html: string): Promise<string> {
  const out: string[] = [];
  for (const f of saved) {
    if (!html.includes(f.family)) continue;
    for (const x of f.faces) {
      try {
        const b64 = await new File(fontsDir(), x.file).base64();
        out.push(
          `@font-face{font-family:'${f.family}';font-style:${x.italic ? 'italic' : 'normal'};font-weight:${x.weight};src:url(data:font/ttf;base64,${b64}) format('truetype')}`
        );
      } catch {
        // ignora o arquivo que não abriu
      }
    }
  }
  return out.join('\n');
}

type Parsed = { weight: 400 | 700; italic: boolean; url: string };

function parseCss(css: string): Parsed[] {
  const out: Parsed[] = [];
  for (const m of css.matchAll(/@font-face\s*\{([^}]*)\}/g)) {
    const body = m[1];
    const url = /url\(\s*['"]?(https:\/\/fonts\.gstatic\.com\/[^)'"\s]+)['"]?\s*\)/i.exec(body)?.[1];
    if (!url) continue;
    const w = parseInt(/font-weight\s*:\s*(\d+)/i.exec(body)?.[1] ?? '400', 10);
    const italic = /font-style\s*:\s*italic/i.test(body);
    out.push({ weight: w >= 600 ? 700 : 400, italic, url });
  }
  return out;
}

async function fetchCss(family: string): Promise<Parsed[]> {
  const fam = encodeURIComponent(family).replace(/%20/g, '+');
  const tries = [
    `family=${fam}:ital,wght@0,400;0,700;1,400;1,700`,
    `family=${fam}:wght@400;700`,
    `family=${fam}`,
  ];
  for (const q of tries) {
    try {
      const res = await fetch(`https://fonts.googleapis.com/css2?${q}&display=swap`, { headers: { 'User-Agent': OLD_UA } });
      if (!res.ok) continue;
      const faces = parseCss(await res.text());
      if (faces.length > 0) return faces;
    } catch {
      // tenta o próximo formato do pedido
    }
  }
  return [];
}

function looksLikeFont(b: Uint8Array): boolean {
  if (b.length < 4) return false;
  const tag = String.fromCharCode(b[0], b[1], b[2], b[3]);
  return tag === 'OTTO' || tag === 'true' || tag === 'ttcf' || (b[0] === 0 && b[1] === 1 && b[2] === 0 && b[3] === 0);
}

/** Baixa a fonte do Google Fonts para o aparelho e coloca em "Minhas fontes". Lança erro se falhar. */
export async function downloadGoogleFont(family: string): Promise<SavedFont> {
  if (!isValidFamily(family)) throw new Error('Nome de fonte inválido.');
  await initFonts();
  const parsed = await fetchCss(family);
  if (parsed.length === 0) throw new Error('Não encontrei essa fonte no Google Fonts (ou não há internet).');

  // Uma variação de cada tipo (regular, negrito, itálico, negrito itálico).
  const wanted = new Map<string, Parsed>();
  for (const p of parsed) {
    const k = keyOf({ weight: p.weight, italic: p.italic, file: '' });
    if (!wanted.has(k)) wanted.set(k, p);
  }

  const dir = fontsDir();
  const faces: FontFace[] = [];
  const slug = slugOf(family);
  for (const p of wanted.values()) {
    const name = `${slug}_${p.weight}${p.italic ? 'i' : ''}.ttf`;
    const tmp = new File(Paths.cache, `fnt_${Date.now().toString(36)}_${name}`);
    try {
      const got = await File.downloadFileAsync(p.url, tmp);
      if (!got.exists || got.size === 0) continue;
      const bytes = await got.bytes();
      if (!looksLikeFont(bytes.slice(0, 4))) continue;
      const dest = new File(dir, name);
      if (dest.exists) dest.delete();
      got.copy(dest);
      faces.push({ weight: p.weight, italic: p.italic, file: name });
    } catch {
      // essa variação não baixou; segue com as outras
    } finally {
      try {
        if (tmp.exists) tmp.delete();
      } catch {
        // ignora
      }
    }
  }
  if (faces.length === 0) throw new Error('Não consegui baixar os arquivos da fonte.');

  const font: SavedFont = { family, faces };
  saved = [...saved.filter((f) => f.family !== family), font].sort((a, b) => a.family.localeCompare(b.family));
  await persist();
  await registerNative(font);
  notify();
  return font;
}

export const hasFont = (family: string): boolean => saved.some((f) => f.family === family);

/** Tira a fonte do aparelho. Textos que a usam voltam à fonte padrão. */
export async function removeFont(family: string): Promise<void> {
  const f = saved.find((x) => x.family === family);
  if (!f) return;
  saved = saved.filter((x) => x.family !== family);
  nativeNames.delete(family);
  await persist();
  for (const x of f.faces) {
    try {
      const file = new File(fontsDir(), x.file);
      if (file.exists) file.delete();
    } catch {
      // ignora
    }
  }
  notify();
}
