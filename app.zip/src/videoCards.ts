import * as VideoThumbnails from 'expo-video-thumbnails';
import { File } from 'expo-file-system';
import { MoodItem, VIDEO_CARD, addMoodItem, listMoodItems, updateMoodItem } from './db';
import { boxOf } from './boardGeometry';
import { MAX_VIDEO_DOWNLOAD, VideoDownload, deleteMedia, isRemote, mediaUri, saveMedia, saveRemoteImage, saveRemoteVideo } from './media';
import { VideoData, WebVideo, parseVideo, stringifyVideo } from './videoData';

const WORLD_W = 5;
const WORLD_H = 8;
const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));

export type { WebVideo } from './videoData';

/** Primeiro quadro (ou um pouco depois, para fugir de tela preta) de um vídeo local ou da web → arquivo temporário. */
async function frameOf(uri: string, timeMs: number): Promise<string | null> {
  try {
    const r = await VideoThumbnails.getThumbnailAsync(uri, { time: timeMs, quality: 0.7 });
    return r.uri;
  } catch {
    return null;
  }
}

/** Capa de um vídeo: tenta 1 s e, se não der (vídeo curtinho), o início. Devolve o nome guardado em media. */
export async function makePoster(videoUri: string): Promise<string | null> {
  const tmp = (await frameOf(videoUri, 1000)) ?? (await frameOf(videoUri, 0));
  if (!tmp) return null;
  try {
    const name = saveMedia(tmp, 'capa.jpg', 'jpg');
    try {
      const f = new File(tmp);
      if (f.exists) f.delete();
    } catch {
      // ignora
    }
    return name;
  } catch {
    return null;
  }
}

/** Copia um vídeo da galeria (ou recebido por compartilhamento) para o app e tira a capa. */
export async function importLocalVideo(
  sourceUri: string,
  fileName: string | null | undefined,
  info: { width?: number | null; height?: number | null; durationMs?: number | null }
): Promise<VideoData> {
  const src = saveMedia(sourceUri, fileName, 'mp4');
  const poster = await makePoster(mediaUri(src));
  return {
    v: 1,
    src,
    poster,
    dur: info.durationMs && info.durationMs > 0 ? info.durationMs / 1000 : null,
    vw: info.width ?? 0,
    vh: info.height ?? 0,
  };
}

/** Vídeo da web: guarda só o endereço. Sem capa informada, tira um quadro direto do endereço (se o servidor deixar). */
export async function dataFromWeb(v: WebVideo): Promise<VideoData> {
  let poster = v.poster;
  if (!poster) {
    const tmp = await frameOf(v.src, 1000);
    if (tmp) {
      try {
        poster = saveMedia(tmp, 'capa.jpg', 'jpg');
        const f = new File(tmp);
        if (f.exists) f.delete();
      } catch {
        // sem capa
      }
    }
  }
  return { v: 1, src: v.src, poster, dur: v.duration, vw: v.width, vh: v.height };
}

/** Tamanho do cartão em unidades: largura padrão (ajustada ao zoom) e altura pela proporção do vídeo. */
export function videoCardSize(d: VideoData, k = 1): { w: number; h: number } {
  const w = VIDEO_CARD.w * k;
  const ratio = d.vw > 0 && d.vh > 0 ? d.vh / d.vw : 9 / 16;
  return { w, h: clamp(w * ratio, w * 0.45, w * 2) };
}

/** Cria o cartão no centro `at` (unidades do quadro). `k` = ajuste ao zoom; `n` = deslocamento para vários de uma vez. */
export async function createVideoCard(
  collectionId: number,
  d: VideoData,
  /** Centro desejado. null = abaixo do último item do quadro (usado quando o vídeo chega de fora, sem tela aberta). */
  at: { x: number; y: number } | null,
  k: number,
  n: number,
  caption?: string | null
): Promise<MoodItem> {
  const { w, h } = videoCardSize(d, k);
  let x: number;
  let y: number;
  if (at) {
    x = clamp(at.x - w / 2 + n * 0.05 * k, 0, WORLD_W - w);
    y = clamp(at.y - h / 2 + n * 0.05 * k, 0, WORLD_H - h);
  } else {
    const items = await listMoodItems(collectionId);
    if (items.length === 0) {
      x = (WORLD_W - w) / 2;
      y = WORLD_H / 2 - h / 2;
    } else {
      const bottom = Math.max(...items.map((i) => i.y + boxOf(i).h));
      x = (WORLD_W - w) / 2;
      y = clamp(bottom + 0.1, 0, WORLD_H - h);
    }
  }
  return addMoodItem({
    collectionId,
    kind: 'video',
    content: stringifyVideo(d),
    x,
    y,
    w,
    h,
    rot: ((n % 5) - 2) * 3,
    bold: false,
    caption: caption ?? null,
  });
}

/** Baixa um vídeo da web para o aparelho (e a capa, se ainda for da web). Devolve o conteúdo novo, ou o motivo da falha. */
export async function downloadVideoCard(
  id: number,
  content: string
): Promise<{ ok: true; content: string } | { ok: false; reason: Exclude<VideoDownload, { ok: true }>['reason'] }> {
  const d = parseVideo(content);
  if (!isRemote(d.src)) return { ok: true, content };
  const r = await saveRemoteVideo(d.src, MAX_VIDEO_DOWNLOAD);
  if (!r.ok) return { ok: false, reason: r.reason };
  let poster = d.poster;
  if (poster && isRemote(poster)) poster = (await saveRemoteImage(poster)) ?? poster;
  if (!poster) poster = await makePoster(mediaUri(r.name));
  const next = stringifyVideo({ ...d, src: r.name, poster });
  await updateMoodItem(id, { content: next });
  return { ok: true, content: next };
}

/** Troca a capa por uma imagem da galeria. Apaga a capa antiga se era um arquivo do app. */
export async function setVideoPoster(id: number, content: string, imageUri: string, fileName?: string | null): Promise<string> {
  const d = parseVideo(content);
  const next = stringifyVideo({ ...d, poster: saveMedia(imageUri, fileName, 'jpg') });
  await updateMoodItem(id, { content: next });
  if (d.poster && !isRemote(d.poster)) deleteMedia(d.poster);
  return next;
}
