/**
 * Página (WebView) do layout livre da nota: caixas de texto, imagens e formas que dá para mover,
 * redimensionar e reorganizar, mais modelos prontos que reencaixam o conteúdo que já está na página.
 * Fala com o React Native por mensagens (ReactNativeWebView.postMessage) e recebe comandos por
 * funções globais (window.initFree, window.setEditable, ...). Unidades: página de 1000 u de largura.
 */
import { colors } from './theme';

export const FREE_HTML = String.raw`<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<style>
:root{--red:${colors.red};--gray:${colors.muted};--panel:${colors.surface}}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;background:#000;color:#fff;font-family:Roboto,"Segoe UI",system-ui,sans-serif;-webkit-text-size-adjust:100%}
body{padding-bottom:40px;overflow-x:hidden}
body.editing{padding-bottom:150px}
#page{position:relative;width:100%;overflow:hidden;touch-action:pan-y;user-select:none;-webkit-user-select:none}
.fr{position:absolute;touch-action:pan-y}
.fr.sel{touch-action:none}
.fr.text{overflow:hidden}
.fr .tx{position:absolute;left:0;top:0;width:100%;white-space:pre-wrap;word-break:break-word;overflow-wrap:anywhere;outline:none;user-select:none;-webkit-user-select:none}
.fr .tx.ed{user-select:text;-webkit-user-select:text;caret-color:var(--red)}
.fr.ph .tx{opacity:.35}
.fr.image{overflow:hidden}
.fr.image img{width:100%;height:100%;display:block;pointer-events:none}
.fr.image.empty{background:#D9D9D9;display:none}
body.editing .fr.image.empty{display:flex;align-items:center;justify-content:center;color:#6b6b6b;font-size:15px;font-weight:700;text-align:center}
.fr.ovf:after{content:"";position:absolute;right:0;bottom:0;width:0;height:0;border-style:solid;border-width:0 0 16px 16px;border-color:transparent transparent var(--red) transparent}
body:not(.editing) .fr.ovf:after{display:none}
#selbox{position:absolute;border:1.5px solid var(--red);pointer-events:none;display:none;z-index:9000}
.hd{position:absolute;width:30px;height:30px;margin:-15px 0 0 -15px;pointer-events:auto;touch-action:none}
.hd:after{content:"";position:absolute;left:9px;top:9px;width:12px;height:12px;background:#fff;border:2px solid var(--red);border-radius:50%}
.g{position:absolute;background:var(--red);z-index:8999;pointer-events:none;display:none}
#bar{position:fixed;left:0;right:0;bottom:0;background:#000;border-top:1px solid #2C2C2E;display:none;z-index:10000;user-select:none;-webkit-user-select:none}
body.editing #bar{display:block}
.row{display:flex;gap:8px;overflow-x:auto;padding:8px 10px;scrollbar-width:none}
.row::-webkit-scrollbar{display:none}
.row.r2{padding-top:0}
.chip{flex:none;background:#2C2C2E;color:#fff;border-radius:18px;padding:0 14px;height:36px;display:flex;align-items:center;font-size:14px;font-weight:700;white-space:nowrap}
.chip.on{background:#fff;color:#000}
.chip.red{color:var(--red)}
.chip.dim{opacity:.4}
.sw{flex:none;width:34px;height:34px;border-radius:50%;border:2px solid #3A3A3C}
.sw.on{border-color:var(--red)}
.hint{color:var(--gray);font-size:13px;padding:0 4px;display:flex;align-items:center;white-space:nowrap}
</style>
</head>
<body>
<div id="page"><div id="frames"></div><div id="selbox"></div><div class="g" id="gv"></div><div class="g" id="gh"></div></div>
<div id="bar"><div class="row" id="r1"></div><div class="row r2" id="r2"></div></div>
<script>
var RN=window.ReactNativeWebView;
function post(o){try{RN.postMessage(JSON.stringify(o));}catch(e){}}
function $(id){return document.getElementById(id);}
var PW=1000,MARGIN=60;
var S={v:1,bg:'#FFFFFF',h:1500,frames:[]};
var sel=null,editable=false,K=1,panel=null,editingId=null,hist=[],saveT=null,lastTap={id:null,t:0};
var pageEl=$('page'),framesEl=$('frames'),selbox=$('selbox'),gv=$('gv'),gh=$('gh');
var FONTS={s:'Roboto,Arial,sans-serif',f:'Georgia,"Times New Roman",serif',m:'"Courier New",monospace'};
var TXT_COLORS=['#111111','#FFFFFF','#E8501F','#FFE600','#FF3030','#808080','#1F3D2B','#2B5BFF'];
var BGS=['#FFFFFF','#F3EEE6','#111111','#000000','#E8501F','#6B7A3A','#FFE600','#1F3D2B'];
function uid(){return 'f'+Date.now().toString(36)+Math.random().toString(36).slice(2,6);}
function get(id){for(var i=0;i<S.frames.length;i++)if(S.frames[i].id===id)return S.frames[i];return null;}
function luma(h){h=String(h||'#fff').replace('#','');var r=parseInt(h.substr(0,2),16),g=parseInt(h.substr(2,2),16),b=parseInt(h.substr(4,2),16);return(0.299*r+0.587*g+0.114*b)/255;}
function inkOn(bg){return luma(bg)<0.45?'#FFFFFF':'#111111';}
/* ---------- histórico e salvamento ---------- */
function snapJson(){return JSON.stringify(S);}
function pushHist(){hist.push(snapJson());if(hist.length>60)hist.shift();}
function pageH(){var m=0;for(var i=0;i<S.frames.length;i++){var f=S.frames[i];m=Math.max(m,f.y+f.h);}return Math.max(1500,Math.ceil(m+160));}
function changed(){clearTimeout(saveT);saveT=setTimeout(flush,400);}
function flush(){clearTimeout(saveT);S.h=pageH();post({type:'fchange',free:S});}
window.flushNow=function(){flush();};
/* ---------- desenho ---------- */
function calcK(){K=pageEl.clientWidth/PW;}
function place(d,f){d.style.left=f.x*K+'px';d.style.top=f.y*K+'px';d.style.width=f.w*K+'px';d.style.height=f.h*K+'px';}
function styleText(t,f){
  t.style.fontSize=(f.fs||32)*K+'px';t.style.fontWeight=f.fw||400;t.style.fontStyle=f.it?'italic':'normal';
  t.style.color=f.col||'#111';t.style.textAlign={l:'left',c:'center',r:'right',j:'justify'}[f.al||'l'];
  t.style.lineHeight=f.lh||1.3;t.style.letterSpacing=(f.ls||0)+'em';t.style.textTransform=f.up?'uppercase':'none';
  t.style.fontFamily=FONTS[f.ff||'s'];
}
function build(f){
  var d=document.createElement('div');d.className='fr '+f.t;d.setAttribute('data-id',f.id);
  if(f.t==='text'){
    var t=document.createElement('div');t.className='tx';styleText(t,f);t.textContent=f.txt||'';d.appendChild(t);
    if(!(f.txt||'').trim())d.classList.add('ph');
  }else if(f.t==='image'){
    d.style.borderRadius=(f.rad||0)*K+'px';
    if(f.src){var im=document.createElement('img');im.src=f.src;im.style.objectFit=f.fit||'cover';im.style.objectPosition=(f.px==null?50:f.px)+'% '+(f.py==null?50:f.py)+'%';d.appendChild(im);if(f.fill)d.style.background=f.fill;}
    else{d.classList.add('empty');d.textContent='Toque duas vezes para escolher a imagem';}
  }else{
    d.style.background=f.fill||'#000';d.style.borderRadius=(f.rad||0)*K+'px';
  }
  place(d,f);
  return d;
}
function measure(d,f){
  if(f.t!=='text')return;
  var t=d.firstChild;
  if(f.beh==='fit'){
    var lo=8,hi=f.fm||600,bh=f.h*K;
    for(var i=0;i<14;i++){var mid=(lo+hi)/2;t.style.fontSize=mid*K+'px';if(t.offsetHeight<=bh&&t.scrollWidth<=d.clientWidth+1)lo=mid;else hi=mid;}
    f.fs=Math.floor(lo);t.style.fontSize=f.fs*K+'px';
  }else if(f.beh!=='fixed'){
    var nh=Math.max(20,Math.ceil(t.offsetHeight/K));
    if(Math.abs(nh-f.h)>1){f.h=nh;place(d,f);}
  }
  d.classList.toggle('ovf',f.beh==='fixed'&&t.offsetHeight>d.clientHeight+2);
}
function elOf(id){return framesEl.querySelector('[data-id="'+id+'"]');}
function render(){
  calcK();
  S.h=pageH();
  pageEl.style.height=S.h*K+'px';pageEl.style.background=S.bg;
  framesEl.innerHTML='';
  for(var i=0;i<S.frames.length;i++){var f=S.frames[i],d=build(f);d.style.zIndex=i+1;framesEl.appendChild(d);}
  for(var j=0;j<S.frames.length;j++){var e=elOf(S.frames[j].id);if(e)measure(e,S.frames[j]);}
  S.h=pageH();pageEl.style.height=S.h*K+'px';
  drawSel();drawBar();
}
function updateFrame(f,remeasure){
  var d=elOf(f.id);if(!d)return;
  var nd=build(f);nd.style.zIndex=d.style.zIndex;if(sel===f.id)nd.classList.add('sel');
  d.parentNode.replaceChild(nd,d);
  if(remeasure!==false)measure(nd,f);
  pageEl.style.height=pageH()*K+'px';
  drawSel();
}
/* ---------- seleção e alças ---------- */
var HANDLES=['nw','n','ne','e','se','s','sw','w'];
function drawSel(){
  var f=sel&&get(sel);
  var olds=framesEl.querySelectorAll('.fr.sel');for(var i=0;i<olds.length;i++)olds[i].classList.remove('sel');
  selbox.innerHTML='';
  if(!f||!editable){selbox.style.display='none';return;}
  var d=elOf(f.id);if(d)d.classList.add('sel');
  selbox.style.display='block';
  selbox.style.left=f.x*K+'px';selbox.style.top=f.y*K+'px';selbox.style.width=f.w*K+'px';selbox.style.height=f.h*K+'px';
  if(f.lock||editingId===f.id)return;
  for(var k=0;k<HANDLES.length;k++){
    var h=HANDLES[k],e=document.createElement('div');e.className='hd';e.setAttribute('data-h',h);
    e.style.left=(h.indexOf('w')>=0?0:h.indexOf('e')>=0?100:50)+'%';
    e.style.top=(h.indexOf('n')>=0?0:h.indexOf('s')>=0?100:50)+'%';
    selbox.appendChild(e);
  }
}
function select(id){
  if(editingId&&editingId!==id)endEdit();
  sel=id;panel=null;drawSel();drawBar();
}
/* ---------- gestos ---------- */
var G=null;
function targetsX(skip){var a=[0,PW/2,PW,MARGIN,PW-MARGIN];for(var i=0;i<S.frames.length;i++){var f=S.frames[i];if(f.id===skip)continue;a.push(f.x,f.x+f.w/2,f.x+f.w);}return a;}
function targetsY(skip){var a=[0,MARGIN];for(var i=0;i<S.frames.length;i++){var f=S.frames[i];if(f.id===skip)continue;a.push(f.y,f.y+f.h/2,f.y+f.h);}return a;}
function snapTo(vals,targets,thr){
  var best=null;
  for(var i=0;i<vals.length;i++)for(var j=0;j<targets.length;j++){var d=targets[j]-vals[i];if(Math.abs(d)<=thr&&(best===null||Math.abs(d)<Math.abs(best.d)))best={d:d,at:targets[j]};}
  return best;
}
function showGuide(el,pos,vertical){
  if(pos==null){el.style.display='none';return;}
  el.style.display='block';
  if(vertical){el.style.left=pos*K+'px';el.style.top='0';el.style.width='1px';el.style.height=pageEl.style.height;}
  else{el.style.top=pos*K+'px';el.style.left='0';el.style.height='1px';el.style.width='100%';}
}
function hideGuides(){gv.style.display='none';gh.style.display='none';}
pageEl.addEventListener('pointerdown',function(e){
  if(!editable)return;
  var hd=e.target.closest&&e.target.closest('.hd');
  var f=sel&&get(sel);
  if(hd&&f&&!f.lock){
    pushHist();
    G={mode:'resize',h:hd.getAttribute('data-h'),sx:e.clientX,sy:e.clientY,o:{x:f.x,y:f.y,w:f.w,h:f.h},id:f.id,moved:false};
    try{pageEl.setPointerCapture(e.pointerId);}catch(x){}
    e.preventDefault();return;
  }
  var fe=e.target.closest&&e.target.closest('.fr');
  if(fe&&fe.getAttribute('data-id')===sel&&f&&!f.lock&&editingId!==f.id){
    pushHist();
    G={mode:'move',sx:e.clientX,sy:e.clientY,o:{x:f.x,y:f.y,w:f.w,h:f.h},id:f.id,moved:false};
    try{pageEl.setPointerCapture(e.pointerId);}catch(x){}
  }
});
pageEl.addEventListener('pointermove',function(e){
  if(!G)return;
  var f=get(G.id);if(!f)return;
  var dx=(e.clientX-G.sx)/K,dy=(e.clientY-G.sy)/K;
  if(!G.moved&&Math.abs(dx)+Math.abs(dy)<6/K)return;
  G.moved=true;
  var thr=8/K,o=G.o,gx=null,gy=null;
  if(G.mode==='move'){
    var nx=o.x+dx,ny=o.y+dy;
    var sx=snapTo([nx,nx+o.w/2,nx+o.w],targetsX(f.id),thr);if(sx){nx+=sx.d;gx=sx.at;}
    var sy=snapTo([ny,ny+o.h/2,ny+o.h],targetsY(f.id),thr);if(sy){ny+=sy.d;gy=sy.at;}
    f.x=Math.round(nx);f.y=Math.max(0,Math.round(ny));
  }else{
    var h=G.h,x=o.x,y=o.y,w=o.w,hh=o.h,min=30;
    var corner=h.length===2;
    if(h.indexOf('e')>=0){var rx=o.x+o.w+dx;var s1=snapTo([rx],targetsX(f.id),thr);if(s1){rx+=s1.d;gx=s1.at;}w=Math.max(min,rx-o.x);}
    if(h.indexOf('w')>=0){var lx=o.x+dx;var s2=snapTo([lx],targetsX(f.id),thr);if(s2){lx+=s2.d;gx=s2.at;}lx=Math.min(lx,o.x+o.w-min);x=lx;w=o.x+o.w-lx;}
    if(h.indexOf('s')>=0){var by=o.y+o.h+dy;var s3=snapTo([by],targetsY(f.id),thr);if(s3){by+=s3.d;gy=s3.at;}hh=Math.max(min,by-o.y);}
    if(h.indexOf('n')>=0){var ty=o.y+dy;var s4=snapTo([ty],targetsY(f.id),thr);if(s4){ty+=s4.d;gy=s4.at;}ty=Math.min(ty,o.y+o.h-min);y=ty;hh=o.y+o.h-ty;}
    if(corner&&f.t==='image'&&o.h>0){
      var ratio=o.w/o.h;hh=w/ratio;if(h.indexOf('n')>=0)y=o.y+o.h-hh;
    }
    if(f.t==='text'&&(h.indexOf('n')>=0||h.indexOf('s')>=0)&&f.beh!=='fit')f.beh='fixed';
    f.x=Math.round(x);f.y=Math.max(0,Math.round(y));f.w=Math.round(w);f.h=Math.round(hh);
  }
  showGuide(gv,gx,true);showGuide(gh,gy,false);
  var d=elOf(f.id);if(d){place(d,f);if(f.t==='text'&&G.mode==='resize')measure(d,f);}
  drawSel();
  e.preventDefault();
});
function endGesture(){
  if(!G)return;
  var f=get(G.id),moved=G.moved;G=null;hideGuides();
  if(moved&&f){
    if(f.t==='text'&&f.beh!=='fixed'&&f.beh!=='fit'){var d=elOf(f.id);if(d)measure(d,f);}
    pageEl.style.height=pageH()*K+'px';drawSel();changed();
  }else{hist.pop();}
}
pageEl.addEventListener('pointerup',function(e){
  var wasGesture=G&&G.moved;
  endGesture();
  if(wasGesture)return;
  tap(e);
});
pageEl.addEventListener('pointercancel',function(){if(G){var m=G.moved;endGesture();}});
function tap(e){
  var tg=document.elementFromPoint(e.clientX,e.clientY)||e.target;
  var hd=tg.closest&&tg.closest('.hd');if(hd)return;
  var fe=tg.closest&&tg.closest('.fr');
  var id=fe?fe.getAttribute('data-id'):null;
  var now=Date.now(),dbl=lastTap.id===id&&now-lastTap.t<340;
  lastTap={id:id,t:now};
  if(!editable){
    if(dbl){window.setEditable(true);post({type:'editing'});lastTap={id:null,t:0};}
    return;
  }
  if(editingId&&id===editingId)return;
  if(!id){select(null);return;}
  if(dbl){
    var f=get(id);
    if(f&&f.t==='text'){select(id);startEdit(id);}
    else if(f&&f.t==='image'){post({type:'pickFrameImage',id:id});}
    lastTap={id:null,t:0};return;
  }
  select(id);
}
/* ---------- edição de texto ---------- */
function startEdit(id){
  var d=elOf(id),f=get(id);if(!d||!f||f.lock)return;
  var t=d.firstChild;editingId=id;pushHist();
  d.classList.remove('ph');
  try{t.contentEditable='plaintext-only';}catch(x){}
  if(t.contentEditable!=='plaintext-only')t.contentEditable='true';
  t.classList.add('ed');d.style.touchAction='auto';
  t.focus();
  var r=document.createRange();r.selectNodeContents(t);r.collapse(false);var s=window.getSelection();s.removeAllRanges();s.addRange(r);
  t.oninput=function(){
    var v=t.innerText.replace(/\n$/,'');f.txt=v;
    if(f.beh==='fit'||f.beh==='auto'||!f.beh){measure(d,f);}
    selbox.style.height=f.h*K+'px';pageEl.style.height=pageH()*K+'px';changed();
  };
  t.onblur=function(){if(editingId===id)endEdit();};
  drawSel();drawBar();
}
function endEdit(){
  var id=editingId;if(!id)return;editingId=null;
  var f=get(id),d=elOf(id);
  if(f&&d){var t=d.firstChild;f.txt=t.innerText.replace(/\n$/,'');t.contentEditable='false';t.classList.remove('ed');}
  if(f)updateFrame(f);
  changed();drawSel();drawBar();
}
/* ---------- ações ---------- */
function cycle(list,cur){var i=list.indexOf(cur);return list[(i+1)%list.length];}
function mut(fn,remeasure){
  var f=sel&&get(sel);if(!f)return;
  pushHist();fn(f);
  updateFrame(f,remeasure);changed();drawBar();
}
function newText(txt,over){
  var top=Math.max(40,Math.round((window.scrollY||document.documentElement.scrollTop||0)/K)+120);
  var f={id:uid(),t:'text',role:'b',x:80,y:top,w:840,h:100,txt:txt||'',fs:40,fw:400,col:inkOn(S.bg),al:'l',lh:1.3,ls:0,ff:'s',beh:'auto'};
  if(over)for(var k in over)f[k]=over[k];
  return f;
}
function addFrame(f){pushHist();S.frames.push(f);render();select(f.id);changed();}
var ACT={
  addText:function(){var f=newText('');addFrame(f);startEdit(f.id);},
  addImage:function(){post({type:'pickFrameImage',id:'new'});},
  addShape:function(){addFrame({id:uid(),t:'shape',x:60,y:Math.max(40,Math.round((window.scrollY||0)/K)+200),w:880,h:6,fill:inkOn(S.bg),rad:0});},
  undo:function(){if(!hist.length)return;if(editingId)endEdit();S=JSON.parse(hist.pop());sel=null;render();changed();},
  panel:function(p){panel=(panel===p?null:p);drawBar();},
  done:function(){if(editingId)endEdit();select(null);},
  del:function(){var f=sel&&get(sel);if(!f)return;pushHist();S.frames=S.frames.filter(function(x){return x.id!==f.id;});sel=null;render();changed();},
  dup:function(){var f=sel&&get(sel);if(!f)return;var c=JSON.parse(JSON.stringify(f));c.id=uid();c.x=Math.min(PW-40,c.x+30);c.y+=30;c.lock=false;addFrame(c);},
  front:function(){var f=sel&&get(sel);if(!f)return;pushHist();S.frames=S.frames.filter(function(x){return x!==f;});S.frames.push(f);render();changed();},
  back:function(){var f=sel&&get(sel);if(!f)return;pushHist();S.frames=S.frames.filter(function(x){return x!==f;});S.frames.unshift(f);render();changed();},
  lock:function(){mut(function(f){f.lock=!f.lock;},false);drawSel();},
  full:function(){mut(function(f){if(f.x===0&&f.w===PW){f.x=MARGIN;f.w=PW-2*MARGIN;}else{f.x=0;f.w=PW;}});},
  center:function(){mut(function(f){f.x=Math.round((PW-f.w)/2);},false);},
  sizeUp:function(){mut(function(f){f.fs=Math.round((f.fs||32)*1.12);if(f.beh==='fit')f.beh='auto';});},
  sizeDown:function(){mut(function(f){f.fs=Math.max(8,Math.round((f.fs||32)/1.12));if(f.beh==='fit')f.beh='auto';});},
  bold:function(){mut(function(f){f.fw=cycle([400,700,800],f.fw||400);});},
  italic:function(){mut(function(f){f.it=!f.it;});},
  upper:function(){mut(function(f){f.up=!f.up;});},
  align:function(){mut(function(f){f.al=cycle(['l','c','r','j'],f.al||'l');},false);},
  font:function(){mut(function(f){f.ff=cycle(['s','f','m'],f.ff||'s');});},
  lead:function(){mut(function(f){f.lh=cycle([0.9,1,1.15,1.3,1.5,1.7],f.lh||1.3);});},
  track:function(){mut(function(f){f.ls=cycle([-0.06,-0.03,0,0.04,0.1],f.ls==null?0:f.ls);});},
  behave:function(){mut(function(f){f.beh=cycle(['auto','fixed','fit'],f.beh||'auto');if(f.beh==='fit')f.fm=600;});},
  swapImage:function(){post({type:'pickFrameImage',id:sel});},
  fit:function(){mut(function(f){f.fit=f.fit==='contain'?'cover':'contain';if(f.fit==='contain'&&!f.fill)f.fill=S.bg;},false);},
  focus:function(){mut(function(f){var o=[[50,50],[50,0],[50,100],[0,50],[100,50]];var i=0;for(var k=0;k<o.length;k++)if(o[k][0]===(f.px==null?50:f.px)&&o[k][1]===(f.py==null?50:f.py))i=k;var n=o[(i+1)%o.length];f.px=n[0];f.py=n[1];},false);},
  round:function(){mut(function(f){f.rad=cycle([0,24,60,500],f.rad||0);},false);},
  color:function(c){mut(function(f){if(f.t==='text')f.col=c;else f.fill=c;},false);},
  bg:function(c){
    pushHist();var wasDark=luma(S.bg)<0.45,isDark=luma(c)<0.45;S.bg=c;
    if(wasDark!==isDark)for(var i=0;i<S.frames.length;i++){var f=S.frames[i];if(f.t==='text'&&(f.col==='#111111'||f.col==='#FFFFFF'))f.col=inkOn(c);if(f.t==='shape'&&(f.fill==='#111111'||f.fill==='#FFFFFF'||f.fill==='#000000'))f.fill=inkOn(c);}
    render();changed();
  },
  preset:function(k){applyPreset(k);panel=null;drawBar();}
};
/* ---------- barra de ferramentas ---------- */
function chip(label,act,arg,cls){return '<div class="chip '+(cls||'')+'" data-act="'+act+'"'+(arg!=null?' data-arg="'+arg+'"':'')+'>'+label+'</div>';}
function swatch(c,act,on){return '<div class="sw'+(on?' on':'')+'" data-act="'+act+'" data-arg="'+c+'" style="background:'+c+'"></div>';}
var AL={l:'esq.',c:'centro',r:'dir.',j:'just.'},FF={s:'Sans',f:'Serifa',m:'Mono'},BEH={auto:'Caixa: cresce',fixed:'Caixa: fixa',fit:'Caixa: ajusta fonte'};
function drawBar(){
  var r1=$('r1'),r2=$('r2');if(!editable){return;}
  var f=sel&&get(sel),h1='',h2='';
  if(panel==='bg'){
    h1=chip('‹ Voltar','panel','bg')+BGS.map(function(c){return swatch(c,'bg',c===S.bg);}).join('');
  }else if(panel==='tpl'){
    h1=chip('‹ Voltar','panel','tpl')+PRESETS.map(function(p){return chip(p.name,'preset',p.key);}).join('')+'<div class="hint">Seu conteúdo é reencaixado no modelo</div>';
  }else if(panel==='color'&&f){
    var cur=f.t==='text'?f.col:f.fill;
    h1=chip('‹ Voltar','panel','color')+TXT_COLORS.concat([S.bg]).map(function(c){return swatch(c,'color',c===cur);}).join('');
  }else if(!f){
    h1=chip('+ Texto','addText')+chip('+ Imagem','addImage')+chip('+ Forma','addShape')+chip('Modelos','panel','tpl')+chip('Fundo','panel','bg')+chip('↶ Desfazer','undo',null,hist.length?'':'dim');
  }else{
    if(f.t==='text'){
      h1=chip('A−','sizeDown')+chip('A+','sizeUp')+chip('Negrito','bold',null,(f.fw||400)>400?'on':'')+chip('Itálico','italic',null,f.it?'on':'')+chip('AA','upper',null,f.up?'on':'')+chip('Alinhar · '+AL[f.al||'l'],'align')+chip('Fonte · '+FF[f.ff||'s'],'font')+chip('Entrelinha · '+(f.lh||1.3),'lead')+chip('Letras · '+(f.ls||0),'track')+chip('Cor','panel','color')+chip(BEH[f.beh||'auto'],'behave');
    }else if(f.t==='image'){
      h1=chip('Trocar imagem','swapImage')+chip(f.fit==='contain'?'Modo: caber':'Modo: preencher','fit')+chip('Foco do recorte','focus')+chip('Cantos','round')+chip('Cor de fundo','panel','color');
    }else{
      h1=chip('Cor','panel','color')+chip('Cantos','round');
    }
    h2=chip('Frente','front')+chip('Trás','back')+chip('Duplicar','dup')+chip(f.x===0&&f.w===PW?'Com margem':'Largura total','full')+chip('Centralizar','center')+chip(f.lock?'Destravar':'Travar','lock',null,f.lock?'on':'')+chip('Excluir','del',null,'red')+chip('OK','done');
  }
  r1.innerHTML=h1;r2.innerHTML=h2;r2.style.display=h2?'flex':'none';
}
function barTap(e){
  var c=e.target.closest&&e.target.closest('[data-act]');if(!c)return;
  var a=c.getAttribute('data-act'),arg=c.getAttribute('data-arg');
  if(ACT[a])ACT[a](arg);
}
['pointerdown','mousedown'].forEach(function(n){$('bar').addEventListener(n,function(e){e.preventDefault();});});
$('bar').addEventListener('click',barTap);
/* ---------- modelos ---------- */
function T(role,x,y,w,h,o){var f={t:'text',role:role,x:x,y:y,w:w,h:h,fs:32,fw:400,al:'l',lh:1.3,ls:0,ff:'s',beh:'auto'};for(var k in o)f[k]=o[k];return f;}
function I(x,y,w,h,o){var f={t:'image',x:x,y:y,w:w,h:h,fit:'cover'};for(var k in o)f[k]=o[k];return f;}
function R(x,y,w,h,fill,rad){return {t:'shape',x:x,y:y,w:w,h:h,fill:fill,rad:rad||0};}
var PRESETS=[
 {key:'capa',name:'Capa',bg:'#FFFFFF',slots:[
  T('h',60,70,880,380,{txt:'Título',fs:170,fw:800,ls:-0.04,lh:0.95,col:'#111111',beh:'fixed'}),
  T('c',60,480,400,60,{txt:'Subtítulo',fs:24,fw:600,up:true,ls:0.06,col:'#111111'}),
  T('b',520,480,420,170,{txt:'Escreva aqui…',fs:26,col:'#111111'}),
  R(60,460,880,3,'#111111'),
  I(60,700,880,700,{})]},
 {key:'numero',name:'Número grande',bg:'#F3EEE6',slots:[
  T('n',40,10,920,540,{txt:'01',fs:560,fw:400,ls:-0.06,lh:0.85,col:'#E8501F',beh:'fixed'}),
  T('h',60,610,520,300,{txt:'Título',fs:100,fw:600,ls:-0.04,lh:0.98,col:'#111111',beh:'fixed'}),
  T('b',60,940,420,360,{txt:'Escreva aqui…',fs:27,lh:1.35,col:'#111111'}),
  I(520,650,420,650,{})]},
 {key:'colunas',name:'Duas colunas',bg:'#FFFFFF',slots:[
  T('h',60,80,880,250,{txt:'Título',fs:110,fw:800,ls:-0.04,lh:1,col:'#111111',beh:'fixed'}),
  R(60,360,880,3,'#111111'),
  T('b',60,400,420,640,{txt:'Primeira coluna…',fs:28,lh:1.45,col:'#111111'}),
  T('b',520,400,420,640,{txt:'Segunda coluna…',fs:28,lh:1.45,col:'#111111'}),
  I(60,1100,880,500,{})]},
 {key:'fototopo',name:'Foto + título',bg:'#FFFFFF',slots:[
  I(0,0,1000,820,{}),
  T('c',60,860,880,40,{txt:'Categoria',fs:22,fw:600,up:true,ls:0.08,col:'#666666'}),
  T('h',60,920,880,230,{txt:'Título',fs:96,fw:700,ls:-0.03,lh:1.02,col:'#111111',beh:'fixed'}),
  T('b',60,1180,560,360,{txt:'Escreva aqui…',fs:28,lh:1.4,col:'#111111'})]},
 {key:'sobrefoto',name:'Texto sobre foto',bg:'#111111',slots:[
  I(0,0,1000,1500,{}),
  T('c',50,60,900,40,{txt:'Subtítulo',fs:24,fw:700,up:true,ls:0.06,col:'#FFE600'}),
  T('h',50,960,900,440,{txt:'Título',fs:190,fw:800,ls:-0.04,lh:0.9,up:true,col:'#FFE600',beh:'fixed'})]},
 {key:'grade',name:'Grade de fotos',bg:'#FFFFFF',slots:[
  T('h',60,60,880,300,{txt:'Título',fs:150,fw:800,ls:-0.045,lh:0.92,col:'#111111',beh:'fixed'}),
  T('c',60,390,880,40,{txt:'Subtítulo',fs:24,fw:600,up:true,ls:0.06,col:'#111111'}),
  I(60,470,420,520,{rad:28}),I(520,470,420,520,{rad:28}),I(60,1030,420,520,{rad:28}),I(520,1030,420,520,{rad:28}),
  T('b',60,1590,880,200,{txt:'Escreva aqui…',fs:28,col:'#111111'})]},
 {key:'solta',name:'Tipografia solta',bg:'#FFFFFF',slots:[
  T('h',40,50,920,320,{txt:'Título',fs:260,fw:400,ls:-0.05,lh:0.9,col:'#111111',beh:'fixed'}),
  I(60,430,500,640,{}),
  T('b',620,470,320,420,{txt:'Escreva aqui…',fs:24,lh:1.4,col:'#111111'}),
  T('c',620,930,320,140,{txt:'Legenda',fs:20,up:true,ls:0.06,col:'#666666'})]},
 {key:'atmosfera',name:'Atmosfera',bg:'#FFFFFF',slots:[
  T('n',380,780,640,700,{txt:'14.08',fs:420,fw:400,ls:-0.05,lh:0.85,col:'#F1F1F1',beh:'fixed'}),
  T('c',100,120,500,100,{txt:'Subtítulo',fs:22,fw:600,up:true,ls:0.04,col:'#111111'}),
  I(0,300,1000,420,{}),
  T('h',100,780,440,460,{txt:'Título',fs:120,fw:600,ls:-0.05,lh:0.95,col:'#333333',beh:'fixed'}),
  T('b',570,800,330,420,{txt:'Escreva aqui…',fs:24,lh:1.4,col:'#111111'})]}
];
var DEFAULTS={};
(function(){for(var i=0;i<PRESETS.length;i++)for(var j=0;j<PRESETS[i].slots.length;j++){var t=PRESETS[i].slots[j].txt;if(t)DEFAULTS[t]=1;}})();
function readingOrder(a,b){return a.y-b.y||a.x-b.x;}
function applyPreset(key){
  var P=null;for(var i=0;i<PRESETS.length;i++)if(PRESETS[i].key===key)P=PRESETS[i];if(!P)return;
  if(editingId)endEdit();
  pushHist();
  var texts=S.frames.filter(function(f){return f.t==='text'&&(f.txt||'').trim()&&!DEFAULTS[(f.txt||'').trim()];}).sort(readingOrder);
  var imgs=S.frames.filter(function(f){return f.t==='image'&&f.src;}).sort(readingOrder);
  var title=null;
  for(var a=0;a<texts.length;a++)if(texts[a].role==='h'){title=texts[a];break;}
  if(!title&&texts.length){title=texts.slice().sort(function(p,q){return (q.fs||0)-(p.fs||0);})[0];}
  var rest=texts.filter(function(t){return t!==title;});
  var out=[],grow=[];
  for(var s=0;s<P.slots.length;s++){
    var sl=JSON.parse(JSON.stringify(P.slots[s]));sl.id=uid();
    if(sl.t==='text'&&sl.role==='h'&&sl.beh==='fixed'){sl.beh='fit';sl.fm=sl.fs;}
    if(sl.t==='text'){
      if(sl.role==='h'&&title){sl.txt=title.txt;title=null;}
      else if(sl.role==='b'&&rest.length){var li=0;for(var z=1;z<rest.length;z++)if((rest[z].txt||'').length>(rest[li].txt||'').length)li=z;sl.txt=rest.splice(li,1)[0].txt;}
      else if(sl.role==='c'&&rest.length){var si=0;for(var y2=1;y2<rest.length;y2++)if((rest[y2].txt||'').length<(rest[si].txt||'').length)si=y2;if((rest[si].txt||'').length<=90)sl.txt=rest.splice(si,1)[0].txt;}
      else if(sl.role==='n'){var nf=texts.filter(function(t){return t.role==='n';})[0];if(nf)sl.txt=nf.txt;}
      if(sl.role==='b'&&sl.beh!=='fixed')grow.push({id:sl.id,h:sl.h});
    }else if(sl.t==='image'){
      var im=imgs.shift();if(im){sl.src=im.src;sl.fit=im.fit||sl.fit;sl.px=im.px;sl.py=im.py;}
    }
    out.push(sl);
  }
  S.bg=P.bg;
  S.frames=out;
  // o que sobrou entra embaixo, sem perder nada
  var y=0;for(var k=0;k<out.length;k++)y=Math.max(y,out[k].y+out[k].h);
  y+=60;
  if(title){rest.unshift(title);}
  for(var r=0;r<rest.length;r++){S.frames.push(newText(rest[r].txt,{y:y,x:60,w:880,fs:30,col:inkOn(P.bg),lh:1.4,role:'b'}));y+=200;}
  for(var m=0;m<imgs.length;m++){S.frames.push({id:uid(),t:'image',src:imgs[m].src,fit:'cover',x:60,y:y,w:880,h:620});y+=680;}
  render();
  // caixas de texto que cresceram empurram o que está logo abaixo
  var byY=grow.map(function(g){return get(g.id);}).filter(Boolean).sort(function(p,q){return p.y-q.y;});
  for(var n=0;n<byY.length;n++){
    var f=byY[n],g0=grow.filter(function(z){return z.id===f.id;})[0],delta=f.h-g0.h;
    if(delta<=0)continue;
    for(var o=0;o<S.frames.length;o++){var q=S.frames[o];if(q===f)continue;
      if(q.y>=g0.h+f.y-1&&q.x<f.x+f.w&&q.x+q.w>f.x)q.y+=delta;}
  }
  render();select(null);changed();
}
/* ---------- comandos vindos do app ---------- */
window.setEditable=function(b){
  editable=!!b;document.body.classList.toggle('editing',editable);
  if(!editable){if(editingId)endEdit();sel=null;panel=null;hideGuides();}
  drawSel();drawBar();
};
window.initFree=function(p){
  S=p.free||{v:1,bg:'#FFFFFF',h:1500,frames:[]};
  hist=[];sel=null;panel=null;editingId=null;
  window.setEditable(!!p.editable);
  if(!p.free){
    var seed=p.seed||{},fr=[];
    if((seed.title||'').trim())fr.push({id:uid(),t:'text',role:'h',x:60,y:60,w:880,h:200,txt:seed.title.trim(),fs:100});
    if((seed.text||'').trim())fr.push({id:uid(),t:'text',role:'b',x:60,y:300,w:880,h:200,txt:seed.text.trim(),fs:28});
    var im=seed.images||[];for(var i=0;i<im.length;i++)fr.push({id:uid(),t:'image',src:im[i],fit:'cover',x:60,y:600+i*100,w:880,h:600});
    S.frames=fr;calcK();render();applyPreset('capa');flush();
  }else{render();}
};
window.setFrameImage=function(id,uri){
  if(!uri)return;
  if(id==='new'){
    var im=new Image();
    im.onload=function(){
      var r=im.naturalHeight/Math.max(1,im.naturalWidth),w=840,h=Math.round(Math.min(1100,Math.max(200,w*r)));
      addFrame({id:uid(),t:'image',src:uri,fit:'cover',x:80,y:Math.max(40,Math.round((window.scrollY||0)/K)+120),w:w,h:h});
    };
    im.onerror=function(){addFrame({id:uid(),t:'image',src:uri,fit:'cover',x:80,y:200,w:840,h:600});};
    im.src=uri;
    return;
  }
  var f=get(id);if(!f)return;pushHist();f.src=uri;updateFrame(f);select(id);changed();
};
window.setScale=function(){};window.setFonts=function(){};window.setRecentColors=function(){};
window.setBacklinks=function(){};window.refreshNoteLinks=function(){};window.kbHidden=function(){};window.setNoteResults=function(){};
var lastW=0;window.addEventListener('resize',function(){var w=pageEl.clientWidth;if(w!==lastW){lastW=w;render();}});
window.addEventListener('error',function(e){post({type:'jserror',message:String(e.message)});});
post({type:'ready'});
</script>
</body>
</html>`;
