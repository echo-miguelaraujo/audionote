/**
 * Página (WebView) do layout livre da nota: caixas de texto, imagens e formas que dá para mover,
 * redimensionar e reorganizar, mais modelos prontos que reencaixam o conteúdo que já está na página.
 * Fala com o React Native por mensagens (ReactNativeWebView.postMessage) e recebe comandos por
 * funções globais (window.initFree, window.setEditable, ...). Unidades: página de 1000 u de largura.
 */
import { colors } from './theme';
import { ICON_CSS, icon, iconMap } from './htmlIcons';
import { PILL_CSS } from './toolbarKit';
import { DEFAULT_PAGE, PAGE_SIZES } from './freeLayout';

export const FREE_HTML = String.raw`<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<style>
:root{--red:${colors.red};--lkc:${colors.red};--gray:${colors.muted};--panel:${colors.surface};--line:${colors.lineDark};--top:0px;--sb:0px}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{height:100%;margin:0;background:#000;color:#fff;font-family:Roboto,"Segoe UI",system-ui,sans-serif;-webkit-text-size-adjust:100%}
body{display:flex;flex-direction:column;overflow:hidden}
/* A página rola dentro de #scroller e a barra (#dock) fica abaixo dele, no fluxo: com o teclado aberto ou fechado,
   a barra nunca cobre o texto e nunca deixa buraco embaixo. */
#scroller{flex:1 1 auto;min-height:0;overflow-y:auto;overflow-x:auto;-webkit-overflow-scrolling:touch;overscroll-behavior:contain;padding-top:var(--top);padding-bottom:calc(var(--sb) + 28px)}
body.editing #scroller{padding-bottom:24px}
#page{position:relative;width:100%;overflow:hidden;touch-action:pan-x pan-y;user-select:none;-webkit-user-select:none}
.fr{position:absolute;touch-action:pan-x pan-y}
.fr.sel,.fr.ms{touch-action:none}
.fr.msel{outline:2px solid var(--red);outline-offset:-2px}
::highlight(find){background:#6b5d00;color:#fff}
::highlight(find-cur){background:#FF3030;color:#fff}
.fr.fnd{outline:2px solid #FF3030;outline-offset:-2px}
#findbar{display:none;position:fixed;top:0;left:0;right:0;z-index:20000;align-items:center;gap:6px;padding:calc(var(--top) + 8px) 10px 8px;background:var(--panel);box-shadow:0 6px 20px rgba(0,0,0,.6)}
#findbar.show{display:flex}
#findq{flex:1;min-width:0;background:#000;color:#fff;border:1px solid var(--line);border-radius:10px;padding:9px 10px;font-size:16px;outline:none}
#findn{color:var(--gray);font-size:14px;min-width:42px;text-align:center}
.fb{background:none;border:0;color:#fff;font-size:18px;padding:6px 8px}
#msbox{position:absolute;border:1.5px dashed var(--red);pointer-events:none;display:none;z-index:8999}
.fr.text{overflow:hidden}
.fr .tx{position:absolute;left:0;top:0;width:100%;white-space:pre-wrap;word-break:break-word;overflow-wrap:anywhere;outline:none;user-select:none;-webkit-user-select:none}
.fr .tx.ed{user-select:text;-webkit-user-select:text;caret-color:var(--red)}
.fr.ph .tx{opacity:.35}
.lkx{color:var(--lkc);text-decoration:underline;text-underline-offset:.14em;text-decoration-thickness:.06em}
::highlight(lkh){color:${colors.red};text-decoration:underline}
.tlt{color:var(--lkc);font-size:15px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-decoration:underline}
.tlu{color:var(--gray);font-size:12px;margin:2px 0 8px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
body:not(.editing) .fr.ph{display:none}
.fr.link{overflow:hidden}
.fr.link .lk{display:flex;flex-direction:column;width:100%;pointer-events:none}
.fr.link .lk.sq{flex-direction:row;align-items:stretch}
.fr.link .lk img{display:block;width:100%;object-fit:cover;flex:none}
.fr.link .lk.sq img{width:34%;height:auto;aspect-ratio:1/1}
.fr.link .lk .lb{min-width:0;flex:1;display:flex;flex-direction:column;justify-content:center}
.fr.link .lk .lt,.fr.link .lk .ld{display:-webkit-box;-webkit-box-orient:vertical;overflow:hidden;word-break:break-word}
.fr.link .lk .ls{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.fr.link.ld .lk .ls:after{content:" · carregando…";opacity:.6;font-weight:400}
.fr.link.lf .lk .ls:after{content:" · sem prévia";opacity:.6;font-weight:400}
.fr.image{overflow:hidden}
.fr.image img{width:100%;height:100%;display:block;pointer-events:none}
.fr.image.empty{background:#D9D9D9;display:none}
body.editing .fr.image.empty{display:flex;align-items:center;justify-content:center;color:#6b6b6b;font-size:15px;font-weight:700;text-align:center;padding:8px}
.fr.ovf:after{content:"";position:absolute;right:0;bottom:0;width:0;height:0;border-style:solid;border-width:0 0 16px 16px;border-color:transparent transparent var(--red) transparent}
body:not(.editing) .fr.ovf:after{display:none}
#pgs{position:absolute;left:0;top:0;width:100%;pointer-events:none;z-index:7000}
#pgs .pl{position:absolute;left:0;width:100%;height:0;border-top:1px solid rgba(128,128,128,.55)}
body.editing #pgs .pl{border-top:2px dashed rgba(255,48,48,.85)}
#pgs .pn{display:none;position:absolute;left:8px;padding:2px 8px;border-radius:10px;background:rgba(0,0,0,.65);color:#fff;font-size:11px;font-weight:700}
body.editing #pgs .pn{display:block}
.pgstrip{display:flex;gap:10px;overflow-x:auto;padding:2px 0 12px;scrollbar-width:none}
.pgstrip::-webkit-scrollbar{display:none}
.pt{flex:none;text-align:center;font-size:12px;font-weight:700;color:var(--gray)}
.pt.on{color:#fff}
.pt .pth{position:relative;margin:0 auto 4px;border-radius:4px;overflow:hidden;border:2px solid #3A3A3C;box-sizing:content-box}
.pt.on .pth{border-color:var(--red)}
.pt .pth i{position:absolute;display:block}
#grid{position:absolute;left:0;top:0;width:100%;pointer-events:none;z-index:8000}
#grid .gc{position:absolute;top:0;bottom:0;background:rgba(255,48,48,.08)}
#grid .gm{position:absolute;top:0;bottom:0;width:0;border-left:1px dashed rgba(255,48,48,.55)}
#selbox{position:absolute;border:1.5px solid var(--red);pointer-events:none;display:none;z-index:9000}
.mv{position:absolute;left:50%;top:100%;margin:14px 0 0 -20px;width:40px;height:40px;border-radius:20px;background:#fff;color:#111;box-shadow:0 2px 10px rgba(0,0,0,.3);display:flex;align-items:center;justify-content:center;pointer-events:auto;touch-action:none}
#zm{position:fixed;right:10px;top:10px;z-index:9500;display:flex;flex-direction:column;gap:6px}
#zm .b{background:#fff;box-shadow:0 2px 10px rgba(0,0,0,.3);border-radius:20px}
.hd{position:absolute;width:30px;height:30px;margin:-15px 0 0 -15px;pointer-events:auto;touch-action:none}
.hd:after{content:"";position:absolute;left:9px;top:9px;width:12px;height:12px;background:#fff;border:2px solid var(--red);border-radius:50%}
.g{position:absolute;background:var(--red);z-index:8999;pointer-events:none;display:none}
/* ---------- dock (barra de baixo): cabeçalho + painel + abas ---------- */
body.editing #dock{display:block}
#dock{flex:none;position:relative;display:none;z-index:10000;user-select:none;-webkit-user-select:none;padding-bottom:calc(var(--sb) + 8px)}
#dh{margin:0 10px}
#pn{max-height:36vh;overflow-y:auto;padding:12px 12px 0;-webkit-overflow-scrolling:touch}
#pn:empty{display:none}
#dock .b{cursor:default}
${ICON_CSS}
${PILL_CSS}
/* painel claro: as classes do painel foram feitas para fundo escuro */
#pn{--panel:#F2F2F2;--gray:#666}
#pn .seg>div,#pn .chip,#pn .rowc .nm,#pn .ib,#pn .tp,#pn .tile,#pn .fontbtn,#pn .sw.plus{color:#111}
#pn .seg>div.on,#pn .chip.on{background:#111;color:#fff}
#pn .chip.red{color:var(--red)}
#pn .sw{border-color:#ddd}#pn .sw.on{border-color:#111}
#pn .tp .th{border-color:#ddd}
#pn .focus div.on{background:#111}
/* sub-pílula: o que se usa toda hora numa linha só; o resto fica atrás do botão de ajustes */
#pn.sub{display:flex;align-items:center;gap:6px;overflow-x:auto;padding:6px;border-radius:26px;max-height:none}
#pn.sub::-webkit-scrollbar{display:none}
#pn.sub>*{flex:0 0 auto}
#pn.sub .lbl,#pn.sub .hint{display:none}
#pn.sub .btns,#pn.sub .sws,#pn.sub .tiles{display:contents}
#pn.sub .seg{display:flex;gap:4px;margin:0}
#pn.sub .seg>div{height:40px;min-width:40px;padding:0 12px;display:flex;align-items:center;justify-content:center;border-radius:20px;white-space:nowrap}
#pn.sub .chip{margin:0;height:40px;display:flex;align-items:center;white-space:nowrap}
#pn.sub .fontbtn{width:auto;margin:0;white-space:nowrap}
#pn.sub .sw{width:32px;height:32px;border-radius:16px;margin:0}
#pn.sub .tile{flex:0 0 auto;margin:0}
#pn.sub .ib{margin:0}
#pn input[type=range]::-webkit-slider-runnable-track{background:#ddd}
#pn input[type=range]::-webkit-slider-thumb{border-color:#111}
.ib{flex:none;width:40px;height:40px;border-radius:20px;background:var(--panel);color:#fff;display:flex;align-items:center;justify-content:center;font-size:19px;font-weight:700}
.ib.dim{opacity:.35}
#pn:empty{display:none}
.lbl{color:var(--gray);font-size:12px;font-weight:700;margin:0 2px 6px}
.seg{display:flex;background:var(--panel);border-radius:14px;padding:3px;gap:3px;margin-bottom:12px}
.seg>div{flex:1;min-width:0;min-height:38px;border-radius:11px;display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:700;color:#fff;text-align:center;padding:0 4px}
.seg>div.on{background:#fff;color:#000}
.seg svg{width:22px;height:22px}
.rowc{display:flex;align-items:center;gap:10px;margin-bottom:8px}
.rowc .nm{width:84px;flex:none;color:#fff;font-size:14px;font-weight:700}
.rowc .val{width:48px;flex:none;text-align:right;color:var(--gray);font-size:13px;font-weight:700}
.rowc .ib{width:34px;height:34px;border-radius:17px;font-size:16px}
input[type=range]{flex:1;min-width:0;height:34px;-webkit-appearance:none;background:transparent;margin:0}
input[type=range]::-webkit-slider-runnable-track{height:4px;border-radius:2px;background:#3A3A3C}
input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;width:24px;height:24px;margin-top:-10px;border-radius:50%;background:#fff;border:2px solid var(--red)}
.fontbtn{display:flex;align-items:center;justify-content:space-between;background:var(--panel);border-radius:14px;min-height:46px;padding:0 16px;font-size:18px;font-weight:600;margin-bottom:12px}
.fontbtn small{color:var(--gray);font-size:20px}
.btns{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:12px}
.chip{flex:none;background:var(--panel);color:#fff;border-radius:20px;padding:0 16px;height:40px;display:flex;align-items:center;font-size:14px;font-weight:700;white-space:nowrap}
.chip.on{background:#fff;color:#000}
.chip.red{color:var(--red)}
.chip.dim{opacity:.4}
.sws{display:flex;flex-wrap:wrap;gap:10px;margin-bottom:12px}
.sw{flex:none;width:40px;height:40px;border-radius:50%;border:2px solid #3A3A3C}
.sw.on{border-color:var(--red)}
.sw.plus{display:flex;align-items:center;justify-content:center;background:var(--panel);color:#fff;font-size:22px;font-weight:700}
.tiles{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:12px}
.tile{background:var(--panel);border-radius:16px;min-height:64px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;font-size:13px;font-weight:700}
.tile b{font-size:22px;line-height:1}
.tpls{display:flex;gap:10px;overflow-x:auto;padding-bottom:10px;scrollbar-width:none}
.tpls::-webkit-scrollbar{display:none}
.tp{flex:none;width:72px;text-align:center;font-size:12px;font-weight:700;color:#fff}
.tp .th{position:relative;width:60px;height:90px;margin:0 auto 6px;border-radius:6px;overflow:hidden;border:1px solid #3A3A3C}
.tp .th i{position:absolute;display:block}
.tp .x{position:absolute;right:2px;top:2px;width:20px;height:20px;border-radius:10px;background:rgba(0,0,0,.7);color:#fff;font-size:12px;display:flex;align-items:center;justify-content:center;z-index:3}
.hint{color:var(--gray);font-size:13px;line-height:1.4;margin:0 2px 10px}
.focus{display:grid;grid-template-columns:repeat(3,44px);gap:6px;margin-bottom:12px}
.focus div{height:34px;border-radius:9px;background:var(--panel)}
.focus div.on{background:#fff}
.nudge{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:12px}
.nudge .ib{width:100%;border-radius:14px}
/* ---------- janela de fontes ---------- */
#scrim{display:none;position:fixed;left:0;top:0;right:0;bottom:0;background:${colors.scrimSoft};z-index:10010}
#sheet{display:none;position:fixed;left:12px;right:12px;bottom:calc(var(--sb) + 12px);max-height:72%;overflow-y:auto;background:#fff;color:#000;border-radius:8.8vw;padding:8px 18px 14px;z-index:10011;box-shadow:0 8px 28px rgba(0,0,0,.45)}
#sheet .ttl{color:#666;font-size:14px;margin:16px 4px 6px}
#sheet .frow{display:flex;align-items:center;justify-content:space-between;min-height:52px;font-size:21px;padding:0 4px;border-bottom:1px solid ${colors.hairline}}
#sheet .frow .ck{color:var(--red);font-weight:800}
#sheet .frow.more{font-size:16px;font-weight:700;color:var(--red);border-bottom:0}
</style>
</head>
<body>
<div id="scroller"><div id="page"><div id="frames"></div><div id="pgs"></div><div id="grid"></div><div id="selbox"></div><div id="msbox"></div><div class="g" id="gv"></div><div class="g" id="gh"></div></div></div>
<div id="findbar"><input id="findq" type="text" placeholder="Localizar na nota" autocomplete="off" autocapitalize="off"><span id="findn">0/0</span><button class="fb" id="findp">${icon('caretUp')}</button><button class="fb" id="findx">${icon('caretDown')}</button><button class="fb" id="findc">${icon('close')}</button></div>
<div id="zm"><div class="b" data-zm="1" role="button" aria-label="Aproximar">${icon('zoomIn')}</div><div class="b" data-zm="-1" role="button" aria-label="Afastar">${icon('zoomOut')}</div></div>
<div id="dock"><div id="pn"></div><div id="dh"><div id="row"></div></div></div>
<div id="scrim"></div><div id="sheet"></div>
<script>
var RN=window.ReactNativeWebView;
function post(o){try{RN.postMessage(JSON.stringify(o));}catch(e){}}
function $(id){return document.getElementById(id);}
var PW=1000;
var S={v:1,bg:'#FFFFFF',h:1250,frames:[],pr:'${DEFAULT_PAGE}',np:1};
var LIB={style:[],tpl:[]},ms=[],msMode=false,sel=null,editable=false,K=1,tab=null,openPref=true,editingId=null,hist=[],fut=[],saveT=null,lastTap={id:null,t:0};
var SIZES=${JSON.stringify(PAGE_SIZES)},pgSel=null;
var INS={top:0,bottom:0},FONTLIST=[],fontSheet=false,NUDGE=10,colorFor='frame',slHist=false,lastBg='';
function MG(){return S.m==null?60:S.m;}
var pageEl=$('page'),framesEl=$('frames'),selbox=$('selbox'),msbox=$('msbox'),gv=$('gv'),gh=$('gh'),gridEl=$('grid');
var FONTS={s:'Roboto,Arial,sans-serif',f:'Georgia,"Times New Roman",serif',m:'"Courier New",monospace'};
var TXT_COLORS=['#111111','#FFFFFF','#E8501F','#FFE600','#FF3030','#808080','#1F3D2B','#2B5BFF','#6B7A3A','#F3EEE6'];
var BGS=['#FFFFFF','#F3EEE6','#111111','#000000','#E8501F','#6B7A3A','#FFE600','#1F3D2B'];
function uid(){return 'f'+Date.now().toString(36)+Math.random().toString(36).slice(2,6);}
/* ---------- links dentro do texto ---------- */
var PL=null;
function okUrl(u){return /^(https?:|mailto:|tel:)/i.test(String(u||'').trim());}
/* os links acompanham as edições do texto (mesma regra de adjustLks em freeLayout.ts) */
function adjLks(lks,a,b){
  if(!lks||!lks.length||a===b)return lks;
  var m=Math.min(a.length,b.length),p=0,q=0;
  while(p<m&&a.charCodeAt(p)===b.charCodeAt(p))p++;
  while(q<m-p&&a.charCodeAt(a.length-1-q)===b.charCodeAt(b.length-1-q))q++;
  var aEnd=a.length-q,cEnd=b.length-q,delta=b.length-a.length,out=[];
  for(var i=0;i<lks.length;i++){var l=lks[i];
    var s=l.s>=aEnd?l.s+delta:l.s<=p?l.s:cEnd;
    var e=l.e<=p?l.e:l.e>=aEnd?l.e+delta:p;
    if(e>s&&b.slice(s,e).trim())out.push({s:s,e:Math.min(e,b.length),url:l.url});
  }
  return out;
}
function setTxt(f,v){var nl=adjLks(f.lks,f.txt||'',v);f.txt=v;if(nl&&nl.length)f.lks=nl;else delete f.lks;}
function setTx(t,f){
  var txt=f.txt||'';t.textContent='';
  if(!f.lks||!f.lks.length){t.textContent=txt;return;}
  var at=0;
  for(var i=0;i<f.lks.length;i++){var l=f.lks[i];
    if(l.s>at)t.appendChild(document.createTextNode(txt.slice(at,l.s)));
    var sp=document.createElement('span');sp.className='lkx';sp.setAttribute('data-i',i);sp.textContent=txt.slice(l.s,l.e);t.appendChild(sp);at=l.e;}
  if(at<txt.length)t.appendChild(document.createTextNode(txt.slice(at)));
}
function nodeAt(t,off){
  var w=document.createTreeWalker(t,NodeFilter.SHOW_TEXT,null),n,c=0;
  while((n=w.nextNode())){var L=n.nodeValue.length;if(off<=c+L)return{n:n,o:off-c};c+=L;}
  return null;
}
/* durante a edição o texto é puro; o trecho com link aparece destacado pelo CSS Custom Highlight (quando o aparelho tem) */
function paintHL(){
  try{
    if(!(window.CSS&&CSS.highlights&&window.Highlight))return;
    CSS.highlights.delete('lkh');
    var f=editingId&&get(editingId),d=f&&elOf(f.id);if(!f||!d||!f.lks||!f.lks.length)return;
    var t=d.firstChild,rs=[];
    for(var i=0;i<f.lks.length;i++){var a=nodeAt(t,f.lks[i].s),b=nodeAt(t,f.lks[i].e);
      if(a&&b){var r=document.createRange();r.setStart(a.n,a.o);r.setEnd(b.n,b.o);rs.push(r);}}
    if(rs.length)CSS.highlights.set('lkh',new (Function.prototype.bind.apply(Highlight,[null].concat(rs)))());
  }catch(x){}
}
function clearHL(){try{if(window.CSS&&CSS.highlights)CSS.highlights.delete('lkh');}catch(x){}}
/* trecho selecionado dentro da caixa em edição, em offsets sobre o texto */
function selRange(){
  var d=editingId&&elOf(editingId);if(!d)return null;
  var t=d.firstChild,sl=window.getSelection();if(!sl||!sl.rangeCount)return null;
  var r=sl.getRangeAt(0);if(!t.contains(r.startContainer)||!t.contains(r.endContainer))return null;
  var a=r.cloneRange();a.selectNodeContents(t);a.setEnd(r.startContainer,r.startOffset);
  var b=r.cloneRange();b.selectNodeContents(t);b.setEnd(r.endContainer,r.endOffset);
  return {s:a.toString().length,e:b.toString().length};
}
function get(id){for(var i=0;i<S.frames.length;i++)if(S.frames[i].id===id)return S.frames[i];return null;}
function luma(h){h=String(h||'#fff').replace('#','');var r=parseInt(h.substr(0,2),16),g=parseInt(h.substr(2,2),16),b=parseInt(h.substr(4,2),16);return(0.299*r+0.587*g+0.114*b)/255;}
function inkOn(bg){return luma(bg)<0.45?'#FFFFFF':'#111111';}
/* ---------- histórico e salvamento ---------- */
function snapJson(){return JSON.stringify(S);}
function pushHist(){hist.push(snapJson());if(hist.length>60)hist.shift();fut=[];}
/* ---------- páginas ---------- */
function sizeOf(k){for(var i=0;i<SIZES.length;i++)if(SIZES[i].key===k)return SIZES[i];return null;}
function PH(){var z=sizeOf(S.pr);return z?z.h:0;}
function botOf(){var m=0;for(var i=0;i<S.frames.length;i++){var f=S.frames[i];m=Math.max(m,f.y+f.h);}return m;}
function npages(){var ph=PH();return ph?Math.max(S.np||1,Math.ceil(botOf()/ph-0.001)):0;}
function pageH(){var ph=PH();if(ph)return npages()*ph;return Math.max(1500,Math.ceil(botOf()+160));}
function fixH(){pageEl.style.height=pageH()*K+'px';drawPages();}
function drawPages(){
  var el=$('pgs'),ph=PH();el.innerHTML='';el.style.height=pageEl.style.height;
  if(!ph)return;
  var n=npages(),h='';
  for(var i=0;i<n;i++){if(i>0)h+='<div class="pl" style="top:'+(i*ph*K)+'px"></div>';h+='<div class="pn" style="top:'+(i*ph*K+6)+'px">'+(i+1)+' / '+n+'</div>';}
  el.innerHTML=h;
}
function curPage(){
  var ph=PH(),n=npages();if(!ph)return 0;
  var y0=Math.max(0,((scEl.scrollTop||0)-INS.top)/K),vh=scEl.clientHeight/K;
  if(pgSel!=null&&pgSel<n&&pgSel*ph<y0+vh&&(pgSel+1)*ph>y0)return pgSel;
  return Math.max(0,Math.min(n-1,Math.floor((y0+vh/2)/ph)));
}
function pageOf(f){var ph=PH();return Math.min(npages()-1,Math.max(0,Math.floor((f.y+f.h/2)/ph)));}
/* caixas que cabem numa página e cruzariam a divisa vão para o topo da próxima; o que está abaixo desce junto */
function paginate(){
  var ph=PH();if(!ph)return;
  var fs=S.frames.slice().sort(function(a,b){return a.y-b.y||a.x-b.x;}),shift=0;
  for(var i=0;i<fs.length;i++){var f=fs[i],y=f.y+shift,pg=Math.floor(y/ph);
    if(f.h<=ph&&y+f.h>(pg+1)*ph+0.5){var ny=(pg+1)*ph+Math.min(MG(),(ph-f.h)/2);shift+=ny-y;y=ny;}
    f.y=Math.round(y);}
  S.np=Math.max(1,Math.ceil(botOf()/ph-0.001));
}
function changed(){clearTimeout(saveT);saveT=setTimeout(flush,400);if(findOpen)findSched();}
function flush(){clearTimeout(saveT);S.h=pageH();if(PH())S.np=npages();post({type:'fchange',free:S});}
window.flushNow=function(){flush();};
/* ---------- desenho ---------- */
function calcK(){K=pageEl.clientWidth/PW;}
function place(d,f){d.style.left=f.x*K+'px';d.style.top=f.y*K+'px';d.style.width=f.w*K+'px';d.style.height=f.h*K+'px';}
function styleText(t,f){
  t.style.fontSize=(f.fs||32)*K+'px';t.style.fontWeight=f.fw||400;t.style.fontStyle=f.it?'italic':'normal';
  t.style.color=f.col||'#111';t.style.textAlign={l:'left',c:'center',r:'right',j:'justify'}[f.al||'l'];
  t.style.lineHeight=f.lh||1.3;t.style.letterSpacing=(f.ls||0)+'em';t.style.textTransform=f.up?'uppercase':'none';
  t.style.fontFamily=famOf(f);t.style.padding=(f.pad||0)*K+'px';
}
function famOf(f){var base=FONTS[f.ff||'s'];if(f.fam&&FONTLIST.indexOf(f.fam)>=0)return "'"+f.fam+"',"+base;return base;}
function build(f){
  var d=document.createElement('div');d.className='fr '+f.t;d.setAttribute('data-id',f.id);
  if(f.t==='text'){
    var t=document.createElement('div');t.className='tx';styleText(t,f);setTx(t,f);d.appendChild(t);
    if(!(f.txt||'').trim())d.classList.add('ph');
  }else if(f.t==='image'){
    d.style.borderRadius=(f.rad||0)*K+'px';
    if(f.src){var im=document.createElement('img');im.src=f.src;im.style.objectFit=f.fit||'cover';im.style.objectPosition=(f.px==null?50:f.px)+'% '+(f.py==null?50:f.py)+'%';d.appendChild(im);if(f.fill)d.style.background=f.fill;}
    else{d.classList.add('empty');d.textContent='Toque duas vezes para escolher a imagem';}
  }else if(f.t==='link'){
    buildLink(d,f);
  }else{
    d.style.background=f.fill||'#000';d.style.borderRadius=(f.rad||0)*K+'px';
  }
  place(d,f);
  return d;
}
/* ---------- card de link ---------- */
function hostOf(u){var m=/^https?:\/\/([^\/?#:]+)/i.exec(String(u||''));return m?m[1].toLowerCase().replace(/^www\./,''):String(u||'');}
function linkFill(f){return f.fill||(luma(S.bg)<0.45?'#2A2A2C':'#F2F2F2');}
function escT(v){return String(v==null?'':v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}
function escA(v){return escT(v).replace(/"/g,'&quot;');}
function buildLink(d,f){
  var fill=linkFill(f),dark=luma(fill)<0.45,ink=dark?'#FFFFFF':'#111111',sub=dark?'#B5B5BA':'#6B6B70';
  var sq=!!f.src&&f.ar>0.85&&f.ar<1.2,ar=Math.min(2.4,Math.max(1,f.ar||1.91));
  d.style.background=fill;d.style.color=ink;d.style.borderRadius=(f.rad==null?24:f.rad)*K+'px';
  d.classList.toggle('ld',f.lst==='loading');d.classList.toggle('lf',f.lst==='fail');
  var w=document.createElement('div');w.className='lk'+(sq?' sq':'');w.style.fontFamily=FONTS.s;
  var h='';
  if(f.src)h+='<img src="'+escA(f.src)+'" alt=""'+(sq?'':' style="aspect-ratio:'+ar+'"')+'>';
  h+='<div class="lb" style="padding:'+24*K+'px '+28*K+'px">'
    +'<div class="lt" style="-webkit-line-clamp:2;font-size:'+38*K+'px;font-weight:700;line-height:1.25">'+escT(f.lt||f.lsite||hostOf(f.url))+'</div>'
    +(f.ld?'<div class="ld" style="-webkit-line-clamp:2;font-size:'+30*K+'px;line-height:1.3;color:'+sub+';margin-top:'+8*K+'px">'+escT(f.ld)+'</div>':'')
    +'<div class="ls" style="font-size:'+26*K+'px;color:'+sub+';margin-top:'+10*K+'px">'+escT(f.lsite||hostOf(f.url))+'</div></div>';
  w.innerHTML=h;d.appendChild(w);
}
var linkAsked={};
/* pede ao app a prévia de cada card que ainda está carregando (uma vez por abertura) */
function askLinkPreviews(){
  for(var i=0;i<S.frames.length;i++){var f=S.frames[i];
    if(f.t==='link'&&f.url&&f.lst==='loading'&&!linkAsked[f.id]){linkAsked[f.id]=1;post({type:'linkCard',lid:f.id,url:f.url});}}
}
function measure(d,f){
  if(f.t==='link'){
    var lk=d.firstChild;if(!lk)return;
    var hh=Math.max(120,Math.ceil(lk.offsetHeight/K));
    if(Math.abs(hh-f.h)>1){f.h=hh;place(d,f);}
    return;
  }
  if(f.t!=='text')return;
  var t=d.firstChild;
  if(f.beh==='fit'){
    var lo=8,hi=f.fm||600,bh=f.h*K;
    for(var i=0;i<14;i++){var mid=(lo+hi)/2;t.style.fontSize=mid*K+'px';if(t.offsetHeight<=bh&&t.scrollWidth<=d.clientWidth+1)lo=mid;else hi=mid;}
    f.fs=Math.floor(lo);t.style.fontSize=f.fs*K+'px';
  }else if(f.beh!=='fixed'){
    var nh=Math.max(20,Math.ceil(t.offsetHeight/K));
    if(Math.abs(nh-f.h)>1){f.h=nh;place(d,f);}
  }
  d.classList.toggle('ovf',f.beh==='fixed'&&t.offsetHeight>d.clientHeight+2);
}
function elOf(id){return framesEl.querySelector('[data-id="'+id+'"]');}
function render(){
  calcK();
  S.h=pageH();
  pageEl.style.background=S.bg;fixH();
  framesEl.innerHTML='';
  for(var i=0;i<S.frames.length;i++){var f=S.frames[i],d=build(f);d.style.zIndex=i+1;framesEl.appendChild(d);}
  for(var j=0;j<S.frames.length;j++){var e=elOf(S.frames[j].id);if(e)measure(e,S.frames[j]);}
  S.h=pageH();fixH();
  paintBody();drawGrid();drawSel();drawBar();askLinkPreviews();if(findOpen)findSched();
}
function paintBody(){
  var c=editable?'#000':S.bg;
  document.documentElement.style.background=c;document.body.style.background=c;
  if(S.bg!==lastBg){lastBg=S.bg;post({type:'bg',color:S.bg});}
}
function drawGrid(){
  gridEl.innerHTML='';gridEl.style.height=pageEl.style.height;
  if(!editable||!S.grid)return;
  var m=MG(),cols=12,gut=16,cw=(PW-2*m-gut*(cols-1))/cols,h='';
  for(var i=0;i<cols;i++){h+='<div class="gc" style="left:'+((m+i*(cw+gut))*K)+'px;width:'+(cw*K)+'px"></div>';}
  h+='<div class="gm" style="left:'+(m*K)+'px"></div><div class="gm" style="left:'+((PW-m)*K)+'px"></div>';
  gridEl.innerHTML=h;
}
function updateFrame(f,remeasure){
  var d=elOf(f.id);if(!d)return;
  var nd=build(f);nd.style.zIndex=d.style.zIndex;if(sel===f.id)nd.classList.add('sel');
  d.parentNode.replaceChild(nd,d);
  if(remeasure!==false)measure(nd,f);
  fixH();
  drawSel();
}
/* ---------- seleção e alças ---------- */
var HANDLES=['nw','n','ne','e','se','s','sw','w'];
function msFr(){var a=[];for(var i=0;i<ms.length;i++){var f=get(ms[i]);if(f)a.push(f);}return a;}
function bbox(a){var x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;for(var i=0;i<a.length;i++){var f=a[i];x0=Math.min(x0,f.x);y0=Math.min(y0,f.y);x1=Math.max(x1,f.x+f.w);y1=Math.max(y1,f.y+f.h);}return {x:x0,y:y0,w:x1-x0,h:y1-y0};}
function grp(g){return S.frames.filter(function(f){return f.gid===g;}).map(function(f){return f.id;});}
function sameG(a){return a.length>0&&!!a[0].gid&&a.every(function(f){return f.gid===a[0].gid;});}
function skp(s,id){return Array.isArray(s)?s.indexOf(id)>=0:s===id;}
function drawMs(){
  ms=ms.filter(function(id){return !!get(id);});
  var olds=framesEl.querySelectorAll('.fr.msel');for(var i=0;i<olds.length;i++)olds[i].classList.remove('msel');
  msbox.innerHTML='';
  var a=editable?msFr():[];
  if(!a.length){msbox.style.display='none';return;}
  for(var j=0;j<a.length;j++){var d=elOf(a[j].id);if(d)d.classList.add('msel');}
  var b=bbox(a);
  msbox.style.display='block';msbox.style.left=b.x*K+'px';msbox.style.top=b.y*K+'px';msbox.style.width=b.w*K+'px';msbox.style.height=b.h*K+'px';
  if(a.every(function(f){return f.lock;}))return;
  ['nw','ne','sw','se'].forEach(function(h){
    var e=document.createElement('div');e.className='hd';e.setAttribute('data-h',h);
    e.style.left=(h.indexOf('w')>=0?0:100)+'%';e.style.top=(h.indexOf('n')>=0?0:100)+'%';msbox.appendChild(e);
  });
}
function setMs(ids,mode){
  if(editingId)endEdit();
  ms=ids;if(mode!=null)msMode=mode;sel=null;
  if(ms.length||msMode){if(tab!=='msa'&&tab!=='msb')tab='msa';}else if(tab==='msa'||tab==='msb')tab=null;
  drawSel();drawBar();
}
function refreshMs(a){
  a.forEach(function(f){var d=elOf(f.id);if(d){place(d,f);if(f.t==='text'&&f.beh!=='fixed'&&f.beh!=='fit')measure(d,f);}});
  fixH();drawMs();changed();drawBar();
}
function msGesture(e){
  var dx=(e.clientX-G.sx)/K,dy=(e.clientY-G.sy)/K;
  if(!G.moved&&Math.abs(dx)+Math.abs(dy)<6/K)return;
  G.moved=true;
  var b=G.b,thr=8/K,gx=null,gy=null,skip=G.o.map(function(q){return q.id;});
  if(G.mode==='msmove'){
    var nx=b.x+dx,ny=b.y+dy;
    var s1=snapTo([nx,nx+b.w/2,nx+b.w],targetsX(skip),thr);if(s1){nx+=s1.d;gx=s1.at;}
    var s2=snapTo([ny,ny+b.h/2,ny+b.h],targetsY(skip),thr);if(s2){ny+=s2.d;gy=s2.at;}
    var ox=Math.round(nx)-b.x,oy=Math.max(0,Math.round(ny))-b.y;
    G.o.forEach(function(q){var f=get(q.id);if(f){f.x=q.x+ox;f.y=Math.max(0,q.y+oy);}});
  }else{
    var h=G.h,west=h.indexOf('w')>=0,north=h.indexOf('n')>=0;
    var ax=west?b.x+b.w:b.x,ay=north?b.y+b.h:b.y;
    var px=(west?b.x:b.x+b.w)+dx,py=(north?b.y:b.y+b.h)+dy;
    var t1=snapTo([px],targetsX(skip),thr);if(t1){px+=t1.d;gx=t1.at;}
    var t2=snapTo([py],targetsY(skip),thr);if(t2){py+=t2.d;gy=t2.at;}
    var sx=Math.max(0.1,(west?ax-px:px-ax)/b.w),sy=Math.max(0.1,(north?ay-py:py-ay)/b.h);
    G.o.forEach(function(q){var f=get(q.id);if(!f)return;
      f.x=Math.round(ax+(q.x-ax)*sx);f.y=Math.max(0,Math.round(ay+(q.y-ay)*sy));
      f.w=Math.max(10,Math.round(q.w*sx));f.h=Math.max(10,Math.round(q.h*sy));});
  }
  G.o.forEach(function(q){var f=get(q.id),d=f&&elOf(f.id);if(d){place(d,f);if(f.t==='text'&&G.mode==='msresize')measure(d,f);}});
  showGuide(gv,gx,true);showGuide(gh,gy,false);
  drawMs();e.preventDefault();
}
function drawSel(){
  drawMs();
  var f=sel&&get(sel);
  var olds=framesEl.querySelectorAll('.fr.sel');for(var i=0;i<olds.length;i++)olds[i].classList.remove('sel');
  selbox.innerHTML='';
  if(!f||!editable){selbox.style.display='none';return;}
  var d=elOf(f.id);if(d)d.classList.add('sel');
  selbox.style.display='block';
  selbox.style.left=f.x*K+'px';selbox.style.top=f.y*K+'px';selbox.style.width=f.w*K+'px';selbox.style.height=f.h*K+'px';
  if(f.lock||editingId===f.id)return;
  for(var k=0;k<HANDLES.length;k++){
    var h=HANDLES[k],e=document.createElement('div');e.className='hd';e.setAttribute('data-h',h);
    e.style.left=(h.indexOf('w')>=0?0:h.indexOf('e')>=0?100:50)+'%';
    e.style.top=(h.indexOf('n')>=0?0:h.indexOf('s')>=0?100:50)+'%';
    selbox.appendChild(e);
  }
  var mv=document.createElement('div');mv.className='mv';mv.setAttribute('aria-label','Mover');mv.innerHTML=IC.move;selbox.appendChild(mv);
}
/* mantém o cursor à vista, acima da barra, enquanto se digita numa caixa alta */
function keepCaret(){
  var sl=window.getSelection();if(!sl||!sl.rangeCount||!editingId)return;
  var rc=sl.getRangeAt(0).getClientRects();if(!rc.length)return;
  var b=rc[rc.length-1],sb=scEl.getBoundingClientRect(),pad=28;
  if(b.bottom>sb.bottom-pad)scEl.scrollTop+=b.bottom-sb.bottom+pad;
  else if(b.top<sb.top+pad)scEl.scrollTop-=sb.top+pad-b.top;
}
function select(id){
  if(ms.length||msMode){ms=[];msMode=false;if(tab==="msa"||tab==="msb")tab=null;}
  if(editingId&&editingId!==id)endEdit();
  if(id!==sel){var f=id&&get(id);tab=f?(openPref?tabsFor(f)[0][0]:null):(openPref&&tab&&tabsFor(null).some(function(t){return t[0]===tab;})?tab:null);}
  sel=id;drawSel();drawBar();
  setTimeout(reveal,60);
}
var scEl=$('scroller');
/* ---------- zoom (botões e pinça) ---------- */
var ZM=1;
function setZoom(z,cx,cy){
  z=Math.max(1,Math.min(4,z));if(Math.abs(z-ZM)<0.001)return;
  var ow=pageEl.clientWidth;
  if(cx==null)cx=scEl.clientWidth/2;if(cy==null)cy=scEl.clientHeight/2;
  var px=scEl.scrollLeft+cx,py=scEl.scrollTop+cy;
  ZM=z;pageEl.style.width=(ZM*100)+'%';scEl.style.overflowX=ZM>1?'auto':'hidden';
  render();
  var r=pageEl.clientWidth/ow;
  scEl.scrollLeft=px*r-cx;scEl.scrollTop=py*r-cy;
  drawSel();
}
$('zm').addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('[data-zm]');if(b)setZoom(ZM*(b.getAttribute('data-zm')==='1'?1.4:1/1.4));});
var pz=null,pzRaf=0;
function pzDist(e){var a=e.touches[0],b=e.touches[1];return Math.hypot(a.clientX-b.clientX,a.clientY-b.clientY);}
scEl.addEventListener('touchstart',function(e){if(e.touches.length===2){if(G)endGesture();pz={d:pzDist(e),z:ZM};}},{passive:true});
scEl.addEventListener('touchmove',function(e){
  if(!pz||e.touches.length!==2)return;
  if(e.cancelable)e.preventDefault();
  var a=e.touches[0],b=e.touches[1],rc=scEl.getBoundingClientRect();
  var nz=pz.z*pzDist(e)/pz.d,cx=(a.clientX+b.clientX)/2-rc.left,cy=(a.clientY+b.clientY)/2-rc.top;
  if(pzRaf)return;pzRaf=requestAnimationFrame(function(){pzRaf=0;setZoom(nz,cx,cy);});
},{passive:false});
scEl.addEventListener('touchend',function(e){if(e.touches.length<2)pz=null;},{passive:true});
function visTop(){return Math.max(0,Math.round(((scEl.scrollTop||0)-INS.top)/K));}
/* rola a página só o necessário para o item selecionado não ficar escondido atrás da barra */
function reveal(){
  var f=sel&&get(sel);if(!f||!editable)return;
  var vh=scEl.clientHeight,y=scEl.scrollTop||0;
  var top=INS.top+f.y*K-y,bot=INS.top+(f.y+f.h)*K-y;
  if(bot>vh-8)scEl.scrollTop=y+Math.max(0,Math.min(bot-vh+16,top-INS.top-16));
  else if(top<INS.top+8)scEl.scrollTop=Math.max(0,y-(INS.top+8-top));
}
/* ---------- gestos ---------- */
var G=null;
function targetsX(skip){var a=[0,PW/2,PW,MG(),PW-MG()];for(var i=0;i<S.frames.length;i++){var f=S.frames[i];if(skp(skip,f.id))continue;a.push(f.x,f.x+f.w/2,f.x+f.w);}return a;}
function targetsY(skip){var a=[0,MG()],ph=PH();if(ph){for(var p=0,n=npages();p<n;p++)a.push(p*ph,p*ph+MG(),(p+1)*ph-MG(),(p+1)*ph);}for(var i=0;i<S.frames.length;i++){var f=S.frames[i];if(skp(skip,f.id))continue;a.push(f.y,f.y+f.h/2,f.y+f.h);}return a;}
function snapTo(vals,targets,thr){
  var best=null;
  for(var i=0;i<vals.length;i++)for(var j=0;j<targets.length;j++){var d=targets[j]-vals[i];if(Math.abs(d)<=thr&&(best===null||Math.abs(d)<Math.abs(best.d)))best={d:d,at:targets[j]};}
  return best;
}
function showGuide(el,pos,vertical){
  if(pos==null){el.style.display='none';return;}
  el.style.display='block';
  if(vertical){el.style.left=pos*K+'px';el.style.top='0';el.style.width='1px';el.style.height=pageEl.style.height;}
  else{el.style.top=pos*K+'px';el.style.left='0';el.style.height='1px';el.style.width='100%';}
}
function hideGuides(){gv.style.display='none';gh.style.display='none';}
pageEl.addEventListener('pointerdown',function(e){
  if(!editable)return;
  if(ms.length){
    var mh=e.target.closest&&e.target.closest('.hd'),mf=e.target.closest&&e.target.closest('.fr');
    var ma=msFr().filter(function(q){return !q.lock;});
    var onH=mh&&mh.parentNode===msbox,onF=mf&&ms.indexOf(mf.getAttribute('data-id'))>=0&&editingId==null;
    if((onH||onF)&&ma.length){
      pushHist();
      G={mode:onH?'msresize':'msmove',h:onH?mh.getAttribute('data-h'):null,sx:e.clientX,sy:e.clientY,b:bbox(onH?msFr():ma),o:ma.map(function(q){return {id:q.id,x:q.x,y:q.y,w:q.w,h:q.h};}),moved:false};
      try{pageEl.setPointerCapture(e.pointerId);}catch(x){}
      if(onH)e.preventDefault();
    }
    return;
  }
  var hd=e.target.closest&&e.target.closest('.hd');
  var f=sel&&get(sel);
  var mvh=e.target.closest&&e.target.closest('.mv');
  if(mvh&&f&&!f.lock){
    pushHist();
    G={mode:'move',sx:e.clientX,sy:e.clientY,o:{x:f.x,y:f.y,w:f.w,h:f.h},id:f.id,moved:false};
    try{pageEl.setPointerCapture(e.pointerId);}catch(x){}
    e.preventDefault();return;
  }
  if(hd&&f&&!f.lock){
    pushHist();
    G={mode:'resize',h:hd.getAttribute('data-h'),sx:e.clientX,sy:e.clientY,o:{x:f.x,y:f.y,w:f.w,h:f.h},id:f.id,moved:false};
    try{pageEl.setPointerCapture(e.pointerId);}catch(x){}
    e.preventDefault();return;
  }
  var fe=e.target.closest&&e.target.closest('.fr');
  if(fe&&fe.getAttribute('data-id')===sel&&f&&!f.lock&&editingId!==f.id){
    pushHist();
    G={mode:'move',sx:e.clientX,sy:e.clientY,o:{x:f.x,y:f.y,w:f.w,h:f.h},id:f.id,moved:false};
    try{pageEl.setPointerCapture(e.pointerId);}catch(x){}
  }
});
pageEl.addEventListener('pointermove',function(e){
  if(!G)return;
  if(G.mode==='msmove'||G.mode==='msresize'){msGesture(e);return;}
  var f=get(G.id);if(!f)return;
  var dx=(e.clientX-G.sx)/K,dy=(e.clientY-G.sy)/K;
  if(!G.moved&&Math.abs(dx)+Math.abs(dy)<6/K)return;
  G.moved=true;
  var thr=8/K,o=G.o,gx=null,gy=null;
  if(G.mode==='move'){
    var nx=o.x+dx,ny=o.y+dy;
    var sx=snapTo([nx,nx+o.w/2,nx+o.w],targetsX(f.id),thr);if(sx){nx+=sx.d;gx=sx.at;}
    var sy=snapTo([ny,ny+o.h/2,ny+o.h],targetsY(f.id),thr);if(sy){ny+=sy.d;gy=sy.at;}
    f.x=Math.round(nx);f.y=Math.max(0,Math.round(ny));
  }else{
    var h=G.h,x=o.x,y=o.y,w=o.w,hh=o.h,min=30;
    var corner=h.length===2;
    if(h.indexOf('e')>=0){var rx=o.x+o.w+dx;var s1=snapTo([rx],targetsX(f.id),thr);if(s1){rx+=s1.d;gx=s1.at;}w=Math.max(min,rx-o.x);}
    if(h.indexOf('w')>=0){var lx=o.x+dx;var s2=snapTo([lx],targetsX(f.id),thr);if(s2){lx+=s2.d;gx=s2.at;}lx=Math.min(lx,o.x+o.w-min);x=lx;w=o.x+o.w-lx;}
    if(h.indexOf('s')>=0){var by=o.y+o.h+dy;var s3=snapTo([by],targetsY(f.id),thr);if(s3){by+=s3.d;gy=s3.at;}hh=Math.max(min,by-o.y);}
    if(h.indexOf('n')>=0){var ty=o.y+dy;var s4=snapTo([ty],targetsY(f.id),thr);if(s4){ty+=s4.d;gy=s4.at;}ty=Math.min(ty,o.y+o.h-min);y=ty;hh=o.y+o.h-ty;}
    if(corner&&f.t==='image'&&o.h>0){
      var ratio=o.w/o.h;hh=w/ratio;if(h.indexOf('n')>=0)y=o.y+o.h-hh;
    }
    if(f.t==='text'&&(h.indexOf('n')>=0||h.indexOf('s')>=0)&&f.beh!=='fit')f.beh='fixed';
    f.x=Math.round(x);f.y=Math.max(0,Math.round(y));f.w=Math.round(w);f.h=Math.round(hh);
  }
  showGuide(gv,gx,true);showGuide(gh,gy,false);
  var d=elOf(f.id);if(d){place(d,f);if(f.t==='text'&&G.mode==='resize')measure(d,f);}
  drawSel();
  e.preventDefault();
});
function endGesture(){
  if(!G)return;
  if(G.mode==='msmove'||G.mode==='msresize'){
    var mm=G.moved,oo=G.o;G=null;hideGuides();
    if(mm){oo.forEach(function(q){var f=get(q.id),d=f&&elOf(f.id);if(d&&f.t==='text'&&f.beh!=='fixed'&&f.beh!=='fit')measure(d,f);});fixH();drawMs();changed();}else{hist.pop();}
    return;
  }
  var f=get(G.id),moved=G.moved;G=null;hideGuides();
  if(moved&&f){
    if(f.t==='text'&&f.beh!=='fixed'&&f.beh!=='fit'){var d=elOf(f.id);if(d)measure(d,f);}
    fixH();drawSel();changed();
  }else{hist.pop();}
}
pageEl.addEventListener('pointerup',function(e){
  var wasGesture=G&&G.moved;
  endGesture();
  if(wasGesture)return;
  tap(e);
});
pageEl.addEventListener('pointercancel',function(){if(G){var m=G.moved;endGesture();}});
function tap(e){
  var tg=document.elementFromPoint(e.clientX,e.clientY)||e.target;
  var hd=tg.closest&&tg.closest('.hd');if(hd)return;
  if(tg.closest&&tg.closest('.mv'))return;
  var fe=tg.closest&&tg.closest('.fr');
  var id=fe?fe.getAttribute('data-id'):null;
  var now=Date.now(),dbl=lastTap.id===id&&now-lastTap.t<340;
  lastTap={id:id,t:now};
  if(!editable){
    var lx=tg.closest&&tg.closest('.lkx'),tf=id&&get(id);
    if(lx&&tf&&tf.lks&&tf.lks[+lx.getAttribute('data-i')]){lastTap={id:null,t:0};post({type:'openLink',url:tf.lks[+lx.getAttribute('data-i')].url});return;}
    var lf=id&&get(id);
    if(lf&&lf.t==='link'&&lf.url){lastTap={id:null,t:0};post({type:'openLink',url:lf.url});return;}
    if(dbl){window.setEditable(true);post({type:'editing'});lastTap={id:null,t:0};}
    else{var stamp=lastTap.t;setTimeout(function(){if(lastTap.t===stamp)post({type:'tapView'});},360);}
    return;
  }
  if(editingId&&id===editingId)return;
  if(msMode){
    if(!id)return;
    var g1=get(id),ids=g1&&g1.gid?grp(g1.gid):[id],on=ms.indexOf(id)>=0;
    var nm=ms.filter(function(x){return ids.indexOf(x)<0;});
    if(!on)nm=nm.concat(ids);
    setMs(nm,true);return;
  }
  if(!id){select(null);return;}
  if(dbl){
    var f=get(id);
    if(f&&f.t==='text'){select(id);startEdit(id);}
    else if(f&&f.t==='image'){post({type:'pickFrameImage',id:id});}
    else if(f&&f.t==='link'){post({type:'frameLinkMenu',id:id,url:f.url||''});}
    lastTap={id:null,t:0};return;
  }
  var g0=get(id);
  if(g0&&g0.gid&&grp(g0.gid).length>1){if(ms.indexOf(id)<0)setMs(grp(g0.gid),false);return;}
  if(g0&&g0.t==='link'&&g0.url&&sel===id){post({type:'openLink',url:g0.url});return;}
  select(id);
}
/* ---------- edição de texto ---------- */
function startEdit(id){
  var d=elOf(id),f=get(id);if(!d||!f||f.lock)return;
  var t=d.firstChild;editingId=id;pushHist();
  d.classList.remove('ph');t.textContent=f.txt||'';
  try{t.contentEditable='plaintext-only';}catch(x){}
  if(t.contentEditable!=='plaintext-only')t.contentEditable='true';
  tab=null;t.classList.add('ed');d.style.touchAction='auto';
  t.focus();
  var r=document.createRange();r.selectNodeContents(t);r.collapse(false);var s=window.getSelection();s.removeAllRanges();s.addRange(r);
  t.oninput=function(){
    var v=t.innerText.replace(/\n$/,''),nl=(f.lks||[]).length;setTxt(f,v);
    if((f.lks||[]).length!==nl&&tab==='txt')drawBar();
    paintHL();
    if(f.beh==='fit'||f.beh==='auto'||!f.beh){measure(d,f);}
    selbox.style.height=f.h*K+'px';fixH();changed();
    keepCaret();
  };
  t.onblur=function(){if(editingId===id)endEdit();};
  paintHL();drawSel();drawBar();
}
function endEdit(){
  var id=editingId;if(!id)return;editingId=null;
  var f=get(id),d=elOf(id);
  clearHL();
  if(f&&d){var t=d.firstChild;setTxt(f,t.innerText.replace(/\n$/,''));t.contentEditable='false';t.classList.remove('ed');}
  if(f)updateFrame(f);
  if(openPref&&sel&&get(sel))tab=tabsFor(get(sel))[0][0];
  changed();drawSel();drawBar();
}
/* ---------- ações ---------- */
function cycle(list,cur){var i=list.indexOf(cur);return list[(i+1)%list.length];}
function mut(fn,remeasure){
  var f=sel&&get(sel);if(!f)return;
  pushHist();fn(f);
  updateFrame(f,remeasure);changed();drawBar();
}
function newText(txt,over){
  var top=Math.max(40,visTop()+120);
  var f={id:uid(),t:'text',role:'b',x:80,y:top,w:840,h:100,txt:txt||'',fs:40,fw:400,col:inkOn(S.bg),al:'l',lh:1.3,ls:0,ff:'s',beh:'auto'};
  if(over)for(var k in over)f[k]=over[k];
  return f;
}
function pasteFlow(items){
  var out=[];
  pushHist();
  items.forEach(function(it){
    var f=null;
    if(it.k==='text'&&(it.txt||'').trim()){
      var m=/^H([1-5])$/.exec(it.tag||''),fs=m?[0,64,50,40,34,30][+m[1]]:30;
      f=newText(it.txt,{x:60,w:880,fs:fs,fw:m?700:400,lh:m?1.15:1.4,role:m?'h':'b'});
      if(it.lks&&it.lks.length)f.lks=JSON.parse(JSON.stringify(it.lks));
    }else if(it.k==='image'&&it.src){f={id:uid(),t:'image',src:it.src,fit:'cover',x:60,w:880,h:600};}
    else if(it.k==='link'&&it.url){f={id:uid(),t:'link',x:60,w:880,h:420,rad:24,url:it.url,lt:it.title||'',ld:it.desc||'',lsite:it.site||'',src:it.img||'',lst:it.state==='ok'?'ok':it.state==='fail'?'fail':'loading'};}
    if(f){f.y=0;S.frames.push(f);out.push(f);}
  });
  if(!out.length){hist.pop();post({type:'toast',text:'Nada para colar'});return;}
  render();
  var y=Math.max(40,visTop()+120);
  out.forEach(function(f){f.y=y;y+=f.h+30;});
  render();
  var ids=out.map(function(f){return f.id;});
  if(ids.length>1)setMs(ids,false);else select(ids[0]);
  changed();
}
function addFrame(f){pushHist();S.frames.push(f);render();select(f.id);changed();}
function shape(w,h,fill,rad){return {id:uid(),t:'shape',x:Math.round((PW-w)/2),y:Math.max(40,visTop()+200),w:w,h:h,fill:fill,rad:rad||0};}
/* ---------- copiar e colar caixas / formatação (vale entre notas) ---------- */
var CLIP={frame:null,style:null};
var STYLE_KEYS={text:['fs','fw','it','col','al','lh','ls','up','ff','fam','pad','beh','fm'],image:['fit','px','py','rad','fill'],shape:['fill','rad'],link:['fill','rad']};
window.setLib=function(l){
  l=l||{};LIB.style=(l.style||[]).filter(function(i){return i&&i.data;});
  LIB.tpl=(l.tpl||[]).filter(function(i){return i&&i.data&&i.data.slots;}).map(function(i){return {key:'u'+i.id,id:i.id,name:i.name,bg:i.data.bg||'#FFFFFF',slots:i.data.slots,user:true};});
  if(editable&&!editingId)drawBar();
};
window.setClip=function(c){
  c=c||{};CLIP.frame=c.frame||null;CLIP.style=(c.style&&c.style.t&&c.style.props)?c.style:null;
  if(editable&&!editingId)drawBar();
};
function frameCopy(f){var c=JSON.parse(JSON.stringify(f));delete c.id;delete c.lock;delete c.gid;return c;}
var ACT={
  goHead:function(id){
    outlineOpen=false;drawSheet();
    var d=elOf(id);if(!d)return;
    var rc=d.getBoundingClientRect();scEl.scrollTo({top:Math.max(0,scEl.scrollTop+rc.top-80),behavior:'smooth'});
  },
  saveStyle:function(){
    var f=sel&&get(sel);if(!f||f.t!=='text')return;
    var d={};ST_KEYS.forEach(function(k){if(f[k]!=null)d[k]=f[k];});
    post({type:'askLib',kind:'style',data:d});
  },
  applyStyle:function(id){
    var it=null;LIB.style.forEach(function(i){if(String(i.id)===String(id))it=i;});if(!it)return;
    mut(function(f){ST_KEYS.forEach(function(k){delete f[k];});for(var k in it.data)f[k]=it.data[k];if(f.beh==='fit')f.fm=f.fs;},true);
  },
  saveTpl:function(){
    var ph=PH(),pg=ph?curPage():0,top=ph?pg*ph:0,slots=[];
    S.frames.slice().sort(readingOrder).forEach(function(f){
      if(f.t==='link')return;
      if(ph&&pageOf(f)!==pg)return;
      var c=JSON.parse(JSON.stringify(f));delete c.id;delete c.lks;delete c.lst;c.y=Math.max(0,c.y-top);
      if(c.t==='text'){c.role=c.role||'b';var ph2={h:'Título',c:'Subtítulo',b:'Escreva aqui…'}[c.role];if(ph2)c.txt=ph2;}
      else if(c.t==='image'){delete c.src;delete c.px;delete c.py;}
      slots.push(c);
    });
    if(!slots.length){post({type:'toast',text:'A página está vazia'});return;}
    post({type:'askLib',kind:'tpl',data:{bg:S.bg,slots:slots}});
  },
  delLib:function(id){post({type:'delLib',id:id});},
  msToggle:function(){
    if(msMode||ms.length){setMs([],false);return;}
    var s0=sel&&get(sel),ids=s0?(s0.gid?grp(s0.gid):[s0.id]):[];
    select(null);setMs(ids,true);
  },
  msAl:function(k){
    var a=msFr().filter(function(q){return !q.lock;});if(!a.length)return;
    pushHist();
    var b=bbox(a),unit=a.length===1||sameG(a),x0=b.x,x1=b.x+b.w,y0=b.y,y1=b.y+b.h;
    if(unit){var ph=PH(),p=ph?Math.min(npages()-1,Math.max(0,Math.floor((b.y+b.h/2)/ph))):0;x0=0;x1=PW;y0=ph?p*ph:0;y1=ph?(p+1)*ph:pageH();
      var dx=0,dy=0;
      if(k==='l')dx=x0-b.x;else if(k==='r')dx=x1-(b.x+b.w);else if(k==='c')dx=(x0+x1)/2-(b.x+b.w/2);
      else if(k==='t')dy=y0-b.y;else if(k==='b')dy=y1-(b.y+b.h);else if(k==='m')dy=(y0+y1)/2-(b.y+b.h/2);
      a.forEach(function(f){f.x=Math.round(f.x+dx);f.y=Math.max(0,Math.round(f.y+dy));});
    }else{
      a.forEach(function(f){
        if(k==='l')f.x=Math.round(x0);else if(k==='r')f.x=Math.round(x1-f.w);else if(k==='c')f.x=Math.round((x0+x1)/2-f.w/2);
        else if(k==='t')f.y=Math.round(y0);else if(k==='b')f.y=Math.round(y1-f.h);else if(k==='m')f.y=Math.round((y0+y1)/2-f.h/2);
      });
    }
    refreshMs(a);
  },
  msDist:function(k){
    var a=msFr().filter(function(q){return !q.lock;});
    if(a.length<3){post({type:'toast',text:'Escolha 3 ou mais caixas'});return;}
    pushHist();
    var P=k==='h'?'x':'y',Z=k==='h'?'w':'h';
    a.sort(function(p,q){return p[P]-q[P];});
    var first=a[0][P],end=-1e9,sum=0;
    a.forEach(function(f){end=Math.max(end,f[P]+f[Z]);sum+=f[Z];});
    var gap=(end-first-sum)/(a.length-1),pos=first;
    a.forEach(function(f){f[P]=Math.round(pos);pos+=f[Z]+gap;});
    refreshMs(a);
  },
  group:function(){var a=msFr();if(a.length<2)return;pushHist();var g='g'+uid();a.forEach(function(f){f.gid=g;});changed();drawBar();post({type:'toast',text:'Agrupado'});},
  ungroup:function(){var a=msFr();pushHist();a.forEach(function(f){delete f.gid;});changed();drawBar();post({type:'toast',text:'Desagrupado'});},
  msDup:function(){
    var a=msFr();if(!a.length)return;pushHist();
    var map={},ids=[];
    a.forEach(function(f){var c=JSON.parse(JSON.stringify(f));c.id=uid();c.lock=false;c.x=Math.min(PW-40,c.x+30);c.y+=30;
      if(c.gid){map[c.gid]=map[c.gid]||('g'+uid());c.gid=map[c.gid];}S.frames.push(c);ids.push(c.id);});
    render();setMs(ids,msMode);changed();
  },
  msDel:function(){
    if(!ms.length)return;pushHist();var rm=ms.slice();
    S.frames=S.frames.filter(function(f){return rm.indexOf(f.id)<0;});
    ms=[];render();setMs([],msMode);changed();
  },
  msCopy:function(){
    var a=msFr();if(!a.length)return;var b=bbox(a);
    CLIP.frame={t:'multi',w:b.w,h:b.h,multi:a.map(function(f){var c=frameCopy(f);c.x-=b.x;c.y-=b.y;if(f.gid)c.gid=f.gid;return c;})};
    post({type:'clip',what:'frame',data:CLIP.frame});post({type:'toast',text:'Copiado'});drawBar();
  },
  msCut:function(){if(!ms.length)return;ACT.msCopy();ACT.msDel();},
  copyFrame:function(){var f=sel&&get(sel);if(!f)return;CLIP.frame=frameCopy(f);post({type:'clip',what:'frame',data:CLIP.frame});drawBar();},
  cutFrame:function(){var f=sel&&get(sel);if(!f)return;ACT.copyFrame();ACT.del();},
  pasteFrame:function(){
    if(!CLIP.frame)return;
    if(CLIP.frame.t==='flowblocks'){pasteFlow(CLIP.frame.items||[]);return;}
    if(CLIP.frame.t==='multi'){
      var mm=CLIP.frame,map={},ids=[],ox=Math.max(0,Math.round((PW-mm.w)/2)),oy=Math.max(40,visTop()+120);
      pushHist();
      mm.multi.forEach(function(q){var c=JSON.parse(JSON.stringify(q));c.id=uid();c.x+=ox;c.y+=oy;if(c.gid){map[c.gid]=map[c.gid]||('g'+uid());c.gid=map[c.gid];}S.frames.push(c);ids.push(c.id);});
      render();setMs(ids,false);changed();return;
    }
    var c=JSON.parse(JSON.stringify(CLIP.frame));c.id=uid();
    c.x=Math.max(0,Math.min(PW-c.w,c.x));c.y=Math.max(40,visTop()+120);
    if(c.t==='link'&&c.lst==='loading')c.lst='loading';
    addFrame(c);
  },
  copyStyle:function(){
    var f=sel&&get(sel);if(!f)return;
    var keys=STYLE_KEYS[f.t]||[],props={};
    for(var i=0;i<keys.length;i++)if(f[keys[i]]!==undefined)props[keys[i]]=f[keys[i]];
    CLIP.style={t:f.t,props:props};post({type:'clip',what:'style',data:CLIP.style});drawBar();
  },
  pasteStyle:function(){
    var st=CLIP.style;if(!st||!sel)return;
    mut(function(f){
      if(f.t===st.t){
        var keys=STYLE_KEYS[f.t]||[];
        for(var i=0;i<keys.length;i++){var k=keys[i];if(st.props[k]!==undefined)f[k]=st.props[k];else delete f[k];}
      }else{
        // tipos diferentes: só o que faz sentido nos dois (cor de fundo e cantos)
        var okFill=f.t!=='text',okRad=f.t!=='text';
        if(okFill&&st.props.fill!==undefined)f.fill=st.props.fill;
        if(okRad&&st.props.rad!==undefined)f.rad=st.props.rad;
        if(f.t!=='text'&&st.t==='text'&&st.props.col&&f.t==='shape')f.fill=st.props.col;
      }
    },true);
  },
  addText:function(){var f=newText('');addFrame(f);startEdit(f.id);},
  addTitle:function(){var f=newText('Título',{role:'h',fs:120,fw:800,ls:-0.04,lh:1});addFrame(f);startEdit(f.id);},
  addImage:function(){post({type:'pickFrameImage',id:'new'});},
  addLink:function(){post({type:'askFrameLink',id:'new',url:''});},
  editLink:function(){var f=sel&&get(sel);if(f&&f.t==='link')post({type:'askFrameLink',id:f.id,url:f.url||''});},
  openLinkFrame:function(){var f=sel&&get(sel);if(f&&f.t==='link'&&f.url)post({type:'openLink',url:f.url});},
  refreshLink:function(){var f=sel&&get(sel);if(f&&f.t==='link')window.refreshFrameLink(f.id);},
  linkSel:function(){
    var f=editingId&&get(editingId);
    if(!f){var g=sel&&get(sel);if(g&&g.t==='text'&&!g.lock){startEdit(g.id);post({type:'toast',text:'Selecione o trecho e toque em Link de novo'});}return;}
    var r=selRange();
    if(r){var tx=f.txt||'';while(r.s<r.e&&/\s/.test(tx.charAt(r.s)))r.s++;while(r.e>r.s&&/\s/.test(tx.charAt(r.e-1)))r.e--;}
    if(!r||r.s>=r.e){post({type:'toast',text:'Selecione o trecho que vai virar link'});return;}
    var hit=null;for(var i=0;i<(f.lks||[]).length;i++)if(f.lks[i].s<r.e&&f.lks[i].e>r.s){hit=f.lks[i];break;}
    PL={id:f.id,s:r.s,e:r.e};
    post({type:'askFrameLink',id:'tl',url:hit?hit.url:''});
  },
  editTL:function(i){var f=sel&&get(sel),l=f&&f.lks&&f.lks[+i];if(!l)return;PL={id:f.id,s:l.s,e:l.e};post({type:'askFrameLink',id:'tl',url:l.url});},
  openTL:function(i){var f=sel&&get(sel),l=f&&f.lks&&f.lks[+i];if(l)post({type:'openLink',url:l.url});},
  delTL:function(i){
    var f=sel&&get(sel);if(!f||!f.lks||!f.lks[+i])return;
    pushHist();f.lks.splice(+i,1);if(!f.lks.length)delete f.lks;
    if(editingId===f.id)paintHL();else updateFrame(f,false);
    changed();drawBar();
  },
  goPage:function(i){var ph=PH();if(!ph)return;pgSel=+i;scEl.scrollTop=pgSel*ph*K;drawBar();},
  addPage:function(){
    var ph=PH();if(!ph)return;if(editingId)endEdit();
    pushHist();S.np=npages()+1;render();changed();ACT.goPage(S.np-1);
  },
  dupPage:function(){
    var ph=PH();if(!ph)return;if(editingId)endEdit();
    var n=npages(),i=curPage(),inPg=[],after=[];
    for(var a=0;a<S.frames.length;a++){var g=pageOf(S.frames[a]);if(g===i)inPg.push(S.frames[a]);else if(g>i)after.push(S.frames[a]);}
    pushHist();
    for(var b=0;b<after.length;b++)after[b].y+=ph;
    for(var c=0;c<inPg.length;c++){var cp=JSON.parse(JSON.stringify(inPg[c]));cp.id=uid();cp.y+=ph;cp.lock=false;S.frames.push(cp);}
    S.np=n+1;sel=null;render();changed();ACT.goPage(i+1);
  },
  delPage:function(){
    var ph=PH();if(!ph)return;if(editingId)endEdit();
    var n=npages(),i=curPage(),keep=[];
    pushHist();
    for(var a=0;a<S.frames.length;a++){var f=S.frames[a],g=pageOf(f);if(g===i)continue;if(g>i)f.y-=ph;keep.push(f);}
    S.frames=keep;S.np=Math.max(1,n-1);sel=null;pgSel=null;render();changed();
    post({type:'toast',text:n>1?'Página excluída (↶ desfaz)':'Página esvaziada (↶ desfaz)'});
  },
  movePage:function(d){
    var ph=PH();d=+d;if(!ph)return;if(editingId)endEdit();
    var n=npages(),i=curPage(),j=i+d;if(j<0||j>=n)return;
    var A=[],B=[];for(var a=0;a<S.frames.length;a++){var g=pageOf(S.frames[a]);if(g===i)A.push(S.frames[a]);else if(g===j)B.push(S.frames[a]);}
    pushHist();
    for(var b=0;b<A.length;b++)A[b].y+=d*ph;
    for(var c=0;c<B.length;c++)B[c].y-=d*ph;
    S.np=n;pgSel=j;render();changed();ACT.goPage(j);
  },
  setFmt:function(k){
    var old=PH(),n=npages();
    if(k==='cont'){if(!old)return;if(editingId)endEdit();pushHist();delete S.pr;delete S.np;sel=null;render();changed();drawBar();return;}
    var z=sizeOf(k);if(!z||S.pr===k)return;
    if(editingId)endEdit();
    pushHist();
    if(old){
      for(var a=0;a<S.frames.length;a++){var f=S.frames[a],i=pageOf(f),off=f.y-i*old,room=z.h-f.h;
        f.y=Math.round(i*z.h+Math.max(0,room>0?Math.min(off,room):off));}
      S.pr=k;S.np=n;
    }else{S.pr=k;S.np=1;paginate();}
    pgSel=null;sel=null;render();changed();drawBar();
  },
  addLine:function(){addFrame(shape(PW-2*MG(),6,inkOn(S.bg),0));},
  addRect:function(){addFrame(shape(420,300,'#E8501F',0));},
  addCircle:function(){addFrame(shape(360,360,'#FFE600',500));},
  undo:function(){if(!hist.length)return;if(editingId)endEdit();fut.push(snapJson());S=JSON.parse(hist.pop());sel=null;render();changed();},
  redo:function(){if(!fut.length)return;if(editingId)endEdit();hist.push(snapJson());S=JSON.parse(fut.pop());sel=null;render();changed();},
  more:function(){more=true;drawBar();setTimeout(reveal,60);},
  less:function(){more=false;drawBar();},
  plusTab:function(){if(ms.length||msMode)setMs([],false);if(editingId)endEdit();if(sel)select(null);if(tab==='add'){tab=null;openPref=false;}else{tab='add';openPref=true;}drawBar();setTimeout(reveal,60);},
  tab:function(t){if(tab===t){tab=null;openPref=false;}else{tab=t;openPref=true;}drawBar();setTimeout(reveal,60);},
  done:function(){if(ms.length||msMode){setMs([],false);return;}if(editingId){endEdit();return;}if(sel){select(null);return;}post({type:'finish'});},
  del:function(){var f=sel&&get(sel);if(!f)return;pushHist();S.frames=S.frames.filter(function(x){return x.id!==f.id;});sel=null;render();changed();},
  dup:function(){var f=sel&&get(sel);if(!f)return;var c=JSON.parse(JSON.stringify(f));c.id=uid();c.x=Math.min(PW-40,c.x+30);c.y+=30;c.lock=false;delete c.gid;addFrame(c);},
  front:function(){var f=sel&&get(sel);if(!f)return;pushHist();S.frames=S.frames.filter(function(x){return x!==f;});S.frames.push(f);render();changed();},
  back:function(){var f=sel&&get(sel);if(!f)return;pushHist();S.frames=S.frames.filter(function(x){return x!==f;});S.frames.unshift(f);render();changed();},
  lock:function(){mut(function(f){f.lock=!f.lock;},false);drawSel();},
  full:function(){mut(function(f){if(f.x===0&&f.w===PW){f.x=MG();f.w=PW-2*MG();}else{f.x=0;f.w=PW;}});},
  margins:function(){mut(function(f){f.x=MG();f.w=PW-2*MG();});},
  alignL:function(){mut(function(f){f.x=MG();},false);},
  alignC:function(){mut(function(f){f.x=Math.round((PW-f.w)/2);},false);},
  alignR:function(){mut(function(f){f.x=PW-MG()-f.w;},false);},
  step:function(n){NUDGE=+n;drawBar();},
  nudge:function(d){
    if(ms.length){var na=msFr().filter(function(q){return !q.lock;});if(!na.length)return;pushHist();
      na.forEach(function(f){if(d==='l')f.x-=NUDGE;if(d==='r')f.x+=NUDGE;if(d==='u')f.y=Math.max(0,f.y-NUDGE);if(d==='d')f.y+=NUDGE;});refreshMs(na);return;}
    mut(function(f){if(d==='l')f.x-=NUDGE;if(d==='r')f.x+=NUDGE;if(d==='u')f.y=Math.max(0,f.y-NUDGE);if(d==='d')f.y+=NUDGE;},false);},
  sizeStep:function(n){mut(function(f){f.fs=Math.max(8,Math.min(600,Math.round((f.fs||32)+(+n))));if(f.beh==='fit')f.beh='auto';});},
  weight:function(w){mut(function(f){f.fw=+w;});},
  italic:function(){mut(function(f){f.it=!f.it;});},
  upper:function(){mut(function(f){f.up=!f.up;});},
  align:function(a){mut(function(f){f.al=a;},false);},
  behave:function(b){mut(function(f){f.beh=b;if(b==='fit')f.fm=Math.max(f.fm||0,f.fs||32,200);});},
  fonts:function(){fontSheet=true;drawSheet();},
  setfont:function(v){
    mut(function(f){if(v.indexOf('u:')===0){f.fam=v.slice(2);f.ff=f.ff||'s';}else{f.fam=null;f.ff=v;}});
    fontSheet=false;drawSheet();
  },
  moreFonts:function(){fontSheet=false;drawSheet();post({type:'openFonts'});},
  swapImage:function(){post({type:'pickFrameImage',id:sel});},
  fit:function(v){mut(function(f){f.fit=v;if(v==='contain'&&!f.fill)f.fill=S.bg;},false);},
  focus:function(v){var a=v.split(',');mut(function(f){f.px=+a[0];f.py=+a[1];},false);},
  color:function(c){mut(function(f){if(f.t==='text')f.col=c;else f.fill=c;},false);},
  customColor:function(){colorFor='frame';post({type:'pickFrameColor',for:'frame'});},
  customBg:function(){colorFor='bg';post({type:'pickFrameColor',for:'bg'});},
  bg:function(c){
    pushHist();var wasDark=luma(S.bg)<0.45,isDark=luma(c)<0.45;S.bg=c;
    if(wasDark!==isDark)for(var i=0;i<S.frames.length;i++){var f=S.frames[i];if(f.t==='text'&&(f.col==='#111111'||f.col==='#FFFFFF'))f.col=inkOn(c);if(f.t==='shape'&&(f.fill==='#111111'||f.fill==='#FFFFFF'||f.fill==='#000000'))f.fill=inkOn(c);}
    render();changed();
  },
  grid:function(){pushHist();S.grid=!S.grid;drawGrid();changed();drawBar();},
  preset:function(k){applyPreset(k);drawBar();}
};
/* ---------- controles deslizantes ---------- */
function szToSl(v){return Math.round(100*Math.log(Math.max(8,v)/8)/Math.log(75));}
function slToSz(v){return Math.round(8*Math.pow(75,v/100));}
var SL={
  fs:{n:'Tamanho',min:0,max:100,step:1,get:function(f){return szToSl(f.fs||32);},set:function(f,v){f.fs=slToSz(v);if(f.beh==='fit')f.beh='auto';},fmt:function(f){return String(f.fs||32);}},
  lh:{n:'Entrelinha',min:0.8,max:2.4,step:0.05,get:function(f){return f.lh||1.3;},set:function(f,v){f.lh=Math.round(v*100)/100;},fmt:function(f){return (f.lh||1.3).toFixed(2);}},
  ls:{n:'Letras',min:-0.1,max:0.4,step:0.01,get:function(f){return f.ls||0;},set:function(f,v){f.ls=Math.round(v*100)/100;},fmt:function(f){return (f.ls||0).toFixed(2);}},
  pad:{n:'Respiro',min:0,max:120,step:2,get:function(f){return f.pad||0;},set:function(f,v){f.pad=Math.round(v);},fmt:function(f){return String(f.pad||0);}},
  rad:{n:'Cantos',min:0,max:500,step:4,get:function(f){return f.rad||0;},set:function(f,v){f.rad=Math.round(v);},fmt:function(f){return (f.rad||0)>=500?'redondo':String(f.rad||0);}},
  m:{n:'Margem',page:1,min:0,max:160,step:2,get:function(){return MG();},set:function(f,v){S.m=Math.round(v);},fmt:function(){return String(MG());}}
};
function slider(k){
  var d=SL[k],t=d.page?S:(sel&&get(sel));if(!t)return '';
  return '<div class="rowc"><div class="nm">'+d.n+'</div><input type="range" data-sl="'+k+'" min="'+d.min+'" max="'+d.max+'" step="'+d.step+'" value="'+d.get(t)+'"><div class="val" id="v_'+k+'">'+d.fmt(t)+'</div></div>';
}
function slide(k,v,final){
  var d=SL[k];if(!d)return;
  var t=d.page?S:(sel&&get(sel));if(!t)return;
  d.set(t,v);
  var lb=$('v_'+k);if(lb)lb.textContent=d.fmt(t);
  if(d.page){drawGrid();}else{updateFrame(t,true);}
  if(final){changed();drawBar();}
}
/* ---------- barra de ferramentas (dock) ---------- */
function swatch(c,act,on){return '<div class="sw'+(on?' on':'')+'" data-act="'+act+'" data-arg="'+c+'" style="background:'+c+'"></div>';}
function seg(items,cur,act){return '<div class="seg">'+items.map(function(i){return '<div class="'+(String(i[0])===String(cur)?'on':'')+'" data-act="'+act+'" data-arg="'+i[0]+'">'+i[1]+'</div>';}).join('')+'</div>';}
function chipB(label,act,arg,cls){return '<div class="chip '+(cls||'')+'" data-act="'+act+'"'+(arg!=null?' data-arg="'+arg+'"':'')+'>'+label+'</div>';}
function lbl(t){return '<div class="lbl">'+t+'</div>';}
function alIcon(a){return IC['align'+a.toUpperCase()]||'';}
var IC=${iconMap(['plus','undo','redo','type','para','palette','move','image','border','link','align','layers','columns','text','select','check','sliders','alignL','alignC','alignR','alignJ','size','circle','square','minus','arrowL','arrowU','arrowD','arrowR','close'])};
var TABICON={txt:'type',par:'para',col:'palette',pos:'move',img:'image',sty:'border',lnk:'link',msa:'align',msb:'layers',tpl:'columns',page:'text'};
function tabsFor(f){
  if(!f&&(msMode||ms.length))return [['msa','Alinhar'],['msb','Organizar']];
  if(!f)return [['add','Adicionar'],['tpl','Modelos'],['page','Página']];
  if(f.t==='text')return [['txt','Texto'],['par','Parágrafo'],['col','Cor'],['pos','Posição']];
  if(f.t==='image')return [['img','Imagem'],['sty','Estilo'],['pos','Posição']];
  if(f.t==='link')return [['lnk','Link'],['sty','Estilo'],['pos','Posição']];
  return [['sty','Estilo'],['pos','Posição']];
}
function fontName(f){return (f.fam&&FONTLIST.indexOf(f.fam)>=0)?f.fam:({s:'Sans',f:'Serifa',m:'Mono'}[f.ff||'s']);}
function colorPanel(cur,custom){
  return '<div class="sws">'+TXT_COLORS.concat([S.bg]).map(function(c){return swatch(c,'color',String(c).toLowerCase()===String(cur||'').toLowerCase());}).join('')+'<div class="sw plus" data-act="'+custom+'">+</div></div>';
}
var PSUB=false,more=false,lastKey='';
function hasFull(f){return !!f&&(tab==='txt'||tab==='par'||tab==='pos'||tab==='img'||tab==='sty');}
function quickHtml(f){
  var st=function(a,t){return '<div class="ib" data-act="sizeStep" data-arg="'+a+'">'+t+'</div>';};
  if(!f){
    if(tab==='add')return panelFull(f);
    if(tab==='msa'&&(msMode||ms.length)&&msFr().length)return panelFull(f);
    return null;
  }
  if(tab==='txt')return '<div class="fontbtn" data-act="fonts" style="font-family:'+famOf(f)+'">'+fontName(f)+'<small>›</small></div>'+st(-2,'−')+'<div class="val" id="v_fs">'+SL.fs.fmt(f)+'</div>'+st(2,'+')+
    seg([[300,'Leve'],[400,'Normal'],[700,'Negrito'],[800,'Extra']],f.fw||400,'weight');
  if(tab==='par')return seg([['l',alIcon('l')],['c',alIcon('c')],['r',alIcon('r')],['j',alIcon('j')]],f.al||'l','align');
  if(tab==='col')return colorPanel(f.col,'customColor');
  if(tab==='lnk')return chipB('Abrir','openLinkFrame')+chipB('Editar link','editLink')+chipB('Atualizar prévia','refreshLink');
  if(tab==='img')return chipB('Trocar imagem','swapImage')+seg([['cover','Preencher'],['contain','Caber inteira']],f.fit||'cover','fit');
  if(tab==='sty')return colorPanel(f.t==='shape'?f.fill:(f.t==='link'?(f.fill||linkFill(f)):f.fill),'customColor');
  if(tab==='pos')return seg([['L',alIcon('l')],['C',alIcon('c')],['R',alIcon('r')]],'','pal')+chipB('Para frente','front')+chipB('Para trás','back')+chipB('Duplicar','dup')+chipB(f.lock?'Destravar':'Travar','lock',null,f.lock?'on':'')+chipB('Excluir','del',null,'red');
  return null;
}
function panelHtml(f){
  PSUB=false;
  if(!tab)return '';
  if(!more){
    var q=quickHtml(f);
    if(q!==null){PSUB=true;return q+(hasFull(f)?'<div class="b" data-act="more" role="button" aria-label="Mais ajustes">'+IC.sliders+'</div>':'');}
  }
  var h=panelFull(f);
  if(more&&hasFull(f))h+='<div class="btns">'+chipB('Fechar ajustes','less')+'</div>';
  return h;
}
function panelFull(f){
  if(!tab)return '';
  var h='';
  if(!f&&(msMode||ms.length)){
    var a=msFr(),one=a.length<2||sameG(a);
    if(!a.length)return lbl('Toque nas caixas para selecioná-las');
    if(tab==='msa'){
      h=lbl(one?'Alinhar à página':'Alinhar entre as caixas')+
        '<div class="btns">'+chipB('Esquerda','msAl','l')+chipB('Centro','msAl','c')+chipB('Direita','msAl','r')+'</div>'+
        '<div class="btns">'+chipB('Topo','msAl','t')+chipB('Meio','msAl','m')+chipB('Base','msAl','b')+'</div>';
      if(!one)h+=lbl('Distribuir (3 ou mais caixas)')+'<div class="btns">'+chipB('Horizontal','msDist','h')+chipB('Vertical','msDist','v')+'</div>';
    }else{
      var anyG=a.some(function(q){return q.gid;});
      h=lbl('Grupo')+'<div class="btns">'+(a.length>1&&!sameG(a)?chipB('Agrupar','group'):'')+(anyG?chipB('Desagrupar','ungroup'):'')+'</div>'+
        lbl('Copiar e colar')+'<div class="btns">'+chipB('Copiar','msCopy')+chipB('Cortar','msCut')+(CLIP.frame?chipB('Colar caixa','pasteFrame'):'')+chipB('Duplicar','msDup')+'</div>'+
        lbl('Mover')+seg([[1,'1'],[10,'10'],[50,'50']],NUDGE,'step')+
        '<div class="nudge"><div class="ib" data-act="nudge" data-arg="l">'+IC.arrowL+'</div><div class="ib" data-act="nudge" data-arg="u">'+IC.arrowU+'</div><div class="ib" data-act="nudge" data-arg="d">'+IC.arrowD+'</div><div class="ib" data-act="nudge" data-arg="r">'+IC.arrowR+'</div></div>'+
        '<div class="btns">'+chipB('Excluir','msDel',null,'red')+'</div>';
    }
    return h;
  }
  if(!f){
    if(tab==='add'){
      h='<div class="tiles">'+
        '<div class="tile" data-act="addText"><b>'+IC.type+'</b>Texto</div>'+
        '<div class="tile" data-act="addTitle"><b>'+IC.size+'</b>Título</div>'+
        '<div class="tile" data-act="addImage"><b>'+IC.image+'</b>Imagem</div>'+
        '<div class="tile" data-act="addLink"><b>'+IC.link+'</b>Link</div>'+
        '<div class="tile" data-act="addLine"><b>'+IC.minus+'</b>Linha</div>'+
        '<div class="tile" data-act="addRect"><b>'+IC.square+'</b>Retângulo</div>'+
        '<div class="tile" data-act="addCircle"><b>'+IC.circle+'</b>Círculo</div></div>'+
        (CLIP.frame?'<div class="btns">'+chipB('Colar caixa copiada','pasteFrame')+'</div>':'');
    }else if(tab==='tpl'){
      h='<div class="hint">Seu conteúdo é reencaixado no modelo escolhido. Nada se perde.</div><div class="tpls">'+PRESETS.concat(LIB.tpl).map(function(p){return '<div class="tp" data-act="preset" data-arg="'+p.key+'"><div class="th" style="background:'+p.bg+'">'+thumb(p)+(p.user?'<div class="x" data-act="delLib" data-arg="'+p.id+'">'+IC.close+'</div>':'')+'</div>'+escT(p.name)+'</div>';}).join('')+'</div><div class="btns">'+chipB('Salvar página como modelo','saveTpl')+'</div>';
    }else if(tab==='page'){
      h=pagesPanel()+lbl('Fundo da página')+'<div class="sws">'+BGS.map(function(c){return swatch(c,'bg',c===S.bg);}).join('')+'<div class="sw plus" data-act="customBg">+</div></div>'+
        slider('m')+
        '<div class="btns">'+chipB(S.grid?'Grade e margens: ligada':'Mostrar grade e margens','grid',null,S.grid?'on':'')+'</div>';
    }
  }else if(tab==='txt'){
    h=lbl('Fonte')+'<div class="fontbtn" data-act="fonts" style="font-family:'+famOf(f)+'">'+fontName(f)+'<small>›</small></div>'+
      '<div class="rowc"><div class="nm">Tamanho</div><div class="ib" data-act="sizeStep" data-arg="-2">−</div><input type="range" data-sl="fs" min="0" max="100" step="1" value="'+SL.fs.get(f)+'"><div class="ib" data-act="sizeStep" data-arg="2">+</div><div class="val" id="v_fs">'+SL.fs.fmt(f)+'</div></div>'+
      seg([[300,'Leve'],[400,'Normal'],[700,'Negrito'],[800,'Extra']],f.fw||400,'weight')+
      '<div class="btns">'+chipB('Itálico','italic',null,f.it?'on':'')+chipB('MAIÚSCULAS','upper',null,f.up?'on':'')+'</div>'+stylesPanel(f)+linkPanel(f);
  }else if(tab==='par'){
    h=seg([['l',alIcon('l')],['c',alIcon('c')],['r',alIcon('r')],['j',alIcon('j')]],f.al||'l','align')+
      slider('lh')+slider('ls')+slider('pad')+
      lbl('Caixa de texto')+seg([['auto','Cresce'],['fixed','Fixa'],['fit','Ajusta a fonte']],f.beh||'auto','behave');
  }else if(tab==='col'){
    h=lbl('Cor do texto')+colorPanel(f.col,'customColor');
  }else if(tab==='lnk'){
    h='<div class="hint" style="word-break:break-all">'+escT(f.url||'')+'</div>'+
      '<div class="btns">'+chipB('Abrir','openLinkFrame')+chipB('Editar link','editLink')+chipB('Atualizar prévia','refreshLink')+'</div>';
  }else if(tab==='img'){
    h='<div class="btns">'+chipB('Trocar imagem','swapImage')+'</div>'+
      seg([['cover','Preencher'],['contain','Caber inteira']],f.fit||'cover','fit');
    if((f.fit||'cover')==='cover'){
      var cur=(f.px==null?50:f.px)+','+(f.py==null?50:f.py),pts=['0,0','50,0','100,0','0,50','50,50','100,50','0,100','50,100','100,100'];
      h+=lbl('Foco do recorte')+'<div class="focus">'+pts.map(function(q){return '<div class="'+(q===cur?'on':'')+'" data-act="focus" data-arg="'+q+'"></div>';}).join('')+'</div>';
    }
  }else if(tab==='sty'){
    h=slider('rad');
    if(f.t==='shape')h+=lbl('Cor')+colorPanel(f.fill,'customColor');
    else if(f.t==='link')h+=lbl('Cor do card')+colorPanel(f.fill||linkFill(f),'customColor');
    else h+=lbl('Cor de fundo (aparece ao caber a imagem)')+colorPanel(f.fill,'customColor');
  }else if(tab==='pos'){
    h=lbl('Alinhar na página')+seg([['L',alIcon('l')],['C',alIcon('c')],['R',alIcon('r')]],'','pal')+
      '<div class="btns">'+chipB(f.x===0&&f.w===PW?'Com margem':'Largura total','full')+chipB('Preencher entre margens','margins')+'</div>'+
      lbl('Copiar e colar')+
      '<div class="btns">'+chipB('Copiar caixa','copyFrame')+chipB('Cortar','cutFrame')+(CLIP.frame?chipB('Colar caixa','pasteFrame'):'')+'</div>'+
      '<div class="btns">'+chipB('Copiar formato','copyStyle')+(CLIP.style?chipB('Colar formato'+(CLIP.style.t!==f.t?' (parcial)':''),'pasteStyle'):'')+'</div>'+
      lbl('Mover')+seg([[1,'1'],[10,'10'],[50,'50']],NUDGE,'step')+
      '<div class="nudge"><div class="ib" data-act="nudge" data-arg="l">'+IC.arrowL+'</div><div class="ib" data-act="nudge" data-arg="u">'+IC.arrowU+'</div><div class="ib" data-act="nudge" data-arg="d">'+IC.arrowD+'</div><div class="ib" data-act="nudge" data-arg="r">'+IC.arrowR+'</div></div>'+
      '<div class="btns">'+chipB('Para frente','front')+chipB('Para trás','back')+chipB('Duplicar','dup')+chipB(f.lock?'Destravar':'Travar','lock',null,f.lock?'on':'')+chipB('Excluir','del',null,'red')+'</div>';
  }
  return h;
}
var ST_KEYS=['ff','fam','fs','fw','it','up','col','al','lh','ls','pad'];
function stylesPanel(f){
  var h=lbl('Estilos')+'<div class="btns">'+chipB('Salvar estilo desta caixa','saveStyle')+'</div>';
  if(LIB.style.length){h+='<div class="btns">';for(var i=0;i<LIB.style.length;i++)h+=chipB(escT(LIB.style[i].name),'applyStyle',LIB.style[i].id)+chipB(IC.close,'delLib',LIB.style[i].id,'red');h+='</div>';}
  return h;
}
function linkPanel(f){
  var h=lbl('Link no texto')+'<div class="btns">'+chipB(editingId===f.id?'Link no trecho selecionado':'Escolher trecho e criar link','linkSel')+'</div>';
  var ls=f.lks||[];
  if(!ls.length)return h+'<div class="hint">Selecione um trecho enquanto escreve e toque em Link. Fora da edição, tocar no trecho abre o endereço.</div>';
  var tx=f.txt||'';
  for(var i=0;i<ls.length;i++){
    var t=tx.slice(ls[i].s,ls[i].e).replace(/\s+/g,' ');
    h+='<div class="tlt">'+escT(t)+'</div><div class="tlu">'+escT(ls[i].url)+'</div>'+
      '<div class="btns">'+chipB('Abrir','openTL',i)+chipB('Editar','editTL',i)+chipB('Remover','delTL',i,'red')+'</div>';
  }
  return h;
}
function pageThumbs(){
  var ph=PH(),n=npages(),cur=curPage(),w=46,sc=w/PW,h='';
  for(var i=0;i<n;i++){
    var top=i*ph,inner='';
    for(var k=0;k<S.frames.length;k++){var f=S.frames[k];
      if(!(f.y<top+ph&&f.y+f.h>top))continue;
      var st='left:'+(f.x*sc)+'px;top:'+((f.y-top)*sc)+'px;width:'+(f.w*sc)+'px;';
      if(f.t==='image')inner+='<i style="'+st+'height:'+(f.h*sc)+'px;background:#9A9A9A"></i>';
      else if(f.t==='shape')inner+='<i style="'+st+'height:'+Math.max(1,f.h*sc)+'px;background:'+(f.fill||'#000')+'"></i>';
      else if(f.t==='link')inner+='<i style="'+st+'height:'+(f.h*sc)+'px;background:#8A8A8A"></i>';
      else inner+='<i style="'+st+'height:'+Math.max(1.5,Math.min(f.h,(f.fs||32)*1.3)*sc)+'px;background:'+(f.col||'#111')+';opacity:.6"></i>';
    }
    h+='<div class="pt'+(i===cur?' on':'')+'" data-act="goPage" data-arg="'+i+'"><div class="pth" style="width:'+w+'px;height:'+(ph*sc)+'px;background:'+S.bg+'">'+inner+'</div>'+(i+1)+'</div>';
  }
  return h;
}
function pagesPanel(){
  var ph=PH(),h='';
  if(ph){
    var n=npages(),cur=curPage();
    h+=lbl('Páginas ('+n+')')+'<div class="pgstrip">'+pageThumbs()+'</div>'+
      '<div class="btns">'+chipB('+ Página','addPage')+chipB('Duplicar','dupPage')+chipB('← Mover','movePage','-1',cur>0?'':'dim')+chipB('Mover →','movePage','1',cur<n-1?'':'dim')+chipB('Excluir','delPage',null,'red')+'</div>';
  }
  h+=lbl('Formato da página')+'<div class="btns">'+SIZES.map(function(z){return chipB(z.name,'setFmt',z.key,S.pr===z.key?'on':'');}).join('')+chipB('Contínua','setFmt','cont',ph?'':'on')+'</div>';
  if(!ph)h+='<div class="hint">Escolha um formato para dividir a nota em páginas. Nada se perde: o que cruzaria a divisa vai para a página seguinte.</div>';
  return h;
}
function thumb(p){
  var sc=60/PW,h='';
  for(var i=0;i<p.slots.length;i++){
    var s=p.slots[i],st='left:'+(s.x*sc)+'px;top:'+(s.y*sc)+'px;width:'+(s.w*sc)+'px;';
    if(s.t==='image')h+='<i style="'+st+'height:'+(s.h*sc)+'px;background:#9A9A9A"></i>';
    else if(s.t==='shape')h+='<i style="'+st+'height:'+Math.max(1,s.h*sc)+'px;background:'+s.fill+'"></i>';
    else h+='<i style="'+st+'height:'+Math.max(2,Math.min(s.h,(s.fs||30)*1.0)*sc)+'px;background:'+(s.col||'#111')+';opacity:.85"></i>';
  }
  return h;
}
function drawBar(){
  if(!editable)return;
  var f=sel&&get(sel),ts=tabsFor(f);
  if(tab&&!ts.some(function(t){return t[0]===tab;}))tab=null;
  var ic=function(n){return IC[n]||'';};
  var tl=ts.filter(function(t){return t[0]!=='add';});
  var rb=function(cls,act,arg,lab,ico){return '<div class="b'+cls+'" data-act="'+act+'"'+(arg!=null?' data-arg="'+arg+'"':'')+' role="button" aria-label="'+lab+'">'+ic(ico)+'</div>';};
  var hb='<div class="b plus" data-act="plusTab" role="button" aria-label="Adicionar">'+ic('plus')+'</div><div class="sep"></div>'
    +rb(hist.length?'':' dim','undo',null,'Desfazer','undo')+rb(fut.length?'':' dim','redo',null,'Refazer','redo')
    +(tl.length?'<div class="sep"></div>':'')
    +tl.map(function(t){return rb(tab===t[0]?' on':'','tab',t[0],t[1],TABICON[t[0]]||'border');}).join('')
    +'<div class="sep"></div>'+rb((msMode||ms.length)?' on':'','msToggle',null,'Selecionar várias caixas','select')
    +rb('','done',null,(f||msMode||ms.length)?'OK':'Concluir','check');
  $('row').innerHTML=hb;
  var pkey=(sel||0)+':'+tab;if(pkey!==lastKey){more=false;lastKey=pkey;}
  $('pn').innerHTML=panelHtml(f);$('pn').className=PSUB?'sub':'';
  layoutDock();
}
function layoutDock(){
  if(editable)setTimeout(reveal,60);
}
function outlineItems(){return S.frames.filter(function(f){return f.t==='text'&&f.role==='h'&&(f.txt||'').trim();}).sort(readingOrder);}
function drawSheet(){
  var sh=$('sheet'),sc=$('scrim');
  if(outlineOpen){
    var hs=outlineItems(),oh='<div class="ttl">Ir para</div>';
    if(!hs.length)oh+='<div class="frow" style="font-size:15px;color:#666">Nenhuma caixa de título nesta nota</div>';
    for(var i=0;i<hs.length;i++){var tx=(hs[i].txt||'').trim().split('\n')[0].slice(0,70);oh+='<div class="frow" data-act="goHead" data-arg="'+hs[i].id+'" style="font-size:17px">'+escT(tx)+'</div>';}
    sh.innerHTML=oh;sh.style.display='block';sc.style.display='block';return;
  }
  if(!fontSheet){sh.style.display='none';sc.style.display='none';return;}
  var f=sel&&get(sel);if(!f){fontSheet=false;sh.style.display='none';sc.style.display='none';return;}
  var cur=(f.fam&&FONTLIST.indexOf(f.fam)>=0)?'u:'+f.fam:(f.ff||'s');
  function row(arg,name,css){return '<div class="frow" data-act="setfont" data-arg="'+arg+'" style="font-family:'+css+'">'+name+(arg===cur?'<span class="ck">✓</span>':'')+'</div>';}
  var h='<div class="ttl">Padrão</div>'+row('s','Sans',FONTS.s)+row('f','Serifa',FONTS.f)+row('m','Mono',FONTS.m);
  h+='<div class="ttl">Minhas fontes</div>';
  if(!FONTLIST.length)h+='<div class="frow" style="font-size:15px;color:#666">Nenhuma ainda</div>';
  for(var i=0;i<FONTLIST.length;i++)h+=row('u:'+FONTLIST[i],FONTLIST[i],"'"+FONTLIST[i]+"',"+FONTS.s);
  h+='<div class="frow more" data-act="moreFonts">+ Buscar mais no Google Fonts</div>';
  sh.innerHTML=h;sh.style.display='block';sc.style.display='block';
}
function dockTap(e){
  var c=e.target.closest&&e.target.closest('[data-act]');if(!c)return;
  var a=c.getAttribute('data-act'),arg=c.getAttribute('data-arg');
  if(a==='pal'){if(arg==='L')ACT.alignL();else if(arg==='C')ACT.alignC();else ACT.alignR();return;}
  if(ACT[a])ACT[a](arg);
}
['pointerdown','mousedown'].forEach(function(n){$('dock').addEventListener(n,function(e){
  var t=e.target;
  if(t&&t.getAttribute&&t.getAttribute('data-sl')){if(n==='pointerdown'&&!slHist){pushHist();slHist=true;}return;}
  e.preventDefault();
});});
$('dock').addEventListener('click',dockTap);
$('sheet').addEventListener('click',dockTap);
$('scrim').addEventListener('click',function(){fontSheet=false;outlineOpen=false;drawSheet();});
$('dock').addEventListener('input',function(e){var k=e.target.getAttribute&&e.target.getAttribute('data-sl');if(k)slide(k,parseFloat(e.target.value),false);});
$('dock').addEventListener('change',function(e){var k=e.target.getAttribute&&e.target.getAttribute('data-sl');if(k){slHist=false;slide(k,parseFloat(e.target.value),true);}});
/* ---------- modelos ---------- */
function T(role,x,y,w,h,o){var f={t:'text',role:role,x:x,y:y,w:w,h:h,fs:32,fw:400,al:'l',lh:1.3,ls:0,ff:'s',beh:'auto'};for(var k in o)f[k]=o[k];return f;}
function I(x,y,w,h,o){var f={t:'image',x:x,y:y,w:w,h:h,fit:'cover'};for(var k in o)f[k]=o[k];return f;}
function R(x,y,w,h,fill,rad){return {t:'shape',x:x,y:y,w:w,h:h,fill:fill,rad:rad||0};}
var PRESETS=[
 {key:'capa',name:'Capa',bg:'#FFFFFF',slots:[
  T('h',60,70,880,380,{txt:'Título',fs:170,fw:800,ls:-0.04,lh:0.95,col:'#111111',beh:'fixed'}),
  T('c',60,480,400,60,{txt:'Subtítulo',fs:24,fw:600,up:true,ls:0.06,col:'#111111'}),
  T('b',520,480,420,170,{txt:'Escreva aqui…',fs:26,col:'#111111'}),
  R(60,460,880,3,'#111111'),
  I(60,700,880,700,{})]},
 {key:'numero',name:'Número grande',bg:'#F3EEE6',slots:[
  T('n',40,10,920,540,{txt:'01',fs:560,fw:400,ls:-0.06,lh:0.85,col:'#E8501F',beh:'fixed'}),
  T('h',60,610,520,300,{txt:'Título',fs:100,fw:600,ls:-0.04,lh:0.98,col:'#111111',beh:'fixed'}),
  T('b',60,940,420,360,{txt:'Escreva aqui…',fs:27,lh:1.35,col:'#111111'}),
  I(520,650,420,650,{})]},
 {key:'colunas',name:'Duas colunas',bg:'#FFFFFF',slots:[
  T('h',60,80,880,250,{txt:'Título',fs:110,fw:800,ls:-0.04,lh:1,col:'#111111',beh:'fixed'}),
  R(60,360,880,3,'#111111'),
  T('b',60,400,420,640,{txt:'Primeira coluna…',fs:28,lh:1.45,col:'#111111'}),
  T('b',520,400,420,640,{txt:'Segunda coluna…',fs:28,lh:1.45,col:'#111111'}),
  I(60,1100,880,500,{})]},
 {key:'fototopo',name:'Foto + título',bg:'#FFFFFF',slots:[
  I(0,0,1000,820,{}),
  T('c',60,860,880,40,{txt:'Categoria',fs:22,fw:600,up:true,ls:0.08,col:'#666666'}),
  T('h',60,920,880,230,{txt:'Título',fs:96,fw:700,ls:-0.03,lh:1.02,col:'#111111',beh:'fixed'}),
  T('b',60,1180,560,360,{txt:'Escreva aqui…',fs:28,lh:1.4,col:'#111111'})]},
 {key:'sobrefoto',name:'Texto sobre foto',bg:'#111111',slots:[
  I(0,0,1000,1500,{}),
  T('c',50,60,900,40,{txt:'Subtítulo',fs:24,fw:700,up:true,ls:0.06,col:'#FFE600'}),
  T('h',50,960,900,440,{txt:'Título',fs:190,fw:800,ls:-0.04,lh:0.9,up:true,col:'#FFE600',beh:'fixed'})]},
 {key:'grade',name:'Grade de fotos',bg:'#FFFFFF',slots:[
  T('h',60,60,880,300,{txt:'Título',fs:150,fw:800,ls:-0.045,lh:0.92,col:'#111111',beh:'fixed'}),
  T('c',60,390,880,40,{txt:'Subtítulo',fs:24,fw:600,up:true,ls:0.06,col:'#111111'}),
  I(60,470,420,520,{rad:28}),I(520,470,420,520,{rad:28}),I(60,1030,420,520,{rad:28}),I(520,1030,420,520,{rad:28}),
  T('b',60,1590,880,200,{txt:'Escreva aqui…',fs:28,col:'#111111'})]},
 {key:'solta',name:'Tipografia solta',bg:'#FFFFFF',slots:[
  T('h',40,50,920,320,{txt:'Título',fs:260,fw:400,ls:-0.05,lh:0.9,col:'#111111',beh:'fixed'}),
  I(60,430,500,640,{}),
  T('b',620,470,320,420,{txt:'Escreva aqui…',fs:24,lh:1.4,col:'#111111'}),
  T('c',620,930,320,140,{txt:'Legenda',fs:20,up:true,ls:0.06,col:'#666666'})]},
 {key:'atmosfera',name:'Atmosfera',bg:'#FFFFFF',slots:[
  T('n',380,780,640,700,{txt:'14.08',fs:420,fw:400,ls:-0.05,lh:0.85,col:'#F1F1F1',beh:'fixed'}),
  T('c',100,120,500,100,{txt:'Subtítulo',fs:22,fw:600,up:true,ls:0.04,col:'#111111'}),
  I(0,300,1000,420,{}),
  T('h',100,780,440,460,{txt:'Título',fs:120,fw:600,ls:-0.05,lh:0.95,col:'#333333',beh:'fixed'}),
  T('b',570,800,330,420,{txt:'Escreva aqui…',fs:24,lh:1.4,col:'#111111'})]}
];
var DEFAULTS={};
(function(){for(var i=0;i<PRESETS.length;i++)for(var j=0;j<PRESETS[i].slots.length;j++){var t=PRESETS[i].slots[j].txt;if(t)DEFAULTS[t]=1;}})();
function cpTx(sl,src){sl.txt=src.txt;if(src.lks&&src.lks.length)sl.lks=JSON.parse(JSON.stringify(src.lks));else delete sl.lks;}
function readingOrder(a,b){return a.y-b.y||a.x-b.x;}
function applyPreset(key){
  var P=null,AP=PRESETS.concat(LIB.tpl);for(var i=0;i<AP.length;i++)if(AP[i].key===key)P=AP[i];if(!P)return;
  if(editingId)endEdit();
  pushHist();
  var texts=S.frames.filter(function(f){return f.t==='text'&&(f.txt||'').trim()&&!DEFAULTS[(f.txt||'').trim()];}).sort(readingOrder);
  var imgs=S.frames.filter(function(f){return f.t==='image'&&f.src;}).sort(readingOrder);
  var lnks=S.frames.filter(function(f){return f.t==='link'&&f.url;}).sort(readingOrder);
  var title=null;
  for(var a=0;a<texts.length;a++)if(texts[a].role==='h'){title=texts[a];break;}
  if(!title&&texts.length){title=texts.slice().sort(function(p,q){return (q.fs||0)-(p.fs||0);})[0];}
  var rest=texts.filter(function(t){return t!==title;});
  var out=[],grow=[];
  for(var s=0;s<P.slots.length;s++){
    var sl=JSON.parse(JSON.stringify(P.slots[s]));sl.id=uid();
    if(sl.t==='text'&&sl.role==='h'&&sl.beh==='fixed'){sl.beh='fit';sl.fm=sl.fs;}
    if(sl.t==='text'){
      if(sl.role==='h'&&title){cpTx(sl,title);title=null;}
      else if(sl.role==='b'&&rest.length){var li=0;for(var z=1;z<rest.length;z++)if((rest[z].txt||'').length>(rest[li].txt||'').length)li=z;cpTx(sl,rest.splice(li,1)[0]);}
      else if(sl.role==='c'&&rest.length){var si=0;for(var y2=1;y2<rest.length;y2++)if((rest[y2].txt||'').length<(rest[si].txt||'').length)si=y2;if((rest[si].txt||'').length<=90)cpTx(sl,rest.splice(si,1)[0]);}
      else if(sl.role==='n'){var nf=texts.filter(function(t){return t.role==='n';})[0];if(nf)cpTx(sl,nf);}
      if(sl.role==='b'&&sl.beh!=='fixed')grow.push({id:sl.id,h:sl.h});
    }else if(sl.t==='image'){
      var im=imgs.shift();if(im){sl.src=im.src;sl.fit=im.fit||sl.fit;sl.px=im.px;sl.py=im.py;}
    }
    out.push(sl);
  }
  S.bg=P.bg;
  S.frames=out;
  // o que sobrou entra embaixo, sem perder nada
  var y=0;for(var k=0;k<out.length;k++)y=Math.max(y,out[k].y+out[k].h);
  y+=60;
  if(title){rest.unshift(title);}
  for(var r=0;r<rest.length;r++){var nt=newText(rest[r].txt,{y:y,x:60,w:880,fs:30,col:inkOn(P.bg),lh:1.4,role:'b'});if(rest[r].lks&&rest[r].lks.length)nt.lks=JSON.parse(JSON.stringify(rest[r].lks));S.frames.push(nt);y+=200;}
  for(var m=0;m<imgs.length;m++){S.frames.push({id:uid(),t:'image',src:imgs[m].src,fit:'cover',x:60,y:y,w:880,h:620});y+=680;}
  for(var q2=0;q2<lnks.length;q2++){var lc=lnks[q2];lc.x=60;lc.w=880;lc.y=y;S.frames.push(lc);y+=lc.h+40;}
  render();
  // caixas de texto que cresceram empurram o que está logo abaixo
  var byY=grow.map(function(g){return get(g.id);}).filter(Boolean).sort(function(p,q){return p.y-q.y;});
  for(var n=0;n<byY.length;n++){
    var f=byY[n],g0=grow.filter(function(z){return z.id===f.id;})[0],delta=f.h-g0.h;
    if(delta<=0)continue;
    for(var o=0;o<S.frames.length;o++){var q=S.frames[o];if(q===f)continue;
      if(q.y>=g0.h+f.y-1&&q.x<f.x+f.w&&q.x+q.w>f.x)q.y+=delta;}
  }
  paginate();render();select(null);changed();
}
/* ---------- localizar na nota (não altera o texto salvo) ---------- */
var outlineOpen=false,findOpen=false,findHits=[],findCur=-1,findT=null,HLF=(window.CSS&&CSS.highlights&&window.Highlight)?true:false;
function fold(t){return String(t).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();}
function foldMap(t){
  var f='',m=[];
  for(var i=0;i<t.length;i++){var c=fold(t.charAt(i));for(var j=0;j<c.length;j++){f+=c.charAt(j);m.push(i);}}
  return {f:f,m:m};
}
function findClear(){
  try{if(HLF){CSS.highlights.delete('find');CSS.highlights.delete('find-cur');}}catch(x){}
  var o=framesEl.querySelectorAll('.fr.fnd');for(var i=0;i<o.length;i++)o[i].classList.remove('fnd');
}
function findRun(keep){
  var q=fold($('findq').value.trim());findHits=[];findCur=-1;
  if(q){
    S.frames.slice().sort(readingOrder).forEach(function(f){
      if(f.t!=='text'||!f.txt)return;
      var fm=foldMap(f.txt),at=0,k;
      while((k=fm.f.indexOf(q,at))>=0){findHits.push({id:f.id,s:fm.m[k],e:fm.m[k+q.length-1]+1});at=k+q.length;}
    });
    if(findHits.length)findCur=keep>=0&&keep<findHits.length?keep:0;
  }
  findShow(keep<0);
}
function findShow(scroll){
  $('findn').textContent=findHits.length?(findCur+1)+'/'+findHits.length:'0/0';
  findClear();
  if(HLF){
    try{
      var others=[],cur=null;
      for(var i=0;i<findHits.length;i++){
        var h=findHits[i],d=elOf(h.id),t=d&&d.firstChild;if(!t)continue;
        var a=nodeAt(t,h.s),b=nodeAt(t,h.e);if(!a||!b)continue;
        var r=document.createRange();r.setStart(a.n,a.o);r.setEnd(b.n,b.o);
        if(i===findCur)cur=r;else others.push(r);
      }
      if(others.length)CSS.highlights.set('find',new (Function.prototype.bind.apply(Highlight,[null].concat(others)))());
      if(cur)CSS.highlights.set('find-cur',new Highlight(cur));
    }catch(x){}
  }
  if(findCur<0)return;
  var ch=findHits[findCur],cd=elOf(ch.id);if(!cd)return;
  cd.classList.add('fnd');
  if(scroll){var rc=cd.getBoundingClientRect();scEl.scrollTo({top:Math.max(0,scEl.scrollTop+rc.top-120),behavior:'smooth'});}
}
function findStep(d){if(!findHits.length)return;findCur=(findCur+d+findHits.length)%findHits.length;findShow(true);}
function findSched(){clearTimeout(findT);findT=setTimeout(function(){findRun(findCur);},150);}
window.openOutline=function(){if(editingId)endEdit();fontSheet=false;outlineOpen=true;drawSheet();};
window.openFind=function(){
  findOpen=true;$('findbar').classList.add('show');post({type:'findState',open:true});
  var q=$('findq');q.focus();q.select();if(q.value)findRun(-1);
};
window.closeFind=function(){
  findOpen=false;findClear();findHits=[];findCur=-1;
  $('findbar').classList.remove('show');$('findq').blur();post({type:'findState',open:false});
};
$('findq').addEventListener('input',function(){clearTimeout(findT);findT=setTimeout(function(){findRun(-1);},120);});
$('findq').addEventListener('keydown',function(e){if(e.key==='Enter'){e.preventDefault();findStep(e.shiftKey?-1:1);}});
$('findp').addEventListener('click',function(){findStep(-1);});
$('findx').addEventListener('click',function(){findStep(1);});
$('findc').addEventListener('click',function(){window.closeFind();});
/* ---------- comandos vindos do app ---------- */
window.setEditable=function(b){
  editable=!!b;document.body.classList.toggle('editing',editable);
  if(!editable){if(editingId)endEdit();ms=[];msMode=false;sel=null;tab=null;fontSheet=false;drawSheet();hideGuides();}
  else{tab=null;}
  paintBody();drawGrid();drawSel();drawBar();layoutDock();
};
window.beginEdit=function(){window.setEditable(true);post({type:'editing'});};
window.initFree=function(p){
  S=p.free||{v:1,bg:'#FFFFFF',h:1250,frames:[],pr:'${DEFAULT_PAGE}',np:1};pgSel=null;
  if(findOpen)window.closeFind();
  outlineOpen=false;
  hist=[];fut=[];ms=[];msMode=false;sel=null;tab=null;editingId=null;
  window.setEditable(!!p.editable);
  if(!p.free){
    var seed=p.seed||{},fr=[];
    if((seed.title||'').trim())fr.push({id:uid(),t:'text',role:'h',x:60,y:60,w:880,h:200,txt:seed.title.trim(),fs:100});
    if((seed.text||'').trim()){
      var bf={id:uid(),t:'text',role:'b',x:60,y:300,w:880,h:200,txt:seed.text.trim(),fs:28},tl=seed.tlinks||[],from=0,ks=[];
      for(var q=0;q<tl.length;q++){var at=bf.txt.indexOf(tl[q].text,from);if(at<0||!okUrl(tl[q].url))continue;ks.push({s:at,e:at+tl[q].text.length,url:tl[q].url});from=at+tl[q].text.length;}
      if(ks.length)bf.lks=ks;
      fr.push(bf);
    }
    var im=seed.images||[];for(var i=0;i<im.length;i++)fr.push({id:uid(),t:'image',src:im[i],fit:'cover',x:60,y:600+i*100,w:880,h:600});
    var lks=seed.links||[];for(var j=0;j<lks.length;j++){var L=lks[j];fr.push({id:uid(),t:'link',x:60,y:600+(im.length+j)*100,w:880,h:420,rad:24,url:L.url,lt:L.title||'',ld:L.desc||'',lsite:L.site||'',src:L.img||'',lst:L.state==='ok'?'ok':L.state==='fail'?'fail':'loading'});}
    S.frames=fr;calcK();render();applyPreset('capa');flush();
  }else{render();}
};
/* O app buscou a prévia do link: preenche o card. */
window.fillLinkCard=function(lid,d){
  var f=get(lid);if(!f||f.t!=='link')return;
  d=d||{};
  if(d.ok){f.lst='ok';f.lt=d.title||'';f.ld=d.desc||'';f.lsite=d.site||'';f.src=d.img||'';f.ar=d.ar||0;}
  else{f.lst='fail';}
  updateFrame(f,true);changed();
};
window.refreshFrameLink=function(id){
  var f=get(id);if(!f||f.t!=='link'||!f.url)return;
  f.lst='loading';delete linkAsked[id];updateFrame(f,true);changed();askLinkPreviews();
};
/* Endereço escolhido no app: cria o card (id 'new') ou troca o link de um existente. */
window.setFrameLink=function(id,url){
  url=String(url||'').trim();if(!url)return;
  if(id==='tl'){
    var pl=PL;PL=null;var tf=pl&&get(pl.id);if(!tf||tf.t!=='text')return;
    if(!/^[a-z][a-z0-9+.-]*:/i.test(url))url=(/^[^\/\s]+@[^\/\s]+$/.test(url)?'mailto:':'https://')+url;
    if(!okUrl(url)){post({type:'toast',text:'Endereço de link inválido'});return;}
    var txl=tf.txt||'',e2=Math.min(pl.e,txl.length);if(pl.s>=e2)return;
    pushHist();
    var keep=(tf.lks||[]).filter(function(l){return l.e<=pl.s||l.s>=e2;});
    keep.push({s:pl.s,e:e2,url:url});keep.sort(function(a,b){return a.s-b.s;});tf.lks=keep;
    if(editingId===tf.id)paintHL();else updateFrame(tf,false);
    changed();drawBar();post({type:'toast',text:'Link no texto salvo'});return;
  }
  if(!/^[a-z][a-z0-9+.-]*:/i.test(url))url='https://'+url;
  if(id==='new'){
    addFrame({id:uid(),t:'link',x:80,y:Math.max(40,visTop()+120),w:840,h:420,url:url,rad:24,lst:'loading'});
    askLinkPreviews();return;
  }
  var f=get(id);if(!f||f.t!=='link')return;
  pushHist();f.url=url;f.lt='';f.ld='';f.lsite='';f.src='';f.ar=0;f.lst='loading';
  delete linkAsked[id];updateFrame(f,true);changed();askLinkPreviews();
};
window.removeFrame=function(id){var f=get(id);if(!f)return;pushHist();S.frames=S.frames.filter(function(x){return x.id!==id;});if(sel===id)sel=null;render();changed();};
window.setFrameImage=function(id,uri){
  if(!uri)return;
  if(id==='new'){
    var im=new Image();
    im.onload=function(){
      var r=im.naturalHeight/Math.max(1,im.naturalWidth),w=840,h=Math.round(Math.min(1100,Math.max(200,w*r)));
      addFrame({id:uid(),t:'image',src:uri,fit:'cover',x:80,y:Math.max(40,visTop()+120),w:w,h:h});
    };
    im.onerror=function(){addFrame({id:uid(),t:'image',src:uri,fit:'cover',x:80,y:200,w:840,h:600});};
    im.src=uri;
    return;
  }
  var f=get(id);if(!f)return;pushHist();f.src=uri;updateFrame(f);select(id);changed();
};
window.setFonts=function(p){
  var list=((p&&p.list)||[]).filter(function(n){return /^[A-Za-z0-9][A-Za-z0-9 ]{0,59}$/.test(n);});
  var st=$('ufonts');if(!st){st=document.createElement('style');st.id='ufonts';document.head.appendChild(st);}
  st.textContent=(p&&p.css)||'';
  FONTLIST=list;
  if(fontSheet)drawSheet();
  if(S.frames.length)render();
  try{Promise.all(list.map(function(n){return document.fonts.load("400 16px '"+n+"'");})).then(function(){if(S.frames.length&&!editingId)render();});}catch(x){}
};
window.setFrameColor=function(hex,which){
  if(!/^#[0-9a-fA-F]{6}$/.test(hex||''))return;
  if(which==='bg')ACT.bg(hex);else if(sel)ACT.color(hex);
};
window.setInsets=function(t,b){
  t=Math.max(0,+t||0);b=Math.max(0,+b||0);
  var d=t-INS.top;INS.top=t;INS.bottom=b;
  document.documentElement.style.setProperty('--top',t+'px');
  document.documentElement.style.setProperty('--sb',b+'px');
  if(d&&(scEl.scrollTop||0)>0)scEl.scrollTop+=d;
  layoutDock();
};
var lastY=0,lastDir='';
scEl.addEventListener('scroll',function(){
  if(editable)return;
  var y=scEl.scrollTop||0,dy=y-lastY;
  if(Math.abs(dy)<18&&y>=40)return;
  var d=(dy>0&&y>=40)?'down':'up';lastY=y;
  if(d!==lastDir){lastDir=d;post({type:'scrollDir',dir:d});}
},{passive:true});
window.setScale=function(){};window.setRecentColors=function(){};
window.setBacklinks=function(){};window.refreshNoteLinks=function(){};window.kbHidden=function(){};window.setNoteResults=function(){};
var lastW=0;window.addEventListener('resize',function(){
  var w=pageEl.clientWidth;if(w!==lastW){lastW=w;render();}
  /* o teclado abriu/fechou: mantém o item em edição à vista, acima da barra */
  if(editable&&(sel||editingId))setTimeout(reveal,80);
});
window.addEventListener('error',function(e){post({type:'jserror',message:String(e.message)});});
post({type:'ready'});
</script>
</body>
</html>`;
