/**
 * Página (WebView) do layout livre da nota: caixas de texto, imagens e formas que dá para mover,
 * redimensionar e reorganizar, mais modelos prontos que reencaixam o conteúdo que já está na página.
 * Fala com o React Native por mensagens (ReactNativeWebView.postMessage) e recebe comandos por
 * funções globais (window.initFree, window.setEditable, ...). Unidades: página de 1000 u de largura.
 */
import { colors } from './theme';

export const FREE_HTML = String.raw`<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<style>
:root{--red:${colors.red};--gray:${colors.muted};--panel:${colors.surface};--line:${colors.lineDark};--top:0px;--sb:0px}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{height:100%;margin:0;background:#000;color:#fff;font-family:Roboto,"Segoe UI",system-ui,sans-serif;-webkit-text-size-adjust:100%}
body{display:flex;flex-direction:column;overflow:hidden}
/* A página rola dentro de #scroller e a barra (#dock) fica abaixo dele, no fluxo: com o teclado aberto ou fechado,
   a barra nunca cobre o texto e nunca deixa buraco embaixo. */
#scroller{flex:1 1 auto;min-height:0;overflow-y:auto;overflow-x:hidden;-webkit-overflow-scrolling:touch;overscroll-behavior:contain;padding-top:var(--top);padding-bottom:calc(var(--sb) + 28px)}
body.editing #scroller{padding-bottom:24px}
#page{position:relative;width:100%;overflow:hidden;touch-action:pan-y;user-select:none;-webkit-user-select:none}
.fr{position:absolute;touch-action:pan-y}
.fr.sel{touch-action:none}
.fr.text{overflow:hidden}
.fr .tx{position:absolute;left:0;top:0;width:100%;white-space:pre-wrap;word-break:break-word;overflow-wrap:anywhere;outline:none;user-select:none;-webkit-user-select:none}
.fr .tx.ed{user-select:text;-webkit-user-select:text;caret-color:var(--red)}
.fr.ph .tx{opacity:.35}
body:not(.editing) .fr.ph{display:none}
.fr.image{overflow:hidden}
.fr.image img{width:100%;height:100%;display:block;pointer-events:none}
.fr.image.empty{background:#D9D9D9;display:none}
body.editing .fr.image.empty{display:flex;align-items:center;justify-content:center;color:#6b6b6b;font-size:15px;font-weight:700;text-align:center;padding:8px}
.fr.ovf:after{content:"";position:absolute;right:0;bottom:0;width:0;height:0;border-style:solid;border-width:0 0 16px 16px;border-color:transparent transparent var(--red) transparent}
body:not(.editing) .fr.ovf:after{display:none}
#grid{position:absolute;left:0;top:0;width:100%;pointer-events:none;z-index:8000}
#grid .gc{position:absolute;top:0;bottom:0;background:rgba(255,48,48,.08)}
#grid .gm{position:absolute;top:0;bottom:0;width:0;border-left:1px dashed rgba(255,48,48,.55)}
#selbox{position:absolute;border:1.5px solid var(--red);pointer-events:none;display:none;z-index:9000}
.hd{position:absolute;width:30px;height:30px;margin:-15px 0 0 -15px;pointer-events:auto;touch-action:none}
.hd:after{content:"";position:absolute;left:9px;top:9px;width:12px;height:12px;background:#fff;border:2px solid var(--red);border-radius:50%}
.g{position:absolute;background:var(--red);z-index:8999;pointer-events:none;display:none}
/* ---------- dock (barra de baixo): cabeçalho + painel + abas ---------- */
#dock{flex:none;position:relative;background:#111;border-top:1px solid var(--line);display:none;z-index:10000;user-select:none;-webkit-user-select:none;padding-bottom:var(--sb)}
body.editing #dock{display:block}
#dh{display:flex;align-items:center;gap:8px;padding:8px 10px 0}
#dh .ctx{flex:1;min-width:0;color:var(--gray);font-size:13px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;padding-left:4px}
.ib{flex:none;width:40px;height:40px;border-radius:20px;background:var(--panel);color:#fff;display:flex;align-items:center;justify-content:center;font-size:19px;font-weight:700}
.ib.dim{opacity:.35}
.ok{flex:none;height:40px;padding:0 18px;border-radius:20px;background:#fff;color:#000;font-size:15px;font-weight:800;display:flex;align-items:center}
#pn{max-height:36vh;overflow-y:auto;padding:12px 12px 2px;-webkit-overflow-scrolling:touch}
#pn:empty{display:none}
#tabs{display:flex;gap:4px;padding:6px 8px 8px}
.tab{flex:1;min-width:0;height:40px;border-radius:20px;display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:700;color:var(--gray);white-space:nowrap}
.tab.on{background:var(--panel);color:#fff}
.lbl{color:var(--gray);font-size:12px;font-weight:700;margin:0 2px 6px}
.seg{display:flex;background:var(--panel);border-radius:14px;padding:3px;gap:3px;margin-bottom:12px}
.seg>div{flex:1;min-width:0;min-height:38px;border-radius:11px;display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:700;color:#fff;text-align:center;padding:0 4px}
.seg>div.on{background:#fff;color:#000}
.seg svg{width:22px;height:22px}
.rowc{display:flex;align-items:center;gap:10px;margin-bottom:8px}
.rowc .nm{width:84px;flex:none;color:#fff;font-size:14px;font-weight:700}
.rowc .val{width:48px;flex:none;text-align:right;color:var(--gray);font-size:13px;font-weight:700}
.rowc .ib{width:34px;height:34px;border-radius:17px;font-size:16px}
input[type=range]{flex:1;min-width:0;height:34px;-webkit-appearance:none;background:transparent;margin:0}
input[type=range]::-webkit-slider-runnable-track{height:4px;border-radius:2px;background:#3A3A3C}
input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;width:24px;height:24px;margin-top:-10px;border-radius:50%;background:#fff;border:2px solid var(--red)}
.fontbtn{display:flex;align-items:center;justify-content:space-between;background:var(--panel);border-radius:14px;min-height:46px;padding:0 16px;font-size:18px;font-weight:600;margin-bottom:12px}
.fontbtn small{color:var(--gray);font-size:20px}
.btns{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:12px}
.chip{flex:none;background:var(--panel);color:#fff;border-radius:20px;padding:0 16px;height:40px;display:flex;align-items:center;font-size:14px;font-weight:700;white-space:nowrap}
.chip.on{background:#fff;color:#000}
.chip.red{color:var(--red)}
.chip.dim{opacity:.4}
.sws{display:flex;flex-wrap:wrap;gap:10px;margin-bottom:12px}
.sw{flex:none;width:40px;height:40px;border-radius:50%;border:2px solid #3A3A3C}
.sw.on{border-color:var(--red)}
.sw.plus{display:flex;align-items:center;justify-content:center;background:var(--panel);color:#fff;font-size:22px;font-weight:700}
.tiles{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:12px}
.tile{background:var(--panel);border-radius:16px;min-height:64px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;font-size:13px;font-weight:700}
.tile b{font-size:22px;line-height:1}
.tpls{display:flex;gap:10px;overflow-x:auto;padding-bottom:10px;scrollbar-width:none}
.tpls::-webkit-scrollbar{display:none}
.tp{flex:none;width:72px;text-align:center;font-size:12px;font-weight:700;color:#fff}
.tp .th{position:relative;width:60px;height:90px;margin:0 auto 6px;border-radius:6px;overflow:hidden;border:1px solid #3A3A3C}
.tp .th i{position:absolute;display:block}
.hint{color:var(--gray);font-size:13px;line-height:1.4;margin:0 2px 10px}
.focus{display:grid;grid-template-columns:repeat(3,44px);gap:6px;margin-bottom:12px}
.focus div{height:34px;border-radius:9px;background:var(--panel)}
.focus div.on{background:#fff}
.nudge{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:12px}
.nudge .ib{width:100%;border-radius:14px}
/* ---------- janela de fontes ---------- */
#scrim{display:none;position:fixed;left:0;top:0;right:0;bottom:0;background:${colors.scrimSoft};z-index:10010}
#sheet{display:none;position:fixed;left:12px;right:12px;bottom:calc(var(--sb) + 12px);max-height:72%;overflow-y:auto;background:#fff;color:#000;border-radius:8.8vw;padding:8px 18px 14px;z-index:10011;box-shadow:0 8px 28px rgba(0,0,0,.45)}
#sheet .ttl{color:#666;font-size:14px;margin:16px 4px 6px}
#sheet .frow{display:flex;align-items:center;justify-content:space-between;min-height:52px;font-size:21px;padding:0 4px;border-bottom:1px solid ${colors.hairline}}
#sheet .frow .ck{color:var(--red);font-weight:800}
#sheet .frow.more{font-size:16px;font-weight:700;color:var(--red);border-bottom:0}
</style>
</head>
<body>
<div id="scroller"><div id="page"><div id="frames"></div><div id="grid"></div><div id="selbox"></div><div class="g" id="gv"></div><div class="g" id="gh"></div></div></div>
<div id="dock"><div id="dh"></div><div id="pn"></div><div id="tabs"></div></div>
<div id="scrim"></div><div id="sheet"></div>
<script>
var RN=window.ReactNativeWebView;
function post(o){try{RN.postMessage(JSON.stringify(o));}catch(e){}}
function $(id){return document.getElementById(id);}
var PW=1000;
var S={v:1,bg:'#FFFFFF',h:1500,frames:[]};
var sel=null,editable=false,K=1,tab=null,openPref=true,editingId=null,hist=[],fut=[],saveT=null,lastTap={id:null,t:0};
var INS={top:0,bottom:0},FONTLIST=[],fontSheet=false,NUDGE=10,colorFor='frame',slHist=false,lastBg='';
function MG(){return S.m==null?60:S.m;}
var pageEl=$('page'),framesEl=$('frames'),selbox=$('selbox'),gv=$('gv'),gh=$('gh'),gridEl=$('grid');
var FONTS={s:'Roboto,Arial,sans-serif',f:'Georgia,"Times New Roman",serif',m:'"Courier New",monospace'};
var TXT_COLORS=['#111111','#FFFFFF','#E8501F','#FFE600','#FF3030','#808080','#1F3D2B','#2B5BFF','#6B7A3A','#F3EEE6'];
var BGS=['#FFFFFF','#F3EEE6','#111111','#000000','#E8501F','#6B7A3A','#FFE600','#1F3D2B'];
function uid(){return 'f'+Date.now().toString(36)+Math.random().toString(36).slice(2,6);}
function get(id){for(var i=0;i<S.frames.length;i++)if(S.frames[i].id===id)return S.frames[i];return null;}
function luma(h){h=String(h||'#fff').replace('#','');var r=parseInt(h.substr(0,2),16),g=parseInt(h.substr(2,2),16),b=parseInt(h.substr(4,2),16);return(0.299*r+0.587*g+0.114*b)/255;}
function inkOn(bg){return luma(bg)<0.45?'#FFFFFF':'#111111';}
/* ---------- histórico e salvamento ---------- */
function snapJson(){return JSON.stringify(S);}
function pushHist(){hist.push(snapJson());if(hist.length>60)hist.shift();fut=[];}
function pageH(){var m=0;for(var i=0;i<S.frames.length;i++){var f=S.frames[i];m=Math.max(m,f.y+f.h);}return Math.max(1500,Math.ceil(m+160));}
function changed(){clearTimeout(saveT);saveT=setTimeout(flush,400);}
function flush(){clearTimeout(saveT);S.h=pageH();post({type:'fchange',free:S});}
window.flushNow=function(){flush();};
/* ---------- desenho ---------- */
function calcK(){K=pageEl.clientWidth/PW;}
function place(d,f){d.style.left=f.x*K+'px';d.style.top=f.y*K+'px';d.style.width=f.w*K+'px';d.style.height=f.h*K+'px';}
function styleText(t,f){
  t.style.fontSize=(f.fs||32)*K+'px';t.style.fontWeight=f.fw||400;t.style.fontStyle=f.it?'italic':'normal';
  t.style.color=f.col||'#111';t.style.textAlign={l:'left',c:'center',r:'right',j:'justify'}[f.al||'l'];
  t.style.lineHeight=f.lh||1.3;t.style.letterSpacing=(f.ls||0)+'em';t.style.textTransform=f.up?'uppercase':'none';
  t.style.fontFamily=famOf(f);t.style.padding=(f.pad||0)*K+'px';
}
function famOf(f){var base=FONTS[f.ff||'s'];if(f.fam&&FONTLIST.indexOf(f.fam)>=0)return "'"+f.fam+"',"+base;return base;}
function build(f){
  var d=document.createElement('div');d.className='fr '+f.t;d.setAttribute('data-id',f.id);
  if(f.t==='text'){
    var t=document.createElement('div');t.className='tx';styleText(t,f);t.textContent=f.txt||'';d.appendChild(t);
    if(!(f.txt||'').trim())d.classList.add('ph');
  }else if(f.t==='image'){
    d.style.borderRadius=(f.rad||0)*K+'px';
    if(f.src){var im=document.createElement('img');im.src=f.src;im.style.objectFit=f.fit||'cover';im.style.objectPosition=(f.px==null?50:f.px)+'% '+(f.py==null?50:f.py)+'%';d.appendChild(im);if(f.fill)d.style.background=f.fill;}
    else{d.classList.add('empty');d.textContent='Toque duas vezes para escolher a imagem';}
  }else{
    d.style.background=f.fill||'#000';d.style.borderRadius=(f.rad||0)*K+'px';
  }
  place(d,f);
  return d;
}
function measure(d,f){
  if(f.t!=='text')return;
  var t=d.firstChild;
  if(f.beh==='fit'){
    var lo=8,hi=f.fm||600,bh=f.h*K;
    for(var i=0;i<14;i++){var mid=(lo+hi)/2;t.style.fontSize=mid*K+'px';if(t.offsetHeight<=bh&&t.scrollWidth<=d.clientWidth+1)lo=mid;else hi=mid;}
    f.fs=Math.floor(lo);t.style.fontSize=f.fs*K+'px';
  }else if(f.beh!=='fixed'){
    var nh=Math.max(20,Math.ceil(t.offsetHeight/K));
    if(Math.abs(nh-f.h)>1){f.h=nh;place(d,f);}
  }
  d.classList.toggle('ovf',f.beh==='fixed'&&t.offsetHeight>d.clientHeight+2);
}
function elOf(id){return framesEl.querySelector('[data-id="'+id+'"]');}
function render(){
  calcK();
  S.h=pageH();
  pageEl.style.height=S.h*K+'px';pageEl.style.background=S.bg;
  framesEl.innerHTML='';
  for(var i=0;i<S.frames.length;i++){var f=S.frames[i],d=build(f);d.style.zIndex=i+1;framesEl.appendChild(d);}
  for(var j=0;j<S.frames.length;j++){var e=elOf(S.frames[j].id);if(e)measure(e,S.frames[j]);}
  S.h=pageH();pageEl.style.height=S.h*K+'px';
  paintBody();drawGrid();drawSel();drawBar();
}
function paintBody(){
  var c=editable?'#000':S.bg;
  document.documentElement.style.background=c;document.body.style.background=c;
  if(S.bg!==lastBg){lastBg=S.bg;post({type:'bg',color:S.bg});}
}
function drawGrid(){
  gridEl.innerHTML='';gridEl.style.height=pageEl.style.height;
  if(!editable||!S.grid)return;
  var m=MG(),cols=12,gut=16,cw=(PW-2*m-gut*(cols-1))/cols,h='';
  for(var i=0;i<cols;i++){h+='<div class="gc" style="left:'+((m+i*(cw+gut))*K)+'px;width:'+(cw*K)+'px"></div>';}
  h+='<div class="gm" style="left:'+(m*K)+'px"></div><div class="gm" style="left:'+((PW-m)*K)+'px"></div>';
  gridEl.innerHTML=h;
}
function updateFrame(f,remeasure){
  var d=elOf(f.id);if(!d)return;
  var nd=build(f);nd.style.zIndex=d.style.zIndex;if(sel===f.id)nd.classList.add('sel');
  d.parentNode.replaceChild(nd,d);
  if(remeasure!==false)measure(nd,f);
  pageEl.style.height=pageH()*K+'px';
  drawSel();
}
/* ---------- seleção e alças ---------- */
var HANDLES=['nw','n','ne','e','se','s','sw','w'];
function drawSel(){
  var f=sel&&get(sel);
  var olds=framesEl.querySelectorAll('.fr.sel');for(var i=0;i<olds.length;i++)olds[i].classList.remove('sel');
  selbox.innerHTML='';
  if(!f||!editable){selbox.style.display='none';return;}
  var d=elOf(f.id);if(d)d.classList.add('sel');
  selbox.style.display='block';
  selbox.style.left=f.x*K+'px';selbox.style.top=f.y*K+'px';selbox.style.width=f.w*K+'px';selbox.style.height=f.h*K+'px';
  if(f.lock||editingId===f.id)return;
  for(var k=0;k<HANDLES.length;k++){
    var h=HANDLES[k],e=document.createElement('div');e.className='hd';e.setAttribute('data-h',h);
    e.style.left=(h.indexOf('w')>=0?0:h.indexOf('e')>=0?100:50)+'%';
    e.style.top=(h.indexOf('n')>=0?0:h.indexOf('s')>=0?100:50)+'%';
    selbox.appendChild(e);
  }
}
function select(id){
  if(editingId&&editingId!==id)endEdit();
  if(id!==sel){var f=id&&get(id);tab=f?(openPref?tabsFor(f)[0][0]:null):(openPref&&tab&&tabsFor(null).some(function(t){return t[0]===tab;})?tab:null);}
  sel=id;drawSel();drawBar();
  setTimeout(reveal,60);
}
var scEl=$('scroller');
function visTop(){return Math.max(0,Math.round(((scEl.scrollTop||0)-INS.top)/K));}
/* rola a página só o necessário para o item selecionado não ficar escondido atrás da barra */
function reveal(){
  var f=sel&&get(sel);if(!f||!editable)return;
  var vh=scEl.clientHeight,y=scEl.scrollTop||0;
  var top=INS.top+f.y*K-y,bot=INS.top+(f.y+f.h)*K-y;
  if(bot>vh-8)scEl.scrollTop=y+Math.max(0,Math.min(bot-vh+16,top-INS.top-16));
  else if(top<INS.top+8)scEl.scrollTop=Math.max(0,y-(INS.top+8-top));
}
/* ---------- gestos ---------- */
var G=null;
function targetsX(skip){var a=[0,PW/2,PW,MG(),PW-MG()];for(var i=0;i<S.frames.length;i++){var f=S.frames[i];if(f.id===skip)continue;a.push(f.x,f.x+f.w/2,f.x+f.w);}return a;}
function targetsY(skip){var a=[0,MG()];for(var i=0;i<S.frames.length;i++){var f=S.frames[i];if(f.id===skip)continue;a.push(f.y,f.y+f.h/2,f.y+f.h);}return a;}
function snapTo(vals,targets,thr){
  var best=null;
  for(var i=0;i<vals.length;i++)for(var j=0;j<targets.length;j++){var d=targets[j]-vals[i];if(Math.abs(d)<=thr&&(best===null||Math.abs(d)<Math.abs(best.d)))best={d:d,at:targets[j]};}
  return best;
}
function showGuide(el,pos,vertical){
  if(pos==null){el.style.display='none';return;}
  el.style.display='block';
  if(vertical){el.style.left=pos*K+'px';el.style.top='0';el.style.width='1px';el.style.height=pageEl.style.height;}
  else{el.style.top=pos*K+'px';el.style.left='0';el.style.height='1px';el.style.width='100%';}
}
function hideGuides(){gv.style.display='none';gh.style.display='none';}
pageEl.addEventListener('pointerdown',function(e){
  if(!editable)return;
  var hd=e.target.closest&&e.target.closest('.hd');
  var f=sel&&get(sel);
  if(hd&&f&&!f.lock){
    pushHist();
    G={mode:'resize',h:hd.getAttribute('data-h'),sx:e.clientX,sy:e.clientY,o:{x:f.x,y:f.y,w:f.w,h:f.h},id:f.id,moved:false};
    try{pageEl.setPointerCapture(e.pointerId);}catch(x){}
    e.preventDefault();return;
  }
  var fe=e.target.closest&&e.target.closest('.fr');
  if(fe&&fe.getAttribute('data-id')===sel&&f&&!f.lock&&editingId!==f.id){
    pushHist();
    G={mode:'move',sx:e.clientX,sy:e.clientY,o:{x:f.x,y:f.y,w:f.w,h:f.h},id:f.id,moved:false};
    try{pageEl.setPointerCapture(e.pointerId);}catch(x){}
  }
});
pageEl.addEventListener('pointermove',function(e){
  if(!G)return;
  var f=get(G.id);if(!f)return;
  var dx=(e.clientX-G.sx)/K,dy=(e.clientY-G.sy)/K;
  if(!G.moved&&Math.abs(dx)+Math.abs(dy)<6/K)return;
  G.moved=true;
  var thr=8/K,o=G.o,gx=null,gy=null;
  if(G.mode==='move'){
    var nx=o.x+dx,ny=o.y+dy;
    var sx=snapTo([nx,nx+o.w/2,nx+o.w],targetsX(f.id),thr);if(sx){nx+=sx.d;gx=sx.at;}
    var sy=snapTo([ny,ny+o.h/2,ny+o.h],targetsY(f.id),thr);if(sy){ny+=sy.d;gy=sy.at;}
    f.x=Math.round(nx);f.y=Math.max(0,Math.round(ny));
  }else{
    var h=G.h,x=o.x,y=o.y,w=o.w,hh=o.h,min=30;
    var corner=h.length===2;
    if(h.indexOf('e')>=0){var rx=o.x+o.w+dx;var s1=snapTo([rx],targetsX(f.id),thr);if(s1){rx+=s1.d;gx=s1.at;}w=Math.max(min,rx-o.x);}
    if(h.indexOf('w')>=0){var lx=o.x+dx;var s2=snapTo([lx],targetsX(f.id),thr);if(s2){lx+=s2.d;gx=s2.at;}lx=Math.min(lx,o.x+o.w-min);x=lx;w=o.x+o.w-lx;}
    if(h.indexOf('s')>=0){var by=o.y+o.h+dy;var s3=snapTo([by],targetsY(f.id),thr);if(s3){by+=s3.d;gy=s3.at;}hh=Math.max(min,by-o.y);}
    if(h.indexOf('n')>=0){var ty=o.y+dy;var s4=snapTo([ty],targetsY(f.id),thr);if(s4){ty+=s4.d;gy=s4.at;}ty=Math.min(ty,o.y+o.h-min);y=ty;hh=o.y+o.h-ty;}
    if(corner&&f.t==='image'&&o.h>0){
      var ratio=o.w/o.h;hh=w/ratio;if(h.indexOf('n')>=0)y=o.y+o.h-hh;
    }
    if(f.t==='text'&&(h.indexOf('n')>=0||h.indexOf('s')>=0)&&f.beh!=='fit')f.beh='fixed';
    f.x=Math.round(x);f.y=Math.max(0,Math.round(y));f.w=Math.round(w);f.h=Math.round(hh);
  }
  showGuide(gv,gx,true);showGuide(gh,gy,false);
  var d=elOf(f.id);if(d){place(d,f);if(f.t==='text'&&G.mode==='resize')measure(d,f);}
  drawSel();
  e.preventDefault();
});
function endGesture(){
  if(!G)return;
  var f=get(G.id),moved=G.moved;G=null;hideGuides();
  if(moved&&f){
    if(f.t==='text'&&f.beh!=='fixed'&&f.beh!=='fit'){var d=elOf(f.id);if(d)measure(d,f);}
    pageEl.style.height=pageH()*K+'px';drawSel();changed();
  }else{hist.pop();}
}
pageEl.addEventListener('pointerup',function(e){
  var wasGesture=G&&G.moved;
  endGesture();
  if(wasGesture)return;
  tap(e);
});
pageEl.addEventListener('pointercancel',function(){if(G){var m=G.moved;endGesture();}});
function tap(e){
  var tg=document.elementFromPoint(e.clientX,e.clientY)||e.target;
  var hd=tg.closest&&tg.closest('.hd');if(hd)return;
  var fe=tg.closest&&tg.closest('.fr');
  var id=fe?fe.getAttribute('data-id'):null;
  var now=Date.now(),dbl=lastTap.id===id&&now-lastTap.t<340;
  lastTap={id:id,t:now};
  if(!editable){
    if(dbl){window.setEditable(true);post({type:'editing'});lastTap={id:null,t:0};}
    else{var stamp=lastTap.t;setTimeout(function(){if(lastTap.t===stamp)post({type:'tapView'});},360);}
    return;
  }
  if(editingId&&id===editingId)return;
  if(!id){select(null);return;}
  if(dbl){
    var f=get(id);
    if(f&&f.t==='text'){select(id);startEdit(id);}
    else if(f&&f.t==='image'){post({type:'pickFrameImage',id:id});}
    lastTap={id:null,t:0};return;
  }
  select(id);
}
/* ---------- edição de texto ---------- */
function startEdit(id){
  var d=elOf(id),f=get(id);if(!d||!f||f.lock)return;
  var t=d.firstChild;editingId=id;pushHist();
  d.classList.remove('ph');
  try{t.contentEditable='plaintext-only';}catch(x){}
  if(t.contentEditable!=='plaintext-only')t.contentEditable='true';
  tab=null;t.classList.add('ed');d.style.touchAction='auto';
  t.focus();
  var r=document.createRange();r.selectNodeContents(t);r.collapse(false);var s=window.getSelection();s.removeAllRanges();s.addRange(r);
  t.oninput=function(){
    var v=t.innerText.replace(/\n$/,'');f.txt=v;
    if(f.beh==='fit'||f.beh==='auto'||!f.beh){measure(d,f);}
    selbox.style.height=f.h*K+'px';pageEl.style.height=pageH()*K+'px';changed();
  };
  t.onblur=function(){if(editingId===id)endEdit();};
  drawSel();drawBar();
}
function endEdit(){
  var id=editingId;if(!id)return;editingId=null;
  var f=get(id),d=elOf(id);
  if(f&&d){var t=d.firstChild;f.txt=t.innerText.replace(/\n$/,'');t.contentEditable='false';t.classList.remove('ed');}
  if(f)updateFrame(f);
  if(openPref&&sel&&get(sel))tab=tabsFor(get(sel))[0][0];
  changed();drawSel();drawBar();
}
/* ---------- ações ---------- */
function cycle(list,cur){var i=list.indexOf(cur);return list[(i+1)%list.length];}
function mut(fn,remeasure){
  var f=sel&&get(sel);if(!f)return;
  pushHist();fn(f);
  updateFrame(f,remeasure);changed();drawBar();
}
function newText(txt,over){
  var top=Math.max(40,visTop()+120);
  var f={id:uid(),t:'text',role:'b',x:80,y:top,w:840,h:100,txt:txt||'',fs:40,fw:400,col:inkOn(S.bg),al:'l',lh:1.3,ls:0,ff:'s',beh:'auto'};
  if(over)for(var k in over)f[k]=over[k];
  return f;
}
function addFrame(f){pushHist();S.frames.push(f);render();select(f.id);changed();}
function shape(w,h,fill,rad){return {id:uid(),t:'shape',x:Math.round((PW-w)/2),y:Math.max(40,visTop()+200),w:w,h:h,fill:fill,rad:rad||0};}
var ACT={
  addText:function(){var f=newText('');addFrame(f);startEdit(f.id);},
  addTitle:function(){var f=newText('Título',{role:'h',fs:120,fw:800,ls:-0.04,lh:1});addFrame(f);startEdit(f.id);},
  addImage:function(){post({type:'pickFrameImage',id:'new'});},
  addLine:function(){addFrame(shape(PW-2*MG(),6,inkOn(S.bg),0));},
  addRect:function(){addFrame(shape(420,300,'#E8501F',0));},
  addCircle:function(){addFrame(shape(360,360,'#FFE600',500));},
  undo:function(){if(!hist.length)return;if(editingId)endEdit();fut.push(snapJson());S=JSON.parse(hist.pop());sel=null;render();changed();},
  redo:function(){if(!fut.length)return;if(editingId)endEdit();hist.push(snapJson());S=JSON.parse(fut.pop());sel=null;render();changed();},
  tab:function(t){if(tab===t){tab=null;openPref=false;}else{tab=t;openPref=true;}drawBar();setTimeout(reveal,60);},
  done:function(){if(editingId){endEdit();return;}if(sel){select(null);return;}post({type:'finish'});},
  del:function(){var f=sel&&get(sel);if(!f)return;pushHist();S.frames=S.frames.filter(function(x){return x.id!==f.id;});sel=null;render();changed();},
  dup:function(){var f=sel&&get(sel);if(!f)return;var c=JSON.parse(JSON.stringify(f));c.id=uid();c.x=Math.min(PW-40,c.x+30);c.y+=30;c.lock=false;addFrame(c);},
  front:function(){var f=sel&&get(sel);if(!f)return;pushHist();S.frames=S.frames.filter(function(x){return x!==f;});S.frames.push(f);render();changed();},
  back:function(){var f=sel&&get(sel);if(!f)return;pushHist();S.frames=S.frames.filter(function(x){return x!==f;});S.frames.unshift(f);render();changed();},
  lock:function(){mut(function(f){f.lock=!f.lock;},false);drawSel();},
  full:function(){mut(function(f){if(f.x===0&&f.w===PW){f.x=MG();f.w=PW-2*MG();}else{f.x=0;f.w=PW;}});},
  margins:function(){mut(function(f){f.x=MG();f.w=PW-2*MG();});},
  alignL:function(){mut(function(f){f.x=MG();},false);},
  alignC:function(){mut(function(f){f.x=Math.round((PW-f.w)/2);},false);},
  alignR:function(){mut(function(f){f.x=PW-MG()-f.w;},false);},
  step:function(n){NUDGE=+n;drawBar();},
  nudge:function(d){mut(function(f){if(d==='l')f.x-=NUDGE;if(d==='r')f.x+=NUDGE;if(d==='u')f.y=Math.max(0,f.y-NUDGE);if(d==='d')f.y+=NUDGE;},false);},
  sizeStep:function(n){mut(function(f){f.fs=Math.max(8,Math.min(600,Math.round((f.fs||32)+(+n))));if(f.beh==='fit')f.beh='auto';});},
  weight:function(w){mut(function(f){f.fw=+w;});},
  italic:function(){mut(function(f){f.it=!f.it;});},
  upper:function(){mut(function(f){f.up=!f.up;});},
  align:function(a){mut(function(f){f.al=a;},false);},
  behave:function(b){mut(function(f){f.beh=b;if(b==='fit')f.fm=Math.max(f.fm||0,f.fs||32,200);});},
  fonts:function(){fontSheet=true;drawSheet();},
  setfont:function(v){
    mut(function(f){if(v.indexOf('u:')===0){f.fam=v.slice(2);f.ff=f.ff||'s';}else{f.fam=null;f.ff=v;}});
    fontSheet=false;drawSheet();
  },
  moreFonts:function(){fontSheet=false;drawSheet();post({type:'openFonts'});},
  swapImage:function(){post({type:'pickFrameImage',id:sel});},
  fit:function(v){mut(function(f){f.fit=v;if(v==='contain'&&!f.fill)f.fill=S.bg;},false);},
  focus:function(v){var a=v.split(',');mut(function(f){f.px=+a[0];f.py=+a[1];},false);},
  color:function(c){mut(function(f){if(f.t==='text')f.col=c;else f.fill=c;},false);},
  customColor:function(){colorFor='frame';post({type:'pickFrameColor',for:'frame'});},
  customBg:function(){colorFor='bg';post({type:'pickFrameColor',for:'bg'});},
  bg:function(c){
    pushHist();var wasDark=luma(S.bg)<0.45,isDark=luma(c)<0.45;S.bg=c;
    if(wasDark!==isDark)for(var i=0;i<S.frames.length;i++){var f=S.frames[i];if(f.t==='text'&&(f.col==='#111111'||f.col==='#FFFFFF'))f.col=inkOn(c);if(f.t==='shape'&&(f.fill==='#111111'||f.fill==='#FFFFFF'||f.fill==='#000000'))f.fill=inkOn(c);}
    render();changed();
  },
  grid:function(){pushHist();S.grid=!S.grid;drawGrid();changed();drawBar();},
  preset:function(k){applyPreset(k);drawBar();}
};
/* ---------- controles deslizantes ---------- */
function szToSl(v){return Math.round(100*Math.log(Math.max(8,v)/8)/Math.log(75));}
function slToSz(v){return Math.round(8*Math.pow(75,v/100));}
var SL={
  fs:{n:'Tamanho',min:0,max:100,step:1,get:function(f){return szToSl(f.fs||32);},set:function(f,v){f.fs=slToSz(v);if(f.beh==='fit')f.beh='auto';},fmt:function(f){return String(f.fs||32);}},
  lh:{n:'Entrelinha',min:0.8,max:2.4,step:0.05,get:function(f){return f.lh||1.3;},set:function(f,v){f.lh=Math.round(v*100)/100;},fmt:function(f){return (f.lh||1.3).toFixed(2);}},
  ls:{n:'Letras',min:-0.1,max:0.4,step:0.01,get:function(f){return f.ls||0;},set:function(f,v){f.ls=Math.round(v*100)/100;},fmt:function(f){return (f.ls||0).toFixed(2);}},
  pad:{n:'Respiro',min:0,max:120,step:2,get:function(f){return f.pad||0;},set:function(f,v){f.pad=Math.round(v);},fmt:function(f){return String(f.pad||0);}},
  rad:{n:'Cantos',min:0,max:500,step:4,get:function(f){return f.rad||0;},set:function(f,v){f.rad=Math.round(v);},fmt:function(f){return (f.rad||0)>=500?'redondo':String(f.rad||0);}},
  m:{n:'Margem',page:1,min:0,max:160,step:2,get:function(){return MG();},set:function(f,v){S.m=Math.round(v);},fmt:function(){return String(MG());}}
};
function slider(k){
  var d=SL[k],t=d.page?S:(sel&&get(sel));if(!t)return '';
  return '<div class="rowc"><div class="nm">'+d.n+'</div><input type="range" data-sl="'+k+'" min="'+d.min+'" max="'+d.max+'" step="'+d.step+'" value="'+d.get(t)+'"><div class="val" id="v_'+k+'">'+d.fmt(t)+'</div></div>';
}
function slide(k,v,final){
  var d=SL[k];if(!d)return;
  var t=d.page?S:(sel&&get(sel));if(!t)return;
  d.set(t,v);
  var lb=$('v_'+k);if(lb)lb.textContent=d.fmt(t);
  if(d.page){drawGrid();}else{updateFrame(t,true);}
  if(final){changed();drawBar();}
}
/* ---------- barra de ferramentas (dock) ---------- */
function swatch(c,act,on){return '<div class="sw'+(on?' on':'')+'" data-act="'+act+'" data-arg="'+c+'" style="background:'+c+'"></div>';}
function seg(items,cur,act){return '<div class="seg">'+items.map(function(i){return '<div class="'+(String(i[0])===String(cur)?'on':'')+'" data-act="'+act+'" data-arg="'+i[0]+'">'+i[1]+'</div>';}).join('')+'</div>';}
function chipB(label,act,arg,cls){return '<div class="chip '+(cls||'')+'" data-act="'+act+'"'+(arg!=null?' data-arg="'+arg+'"':'')+'>'+label+'</div>';}
function lbl(t){return '<div class="lbl">'+t+'</div>';}
function alIcon(a){
  var w={l:[16,10,14,8],c:[16,10,14,8],r:[16,10,14,8],j:[16,16,16,16]}[a],x=[],y=[4,9,14,19],i;
  for(i=0;i<4;i++){var st=a==='r'?22-w[i]:a==='c'?11-w[i]/2+1:3;x.push('<line x1="'+st+'" y1="'+y[i]+'" x2="'+(st+w[i])+'" y2="'+y[i]+'" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>');}
  return '<svg viewBox="0 0 24 24">'+x.join('')+'</svg>';
}
function tabsFor(f){
  if(!f)return [['add','Adicionar'],['tpl','Modelos'],['page','Página']];
  if(f.t==='text')return [['txt','Texto'],['par','Parágrafo'],['col','Cor'],['pos','Posição']];
  if(f.t==='image')return [['img','Imagem'],['sty','Estilo'],['pos','Posição']];
  return [['sty','Estilo'],['pos','Posição']];
}
function fontName(f){return (f.fam&&FONTLIST.indexOf(f.fam)>=0)?f.fam:({s:'Sans',f:'Serifa',m:'Mono'}[f.ff||'s']);}
function colorPanel(cur,custom){
  return '<div class="sws">'+TXT_COLORS.concat([S.bg]).map(function(c){return swatch(c,'color',String(c).toLowerCase()===String(cur||'').toLowerCase());}).join('')+'<div class="sw plus" data-act="'+custom+'">+</div></div>';
}
function panelHtml(f){
  if(!tab)return '';
  var h='';
  if(!f){
    if(tab==='add'){
      h='<div class="tiles">'+
        '<div class="tile" data-act="addText"><b>T</b>Texto</div>'+
        '<div class="tile" data-act="addTitle"><b style="font-weight:900">Aa</b>Título</div>'+
        '<div class="tile" data-act="addImage"><b>▣</b>Imagem</div>'+
        '<div class="tile" data-act="addLine"><b>—</b>Linha</div>'+
        '<div class="tile" data-act="addRect"><b>■</b>Retângulo</div>'+
        '<div class="tile" data-act="addCircle"><b>●</b>Círculo</div></div>';
    }else if(tab==='tpl'){
      h='<div class="hint">Seu conteúdo é reencaixado no modelo escolhido. Nada se perde.</div><div class="tpls">'+PRESETS.map(function(p){return '<div class="tp" data-act="preset" data-arg="'+p.key+'"><div class="th" style="background:'+p.bg+'">'+thumb(p)+'</div>'+p.name+'</div>';}).join('')+'</div>';
    }else if(tab==='page'){
      h=lbl('Fundo da página')+'<div class="sws">'+BGS.map(function(c){return swatch(c,'bg',c===S.bg);}).join('')+'<div class="sw plus" data-act="customBg">+</div></div>'+
        slider('m')+
        '<div class="btns">'+chipB(S.grid?'Grade e margens: ligada':'Mostrar grade e margens','grid',null,S.grid?'on':'')+'</div>';
    }
  }else if(tab==='txt'){
    h=lbl('Fonte')+'<div class="fontbtn" data-act="fonts" style="font-family:'+famOf(f)+'">'+fontName(f)+'<small>›</small></div>'+
      '<div class="rowc"><div class="nm">Tamanho</div><div class="ib" data-act="sizeStep" data-arg="-2">−</div><input type="range" data-sl="fs" min="0" max="100" step="1" value="'+SL.fs.get(f)+'"><div class="ib" data-act="sizeStep" data-arg="2">+</div><div class="val" id="v_fs">'+SL.fs.fmt(f)+'</div></div>'+
      seg([[300,'Leve'],[400,'Normal'],[700,'Negrito'],[800,'Extra']],f.fw||400,'weight')+
      '<div class="btns">'+chipB('Itálico','italic',null,f.it?'on':'')+chipB('MAIÚSCULAS','upper',null,f.up?'on':'')+'</div>';
  }else if(tab==='par'){
    h=seg([['l',alIcon('l')],['c',alIcon('c')],['r',alIcon('r')],['j',alIcon('j')]],f.al||'l','align')+
      slider('lh')+slider('ls')+slider('pad')+
      lbl('Caixa de texto')+seg([['auto','Cresce'],['fixed','Fixa'],['fit','Ajusta a fonte']],f.beh||'auto','behave');
  }else if(tab==='col'){
    h=lbl('Cor do texto')+colorPanel(f.col,'customColor');
  }else if(tab==='img'){
    h='<div class="btns">'+chipB('Trocar imagem','swapImage')+'</div>'+
      seg([['cover','Preencher'],['contain','Caber inteira']],f.fit||'cover','fit');
    if((f.fit||'cover')==='cover'){
      var cur=(f.px==null?50:f.px)+','+(f.py==null?50:f.py),pts=['0,0','50,0','100,0','0,50','50,50','100,50','0,100','50,100','100,100'];
      h+=lbl('Foco do recorte')+'<div class="focus">'+pts.map(function(q){return '<div class="'+(q===cur?'on':'')+'" data-act="focus" data-arg="'+q+'"></div>';}).join('')+'</div>';
    }
  }else if(tab==='sty'){
    h=slider('rad');
    if(f.t==='shape')h+=lbl('Cor')+colorPanel(f.fill,'customColor');
    else h+=lbl('Cor de fundo (aparece ao caber a imagem)')+colorPanel(f.fill,'customColor');
  }else if(tab==='pos'){
    h=lbl('Alinhar na página')+seg([['L',alIcon('l')],['C',alIcon('c')],['R',alIcon('r')]],'','pal')+
      '<div class="btns">'+chipB(f.x===0&&f.w===PW?'Com margem':'Largura total','full')+chipB('Preencher entre margens','margins')+'</div>'+
      lbl('Mover')+seg([[1,'1'],[10,'10'],[50,'50']],NUDGE,'step')+
      '<div class="nudge"><div class="ib" data-act="nudge" data-arg="l">←</div><div class="ib" data-act="nudge" data-arg="u">↑</div><div class="ib" data-act="nudge" data-arg="d">↓</div><div class="ib" data-act="nudge" data-arg="r">→</div></div>'+
      '<div class="btns">'+chipB('Para frente','front')+chipB('Para trás','back')+chipB('Duplicar','dup')+chipB(f.lock?'Destravar':'Travar','lock',null,f.lock?'on':'')+chipB('Excluir','del',null,'red')+'</div>';
  }
  return h;
}
function thumb(p){
  var sc=60/PW,h='';
  for(var i=0;i<p.slots.length;i++){
    var s=p.slots[i],st='left:'+(s.x*sc)+'px;top:'+(s.y*sc)+'px;width:'+(s.w*sc)+'px;';
    if(s.t==='image')h+='<i style="'+st+'height:'+(s.h*sc)+'px;background:#9A9A9A"></i>';
    else if(s.t==='shape')h+='<i style="'+st+'height:'+Math.max(1,s.h*sc)+'px;background:'+s.fill+'"></i>';
    else h+='<i style="'+st+'height:'+Math.max(2,Math.min(s.h,(s.fs||30)*1.0)*sc)+'px;background:'+(s.col||'#111')+';opacity:.85"></i>';
  }
  return h;
}
function ctxLabel(f){
  if(!f)return tab?'':'Toque num item para editar';
  if(editingId)return 'Escrevendo…';
  var n={text:'Texto',image:'Imagem',shape:'Forma'}[f.t];
  return n+(f.lock?' · travado':'');
}
function drawBar(){
  if(!editable)return;
  var f=sel&&get(sel),ts=tabsFor(f);
  if(tab&&!ts.some(function(t){return t[0]===tab;}))tab=null;
  $('dh').innerHTML='<div class="ctx">'+ctxLabel(f)+'</div>'+
    '<div class="ib'+(hist.length?'':' dim')+'" data-act="undo">↶</div><div class="ib'+(fut.length?'':' dim')+'" data-act="redo">↷</div>'+
    '<div class="ok" data-act="done">'+(f?'OK':'Concluir')+'</div>';
  $('pn').innerHTML=panelHtml(f);
  $('tabs').innerHTML=ts.map(function(t){return '<div class="tab'+(tab===t[0]?' on':'')+'" data-act="tab" data-arg="'+t[0]+'">'+t[1]+'</div>';}).join('');
  layoutDock();
}
function layoutDock(){
  if(editable)setTimeout(reveal,60);
}
function drawSheet(){
  var sh=$('sheet'),sc=$('scrim');
  if(!fontSheet){sh.style.display='none';sc.style.display='none';return;}
  var f=sel&&get(sel);if(!f){fontSheet=false;sh.style.display='none';sc.style.display='none';return;}
  var cur=(f.fam&&FONTLIST.indexOf(f.fam)>=0)?'u:'+f.fam:(f.ff||'s');
  function row(arg,name,css){return '<div class="frow" data-act="setfont" data-arg="'+arg+'" style="font-family:'+css+'">'+name+(arg===cur?'<span class="ck">✓</span>':'')+'</div>';}
  var h='<div class="ttl">Padrão</div>'+row('s','Sans',FONTS.s)+row('f','Serifa',FONTS.f)+row('m','Mono',FONTS.m);
  h+='<div class="ttl">Minhas fontes</div>';
  if(!FONTLIST.length)h+='<div class="frow" style="font-size:15px;color:#666">Nenhuma ainda</div>';
  for(var i=0;i<FONTLIST.length;i++)h+=row('u:'+FONTLIST[i],FONTLIST[i],"'"+FONTLIST[i]+"',"+FONTS.s);
  h+='<div class="frow more" data-act="moreFonts">+ Buscar mais no Google Fonts</div>';
  sh.innerHTML=h;sh.style.display='block';sc.style.display='block';
}
function dockTap(e){
  var c=e.target.closest&&e.target.closest('[data-act]');if(!c)return;
  var a=c.getAttribute('data-act'),arg=c.getAttribute('data-arg');
  if(a==='pal'){if(arg==='L')ACT.alignL();else if(arg==='C')ACT.alignC();else ACT.alignR();return;}
  if(ACT[a])ACT[a](arg);
}
['pointerdown','mousedown'].forEach(function(n){$('dock').addEventListener(n,function(e){
  var t=e.target;
  if(t&&t.getAttribute&&t.getAttribute('data-sl')){if(n==='pointerdown'&&!slHist){pushHist();slHist=true;}return;}
  e.preventDefault();
});});
$('dock').addEventListener('click',dockTap);
$('sheet').addEventListener('click',dockTap);
$('scrim').addEventListener('click',function(){fontSheet=false;drawSheet();});
$('dock').addEventListener('input',function(e){var k=e.target.getAttribute&&e.target.getAttribute('data-sl');if(k)slide(k,parseFloat(e.target.value),false);});
$('dock').addEventListener('change',function(e){var k=e.target.getAttribute&&e.target.getAttribute('data-sl');if(k){slHist=false;slide(k,parseFloat(e.target.value),true);}});
/* ---------- modelos ---------- */
function T(role,x,y,w,h,o){var f={t:'text',role:role,x:x,y:y,w:w,h:h,fs:32,fw:400,al:'l',lh:1.3,ls:0,ff:'s',beh:'auto'};for(var k in o)f[k]=o[k];return f;}
function I(x,y,w,h,o){var f={t:'image',x:x,y:y,w:w,h:h,fit:'cover'};for(var k in o)f[k]=o[k];return f;}
function R(x,y,w,h,fill,rad){return {t:'shape',x:x,y:y,w:w,h:h,fill:fill,rad:rad||0};}
var PRESETS=[
 {key:'capa',name:'Capa',bg:'#FFFFFF',slots:[
  T('h',60,70,880,380,{txt:'Título',fs:170,fw:800,ls:-0.04,lh:0.95,col:'#111111',beh:'fixed'}),
  T('c',60,480,400,60,{txt:'Subtítulo',fs:24,fw:600,up:true,ls:0.06,col:'#111111'}),
  T('b',520,480,420,170,{txt:'Escreva aqui…',fs:26,col:'#111111'}),
  R(60,460,880,3,'#111111'),
  I(60,700,880,700,{})]},
 {key:'numero',name:'Número grande',bg:'#F3EEE6',slots:[
  T('n',40,10,920,540,{txt:'01',fs:560,fw:400,ls:-0.06,lh:0.85,col:'#E8501F',beh:'fixed'}),
  T('h',60,610,520,300,{txt:'Título',fs:100,fw:600,ls:-0.04,lh:0.98,col:'#111111',beh:'fixed'}),
  T('b',60,940,420,360,{txt:'Escreva aqui…',fs:27,lh:1.35,col:'#111111'}),
  I(520,650,420,650,{})]},
 {key:'colunas',name:'Duas colunas',bg:'#FFFFFF',slots:[
  T('h',60,80,880,250,{txt:'Título',fs:110,fw:800,ls:-0.04,lh:1,col:'#111111',beh:'fixed'}),
  R(60,360,880,3,'#111111'),
  T('b',60,400,420,640,{txt:'Primeira coluna…',fs:28,lh:1.45,col:'#111111'}),
  T('b',520,400,420,640,{txt:'Segunda coluna…',fs:28,lh:1.45,col:'#111111'}),
  I(60,1100,880,500,{})]},
 {key:'fototopo',name:'Foto + título',bg:'#FFFFFF',slots:[
  I(0,0,1000,820,{}),
  T('c',60,860,880,40,{txt:'Categoria',fs:22,fw:600,up:true,ls:0.08,col:'#666666'}),
  T('h',60,920,880,230,{txt:'Título',fs:96,fw:700,ls:-0.03,lh:1.02,col:'#111111',beh:'fixed'}),
  T('b',60,1180,560,360,{txt:'Escreva aqui…',fs:28,lh:1.4,col:'#111111'})]},
 {key:'sobrefoto',name:'Texto sobre foto',bg:'#111111',slots:[
  I(0,0,1000,1500,{}),
  T('c',50,60,900,40,{txt:'Subtítulo',fs:24,fw:700,up:true,ls:0.06,col:'#FFE600'}),
  T('h',50,960,900,440,{txt:'Título',fs:190,fw:800,ls:-0.04,lh:0.9,up:true,col:'#FFE600',beh:'fixed'})]},
 {key:'grade',name:'Grade de fotos',bg:'#FFFFFF',slots:[
  T('h',60,60,880,300,{txt:'Título',fs:150,fw:800,ls:-0.045,lh:0.92,col:'#111111',beh:'fixed'}),
  T('c',60,390,880,40,{txt:'Subtítulo',fs:24,fw:600,up:true,ls:0.06,col:'#111111'}),
  I(60,470,420,520,{rad:28}),I(520,470,420,520,{rad:28}),I(60,1030,420,520,{rad:28}),I(520,1030,420,520,{rad:28}),
  T('b',60,1590,880,200,{txt:'Escreva aqui…',fs:28,col:'#111111'})]},
 {key:'solta',name:'Tipografia solta',bg:'#FFFFFF',slots:[
  T('h',40,50,920,320,{txt:'Título',fs:260,fw:400,ls:-0.05,lh:0.9,col:'#111111',beh:'fixed'}),
  I(60,430,500,640,{}),
  T('b',620,470,320,420,{txt:'Escreva aqui…',fs:24,lh:1.4,col:'#111111'}),
  T('c',620,930,320,140,{txt:'Legenda',fs:20,up:true,ls:0.06,col:'#666666'})]},
 {key:'atmosfera',name:'Atmosfera',bg:'#FFFFFF',slots:[
  T('n',380,780,640,700,{txt:'14.08',fs:420,fw:400,ls:-0.05,lh:0.85,col:'#F1F1F1',beh:'fixed'}),
  T('c',100,120,500,100,{txt:'Subtítulo',fs:22,fw:600,up:true,ls:0.04,col:'#111111'}),
  I(0,300,1000,420,{}),
  T('h',100,780,440,460,{txt:'Título',fs:120,fw:600,ls:-0.05,lh:0.95,col:'#333333',beh:'fixed'}),
  T('b',570,800,330,420,{txt:'Escreva aqui…',fs:24,lh:1.4,col:'#111111'})]}
];
var DEFAULTS={};
(function(){for(var i=0;i<PRESETS.length;i++)for(var j=0;j<PRESETS[i].slots.length;j++){var t=PRESETS[i].slots[j].txt;if(t)DEFAULTS[t]=1;}})();
function readingOrder(a,b){return a.y-b.y||a.x-b.x;}
function applyPreset(key){
  var P=null;for(var i=0;i<PRESETS.length;i++)if(PRESETS[i].key===key)P=PRESETS[i];if(!P)return;
  if(editingId)endEdit();
  pushHist();
  var texts=S.frames.filter(function(f){return f.t==='text'&&(f.txt||'').trim()&&!DEFAULTS[(f.txt||'').trim()];}).sort(readingOrder);
  var imgs=S.frames.filter(function(f){return f.t==='image'&&f.src;}).sort(readingOrder);
  var title=null;
  for(var a=0;a<texts.length;a++)if(texts[a].role==='h'){title=texts[a];break;}
  if(!title&&texts.length){title=texts.slice().sort(function(p,q){return (q.fs||0)-(p.fs||0);})[0];}
  var rest=texts.filter(function(t){return t!==title;});
  var out=[],grow=[];
  for(var s=0;s<P.slots.length;s++){
    var sl=JSON.parse(JSON.stringify(P.slots[s]));sl.id=uid();
    if(sl.t==='text'&&sl.role==='h'&&sl.beh==='fixed'){sl.beh='fit';sl.fm=sl.fs;}
    if(sl.t==='text'){
      if(sl.role==='h'&&title){sl.txt=title.txt;title=null;}
      else if(sl.role==='b'&&rest.length){var li=0;for(var z=1;z<rest.length;z++)if((rest[z].txt||'').length>(rest[li].txt||'').length)li=z;sl.txt=rest.splice(li,1)[0].txt;}
      else if(sl.role==='c'&&rest.length){var si=0;for(var y2=1;y2<rest.length;y2++)if((rest[y2].txt||'').length<(rest[si].txt||'').length)si=y2;if((rest[si].txt||'').length<=90)sl.txt=rest.splice(si,1)[0].txt;}
      else if(sl.role==='n'){var nf=texts.filter(function(t){return t.role==='n';})[0];if(nf)sl.txt=nf.txt;}
      if(sl.role==='b'&&sl.beh!=='fixed')grow.push({id:sl.id,h:sl.h});
    }else if(sl.t==='image'){
      var im=imgs.shift();if(im){sl.src=im.src;sl.fit=im.fit||sl.fit;sl.px=im.px;sl.py=im.py;}
    }
    out.push(sl);
  }
  S.bg=P.bg;
  S.frames=out;
  // o que sobrou entra embaixo, sem perder nada
  var y=0;for(var k=0;k<out.length;k++)y=Math.max(y,out[k].y+out[k].h);
  y+=60;
  if(title){rest.unshift(title);}
  for(var r=0;r<rest.length;r++){S.frames.push(newText(rest[r].txt,{y:y,x:60,w:880,fs:30,col:inkOn(P.bg),lh:1.4,role:'b'}));y+=200;}
  for(var m=0;m<imgs.length;m++){S.frames.push({id:uid(),t:'image',src:imgs[m].src,fit:'cover',x:60,y:y,w:880,h:620});y+=680;}
  render();
  // caixas de texto que cresceram empurram o que está logo abaixo
  var byY=grow.map(function(g){return get(g.id);}).filter(Boolean).sort(function(p,q){return p.y-q.y;});
  for(var n=0;n<byY.length;n++){
    var f=byY[n],g0=grow.filter(function(z){return z.id===f.id;})[0],delta=f.h-g0.h;
    if(delta<=0)continue;
    for(var o=0;o<S.frames.length;o++){var q=S.frames[o];if(q===f)continue;
      if(q.y>=g0.h+f.y-1&&q.x<f.x+f.w&&q.x+q.w>f.x)q.y+=delta;}
  }
  render();select(null);changed();
}
/* ---------- comandos vindos do app ---------- */
window.setEditable=function(b){
  editable=!!b;document.body.classList.toggle('editing',editable);
  if(!editable){if(editingId)endEdit();sel=null;tab=null;fontSheet=false;drawSheet();hideGuides();}
  else{tab=null;}
  paintBody();drawGrid();drawSel();drawBar();layoutDock();
};
window.beginEdit=function(){window.setEditable(true);post({type:'editing'});};
window.initFree=function(p){
  S=p.free||{v:1,bg:'#FFFFFF',h:1500,frames:[]};
  hist=[];fut=[];sel=null;tab=null;editingId=null;
  window.setEditable(!!p.editable);
  if(!p.free){
    var seed=p.seed||{},fr=[];
    if((seed.title||'').trim())fr.push({id:uid(),t:'text',role:'h',x:60,y:60,w:880,h:200,txt:seed.title.trim(),fs:100});
    if((seed.text||'').trim())fr.push({id:uid(),t:'text',role:'b',x:60,y:300,w:880,h:200,txt:seed.text.trim(),fs:28});
    var im=seed.images||[];for(var i=0;i<im.length;i++)fr.push({id:uid(),t:'image',src:im[i],fit:'cover',x:60,y:600+i*100,w:880,h:600});
    S.frames=fr;calcK();render();applyPreset('capa');flush();
  }else{render();}
};
window.setFrameImage=function(id,uri){
  if(!uri)return;
  if(id==='new'){
    var im=new Image();
    im.onload=function(){
      var r=im.naturalHeight/Math.max(1,im.naturalWidth),w=840,h=Math.round(Math.min(1100,Math.max(200,w*r)));
      addFrame({id:uid(),t:'image',src:uri,fit:'cover',x:80,y:Math.max(40,visTop()+120),w:w,h:h});
    };
    im.onerror=function(){addFrame({id:uid(),t:'image',src:uri,fit:'cover',x:80,y:200,w:840,h:600});};
    im.src=uri;
    return;
  }
  var f=get(id);if(!f)return;pushHist();f.src=uri;updateFrame(f);select(id);changed();
};
window.setFonts=function(p){
  var list=((p&&p.list)||[]).filter(function(n){return /^[A-Za-z0-9][A-Za-z0-9 ]{0,59}$/.test(n);});
  var st=$('ufonts');if(!st){st=document.createElement('style');st.id='ufonts';document.head.appendChild(st);}
  st.textContent=(p&&p.css)||'';
  FONTLIST=list;
  if(fontSheet)drawSheet();
  if(S.frames.length)render();
  try{Promise.all(list.map(function(n){return document.fonts.load("400 16px '"+n+"'");})).then(function(){if(S.frames.length&&!editingId)render();});}catch(x){}
};
window.setFrameColor=function(hex,which){
  if(!/^#[0-9a-fA-F]{6}$/.test(hex||''))return;
  if(which==='bg')ACT.bg(hex);else if(sel)ACT.color(hex);
};
window.setInsets=function(t,b){
  t=Math.max(0,+t||0);b=Math.max(0,+b||0);
  var d=t-INS.top;INS.top=t;INS.bottom=b;
  document.documentElement.style.setProperty('--top',t+'px');
  document.documentElement.style.setProperty('--sb',b+'px');
  if(d&&(scEl.scrollTop||0)>0)scEl.scrollTop+=d;
  layoutDock();
};
var lastY=0,lastDir='';
scEl.addEventListener('scroll',function(){
  if(editable)return;
  var y=scEl.scrollTop||0,dy=y-lastY;
  if(Math.abs(dy)<18&&y>=40)return;
  var d=(dy>0&&y>=40)?'down':'up';lastY=y;
  if(d!==lastDir){lastDir=d;post({type:'scrollDir',dir:d});}
},{passive:true});
window.setScale=function(){};window.setRecentColors=function(){};
window.setBacklinks=function(){};window.refreshNoteLinks=function(){};window.kbHidden=function(){};window.setNoteResults=function(){};
var lastW=0;window.addEventListener('resize',function(){
  var w=pageEl.clientWidth;if(w!==lastW){lastW=w;render();}
  /* o teclado abriu/fechou: mantém o item em edição à vista, acima da barra */
  if(editable&&(sel||editingId))setTimeout(reveal,80);
});
window.addEventListener('error',function(e){post({type:'jserror',message:String(e.message)});});
post({type:'ready'});
</script>
</body>
</html>`;
