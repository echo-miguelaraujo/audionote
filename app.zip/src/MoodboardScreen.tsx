import React, { memo, useCallback, useEffect, useRef, useState } from 'react';
import { Animated, PanResponder, Pressable, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { appAlert, appError, appMenu } from './dialog';
import {
  MoodCollection,
  createCollection,
  deleteCollection,
  listCollections,
  renameCollection,
  setCollectionPos,
} from './db';
import { Collage } from './Collage';
import { DotGrid } from './DotGrid';
import { mediaFile } from './media';
import { PromptDialog } from './PromptDialog';
import { IconButton } from './Button';
import { colors, fonts, HIT } from './theme';
import { useBoardLook } from './boardTheme';

type Props = {
  version: number;
  onOpen: (collectionId: number) => void;
  onChanged: () => void;
};

/** Tamanho do quadro livre, em "unidades" (1 = lado menor da tela). */
const WORLD_W = 18;
const WORLD_H = 27;
const MAX_ZOOM = 3;
/** Tamanho de cada coleção (nome + colagem), em unidades. */
const TILE_W = 0.46;
const TILE_H = 0.66;

type View2 = { tx: number; ty: number; z: number };
type Item = MoodCollection & { px: number; py: number };

const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));

type CanvasGesture = { move: (e: any) => void; end: () => void };

/** Uma coleção no quadro. Toque abre; segurar abre o menu; arrastar muda de lugar; pinça dá zoom no quadro. */
const Tile = memo(function Tile({
  c,
  u,
  viewRef,
  gesture,
  onOpen,
  onMenu,
  onMoved,
  dark,
}: {
  c: Item;
  dark: boolean;
  u: number;
  viewRef: React.MutableRefObject<View2>;
  gesture: React.MutableRefObject<CanvasGesture>;
  onOpen: (id: number) => void;
  onMenu: (c: MoodCollection) => void;
  onMoved: (id: number, x: number, y: number) => void;
}) {
  const [live, setLive] = useState<{ dx: number; dy: number } | null>(null);
  const latest = useRef({ c, onOpen, onMenu, onMoved });
  latest.current = { c, onOpen, onMenu, onMoved };
  const st = useRef({ dragging: false, pinched: false, long: false, dx: 0, dy: 0 });
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const stopTimer = () => {
    if (timer.current) clearTimeout(timer.current);
    timer.current = null;
  };

  const pan = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderTerminationRequest: () => false,
      onPanResponderGrant: () => {
        st.current = { dragging: false, pinched: false, long: false, dx: 0, dy: 0 };
        stopTimer();
        timer.current = setTimeout(() => {
          const s = st.current;
          if (s.dragging || s.pinched) return;
          s.long = true;
          latest.current.onMenu(latest.current.c);
        }, 450);
      },
      onPanResponderMove: (e, g) => {
        const s = st.current;
        const t = e.nativeEvent.touches;
        if (t.length >= 2) {
          // Dois dedos: é zoom do quadro, não arrasto da coleção.
          s.pinched = true;
          stopTimer();
          setLive(null);
          gesture.current.move(e);
          return;
        }
        if (s.pinched || s.long) return;
        if (!s.dragging && Math.hypot(g.dx, g.dy) > 10) {
          s.dragging = true;
          stopTimer();
        }
        if (s.dragging) {
          const z = viewRef.current.z || 1;
          s.dx = g.dx / z;
          s.dy = g.dy / z;
          setLive({ dx: s.dx, dy: s.dy });
        }
      },
      onPanResponderRelease: () => {
        const s = st.current;
        stopTimer();
        const { c: cc, onOpen: open, onMoved: moved } = latest.current;
        if (s.pinched) gesture.current.end();
        else if (s.dragging) {
          moved(
            cc.id,
            clamp(cc.px + s.dx / u, 0, WORLD_W - TILE_W),
            clamp(cc.py + s.dy / u, 0, WORLD_H - TILE_H)
          );
        } else if (!s.long) open(cc.id);
        setLive(null);
      },
      onPanResponderTerminate: () => {
        stopTimer();
        if (st.current.pinched) gesture.current.end();
        setLive(null);
      },
    })
  ).current;

  useEffect(() => stopTimer, []);

  return (
    <View
      {...pan.panHandlers}
      style={{
        position: 'absolute',
        left: c.px * u,
        top: c.py * u,
        width: TILE_W * u,
        alignItems: 'center',
        zIndex: live ? 10 : 0,
        opacity: live ? 0.9 : 1,
        transform: [{ translateX: live?.dx ?? 0 }, { translateY: live?.dy ?? 0 }, { scale: live ? 1.04 : 1 }],
      }}
    >
      <Text
        numberOfLines={1}
        style={{
          fontFamily: fonts.regular,
          fontSize: u * 0.058,
          letterSpacing: -u * 0.058 * 0.04,
          color: dark ? colors.onDark : colors.onLight,
          marginBottom: u * 0.02,
          maxWidth: '100%',
        }}
      >
        {c.name}
      </Text>
      <Collage covers={c.covers} sw={u} />
    </View>
  );
});

export function MoodboardScreen({ version, onOpen, onChanged }: Props) {
  const { width: sw, height: sh } = useWindowDimensions();
  // Unidade fixa (lado menor da tela): o quadro tem o mesmo tamanho em pé e deitado.
  const u = Math.min(sw, sh);
  const insets = useSafeAreaInsets();
  const [cols, setCols] = useState<Item[] | null>(null);
  const [creating, setCreating] = useState(false);
  const [renaming, setRenaming] = useState<MoodCollection | null>(null);

  // ---------- zoom e posição do quadro (mesmo esquema da tela de uma coleção) ----------
  const worldW = WORLD_W * u;
  const worldH = WORLD_H * u;
  const minZoom = Math.max(sw / worldW, sh / worldH);
  const view = useRef<View2>({ tx: 0, ty: 0, z: 1 });
  const atx = useRef(new Animated.Value(0)).current;
  const aty = useRef(new Animated.Value(0)).current;
  const az = useRef(new Animated.Value(1)).current;
  const rootRef = useRef<View>(null);
  const origin = useRef({ x: 0, y: 0 });
  const fitted = useRef(false);

  const clampView = useCallback(
    (v: View2): View2 => {
      const z = clamp(v.z, minZoom, MAX_ZOOM);
      return { z, tx: clamp(v.tx, sw - worldW * z, 0), ty: clamp(v.ty, sh - worldH * z, 0) };
    },
    [minZoom, sw, sh, worldW, worldH]
  );

  const setView = useCallback(
    (v: View2) => {
      const c = clampView(v);
      view.current = c;
      atx.setValue(c.tx);
      aty.setValue(c.ty);
      az.setValue(c.z);
    },
    [clampView, atx, aty, az]
  );

  const fitAll = useCallback(
    (list: Item[]) => {
      if (list.length === 0) {
        setView({ z: 1, tx: sw / 2 - worldW / 2, ty: sh / 2 - worldH / 2 });
        return;
      }
      let x0 = Infinity,
        y0 = Infinity,
        x1 = -Infinity,
        y1 = -Infinity;
      for (const c of list) {
        x0 = Math.min(x0, c.px);
        y0 = Math.min(y0, c.py);
        x1 = Math.max(x1, c.px + TILE_W);
        y1 = Math.max(y1, c.py + TILE_H);
      }
      const pad = 0.12;
      const bw = (x1 - x0 + pad * 2) * u;
      const bh = (y1 - y0 + pad * 2) * u;
      const z = clamp(Math.min(sw / bw, (sh * 0.8) / bh, 1), minZoom, 1);
      const cx = ((x0 + x1) / 2) * u;
      const cy = ((y0 + y1) / 2) * u;
      setView({ z, tx: sw / 2 - cx * z, ty: sh / 2 - cy * z });
    },
    [setView, sw, sh, u, worldW, worldH, minZoom]
  );

  // Girou a tela: mantém o quadro dentro dos limites.
  useEffect(() => {
    setView(view.current);
  }, [sw, sh, setView]);

  const load = useCallback(async () => {
    const list = await listCollections();
    // Coleções ainda sem lugar ganham um: grade de 2 colunas no meio do quadro (a mais nova primeiro).
    let k = 0;
    const out: Item[] = list.map((c) => {
      if (c.x !== null && c.y !== null) return { ...c, px: c.x, py: c.y };
      const px = WORLD_W / 2 - TILE_W - 0.05 + (k % 2) * (TILE_W + 0.1);
      const py = WORLD_H / 2 - 1.2 + Math.floor(k / 2) * (TILE_H + 0.1);
      k++;
      setCollectionPos(c.id, px, py).catch(() => {});
      return { ...c, px, py };
    });
    setCols(out);
    if (!fitted.current) {
      fitted.current = true;
      fitAll(out);
    }
  }, [fitAll]);

  const loadRef = useRef(load);
  loadRef.current = load;
  useEffect(() => {
    loadRef.current().catch((e) => appError('Erro ao ler as coleções', e));
  }, [version]);

  // ---------- gesto do fundo: 1 dedo arrasta o quadro; 2 dedos dão zoom ----------
  const bg = useRef<{ n: number; v: View2; cx: number; cy: number; dist: number } | null>(null);
  const gesture = useRef<CanvasGesture>({ move: () => {}, end: () => {} });
  gesture.current = {
    move: (e) => {
      const t = e.nativeEvent.touches;
      if (!t || t.length === 0) return;
      const n = Math.min(2, t.length);
      const ox = origin.current.x;
      const oy = origin.current.y;
      const cx = (n === 2 ? (t[0].pageX + t[1].pageX) / 2 : t[0].pageX) - ox;
      const cy = (n === 2 ? (t[0].pageY + t[1].pageY) / 2 : t[0].pageY) - oy;
      const dist = n === 2 ? Math.hypot(t[1].pageX - t[0].pageX, t[1].pageY - t[0].pageY) : 0;
      if (!bg.current || bg.current.n !== n) {
        bg.current = { n, v: { ...view.current }, cx, cy, dist };
        return;
      }
      const b = bg.current;
      if (n === 1) {
        setView({ z: b.v.z, tx: b.v.tx + (cx - b.cx), ty: b.v.ty + (cy - b.cy) });
      } else {
        const z = clamp(b.v.z * (dist / (b.dist || 1)), minZoom, MAX_ZOOM);
        const wx = (b.cx - b.v.tx) / b.v.z;
        const wy = (b.cy - b.v.ty) / b.v.z;
        setView({ z, tx: cx - wx * z, ty: cy - wy * z });
      }
    },
    end: () => {
      bg.current = null;
    },
  };
  const bgPan = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderTerminationRequest: () => false,
      onPanResponderGrant: () => {
        bg.current = null;
      },
      onPanResponderMove: (e) => gesture.current.move(e),
      onPanResponderRelease: () => gesture.current.end(),
      onPanResponderTerminate: () => gesture.current.end(),
    })
  ).current;

  const onMoved = useCallback((id: number, x: number, y: number) => {
    setCols((prev) => (prev ? prev.map((c) => (c.id === id ? { ...c, px: x, py: y } : c)) : prev));
    setCollectionPos(id, x, y).catch(() => {});
  }, []);

  const menu = useCallback(
    (c: MoodCollection) =>
      appMenu(c.name, undefined, [
        { text: 'Renomear', onPress: () => setRenaming(c) },
        {
          text: 'Excluir',
          style: 'destructive',
          onPress: () =>
            appAlert('Excluir coleção?', `"${c.name}", as coleções de dentro dela e as imagens serão apagadas. As notas vinculadas não são apagadas.`, [
              { text: 'Cancelar', style: 'cancel' },
              {
                text: 'Excluir',
                style: 'destructive',
                onPress: async () => {
                  const files = await deleteCollection(c.id);
                  files.forEach((f) => {
                    try {
                      const file = mediaFile(f);
                      if (file.exists) file.delete();
                    } catch {
                      // arquivo já não existe
                    }
                  });
                  onChanged();
                },
              },
            ]),
        },
        { text: 'Cancelar', style: 'cancel' },
      ]),
    [onChanged]
  );

  const look = useBoardLook();
  const titleSize = u * 0.14;
  const labelSize = u * 0.058;

  return (
    <View
      ref={rootRef}
      style={[styles.flex, { backgroundColor: look.paper }]}
      onLayout={() => {
        rootRef.current?.measure((_x, _y, _w, _h, px, py) => {
          origin.current = { x: px ?? 0, y: py ?? 0 };
        });
      }}
    >
      {/* Quadro livre: grade e coleções andam e dão zoom juntas. */}
      <View style={StyleSheet.absoluteFill} {...bgPan.panHandlers}>
        <Animated.View
          style={{
            position: 'absolute',
            left: 0,
            top: 0,
            width: worldW,
            height: worldH,
            transformOrigin: 'top left',
            transform: [{ translateX: atx }, { translateY: aty }, { scale: az }],
          }}
        >
          <DotGrid width={worldW} height={worldH} bg={look.paper} dot={look.dot} />
          {(cols ?? []).map((c) => (
            <Tile key={c.id} dark={look.dark} c={c} u={u} viewRef={view} gesture={gesture} onOpen={onOpen} onMenu={menu} onMoved={onMoved} />
          ))}
        </Animated.View>
      </View>

      <View
        style={[styles.head, { paddingTop: insets.top + u * 0.05, paddingHorizontal: u * 0.055 }]}
        pointerEvents="box-none"
      >
        <Text
          pointerEvents="none"
          style={{
            flex: 1,
            fontFamily: fonts.bold,
            fontSize: titleSize,
            letterSpacing: -titleSize * 0.05,
            color: look.dark ? colors.onDark : colors.onLight,
          }}
          numberOfLines={1}
        >
          coleções
        </Text>
        <Pressable onPress={() => setCreating(true)} hitSlop={HIT.md} accessibilityRole="button" accessibilityLabel="Nova coleção">
          <Text style={{ fontFamily: fonts.light, fontSize: u * 0.12, lineHeight: u * 0.12, color: colors.red }}>+</Text>
        </Pressable>
      </View>

      {cols !== null && cols.length === 0 && (
        <Text
          pointerEvents="none"
          style={{
            position: 'absolute',
            left: u * 0.055,
            right: u * 0.055,
            top: sh / 2 - labelSize,
            textAlign: 'center',
            fontFamily: fonts.regular,
            fontSize: labelSize,
            color: look.dark ? colors.muted : colors.subtle,
          }}
        >
          Toque no + para criar sua primeira coleção.
        </Text>
      )}

      {/* Só "ajustar à tela"; o zoom é pela pinça com dois dedos. */}
      <View
        style={{ position: 'absolute', right: u * 0.04, bottom: insets.bottom + u * 0.26, gap: u * 0.025 }}
        pointerEvents="box-none"
      >
        <IconButton u={u} icon="expand" label="Ajustar à tela" onPress={() => fitAll(cols ?? [])} />
      </View>

      <PromptDialog
        visible={creating}
        title="Nova coleção"
        initialValue=""
        placeholder="Nome da coleção"
        onCancel={() => setCreating(false)}
        onSubmit={async (v) => {
          setCreating(false);
          const id = await createCollection(v);
          // A nova coleção nasce no centro do que está sendo visto.
          const vv = view.current;
          const cx = (sw / 2 - vv.tx) / vv.z / u;
          const cy = (sh / 2 - vv.ty) / vv.z / u;
          await setCollectionPos(
            id,
            clamp(cx - TILE_W / 2, 0, WORLD_W - TILE_W),
            clamp(cy - TILE_H / 2, 0, WORLD_H - TILE_H)
          ).catch(() => {});
          onChanged();
          onOpen(id);
        }}
      />
      <PromptDialog
        visible={renaming !== null}
        title="Renomear coleção"
        initialValue={renaming?.name ?? ''}
        onCancel={() => setRenaming(null)}
        onSubmit={async (v) => {
          if (renaming) await renameCollection(renaming.id, v);
          setRenaming(null);
          onChanged();
        }}
      />
      {/* Brilho e tom quente: véus por cima de tudo, sem pegar toque. */}
      {look.dim < 1 && (
        <View pointerEvents="none" style={[StyleSheet.absoluteFill, { backgroundColor: '#000', opacity: 1 - look.dim }]} />
      )}
      {look.tint && <View pointerEvents="none" style={[StyleSheet.absoluteFill, { backgroundColor: look.tint }]} />}
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: colors.paper, overflow: 'hidden' },
  head: { position: 'absolute', top: 0, left: 0, right: 0, flexDirection: 'row', alignItems: 'center' },
});
