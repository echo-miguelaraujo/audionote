import React, { useCallback, useEffect, useState } from 'react';
import { Image, Pressable, ScrollView, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { appAlert } from './dialog';
import {
  MoodCollection,
  createCollection,
  deleteCollection,
  listCollections,
  renameCollection,
} from './db';
import { mediaFile, mediaUri } from './media';
import { PromptDialog } from './PromptDialog';
import { fonts } from './theme';

type Props = {
  version: number;
  onOpen: (collectionId: number) => void;
  onChanged: () => void;
};

// Cada capa da colagem: posição e tamanho (em unidades de largura da tela) e giro. Da de trás para a da frente.
const LAYERS = [
  { l: 0.0, t: 0.07, w: 0.12, h: 0.16, r: -8 },
  { l: 0.2, t: 0.1, w: 0.19, h: 0.26, r: 14 },
  { l: 0.11, t: 0.0, w: 0.2, h: 0.28, r: 0 },
  { l: 0.02, t: 0.15, w: 0.23, h: 0.31, r: -14 },
];

function Collage({ covers, sw }: { covers: string[]; sw: number }) {
  // Com menos de 4 imagens, usa só as capas da frente.
  const layers = LAYERS.slice(LAYERS.length - covers.length);
  // covers[0] é a mais recente: vai na frente (última camada).
  const ordered = [...covers].reverse();
  return (
    <View style={{ width: sw * 0.42, height: sw * 0.48 }}>
      {covers.length === 0 && (
        <View
          style={{
            position: 'absolute',
            left: sw * 0.08,
            top: sw * 0.06,
            width: sw * 0.22,
            height: sw * 0.3,
            borderRadius: sw * 0.02,
            borderWidth: 1.5,
            borderColor: 'rgba(0,0,0,0.25)',
            borderStyle: 'dashed',
          }}
        />
      )}
      {ordered.map((name, i) => {
        const L = layers[i];
        return (
          <Image
            key={`${name}-${i}`}
            source={{ uri: mediaUri(name) }}
            resizeMode="cover"
            style={{
              position: 'absolute',
              left: L.l * sw,
              top: L.t * sw,
              width: L.w * sw,
              height: L.h * sw,
              transform: [{ rotate: `${L.r}deg` }],
            }}
          />
        );
      })}
    </View>
  );
}

export function MoodboardScreen({ version, onOpen, onChanged }: Props) {
  const { width: sw } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const [cols, setCols] = useState<MoodCollection[] | null>(null);
  const [creating, setCreating] = useState(false);
  const [renaming, setRenaming] = useState<MoodCollection | null>(null);

  const load = useCallback(async () => {
    setCols(await listCollections());
  }, []);

  useEffect(() => {
    load().catch((e) => appAlert('Erro ao ler as coleções', String(e)));
  }, [load, version]);

  const menu = (c: MoodCollection) =>
    appAlert(c.name, undefined, [
      { text: 'Renomear', onPress: () => setRenaming(c) },
      {
        text: 'Excluir',
        style: 'destructive',
        onPress: () =>
          appAlert('Excluir coleção?', `"${c.name}" e as imagens dela serão apagadas.`, [
            { text: 'Cancelar', style: 'cancel' },
            {
              text: 'Excluir',
              style: 'destructive',
              onPress: async () => {
                const files = await deleteCollection(c.id);
                files.forEach((f) => {
                  try {
                    const file = mediaFile(f);
                    if (file.exists) file.delete();
                  } catch {
                    // arquivo já não existe
                  }
                });
                onChanged();
              },
            },
          ]),
      },
      { text: 'Cancelar', style: 'cancel' },
    ]);

  const titleSize = sw * 0.14;
  const labelSize = sw * 0.058;

  return (
    <View style={styles.flex}>
      <ScrollView
        contentContainerStyle={{
          paddingTop: insets.top + sw * 0.05,
          paddingHorizontal: sw * 0.055,
          paddingBottom: sw * 0.3,
        }}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.head}>
          <Text
            style={{
              flex: 1,
              fontFamily: fonts.bold,
              fontSize: titleSize,
              letterSpacing: -titleSize * 0.05,
              color: '#000',
            }}
            numberOfLines={1}
          >
            coleções
          </Text>
          <Pressable onPress={() => setCreating(true)} hitSlop={14} accessibilityLabel="Nova coleção">
            <Text style={{ fontFamily: fonts.light, fontSize: sw * 0.12, lineHeight: sw * 0.12, color: '#FF3030' }}>+</Text>
          </Pressable>
        </View>

        {cols !== null && cols.length === 0 && (
          <Text style={{ fontFamily: fonts.regular, fontSize: labelSize, color: '#808080', marginTop: sw * 0.12 }}>
            Toque no + para criar sua primeira coleção.
          </Text>
        )}

        <View style={styles.grid}>
          {(cols ?? []).map((c) => (
            <Pressable
              key={c.id}
              onPress={() => onOpen(c.id)}
              onLongPress={() => menu(c)}
              delayLongPress={350}
              style={{ width: '50%', alignItems: 'center', marginTop: sw * 0.09 }}
            >
              <Text
                numberOfLines={1}
                style={{
                  fontFamily: fonts.regular,
                  fontSize: labelSize,
                  letterSpacing: -labelSize * 0.04,
                  color: '#000',
                  marginBottom: sw * 0.035,
                  maxWidth: '90%',
                }}
              >
                {c.name}
              </Text>
              <Collage covers={c.covers} sw={sw} />
            </Pressable>
          ))}
        </View>
      </ScrollView>

      <PromptDialog
        visible={creating}
        title="Nova coleção"
        initialValue=""
        placeholder="Nome da coleção"
        onCancel={() => setCreating(false)}
        onSubmit={async (v) => {
          setCreating(false);
          const id = await createCollection(v);
          onChanged();
          onOpen(id);
        }}
      />
      <PromptDialog
        visible={renaming !== null}
        title="Renomear coleção"
        initialValue={renaming?.name ?? ''}
        onCancel={() => setRenaming(null)}
        onSubmit={async (v) => {
          if (renaming) await renameCollection(renaming.id, v);
          setRenaming(null);
          onChanged();
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: 'transparent' },
  head: { flexDirection: 'row', alignItems: 'center' },
  grid: { flexDirection: 'row', flexWrap: 'wrap' },
});
