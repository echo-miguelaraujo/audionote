import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { appAlert } from './dialog';
import { REDIRECT_URL, signInWithGoogle, signOut } from './supabase';
import { getSyncState, requestSync, subscribeSync } from './sync';
import { Button } from './Button';
import { StateMessage } from './StateMessage';
import { colors, fonts, TYPE, SPACE } from './theme';

const when = (ms: number | null) =>
  ms ? new Date(ms).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) : '—';

/** Conta Google + sincronização com o Supabase (aparece no topo das Configurações). */
export function SyncSection() {
  const { width: sw } = useWindowDimensions();
  const [s, setS] = useState(getSyncState());
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  useEffect(() => subscribeSync(() => setS(getSyncState())), []);

  const label = sw * 0.04;
  const small = sw * 0.036;

  const login = async () => {
    setBusy(true);
    setMsg(null);
    try {
      const r = await signInWithGoogle();
      if (!r.ok) setMsg(r.message ?? 'Não foi possível entrar.');
    } catch (e) {
      setMsg(String(e));
    } finally {
      setBusy(false);
    }
  };

  const logout = () =>
    appAlert('Sair da conta?', 'Seus dados continuam no celular e na nuvem. Só a sincronização para até você entrar de novo.', [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Sair', style: 'destructive', onPress: () => signOut().catch(() => {}) },
    ]);

  const btn = (text: string, onPress: () => void, primary = true, loading = false) => (
    <Button
      label={text}
      onPress={onPress}
      variant={primary ? 'primary' : 'secondary'}
      loading={loading}
      disabled={busy && !loading}
    />
  );

  return (
    <View style={{ marginTop: sw * SPACE.xl }}>
      <Text style={[styles.label, { fontSize: label }]}>Conta e sincronização</Text>

      {s.phase === 'off' && (
        <Text style={[styles.note, { fontSize: small }]}>
          Preencha a URL e a chave anon do Supabase em src/supabaseConfig.ts para ligar a sincronização.
        </Text>
      )}

      {s.phase === 'signed-out' && (
        <View style={{ marginTop: sw * SPACE.sm, gap: sw * SPACE.sm }}>
          <Text style={[styles.note, { fontSize: small }]}>
            Entre com o Google para guardar suas notas, coleções e agenda na nuvem e abrir em outros aparelhos.
          </Text>
          {btn('Entrar com Google', login, true, busy)}
          <Text style={[styles.note, { fontSize: small * 0.92 }]}>URL de retorno a cadastrar no Supabase: {REDIRECT_URL}</Text>
        </View>
      )}

      {s.phase !== 'off' && s.phase !== 'signed-out' && (
        <View style={{ marginTop: sw * SPACE.sm, gap: sw * SPACE.sm }}>
          <Text style={{ color: colors.text, fontFamily: fonts.regular, fontSize: sw * TYPE.body }}>{s.email ?? 'Conectado'}</Text>
          <Text style={[styles.note, { fontSize: small }]}>
            {s.phase === 'syncing'
              ? 'Sincronizando…'
              : s.phase === 'error'
                ? `Erro: ${s.error}`
                : `Última: ${when(s.lastSyncAt)}${s.lastSummary ? ` · ${s.lastSummary}` : ''}`}
            {s.pending > 0 ? `\n${s.pending} alteração(ões) aguardando envio.` : ''}
          </Text>
          {btn('Sincronizar agora', () => requestSync({ media: true }), true, s.phase === 'syncing')}
          {btn('Sair da conta', logout, false)}
        </View>
      )}

      {msg && (
        <StateMessage kind="error" size={TYPE.label} style={{ marginTop: sw * SPACE.sm }}>
          {msg}
        </StateMessage>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  label: { color: colors.muted, fontFamily: fonts.regular },
  note: { color: colors.muted, fontFamily: fonts.regular, lineHeight: 20 },
  btn: { alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: colors.text },
});
