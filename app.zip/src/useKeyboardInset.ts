import { useEffect, useRef, useState } from 'react';
import { Keyboard, useWindowDimensions } from 'react-native';

/**
 * Altura que o teclado cobre da tela, para telas e diálogos deixarem o campo visível.
 * No Android com tela de ponta a ponta a janela não encolhe sozinha; quando ela encolhe,
 * devolve 0 para não somar folga duas vezes (mesma regra de `NoteScreen` e `TextEditorOverlay`).
 */
export function useKeyboardInset(): number {
  const { height } = useWindowDimensions();
  const current = useRef(height);
  const full = useRef(height);
  current.current = height;
  if (height > full.current) full.current = height;
  const [inset, setInset] = useState(0);

  useEffect(() => {
    let timer: ReturnType<typeof setTimeout> | undefined;
    const show = Keyboard.addListener('keyboardDidShow', (e) => {
      const h = e.endCoordinates?.height ?? 0;
      // Espera a janela assentar para saber se ela encolheu sozinha.
      timer = setTimeout(() => setInset(current.current >= full.current - 20 ? h : 0), 150);
    });
    const hide = Keyboard.addListener('keyboardDidHide', () => {
      if (timer) clearTimeout(timer);
      setInset(0);
    });
    return () => {
      if (timer) clearTimeout(timer);
      show.remove();
      hide.remove();
    };
  }, []);

  return inset;
}
