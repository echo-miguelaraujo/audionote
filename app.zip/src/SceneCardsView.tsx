import React, { useEffect, useRef, useState } from 'react';
import { BackHandler, Image, Pressable, ScrollView, Text, View, useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { mediaUri } from './media';
import { ImageViewer } from './ImageViewer';
import { SCENE_LABELS, SceneInfo } from './SceneFields';
import { SCENE_STATUS } from './SceneCard';
import { colors, fonts, RADIUS, TYPE } from './theme';

export type CardScene = {
  key: number;
  /** Id da coleção da cena (para abrir a edição). */
  subId: number;
  number: number;
  status: number;
  covers: string[];
  info: SceneInfo;
};

/**
 * Cenas como cards, uma por tela: foto cheia (passa de lado) e, embaixo, a gaveta com a ficha completa.
 * Setas ‹ › trocam de cena. Cobre a tela do quadro; "Voltar" ou o botão voltar do aparelho fecham.
 */
export function SceneCardsView({
  scenes,
  startIndex,
  onClose,
  onEdit,
}: {
  scenes: CardScene[];
  startIndex: number;
  onClose: () => void;
  onEdit: (subId: number) => void;
}) {
  const { width: sw, height: sh } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const [idx, setIdx] = useState(Math.min(Math.max(startIndex, 0), Math.max(0, scenes.length - 1)));
  const [page, setPage] = useState(0);
  const photoRef = useRef<ScrollView>(null);
  const [viewer, setViewer] = useState<string | null>(null);
  const s = scenes[idx];
  const drawerH = sh * 0.52;
  const photoH = sh - drawerH + sw * RADIUS.sheet;

  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      onClose();
      return true;
    });
    return () => sub.remove();
  }, [onClose]);
  useEffect(() => {
    setPage(0);
    photoRef.current?.scrollTo({ x: 0, animated: false });
  }, [idx]);

  if (!s) return null;
  const go = (d: number) => setIdx((i) => Math.min(Math.max(i + d, 0), scenes.length - 1));
  const pill = { backgroundColor: '#000', borderRadius: sw * 0.06, paddingHorizontal: sw * 0.04, height: sw * 0.1, justifyContent: 'center' as const };
  const circle = (dark: boolean, disabled: boolean) => ({
    width: sw * 0.12,
    height: sw * 0.12,
    borderRadius: sw * 0.06,
    backgroundColor: dark ? colors.onLight : colors.hairline,
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
    opacity: disabled ? 0.35 : 1,
  });
  const rows = SCENE_LABELS.filter((f) => f.key !== 'name');

  return (
    <View style={{ position: 'absolute', left: 0, right: 0, top: 0, bottom: 0, backgroundColor: colors.onLight, zIndex: 50 }}>
      <ScrollView
        ref={photoRef}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        style={{ position: 'absolute', left: 0, top: 0, width: sw, height: photoH }}
        onMomentumScrollEnd={(e) => setPage(Math.round(e.nativeEvent.contentOffset.x / sw))}
      >
        {(s.covers.length ? s.covers : [null]).map((c, i) => (
          <View key={c ?? 'vazio'} style={{ width: sw, height: photoH, backgroundColor: colors.hairline, alignItems: 'center', justifyContent: 'center' }}>
            {c ? (
              <Pressable onPress={() => setViewer(c)} accessibilityRole="imagebutton" accessibilityLabel="Ver imagem inteira" style={{ width: sw, height: photoH }}>
                <Image source={{ uri: mediaUri(c) }} blurRadius={40} resizeMode="cover" style={{ position: 'absolute', width: sw, height: photoH, opacity: 0.9 }} />
                <Image source={{ uri: mediaUri(c) }} resizeMode="contain" style={{ width: sw, height: photoH }} />
              </Pressable>
            ) : (
              <Text style={{ fontFamily: fonts.regular, fontSize: sw * TYPE.body, color: colors.subtle }}>Sem imagem de referência</Text>
            )}
          </View>
        ))}
      </ScrollView>

      <View style={{ position: 'absolute', left: sw * 0.04, right: sw * 0.04, top: insets.top + sw * 0.03, flexDirection: 'row', justifyContent: 'space-between' }}>
        <Pressable onPress={onClose} accessibilityRole="button" style={pill}>
          <Text style={{ fontFamily: fonts.bold, fontSize: sw * TYPE.body, color: colors.onDark }}>‹ Voltar</Text>
        </Pressable>
        {s.covers.length > 1 && (
          <View style={pill}>
            <Text style={{ fontFamily: fonts.bold, fontSize: sw * TYPE.caption, color: colors.onDark }}>{`${page + 1}/${s.covers.length}`}</Text>
          </View>
        )}
      </View>

      {s.covers.length > 1 && s.covers.length <= 8 && (
        <View style={{ position: 'absolute', left: 0, right: 0, top: photoH - sw * RADIUS.sheet - sw * 0.05, flexDirection: 'row', justifyContent: 'center', gap: sw * 0.016 }}>
          {s.covers.map((c, i) => (
            <View key={c} style={{ width: sw * 0.022, height: sw * 0.022, borderRadius: sw * 0.011, backgroundColor: i === page ? '#fff' : 'rgba(255,255,255,0.55)' }} />
          ))}
        </View>
      )}

      <View
        style={{
          position: 'absolute',
          left: 0,
          right: 0,
          bottom: 0,
          height: drawerH,
          backgroundColor: colors.paper,
          borderTopLeftRadius: sw * RADIUS.sheet,
          borderTopRightRadius: sw * RADIUS.sheet,
          paddingTop: sw * 0.045,
          paddingHorizontal: sw * 0.06,
          paddingBottom: insets.bottom + sw * 0.03,
        }}
      >
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: sw * 0.03 }}>
          <View style={{ minWidth: sw * 0.09, height: sw * 0.09, borderRadius: sw * 0.045, backgroundColor: colors.onLight, alignItems: 'center', justifyContent: 'center', paddingHorizontal: sw * 0.02 }}>
            <Text style={{ fontFamily: fonts.bold, fontSize: sw * TYPE.caption, color: colors.onDark }}>{s.number}</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text numberOfLines={2} style={{ fontFamily: fonts.bold, fontSize: sw * TYPE.title, color: colors.onLight }}>
              {s.info.name || `Cena ${s.number}`}
            </Text>
            <Text style={{ fontFamily: fonts.regular, fontSize: sw * TYPE.caption, color: colors.subtle }}>{SCENE_STATUS[s.status]?.label ?? 'Ideia'}</Text>
          </View>
          <Pressable onPress={() => onEdit(s.subId)} hitSlop={16} accessibilityRole="button">
            <Text style={{ fontFamily: fonts.bold, fontSize: sw * TYPE.body, color: colors.red }}>Editar</Text>
          </Pressable>
        </View>

        <ScrollView style={{ flex: 1, marginTop: sw * 0.03 }} showsVerticalScrollIndicator={false} contentContainerStyle={{ gap: sw * 0.035, paddingBottom: sw * 0.03 }}>
          {rows.map((f) => (
            <View key={f.key}>
              <Text style={{ fontFamily: fonts.regular, fontSize: sw * TYPE.caption, color: colors.subtle }}>{f.label}</Text>
              <Text style={{ fontFamily: fonts.bold, fontSize: sw * TYPE.body, color: s.info[f.key] ? colors.onLight : colors.subtle, marginTop: 2 }}>
                {s.info[f.key] || '—'}
              </Text>
            </View>
          ))}
        </ScrollView>

        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingTop: sw * 0.02 }}>
          <Pressable onPress={() => go(-1)} disabled={idx === 0} accessibilityRole="button" accessibilityLabel="Cena anterior" style={circle(false, idx === 0)}>
            <Text style={{ fontFamily: fonts.bold, fontSize: sw * 0.07, color: colors.onLight }}>‹</Text>
          </Pressable>
          <Text style={{ fontFamily: fonts.bold, fontSize: sw * TYPE.body, color: colors.onLight }}>{`${idx + 1} / ${scenes.length}`}</Text>
          <Pressable onPress={() => go(1)} disabled={idx === scenes.length - 1} accessibilityRole="button" accessibilityLabel="Próxima cena" style={circle(true, idx === scenes.length - 1)}>
            <Text style={{ fontFamily: fonts.bold, fontSize: sw * 0.07, color: colors.onDark }}>›</Text>
          </Pressable>
        </View>
      </View>
      {viewer ? <ImageViewer uri={viewer} onClose={() => setViewer(null)} /> : null}
    </View>
  );
}
