/**
 * Sincroniza o texto e as imagens entre a nota corrida (`html`) e o layout livre (`free`).
 * Cada lado guarda uma "foto" do que valia na última sincronização (`free.sync`). Ao trocar de
 * layout, só o que mudou no lado editado (linhas e imagens) é levado ao outro, então a
 * diagramação (posições, tamanhos, formatação) do lado de destino é preservada.
 */
import { Free, Frame, appendTextFrames } from './freeLayout';
import { htmlToText } from './note';

const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const BLOCK = /<(p|h[1-6]|li|blockquote)\b[^>]*>([\s\S]*?)<\/\1>/gi;
const IMG = /<img\b[^>]*\bsrc="([^"]+)"[^>]*>/gi;

export type Sync = { fl: string[]; fi: string[]; rl: string[]; ri: string[]; t: string };

/** Linhas de texto da nota corrida, uma por bloco (parágrafo, título, item, citação). */
export function flowLines(html: string): string[] {
  const out: string[] = [];
  for (const m of html.matchAll(BLOCK)) {
    const t = htmlToText(m[2]).replace(/\s+/g, ' ').trim();
    if (t) out.push(t);
  }
  return out;
}
export const flowImgs = (html: string): string[] => [...html.matchAll(IMG)].map((m) => m[1]);

const reading = (a: Frame, b: Frame) => a.y - b.y || a.x - b.x;
const textFrames = (free: Free) => free.frames.filter((f) => f.t === 'text').sort(reading);

export function freeLines(free: Free): string[] {
  const out: string[] = [];
  for (const f of textFrames(free)) for (const l of (f.txt ?? '').split('\n')) if (l.trim()) out.push(l.replace(/\s+/g, ' ').trim());
  return out;
}
export const freeImgs = (free: Free): string[] => free.frames.filter((f) => f.t === 'image' && f.src).map((f) => f.src as string);

export const makeSync = (html: string, title: string, free: Free): Sync => ({
  fl: flowLines(html),
  fi: flowImgs(html),
  rl: freeLines(free),
  ri: freeImgs(free),
  t: title,
});

type Hunk = { at: number; del: string[]; add: string[]; prev: string | null };

/** Diferença por LCS entre duas listas de linhas. */
function diff(a: string[], b: string[]): Hunk[] {
  const n = a.length;
  const m = b.length;
  const L: number[][] = Array.from({ length: n + 1 }, () => new Array(m + 1).fill(0));
  for (let i = n - 1; i >= 0; i--) for (let j = m - 1; j >= 0; j--) L[i][j] = a[i] === b[j] ? L[i + 1][j + 1] + 1 : Math.max(L[i + 1][j], L[i][j + 1]);
  const hunks: Hunk[] = [];
  let i = 0;
  let j = 0;
  let cur: Hunk | null = null;
  const close = () => {
    if (cur) hunks.push(cur);
    cur = null;
  };
  while (i < n || j < m) {
    if (i < n && j < m && a[i] === b[j]) {
      close();
      i++;
      j++;
      continue;
    }
    if (!cur) cur = { at: i, del: [], add: [], prev: i > 0 ? a[i - 1] : null };
    if (j < m && (i >= n || L[i][j + 1] >= L[i + 1][j])) cur.add.push(b[j++]);
    else cur.del.push(a[i++]);
  }
  close();
  return hunks;
}

const newId = () => `f${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;

/** Leva ao layout livre o que mudou na nota corrida desde a última sincronização. */
export function flowToFree(free: Free, html: string, title: string): Free {
  const s = free.sync;
  if (!s) return { ...free, sync: makeSync(html, title, free) };
  const curLines = flowLines(html);
  const curImgs = flowImgs(html);
  let frames: Frame[] = free.frames.map((f) => ({ ...f }));
  const tf = () => frames.filter((f) => f.t === 'text').sort(reading);
  const extra: string[] = [];

  // título
  if (s.t !== title && title.trim()) {
    const h = tf().find((f) => (f.txt ?? '').split('\n')[0].trim() === s.t.trim());
    if (h && s.t.trim()) h.txt = [title.trim(), ...(h.txt ?? '').split('\n').slice(1)].join('\n');
  }

  for (const h of diff(s.fl, curLines)) {
    const find = (text: string): { f: Frame; li: number } | null => {
      for (const f of tf()) {
        const ls = (f.txt ?? '').split('\n');
        const li = ls.findIndex((l) => l.replace(/\s+/g, ' ').trim() === text);
        if (li >= 0) return { f, li };
      }
      return null;
    };
    const pairs = Math.min(h.del.length, h.add.length);
    let last: string | null = h.prev;
    for (let k = 0; k < h.del.length; k++) {
      const hit = find(h.del[k]);
      if (!hit) {
        if (k < pairs) extra.push(h.add[k]);
        continue;
      }
      const ls = (hit.f.txt ?? '').split('\n');
      if (k < pairs) {
        ls[hit.li] = h.add[k];
        last = h.add[k];
      } else ls.splice(hit.li, 1);
      hit.f.txt = ls.join('\n');
    }
    const rest = h.add.slice(pairs);
    if (rest.length) {
      const anchor = last ? find(last) : null;
      if (anchor) {
        const ls = (anchor.f.txt ?? '').split('\n');
        ls.splice(anchor.li + 1, 0, ...rest);
        anchor.f.txt = ls.join('\n');
      } else extra.push(...rest);
    }
  }
  frames = frames.filter((f) => f.t !== 'text' || (f.txt ?? '').trim() || f.role === undefined);
  let out: Free = { ...free, frames };

  if (extra.length) out = appendTextFrames(out, [{ text: extra.join('\n') }]);

  // imagens
  const gone = s.fi.filter((x) => !curImgs.includes(x));
  const fresh = curImgs.filter((x) => !s.fi.includes(x));
  out = { ...out, frames: out.frames.filter((f) => !(f.t === 'image' && f.src && gone.includes(f.src))) };
  if (fresh.length) {
    let y = Math.max(0, ...out.frames.map((f) => f.y + f.h)) + 40;
    const add: Frame[] = fresh.map((src) => {
      const fr: Frame = { id: newId(), t: 'image', x: 80, y, w: 840, h: 560, src, fit: 'cover', rad: 0 };
      y += 600;
      return fr;
    });
    out = { ...out, frames: [...out.frames, ...add], h: Math.max(out.h, y + 80) };
  }
  return { ...out, sync: makeSync(html, title, out) };
}

/** Leva à nota corrida o que mudou no layout livre desde a última sincronização. */
export function freeToFlow(free: Free, html: string, title: string): { html: string; title: string; free: Free } {
  const s = free.sync;
  if (!s) return { html, title, free: { ...free, sync: makeSync(html, title, free) } };
  let out = html;
  const cur = freeLines(free);

  // título: a primeira linha do título da página
  let newTitle = title;
  const hd = textFrames(free).find((f) => f.role === 'h') ?? null;
  if (hd) {
    const first = (hd.txt ?? '').split('\n')[0].trim();
    if (first && s.rl[0] !== undefined && s.rl.includes(title.trim()) && first !== title.trim() && !cur.includes(title.trim())) newTitle = first;
  }

  for (const h of diff(s.rl, cur)) {
    const blocks = () => [...out.matchAll(BLOCK)].map((m) => ({ m, text: htmlToText(m[2]).replace(/\s+/g, ' ').trim() }));
    const pairs = Math.min(h.del.length, h.add.length);
    const find = (text: string) => blocks().find((x) => x.text === text);
    const tail: string[] = [];
    let last: string | null = h.prev;
    for (let k = 0; k < h.del.length; k++) {
      const b = find(h.del[k]);
      if (!b) {
        if (k < pairs) tail.push(h.add[k]);
        continue;
      }
      const start = b.m.index ?? 0;
      const whole = b.m[0];
      const tag = b.m[1].toLowerCase();
      const open = whole.slice(0, whole.indexOf('>') + 1);
      const repl = k < pairs ? `${open}${esc(h.add[k])}</${tag}>` : '';
      if (k < pairs) last = h.add[k];
      out = out.slice(0, start) + repl + out.slice(start + whole.length);
    }
    const rest = h.add.slice(pairs);
    if (rest.length) {
      const anchor = last ? find(last) : null;
      const html2 = rest.map((t) => `<p>${esc(t)}</p>`).join('');
      if (anchor) {
        const end = (anchor.m.index ?? 0) + anchor.m[0].length;
        out = out.slice(0, end) + html2 + out.slice(end);
      } else tail.push(...rest);
    }
    if (tail.length) out += tail.map((t) => `<p>${esc(t)}</p>`).join('');
  }

  // imagens
  const curImgs = freeImgs(free);
  const gone = s.ri.filter((x) => !curImgs.includes(x));
  const fresh = curImgs.filter((x) => !s.ri.includes(x));
  for (const g of gone) out = out.replace(new RegExp(`<img\\b[^>]*\\bsrc="${g.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}"[^>]*>`, 'gi'), '');
  for (const src of fresh) out += `<p><img src="${src.replace(/"/g, '&quot;')}"></p>`;

  return { html: out, title: newTitle, free: { ...free, sync: makeSync(out, newTitle, free) } };
}
