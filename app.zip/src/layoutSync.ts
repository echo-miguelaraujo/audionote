/**
 * Sincroniza o texto e as imagens entre a nota corrida (`html`) e o layout livre (`free`).
 * Cada lado guarda uma "foto" do que valia na última sincronização (`free.sync`). Ao trocar de
 * layout, só o que mudou no lado editado (linhas e imagens) é levado ao outro, então a
 * diagramação (posições, tamanhos, formatação) do lado de destino é preservada.
 */
import { Free, Frame, appendTextFrames, adjustLks, fitY, frameLkKeys, lkKey, lkSegments, safeUrl } from './freeLayout';
import { htmlToText } from './note';

const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const BLOCK = /<(p|h[1-6]|li|blockquote)\b[^>]*>([\s\S]*?)<\/\1>/gi;
const IMG = /<img\b[^>]*\bsrc="([^"]+)"[^>]*>/gi;
const CARD = /<a\b[^>]*class="[^"]*\blkcard\b[^"]*"[^>]*>[\s\S]*?<\/a>/gi;
const stripCards = (html: string) => html.replace(CARD, '');
const unesc = (s: string) => s.replace(/&quot;/g, '"').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
const attr = (tag: string, name: string) => {
  const m = new RegExp(`\\b${name}="([^"]*)"`, 'i').exec(tag);
  return m ? unesc(m[1]) : '';
};
const spanOf = (card: string, cls: string) => {
  const m = new RegExp(`<span class="${cls}">([\\s\\S]*?)</span>`, 'i').exec(card);
  return m ? unesc(htmlToText(m[1])) : '';
};
/** Cards de link da nota corrida, com a prévia que já carregaram. */
const flowCards = (html: string) =>
  [...html.matchAll(CARD)].map((m) => {
    const tag = m[0].slice(0, m[0].indexOf('>') + 1);
    const img = /<img\b[^>]*\bsrc="([^"]+)"/i.exec(m[0]);
    return { url: attr(tag, 'href'), state: attr(tag, 'data-state'), title: spanOf(m[0], 'lk-t'), desc: spanOf(m[0], 'lk-d'), site: spanOf(m[0], 'lk-s'), img: img ? unesc(img[1]) : '' };
  });

export type Sync = { fl: string[]; fi: string[]; rl: string[]; ri: string[]; t: string; fk?: string[]; rk?: string[] };

/** Linhas de texto da nota corrida, uma por bloco (parágrafo, título, item, citação). */
export function flowLines(html: string): string[] {
  const out: string[] = [];
  for (const m of stripCards(html).matchAll(BLOCK)) {
    const t = htmlToText(m[2]).replace(/\s+/g, ' ').trim();
    if (t) out.push(t);
  }
  return out;
}
/** Imagens e links (como `lk:<url>`) da nota corrida. A capa dentro de um card não é imagem da nota. */
export const flowImgs = (html: string): string[] => [
  ...[...stripCards(html).matchAll(IMG)].map((m) => m[1]),
  ...flowCards(html).filter((c) => c.url).map((c) => `lk:${c.url}`),
];

const reading = (a: Frame, b: Frame) => a.y - b.y || a.x - b.x;
const textFrames = (free: Free) => free.frames.filter((f) => f.t === 'text').sort(reading);

export function freeLines(free: Free): string[] {
  const out: string[] = [];
  for (const f of textFrames(free)) for (const l of (f.txt ?? '').split('\n')) if (l.trim()) out.push(l.replace(/\s+/g, ' ').trim());
  return out;
}
export const freeImgs = (free: Free): string[] => [
  ...free.frames.filter((f) => f.t === 'image' && f.src).map((f) => f.src as string),
  ...free.frames.filter((f) => f.t === 'link' && f.url).map((f) => `lk:${f.url}`),
];

const ANCHOR = /<a\b(?![^>]*\blkcard\b)([^>]*)>([\s\S]*?)<\/a>/gi;
/** Links no meio do texto da nota corrida (fora dos cards): chave = trecho + endereço. */
export const flowLinkKeys = (html: string): string[] =>
  [...html.matchAll(ANCHOR)]
    .map((m) => {
      const url = safeUrl(attr(`<a ${m[1]}>`, 'href'));
      const t = unesc(htmlToText(m[2]));
      return url && t.trim() ? lkKey(t, url) : '';
    })
    .filter(Boolean);
export const freeLinkKeys = (free: Free): string[] => textFrames(free).flatMap(frameLkKeys);

export const makeSync = (html: string, title: string, free: Free): Sync => ({
  fl: flowLines(html),
  fi: flowImgs(html),
  rl: freeLines(free),
  ri: freeImgs(free),
  t: title,
  fk: flowLinkKeys(html),
  rk: freeLinkKeys(free),
});

/** a − b como multiconjunto (respeita repetições). */
function minus(a: string[], b: string[]): string[] {
  const left = [...b];
  const out: string[] = [];
  for (const x of a) {
    const i = left.indexOf(x);
    if (i >= 0) left.splice(i, 1);
    else out.push(x);
  }
  return out;
}

/** HTML de uma linha do livre, com os links do trecho como <a href>. `from` = posição da linha em `txt`. */
function richLine(f: Frame, from: number, line: string): string {
  const to = from + line.length;
  const part = (f.lks ?? []).filter((l) => l.e > from && l.s < to).map((l) => ({ s: Math.max(l.s, from) - from, e: Math.min(l.e, to) - from, url: l.url }));
  return lkSegments(line, part)
    .map((g) => (g.url ? `<a href="${g.url.replace(/&/g, '&amp;').replace(/"/g, '&quot;')}">${esc(g.t)}</a>` : esc(g.t)))
    .join('');
}
/** Mapa linha normalizada → HTML com links, para as linhas do livre que têm link. */
function richMap(free: Free): Map<string, string> {
  const m = new Map<string, string>();
  for (const f of textFrames(free)) {
    if (!f.lks?.length) continue;
    let at = 0;
    for (const l of (f.txt ?? '').split('\n')) {
      const key = l.replace(/\s+/g, ' ').trim();
      if (key && !m.has(key)) m.set(key, richLine(f, at, l));
      at += l.length + 1;
    }
  }
  return m;
}

/** Envolve com <a> a primeira ocorrência do trecho que ainda não é link (só em texto, nunca dentro de tag). */
function wrapInHtml(html: string, text: string, url: string): string | null {
  const needle = esc(text.replace(/\s+/g, ' ').trim());
  const href = url.replace(/&/g, '&amp;').replace(/"/g, '&quot;');
  for (const b of html.matchAll(BLOCK)) {
    const inner = b[2];
    let depth = 0;
    const toks = inner.split(/(<[^>]+>)/);
    for (let i = 0; i < toks.length; i++) {
      const tk = toks[i];
      if (tk.startsWith('<')) {
        if (/^<a\b/i.test(tk)) depth++;
        else if (/^<\/a>/i.test(tk)) depth = Math.max(0, depth - 1);
        continue;
      }
      const at = depth === 0 ? tk.indexOf(needle) : -1;
      if (at < 0) continue;
      toks[i] = tk.slice(0, at) + `<a href="${href}">${needle}</a>` + tk.slice(at + needle.length);
      const start = (b.index ?? 0) + b[0].indexOf(inner);
      return html.slice(0, start) + toks.join('') + html.slice(start + inner.length);
    }
  }
  return null;
}
/** Tira o link (mantém o texto) da primeira âncora com esse trecho e endereço. */
function unwrapInHtml(html: string, key: string): string {
  let done = false;
  return html.replace(ANCHOR, (all, a, inner) => {
    if (done) return all;
    const url = safeUrl(attr(`<a ${a}>`, 'href'));
    if (lkKey(unesc(htmlToText(inner)), url) !== key) return all;
    done = true;
    return inner;
  });
}

type Hunk = { at: number; del: string[]; add: string[]; prev: string | null };

/** Diferença por LCS entre duas listas de linhas. */
function diff(a: string[], b: string[]): Hunk[] {
  const n = a.length;
  const m = b.length;
  const L: number[][] = Array.from({ length: n + 1 }, () => new Array(m + 1).fill(0));
  for (let i = n - 1; i >= 0; i--) for (let j = m - 1; j >= 0; j--) L[i][j] = a[i] === b[j] ? L[i + 1][j + 1] + 1 : Math.max(L[i + 1][j], L[i][j + 1]);
  const hunks: Hunk[] = [];
  let i = 0;
  let j = 0;
  let cur: Hunk | null = null;
  const close = () => {
    if (cur) hunks.push(cur);
    cur = null;
  };
  while (i < n || j < m) {
    if (i < n && j < m && a[i] === b[j]) {
      close();
      i++;
      j++;
      continue;
    }
    if (!cur) cur = { at: i, del: [], add: [], prev: i > 0 ? a[i - 1] : null };
    if (j < m && (i >= n || L[i][j + 1] >= L[i + 1][j])) cur.add.push(b[j++]);
    else cur.del.push(a[i++]);
  }
  close();
  return hunks;
}

const newId = () => `f${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;

/** Leva ao layout livre o que mudou na nota corrida desde a última sincronização. */
export function flowToFree(free: Free, html: string, title: string): Free {
  const s = free.sync;
  if (!s) return { ...free, sync: makeSync(html, title, free) };
  const curLines = flowLines(html);
  const curImgs = flowImgs(html);
  let frames: Frame[] = free.frames.map((f) => ({ ...f }));
  const tf = () => frames.filter((f) => f.t === 'text').sort(reading);
  const extra: string[] = [];
  // cada vez que o texto de uma caixa muda, os links dela acompanham
  const before = new Map<string, string>(frames.filter((f) => f.t === 'text').map((f) => [f.id, f.txt ?? '']));

  // título
  if (s.t !== title && title.trim()) {
    const h = tf().find((f) => (f.txt ?? '').split('\n')[0].trim() === s.t.trim());
    if (h && s.t.trim()) h.txt = [title.trim(), ...(h.txt ?? '').split('\n').slice(1)].join('\n');
  }

  for (const h of diff(s.fl, curLines)) {
    const find = (text: string): { f: Frame; li: number } | null => {
      for (const f of tf()) {
        const ls = (f.txt ?? '').split('\n');
        const li = ls.findIndex((l) => l.replace(/\s+/g, ' ').trim() === text);
        if (li >= 0) return { f, li };
      }
      return null;
    };
    const pairs = Math.min(h.del.length, h.add.length);
    let last: string | null = h.prev;
    for (let k = 0; k < h.del.length; k++) {
      const hit = find(h.del[k]);
      if (!hit) {
        if (k < pairs) extra.push(h.add[k]);
        continue;
      }
      const ls = (hit.f.txt ?? '').split('\n');
      if (k < pairs) {
        ls[hit.li] = h.add[k];
        last = h.add[k];
      } else ls.splice(hit.li, 1);
      hit.f.txt = ls.join('\n');
    }
    const rest = h.add.slice(pairs);
    if (rest.length) {
      const anchor = last ? find(last) : null;
      if (anchor) {
        const ls = (anchor.f.txt ?? '').split('\n');
        ls.splice(anchor.li + 1, 0, ...rest);
        anchor.f.txt = ls.join('\n');
      } else extra.push(...rest);
    }
  }
  for (const f of frames) {
    if (f.t !== 'text' || !f.lks) continue;
    const l = adjustLks(f.lks, before.get(f.id) ?? '', f.txt ?? '');
    if (l && l.length) f.lks = l;
    else delete f.lks;
  }
  frames = frames.filter((f) => f.t !== 'text' || (f.txt ?? '').trim() || f.role === undefined);
  let out: Free = { ...free, frames };

  if (extra.length) out = appendTextFrames(out, [{ text: extra.join('\n') }]);

  // links no texto: o que apareceu ou sumiu na nota corrida
  if (s.fk) {
    const nowK = flowLinkKeys(html);
    const goneK = minus(s.fk, nowK);
    const freshK = minus(nowK, s.fk);
    if (goneK.length || freshK.length) {
      const fr = out.frames.map((f) => (f.t === 'text' && f.lks ? { ...f, lks: [...f.lks] } : f));
      for (const k of goneK) {
        for (const f of fr) {
          if (f.t !== 'text' || !f.lks) continue;
          const i = f.lks.findIndex((l) => lkKey((f.txt ?? '').slice(l.s, l.e), l.url) === k);
          if (i >= 0) {
            f.lks.splice(i, 1);
            if (!f.lks.length) delete f.lks;
            break;
          }
        }
      }
      for (const k of freshK) {
        const [text, url] = k.split('\u0001');
        let placed = false;
        for (const f of fr.filter((x) => x.t === 'text').sort(reading)) {
          const txt = f.txt ?? '';
          let from = 0;
          while (!placed) {
            const at = txt.indexOf(text, from);
            if (at < 0) break;
            const e = at + text.length;
            if (!(f.lks ?? []).some((l) => l.s < e && l.e > at)) {
              f.lks = [...(f.lks ?? []), { s: at, e, url }].sort((a, b) => a.s - b.s);
              placed = true;
            } else from = at + 1;
          }
          if (placed) break;
        }
      }
      out = { ...out, frames: fr };
    }
  }

  // imagens
  const gone = s.fi.filter((x) => !curImgs.includes(x));
  const fresh = curImgs.filter((x) => !s.fi.includes(x));
  out = { ...out, frames: out.frames.filter((f) => !(f.t === 'image' && f.src && gone.includes(f.src)) && !(f.t === 'link' && f.url && gone.includes(`lk:${f.url}`))) };
  if (fresh.length) {
    let y = Math.max(0, ...out.frames.map((f) => f.y + f.h)) + 40;
    const cards = flowCards(html);
    const add: Frame[] = fresh.map((src) => {
      if (src.startsWith('lk:')) {
        const url = src.slice(3);
        y = fitY(out, y, 420);
        const c = cards.find((x) => x.url === url);
        const fr: Frame = { id: newId(), t: 'link', x: 80, y, w: 840, h: 420, url, rad: 24, lst: c?.state === 'ok' ? 'ok' : c?.state === 'fail' ? 'fail' : 'loading' };
        if (c?.title) fr.lt = c.title;
        if (c?.desc) fr.ld = c.desc;
        if (c?.site) fr.lsite = c.site;
        if (c?.img) fr.src = c.img;
        y += 460;
        return fr;
      }
      y = fitY(out, y, 560);
      const fr: Frame = { id: newId(), t: 'image', x: 80, y, w: 840, h: 560, src, fit: 'cover', rad: 0 };
      y += 600;
      return fr;
    });
    out = { ...out, frames: [...out.frames, ...add], h: Math.max(out.h, y + 80) };
  }
  return { ...out, sync: makeSync(html, title, out) };
}

/** Leva à nota corrida o que mudou no layout livre desde a última sincronização. */
export function freeToFlow(free: Free, html: string, title: string): { html: string; title: string; free: Free } {
  const s = free.sync;
  if (!s) return { html, title, free: { ...free, sync: makeSync(html, title, free) } };
  let out = html;
  const cur = freeLines(free);
  const rich = richMap(free);
  const para = (t: string) => rich.get(t) ?? esc(t);

  // título: a primeira linha do título da página
  let newTitle = title;
  const hd = textFrames(free).find((f) => f.role === 'h') ?? null;
  if (hd) {
    const first = (hd.txt ?? '').split('\n')[0].trim();
    if (first && s.rl[0] !== undefined && s.rl.includes(title.trim()) && first !== title.trim() && !cur.includes(title.trim())) newTitle = first;
  }

  for (const h of diff(s.rl, cur)) {
    const blocks = () => [...out.matchAll(BLOCK)].map((m) => ({ m, text: htmlToText(m[2]).replace(/\s+/g, ' ').trim() }));
    const pairs = Math.min(h.del.length, h.add.length);
    const find = (text: string) => blocks().find((x) => x.text === text);
    const tail: string[] = [];
    let last: string | null = h.prev;
    for (let k = 0; k < h.del.length; k++) {
      const b = find(h.del[k]);
      if (!b) {
        if (k < pairs) tail.push(h.add[k]);
        continue;
      }
      const start = b.m.index ?? 0;
      const whole = b.m[0];
      const tag = b.m[1].toLowerCase();
      const open = whole.slice(0, whole.indexOf('>') + 1);
      const repl = k < pairs ? `${open}${para(h.add[k])}</${tag}>` : '';
      if (k < pairs) last = h.add[k];
      out = out.slice(0, start) + repl + out.slice(start + whole.length);
    }
    const rest = h.add.slice(pairs);
    if (rest.length) {
      const anchor = last ? find(last) : null;
      const html2 = rest.map((t) => `<p>${para(t)}</p>`).join('');
      if (anchor) {
        const end = (anchor.m.index ?? 0) + anchor.m[0].length;
        out = out.slice(0, end) + html2 + out.slice(end);
      } else tail.push(...rest);
    }
    if (tail.length) out += tail.map((t) => `<p>${para(t)}</p>`).join('');
  }

  // links no texto: o que apareceu ou sumiu no livre
  if (s.rk) {
    const nowK = freeLinkKeys(free);
    for (const k of minus(s.rk, nowK)) out = unwrapInHtml(out, k);
    const have = flowLinkKeys(out);
    for (const k of minus(nowK, s.rk)) {
      if (have.includes(k)) {
        have.splice(have.indexOf(k), 1);
        continue;
      }
      const [text, url] = k.split('\u0001');
      out = wrapInHtml(out, text, url) ?? out;
    }
  }

  // imagens
  const curImgs = freeImgs(free);
  const gone = s.ri.filter((x) => !curImgs.includes(x));
  const fresh = curImgs.filter((x) => !s.ri.includes(x));
  const re = (x: string) => x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const q = (x: string) => x.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
  for (const g of gone) {
    if (g.startsWith('lk:')) {
      out = out.replace(CARD, (c) => (attr(c.slice(0, c.indexOf('>') + 1), 'href') === g.slice(3) ? '' : c));
      out = out.replace(/<p>\s*<\/p>/gi, '');
    } else out = out.replace(new RegExp(`<img\\b[^>]*\\bsrc="${re(q(g))}"[^>]*>`, 'gi'), '');
  }
  for (const src of fresh) {
    if (!src.startsWith('lk:')) {
      out += `<p><img src="${q(src)}"></p>`;
      continue;
    }
    const f = free.frames.find((x) => x.t === 'link' && x.url === src.slice(3));
    if (!f?.url) continue;
    const sq = !!f.src && (f.ar ?? 0) > 0.85 && (f.ar ?? 0) < 1.2;
    out +=
      `<p><a class="lkcard${sq ? ' sq' : ''}" contenteditable="false" href="${q(f.url)}" data-lid="${q(f.id)}" data-state="${f.lst ?? 'loading'}">` +
      (f.src ? `<img src="${q(f.src)}" alt="">` : '') +
      `<span class="lk-b"><span class="lk-t">${esc(f.lt || f.url)}</span>` +
      (f.ld ? `<span class="lk-d">${esc(f.ld)}</span>` : '') +
      `<span class="lk-s">${esc(f.lsite || f.url)}</span></span></a></p>`;
  }

  return { html: out, title: newTitle, free: { ...free, sync: makeSync(out, newTitle, free) } };
}
