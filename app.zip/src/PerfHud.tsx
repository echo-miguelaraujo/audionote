import React, { useEffect, useRef, useState } from 'react';
import { Pressable, Text, View, useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { BUILD_TAG, perfCount, perfMarks, setPerf, usePerf } from './perf';
import { getSyncState, subscribeSync } from './sync';

/**
 * Painel de diagnóstico (Configurações > Desempenho).
 * - JS fps / pior quadro: se o JavaScript fica parado, o quadro trava.
 * - redesenhos/s e câmera/s: quantas vezes a tela do quadro foi refeita e a câmera movida no último segundo.
 * - sync: se a sincronização está rodando agora.
 * Os botões desligam partes do quadro para descobrir o que pesa.
 */
export function PerfHud({ items, images }: { items: number; images: number }) {
  const { width: sw } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const f = usePerf();
  const [stat, setStat] = useState({ fps: 0, worst: 0, renders: 0, views: 0 });
  const [phase, setPhase] = useState(getSyncState().phase);
  const [stall, setStall] = useState<{ ms: number; names: string } | null>(null);
  const raf = useRef(0);

  useEffect(() => {
    const un = subscribeSync(() => setPhase(getSyncState().phase));
    return un;
  }, []);

  useEffect(() => {
    let last = performance.now();
    let start = last;
    let frames = 0;
    let worst = 0;
    let r0 = perfCount.render;
    let v0 = perfCount.view;
    const loop = (t: number) => {
      frames += 1;
      if (t - last > 1000) {
        const names = Array.from(new Set(perfMarks.filter((m) => m.t > last - 30 && m.t <= t).map((m) => m.name)));
        setStall({ ms: Math.round(t - last), names: names.length ? names.join(', ') : 'nenhuma tarefa marcada' });
      }
      worst = Math.max(worst, t - last);
      last = t;
      if (t - start >= 1000) {
        const sec = (t - start) / 1000;
        setStat({
          fps: Math.round(frames / sec),
          worst: Math.round(worst),
          renders: Math.round((perfCount.render - r0) / sec),
          views: Math.round((perfCount.view - v0) / sec),
        });
        r0 = perfCount.render;
        v0 = perfCount.view;
        start = t;
        frames = 0;
        worst = 0;
      }
      raf.current = requestAnimationFrame(loop);
    };
    raf.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf.current);
  }, []);

  const fs = sw * 0.03;
  const chip = (label: string, on: boolean, onPress: () => void) => (
    <Pressable
      onPress={onPress}
      style={{
        paddingHorizontal: sw * 0.025,
        paddingVertical: sw * 0.012,
        borderRadius: sw * 0.04,
        backgroundColor: on ? '#2E7D32' : '#B71C1C',
        marginTop: sw * 0.008,
      }}
    >
      <Text style={{ color: '#fff', fontSize: fs, fontWeight: '700' }}>{`${label}: ${on ? 'ligado' : 'DESLIGADO'}`}</Text>
    </Pressable>
  );

  return (
    <View
      pointerEvents="box-none"
      style={{ position: 'absolute', top: insets.top + sw * 0.16, right: sw * 0.02, alignItems: 'flex-end', zIndex: 9999, elevation: 30 }}
    >
      <View pointerEvents="none" style={{ backgroundColor: 'rgba(0,0,0,0.8)', borderRadius: sw * 0.03, padding: sw * 0.022 }}>
        <Text style={{ color: stat.fps >= 50 ? '#7CFC9A' : stat.fps >= 30 ? '#FFD54F' : '#FF6B6B', fontSize: fs, fontWeight: '700' }}>
          {`JS ${stat.fps} fps · pior quadro ${stat.worst} ms`}
        </Text>
        <Text style={{ color: '#fff', fontSize: fs }}>{`${stat.renders} redesenhos/s · câmera ${stat.views}/s`}</Text>
        <Text style={{ color: phase === 'syncing' ? '#FFD54F' : '#fff', fontSize: fs }}>{`sync: ${phase} · ${items} itens · ${images} imagens`}</Text>
        {stall && <Text style={{ color: '#FFB74D', fontSize: fs }}>{`última trava ${stall.ms} ms ← ${stall.names}`}</Text>}
        <Text style={{ color: '#9AA0A6', fontSize: fs * 0.85 }}>{`build ${BUILD_TAG}`}</Text>
      </View>
      {chip('Grade de pontos', f.grid, () => setPerf({ grid: !f.grid }))}
      {chip('Imagens', f.images, () => setPerf({ images: !f.images }))}
      {chip('Cartões e textos', f.cards, () => setPerf({ cards: !f.cards }))}
      {chip('Sombras dos cartões', f.shadows, () => setPerf({ shadows: !f.shadows }))}
      {chip('Sincronização', f.sync, () => setPerf({ sync: !f.sync }))}
      {chip('Tarefas de fundo', f.bg, () => setPerf({ bg: !f.bg }))}
    </View>
  );
}
