import React, { useEffect, useRef, useState } from 'react';
import { Pressable, Text, View, useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { setPerf, usePerf } from './perf';

/**
 * Painel de diagnóstico (Configurações > Desempenho). Mostra quadros por segundo do JavaScript e o pior
 * "engasgo" do último segundo, e deixa desligar a grade de pontos e as imagens para ver o que pesa.
 * Se o FPS do JS está alto mas a tela trava, o gargalo é o desenho (GPU); se cai, é o JavaScript.
 */
export function PerfHud({ items, images }: { items: number; images: number }) {
  const { width: sw } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const f = usePerf();
  const [stat, setStat] = useState({ fps: 0, worst: 0 });
  const raf = useRef(0);

  useEffect(() => {
    let last = performance.now();
    let start = last;
    let frames = 0;
    let worst = 0;
    const loop = (t: number) => {
      frames += 1;
      worst = Math.max(worst, t - last);
      last = t;
      if (t - start >= 1000) {
        setStat({ fps: Math.round((frames * 1000) / (t - start)), worst: Math.round(worst) });
        start = t;
        frames = 0;
        worst = 0;
      }
      raf.current = requestAnimationFrame(loop);
    };
    raf.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf.current);
  }, []);

  const fs = sw * 0.032;
  const chip = (label: string, on: boolean, onPress: () => void) => (
    <Pressable
      onPress={onPress}
      style={{
        paddingHorizontal: sw * 0.025,
        paddingVertical: sw * 0.015,
        borderRadius: sw * 0.04,
        backgroundColor: on ? '#2E7D32' : '#B71C1C',
        marginTop: sw * 0.01,
      }}
    >
      <Text style={{ color: '#fff', fontSize: fs, fontWeight: '700' }}>{`${label}: ${on ? 'ligado' : 'DESLIGADO'}`}</Text>
    </Pressable>
  );

  return (
    <View
      pointerEvents="box-none"
      style={{ position: 'absolute', top: insets.top + sw * 0.16, right: sw * 0.02, alignItems: 'flex-end', zIndex: 9999, elevation: 30 }}
    >
      <View pointerEvents="none" style={{ backgroundColor: 'rgba(0,0,0,0.78)', borderRadius: sw * 0.03, padding: sw * 0.025 }}>
        <Text style={{ color: stat.fps >= 50 ? '#7CFC9A' : stat.fps >= 30 ? '#FFD54F' : '#FF6B6B', fontSize: fs, fontWeight: '700' }}>
          {`JS ${stat.fps} fps · pior quadro ${stat.worst} ms`}
        </Text>
        <Text style={{ color: '#fff', fontSize: fs }}>{`${items} itens · ${images} imagens/vídeos`}</Text>
      </View>
      {chip('Grade de pontos', f.grid, () => setPerf({ grid: !f.grid }))}
      {chip('Imagens', f.images, () => setPerf({ images: !f.images }))}
    </View>
  );
}
