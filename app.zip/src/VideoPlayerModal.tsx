import React, { useEffect, useState } from 'react';
import { Modal, Pressable, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { VideoView, useVideoPlayer } from 'expo-video';
import { Icon } from './Icon';
import { mediaUri } from './media';
import { colors, fonts, HIT } from './theme';

type Props = {
  /** Nome do arquivo em media ou endereço http(s). null = fechado. */
  src: string | null;
  caption?: string | null;
  onClose: () => void;
};

function Player({ src, caption, onClose }: { src: string; caption?: string | null; onClose: () => void }) {
  const { width: sw, height: sh } = useWindowDimensions();
  const u = Math.min(sw, sh);
  const insets = useSafeAreaInsets();
  const [failed, setFailed] = useState(false);
  const player = useVideoPlayer({ uri: mediaUri(src) }, (p) => {
    p.loop = true;
    p.play();
  });

  useEffect(() => {
    const sub = player.addListener('statusChange', ({ status }) => {
      if (status === 'error') setFailed(true);
    });
    return () => sub.remove();
  }, [player]);

  return (
    <View style={styles.root}>
      <StatusBar style="light" />
      <VideoView
        player={player}
        style={StyleSheet.absoluteFill}
        contentFit="contain"
        nativeControls
        allowsFullscreen={false}
      />
      {failed && (
        <View pointerEvents="none" style={[StyleSheet.absoluteFill, { alignItems: 'center', justifyContent: 'center', padding: u * 0.08 }]}>
          <Text style={{ color: colors.onDark, fontFamily: fonts.regular, fontSize: u * 0.045, textAlign: 'center' }}>
            Não consegui tocar este vídeo. Se for da web, o endereço pode ter expirado: use "Baixar para o aparelho" quando ele ainda funcionar.
          </Text>
        </View>
      )}
      <Pressable
        onPress={onClose}
        hitSlop={HIT.md}
        accessibilityRole="button"
        accessibilityLabel="Fechar vídeo"
        style={{
          position: 'absolute',
          top: insets.top + u * 0.025,
          right: u * 0.04,
          width: u * 0.11,
          height: u * 0.11,
          borderRadius: u * 0.055,
          backgroundColor: colors.overlayButtonStrong,
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Icon name="close" size={u * 0.055} />
      </Pressable>
      {!!caption && (
        <View pointerEvents="none" style={{ position: 'absolute', left: 0, right: 0, top: insets.top + u * 0.03, paddingLeft: u * 0.05, paddingRight: u * 0.2 }}>
          <Text numberOfLines={2} style={{ color: colors.onDark, fontFamily: fonts.regular, fontSize: u * 0.032 }}>
            {caption}
          </Text>
        </View>
      )}
    </View>
  );
}

/** Tela cheia para assistir a um vídeo do quadro (com controles, em repetição). */
export function VideoPlayerModal({ src, caption, onClose }: Props) {
  return (
    <Modal visible={src !== null} animationType="fade" statusBarTranslucent supportedOrientations={['portrait', 'landscape']} onRequestClose={onClose}>
      {src !== null && <Player key={src} src={src} caption={caption} onClose={onClose} />}
    </Modal>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#000' },
});
