import React, { memo, useEffect, useMemo, useRef, useState } from 'react';
import { Animated, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { colors, fonts } from './theme';

/**
 * Cada bloco do pontilhado tem 2 × 3,2 unidades (50 × 80 passos de pontos, sem emendas visíveis).
 * Blocos pequenos permitem desenhar só os que aparecem na tela quando o quadro é grande.
 */
const BLOCK_W = 2;
const BLOCK_H = 3.2;
/** Abaixo deste zoom os pontos têm poucos pixels de distância e viram mancha: a grade nem é desenhada. */
const MIN_ZOOM_SHOWN = 0.12;

type Cam = { tx: Animated.Value; ty: Animated.Value; z: Animated.Value };
type Range = { c0: number; c1: number; r0: number; r1: number; show: boolean };

const val = (v: Animated.Value): number => (v as any).__getValue?.() ?? 0;

/**
 * Fundo com a grade de pontinhos do moodboard (claro por padrão; `bg` e `dot` trocam as cores).
 * Sem imagem e sem lib extra: cada bloco é um único Text.
 * Com `cam` (câmera do quadro), só os blocos que aparecem na tela (mais uma folga de um bloco) são desenhados;
 * a lista se atualiza durante o gesto, sem refazer a tela do quadro.
 */
export const DotGrid = memo(function DotGrid({
  width,
  height,
  bg = colors.paper,
  dot = colors.inkSoft,
  cam,
}: {
  width?: number;
  height?: number;
  bg?: string;
  dot?: string;
  cam?: Cam;
}) {
  const win = useWindowDimensions();
  const sw = width ?? win.width;
  const sh = height ?? win.height;
  // O espaçamento é sempre relativo ao lado menor da tela (igual em pé e deitado), não à do quadro.
  const unit = Math.min(win.width, win.height);
  const step = unit * 0.04;
  const fontSize = unit * 0.032;
  const bw = BLOCK_W * unit;
  const bh = BLOCK_H * unit;
  const nCols = Math.max(1, Math.ceil(sw / bw));
  const nRows = Math.max(1, Math.ceil(sh / bh));

  const compute = (): Range => {
    if (!cam) return { c0: 0, c1: nCols - 1, r0: 0, r1: nRows - 1, show: true };
    const z = val(cam.z) || 1;
    const x0 = -val(cam.tx) / z;
    const y0 = -val(cam.ty) / z;
    const x1 = x0 + win.width / z;
    const y1 = y0 + win.height / z;
    return {
      c0: Math.max(0, Math.floor(x0 / bw) - 1),
      c1: Math.min(nCols - 1, Math.floor(x1 / bw) + 1),
      r0: Math.max(0, Math.floor(y0 / bh) - 1),
      r1: Math.min(nRows - 1, Math.floor(y1 / bh) + 1),
      show: z >= MIN_ZOOM_SHOWN,
    };
  };

  const [range, setRange] = useState<Range>(compute);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const computeRef = useRef(compute);
  computeRef.current = compute;

  useEffect(() => {
    if (!cam) return;
    const upd = () => {
      timer.current = null;
      const n = computeRef.current();
      setRange((o) => (o.c0 === n.c0 && o.c1 === n.c1 && o.r0 === n.r0 && o.r1 === n.r1 && o.show === n.show ? o : n));
    };
    const poke = () => {
      if (!timer.current) timer.current = setTimeout(upd, 90);
    };
    const ids = [cam.tx.addListener(poke), cam.ty.addListener(poke), cam.z.addListener(poke)];
    upd();
    return () => {
      cam.tx.removeListener(ids[0]);
      cam.ty.removeListener(ids[1]);
      cam.z.removeListener(ids[2]);
      if (timer.current) clearTimeout(timer.current);
      timer.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cam, nCols, nRows, bw, bh, win.width, win.height]);

  const blocks = useMemo(() => {
    const out: { key: string; x: number; y: number; w: number; h: number }[] = [];
    if (!range.show) return out;
    for (let r = range.r0; r <= range.r1; r++) {
      for (let c = range.c0; c <= range.c1; c++) {
        const x = c * bw;
        const y = r * bh;
        out.push({ key: `${c}_${r}`, x, y, w: Math.min(bw, sw - x), h: Math.min(bh, sh - y) });
      }
    }
    return out;
  }, [range, bw, bh, sw, sh]);

  // Um bloco cheio serve de modelo; os da borda só cortam (overflow) o excesso.
  const text = useMemo(() => {
    const cols = Math.ceil(Math.min(bw, sw) / step) + 1;
    const rows = Math.ceil(Math.min(bh, sh) / step) + 1;
    return Array.from({ length: rows }, () => '.'.repeat(cols)).join('\n');
  }, [sw, sh, bw, bh, step]);

  return (
    <View pointerEvents="none" style={[StyleSheet.absoluteFill, { backgroundColor: bg, overflow: 'hidden' }]}>
      {blocks.map((b) => (
        <View key={b.key} style={{ position: 'absolute', left: b.x, top: b.y, width: b.w, height: b.h, overflow: 'hidden' }}>
          <Text
            allowFontScaling={false}
            style={{
              fontFamily: fonts.regular,
              fontSize,
              lineHeight: step,
              letterSpacing: step - fontSize * 0.27,
              color: dot,
              width: (Math.min(bw, sw) + step * 2) * 1.6,
            }}
          >
            {text}
          </Text>
        </View>
      ))}
    </View>
  );
});
