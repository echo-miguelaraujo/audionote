import React, { memo, useMemo } from 'react';
import { StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { fonts } from './theme';

/** Fundo branco com a grade de pontinhos do moodboard. Um único Text, sem imagem e sem lib extra. */
export const DotGrid = memo(function DotGrid() {
  const { width: sw, height: sh } = useWindowDimensions();
  const step = sw * 0.04;
  const fontSize = sw * 0.032;
  const text = useMemo(() => {
    const cols = Math.ceil(sw / step) + 1;
    const rows = Math.ceil(sh / step) + 1;
    return Array.from({ length: rows }, () => '.'.repeat(cols)).join('\n');
  }, [sw, sh, step]);

  return (
    <View pointerEvents="none" style={[StyleSheet.absoluteFill, { backgroundColor: '#FFFFFF', overflow: 'hidden' }]}>
      <Text
        allowFontScaling={false}
        style={{
          fontFamily: fonts.regular,
          fontSize,
          lineHeight: step,
          letterSpacing: step - fontSize * 0.27,
          color: 'rgba(0,0,0,0.55)',
          width: sw * 2,
        }}
      >
        {text}
      </Text>
    </View>
  );
});
