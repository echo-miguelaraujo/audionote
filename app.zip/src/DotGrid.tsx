import React, { memo, useMemo } from 'react';
import { StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { colors, fonts } from './theme';

/** Cada bloco do pontilhado tem 5 × 8 unidades; quadros grandes repetem blocos em vez de um texto gigante. */
const BLOCK_W = 5;
const BLOCK_H = 8;

/**
 * Fundo com a grade de pontinhos do moodboard (claro por padrão; `bg` e `dot` trocam as cores).
 * Sem imagem e sem lib extra: cada bloco é um único Text.
 */
export const DotGrid = memo(function DotGrid({
  width,
  height,
  bg = colors.paper,
  dot = colors.inkSoft,
}: {
  width?: number;
  height?: number;
  bg?: string;
  dot?: string;
}) {
  const win = useWindowDimensions();
  const sw = width ?? win.width;
  const sh = height ?? win.height;
  // O espaçamento é sempre relativo ao lado menor da tela (igual em pé e deitado), não à do quadro.
  const unit = Math.min(win.width, win.height);
  const step = unit * 0.04;
  const fontSize = unit * 0.032;
  const bw = BLOCK_W * unit;
  const bh = BLOCK_H * unit;

  const blocks = useMemo(() => {
    const out: { key: string; x: number; y: number; w: number; h: number }[] = [];
    for (let y = 0; y < sh; y += bh) {
      for (let x = 0; x < sw; x += bw) {
        out.push({ key: `${x}_${y}`, x, y, w: Math.min(bw, sw - x), h: Math.min(bh, sh - y) });
      }
    }
    return out;
  }, [sw, sh, bw, bh]);

  // Um bloco cheio serve de modelo; os da borda só cortam (overflow) o excesso.
  const text = useMemo(() => {
    const cols = Math.ceil(Math.min(bw, sw) / step) + 1;
    const rows = Math.ceil(Math.min(bh, sh) / step) + 1;
    return Array.from({ length: rows }, () => '.'.repeat(cols)).join('\n');
  }, [sw, sh, bw, bh, step]);

  return (
    <View pointerEvents="none" style={[StyleSheet.absoluteFill, { backgroundColor: bg, overflow: 'hidden' }]}>
      {blocks.map((b) => (
        <View key={b.key} style={{ position: 'absolute', left: b.x, top: b.y, width: b.w, height: b.h, overflow: 'hidden' }}>
          <Text
            allowFontScaling={false}
            style={{
              fontFamily: fonts.regular,
              fontSize,
              lineHeight: step,
              letterSpacing: step - fontSize * 0.27,
              color: dot,
              width: (Math.min(bw, sw) + step * 2) * 1.6,
            }}
          >
            {text}
          </Text>
        </View>
      ))}
    </View>
  );
});
