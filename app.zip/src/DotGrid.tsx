import React, { memo, useMemo } from 'react';
import { StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { colors, fonts } from './theme';

/** Fundo branco com a grade de pontinhos do moodboard. Um único Text, sem imagem e sem lib extra. */
export const DotGrid = memo(function DotGrid({ width, height }: { width?: number; height?: number }) {
  const win = useWindowDimensions();
  const sw = width ?? win.width;
  const sh = height ?? win.height;
  // O espaçamento é sempre relativo ao lado menor da tela (igual em pé e deitado), não à do quadro.
  const unit = Math.min(win.width, win.height);
  const step = unit * 0.04;
  const fontSize = unit * 0.032;
  const text = useMemo(() => {
    const cols = Math.ceil(sw / step) + 1;
    const rows = Math.ceil(sh / step) + 1;
    return Array.from({ length: rows }, () => '.'.repeat(cols)).join('\n');
  }, [sw, sh, step]);

  return (
    <View pointerEvents="none" style={[StyleSheet.absoluteFill, { backgroundColor: colors.paper, overflow: 'hidden' }]}>
      <Text
        allowFontScaling={false}
        style={{
          fontFamily: fonts.regular,
          fontSize,
          lineHeight: step,
          letterSpacing: step - fontSize * 0.27,
          color: colors.inkSoft,
          width: (sw + step * 2) * 1.6,
        }}
      >
        {text}
      </Text>
    </View>
  );
});
