import React, { useEffect, useMemo, useState } from 'react';
import { Text, useWindowDimensions } from 'react-native';
import { DialogActions, DialogInput, DialogShell, DialogTitle } from './DialogBase';
import { colors, fonts, SPACE, TYPE } from './theme';

/** Máximo de cenas criadas de uma vez a partir de um texto. */
export const MAX_TEXT_SCENES = 40;
export type TextScene = { name: string; dialogue: string };

function clip(s: string, n: number): string {
  if (s.length <= n) return s;
  const cut = s.slice(0, n);
  const sp = cut.lastIndexOf(' ');
  return `${(sp > n * 0.5 ? cut.slice(0, sp) : cut).trim()}…`;
}

/**
 * Divide um texto em cenas: um trecho por parágrafo (separado por linha em branco) ou, se não houver
 * linhas em branco, uma cena por linha. O trecho vira as Falas; o título é a primeira linha curta
 * ou a primeira frase. Tira numeração do começo ("1.", "Cena 2:", "-").
 */
export function parseScenesText(raw: string): TextScene[] {
  const norm = raw.replace(/\r\n?/g, '\n').trim();
  if (!norm) return [];
  let chunks = norm.split(/\n\s*\n+/).map((c) => c.trim()).filter(Boolean);
  if (chunks.length === 1 && norm.includes('\n')) chunks = norm.split('\n').map((c) => c.trim()).filter(Boolean);
  const out: TextScene[] = [];
  for (const chunk of chunks.slice(0, MAX_TEXT_SCENES)) {
    const text = chunk.replace(/^\s*(cena\s*\d+\s*[:.\-–—)]\s*|[-*•]\s+|\d+\s*[.)\-–]\s+)/i, '').trim();
    if (!text) continue;
    const lines = text.split('\n').map((l) => l.trim()).filter(Boolean);
    if (lines.length > 1 && lines[0].length <= 50) {
      out.push({ name: clip(lines[0].replace(/[:.]$/, ''), 40), dialogue: lines.slice(1).join('\n') });
    } else {
      const m = text.match(/^[^.!?…\n]+[.!?…]?/);
      out.push({ name: clip((m ? m[0] : text).trim() || 'Cena', 40), dialogue: text });
    }
  }
  return out;
}

/** Janela para colar um texto e criar uma cena por parágrafo. */
export function ScenesFromTextDialog({
  visible,
  onCancel,
  onSubmit,
}: {
  visible: boolean;
  onCancel: () => void;
  onSubmit: (scenes: TextScene[]) => void;
}) {
  const { width: sw } = useWindowDimensions();
  const [value, setValue] = useState('');
  useEffect(() => {
    if (visible) setValue('');
  }, [visible]);
  const total = useMemo(() => parseScenesText(value.replace(/\n/g, '\n')).length, [value]);
  const overflow = useMemo(() => {
    const norm = value.replace(/\r\n?/g, '\n').trim();
    if (!norm) return 0;
    let c = norm.split(/\n\s*\n+/).filter((x) => x.trim()).length;
    if (c === 1 && norm.includes('\n')) c = norm.split('\n').filter((x) => x.trim()).length;
    return Math.max(0, c - MAX_TEXT_SCENES);
  }, [value]);
  return (
    <DialogShell visible={visible} onClose={onCancel} keyboard>
      <DialogTitle>Criar cenas de um texto</DialogTitle>
      <Text style={{ color: colors.subtle, fontFamily: fonts.regular, fontSize: sw * TYPE.caption, marginTop: sw * SPACE.sm }}>
        Cole o roteiro. Cada parágrafo (separado por linha em branco) vira uma cena, com o texto nas Falas.
      </Text>
      <DialogInput
        value={value}
        onChangeText={setValue}
        autoFocus
        multiline
        placeholder="Cole ou escreva aqui…"
        textAlignVertical="top"
        style={{ minHeight: sw * 0.4, maxHeight: sw * 0.55 }}
      />
      <Text style={{ color: colors.onLight, fontFamily: fonts.regular, fontSize: sw * TYPE.caption, marginTop: sw * SPACE.sm }}>
        {total === 0 ? 'Nenhuma cena ainda' : total === 1 ? '1 cena será criada' : `${total} cenas serão criadas`}
        {overflow > 0 ? ` (só as ${MAX_TEXT_SCENES} primeiras; ${overflow} ficam de fora)` : ''}
      </Text>
      <DialogActions
        onCancel={onCancel}
        confirmLabel="Criar"
        confirmDisabled={total === 0}
        onConfirm={() => onSubmit(parseScenesText(value))}
      />
    </DialogShell>
  );
}
