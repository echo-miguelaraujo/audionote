import { useEffect, useSyncExternalStore } from 'react';
import { getSetting, setSetting } from './settings';

/**
 * Diagnóstico de desempenho do quadro. `hud` liga o painel (lembrado entre aberturas); `grid` e `images`
 * são interruptores de teste (voltam a ligado ao reabrir o app) para descobrir o que pesa no aparelho.
 */
export type PerfFlags = { hud: boolean; grid: boolean; images: boolean };

const KEY_HUD = 'perf_hud';
let flags: PerfFlags = { hud: false, grid: true, images: true };
let loaded = false;
const subs = new Set<() => void>();

function emit() {
  subs.forEach((s) => s());
}

export function setPerf(p: Partial<PerfFlags>) {
  flags = { ...flags, ...p };
  emit();
  if (p.hud !== undefined) setSetting(KEY_HUD, p.hud ? '1' : '').catch(() => {});
}

export function usePerf(): PerfFlags {
  useEffect(() => {
    if (loaded) return;
    loaded = true;
    getSetting(KEY_HUD)
      .then((v) => {
        if (v === '1' && !flags.hud) {
          flags = { ...flags, hud: true };
          emit();
        }
      })
      .catch(() => {});
  }, []);
  return useSyncExternalStore(
    (cb) => {
      subs.add(cb);
      return () => {
        subs.delete(cb);
      };
    },
    () => flags
  );
}
