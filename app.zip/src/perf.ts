import { useEffect, useSyncExternalStore } from 'react';
import { getSetting, setSetting } from './settings';

/**
 * Diagnóstico de desempenho do quadro. `hud` liga o painel (lembrado entre aberturas); `grid` e `images`
 * são interruptores de teste (voltam a ligado ao reabrir o app) para descobrir o que pesa no aparelho.
 */
export type PerfFlags = { hud: boolean; grid: boolean; images: boolean; cards: boolean; shadows: boolean; sync: boolean; bg: boolean };

/** Contadores lidos pelo painel a cada segundo: redesenhos da tela do quadro e movimentos de câmera. */
export const perfCount = { render: 0, view: 0 };
export const getPerf = (): PerfFlags => flags;

/** Marcas de "tarefa de fundo começou agora": o painel as cruza com cada travada do JS para apontar o que estava rodando. */
export const perfMarks: { name: string; t: number }[] = [];
export function perfMark(name: string) {
  perfMarks.push({ name, t: performance.now() });
  if (perfMarks.length > 60) perfMarks.splice(0, perfMarks.length - 60);
}

/** Etiqueta da versão do código do quadro: aparece no painel para confirmar qual build está rodando. */
export const BUILD_TAG = 'diag-6 (sync espera a tela parada)';

const KEY_HUD = 'perf_hud';
let flags: PerfFlags = { hud: false, grid: true, images: true, cards: true, shadows: true, sync: true, bg: true };
let loaded = false;
const subs = new Set<() => void>();

function emit() {
  subs.forEach((s) => s());
}

export function setPerf(p: Partial<PerfFlags>) {
  flags = { ...flags, ...p };
  emit();
  if (p.hud !== undefined) setSetting(KEY_HUD, p.hud ? '1' : '').catch(() => {});
}

export function usePerf(): PerfFlags {
  useEffect(() => {
    if (loaded) return;
    loaded = true;
    getSetting(KEY_HUD)
      .then((v) => {
        if (v === '1' && !flags.hud) {
          flags = { ...flags, hud: true };
          emit();
        }
      })
      .catch(() => {});
  }, []);
  return useSyncExternalStore(
    (cb) => {
      subs.add(cb);
      return () => {
        subs.delete(cb);
      };
    },
    () => flags
  );
}
