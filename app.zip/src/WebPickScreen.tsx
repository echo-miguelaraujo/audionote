import React, { useRef, useState } from 'react';
import { Modal, Pressable, ScrollView, StyleSheet, Text, TextInput, View, useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { WebView, WebViewMessageEvent } from 'react-native-webview';
import type { StockPhoto } from './stockImages';
import { domainOf, normalizeUrl } from './linkPreview';
import { colors, fonts, SPACE, TYPE } from './theme';

type Pick = { url: string; w: number; h: number; page: string };

const SITES = [
  { label: 'Google Imagens', url: 'https://www.google.com/imghp' },
  { label: 'Pinterest', url: 'https://br.pinterest.com' },
  { label: 'Behance', url: 'https://www.behance.net' },
  { label: 'Are.na', url: 'https://www.are.na' },
];

/**
 * Com o modo "Escolher imagens" ligado, tocar numa imagem da página a marca (ou desmarca) em vez de abrir.
 * Pega a maior versão disponível (srcset) e avisa o app, que guarda a imagem e o endereço da página.
 */
const PICK_JS = String.raw`(function(){
if(window.__pk){return;}window.__pk=1;window.__pickMode=false;var sel={};
function abs(u){try{return new URL(u,location.href).toString();}catch(e){return '';}}
function best(img){
  var s=img.getAttribute('srcset')||'',bestU='',bestW=0;
  if(s){s.split(',').forEach(function(p){var a=p.trim().split(/\s+/);if(!a[0])return;var d=parseFloat(a[1])||1;if(a[1]&&/x$/.test(a[1]))d=d*1000;if(d>=bestW){bestW=d;bestU=a[0];}});}
  var u=abs(bestU||img.currentSrc||img.src);
  if(/pinimg\.com/.test(u))u=u.replace(/\/\d+x\//,'/736x/');
  return u;
}
function find(x,y){
  var els=document.elementsFromPoint(x,y);
  for(var i=0;i<els.length;i++){
    var e=els[i];
    if(e.tagName==='IMG')return {el:e,url:best(e),w:e.naturalWidth,h:e.naturalHeight};
    var bg=getComputedStyle(e).backgroundImage;
    var m=/url\(["']?([^"')]+)["']?\)/.exec(bg||'');
    if(m)return {el:e,url:abs(m[1]),w:e.clientWidth,h:e.clientHeight};
  }
  return null;
}
document.addEventListener('click',function(e){
  if(!window.__pickMode)return;
  e.preventDefault();e.stopPropagation();
  var f=find(e.clientX,e.clientY);
  if(!f||!f.url)return;
  if(/^(data|blob):/.test(f.url)){window.ReactNativeWebView.postMessage(JSON.stringify({type:'bad'}));return;}
  var on=!sel[f.url];sel[f.url]=on;
  f.el.style.outline=on?'5px solid #FF3030':'';f.el.style.outlineOffset=on?'-5px':'';
  window.ReactNativeWebView.postMessage(JSON.stringify({type:'pick',on:on,url:f.url,w:f.w,h:f.h,page:location.href}));
},true);
})();true;`;

type Props = { visible: boolean; onClose: () => void; onPick: (list: StockPhoto[]) => void };

/** Navegador para buscar imagens na web: liga o modo "Escolher imagens", toca nas que quiser e adiciona todas ao quadro. */
export function WebPickScreen({ visible, onClose, onPick }: Props) {
  const { width: sw } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const web = useRef<WebView>(null);
  const [text, setText] = useState('');
  const [uri, setUri] = useState<string | null>(null);
  const [picking, setPicking] = useState(false);
  const [picks, setPicks] = useState<Pick[]>([]);
  const [hint, setHint] = useState<string | null>(null);

  const go = (raw: string) => {
    const t = raw.trim();
    if (!t) return;
    const u = normalizeUrl(t) ?? `https://www.google.com/search?tbm=isch&q=${encodeURIComponent(t)}`;
    setUri(u);
    setText(u);
  };
  const setMode = (on: boolean) => {
    setPicking(on);
    web.current?.injectJavaScript(`window.__pickMode=${on};true;`);
  };
  const flash = (t: string) => {
    setHint(t);
    setTimeout(() => setHint(null), 2600);
  };
  const onMessage = (e: WebViewMessageEvent) => {
    try {
      const m = JSON.parse(e.nativeEvent.data);
      if (m.type === 'bad') flash('Essa miniatura não tem endereço. Abra a imagem e toque nela de novo.');
      else if (m.type === 'pick') {
        setPicks((prev) =>
          m.on
            ? prev.some((p) => p.url === m.url)
              ? prev
              : [...prev, { url: m.url, w: Number(m.w) || 0, h: Number(m.h) || 0, page: m.page }]
            : prev.filter((p) => p.url !== m.url)
        );
      }
    } catch {
      // mensagem de outra origem: ignora
    }
  };
  const finish = () => {
    if (picks.length === 0) return;
    onPick(
      picks.map((p) => ({
        uid: `web:${p.url}`,
        source: 'link',
        width: p.w,
        height: p.h,
        sizeUnknown: !(p.w > 0 && p.h > 0),
        thumbUrl: p.url,
        fullUrl: p.url,
        pageUrl: p.page,
        author: domainOf(p.page),
        authorUrl: p.page,
        caption: `Fonte: ${domainOf(p.page)} · ${p.page}`,
      }))
    );
    setPicks([]);
    setPicking(false);
  };
  const close = () => {
    setPicks([]);
    setPicking(false);
    onClose();
  };

  const pad = sw * SPACE.md;
  const pill = {
    borderRadius: sw * 0.08,
    paddingHorizontal: sw * 0.04,
    paddingVertical: sw * 0.022,
  };

  return (
    <Modal visible={visible} animationType="slide" statusBarTranslucent onRequestClose={close}>
      <View style={[styles.root, { paddingTop: insets.top }]}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: pad, padding: pad }}>
          <Pressable onPress={close} hitSlop={12}>
            <Text style={{ color: colors.red, fontFamily: fonts.bold, fontSize: sw * TYPE.body }}>Fechar</Text>
          </Pressable>
          <TextInput
            value={text}
            onChangeText={setText}
            onSubmitEditing={() => go(text)}
            placeholder="Buscar ou colar endereço"
            placeholderTextColor={colors.subtle}
            autoCapitalize="none"
            autoCorrect={false}
            returnKeyType="go"
            selectTextOnFocus
            style={{ flex: 1, ...pill, backgroundColor: colors.paper, color: colors.onLight, fontFamily: fonts.regular, fontSize: sw * TYPE.body }}
          />
        </View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ flexGrow: 0 }} contentContainerStyle={{ paddingHorizontal: pad, gap: sw * SPACE.sm, paddingBottom: sw * SPACE.sm }}>
          {SITES.map((s) => (
            <Pressable key={s.label} onPress={() => go(s.url)} style={{ ...pill, backgroundColor: colors.paper }}>
              <Text style={{ color: colors.onLight, fontFamily: fonts.bold, fontSize: sw * TYPE.caption * 1.1 }}>{s.label}</Text>
            </Pressable>
          ))}
        </ScrollView>

        <View style={{ flex: 1, backgroundColor: colors.paper }}>
          {uri ? (
            <WebView
              ref={web}
              source={{ uri }}
              injectedJavaScript={PICK_JS}
              onMessage={onMessage}
              onLoadEnd={() => web.current?.injectJavaScript(`window.__pickMode=${picking};true;`)}
              onNavigationStateChange={(n) => n.url && setText(n.url)}
              javaScriptEnabled
              domStorageEnabled
              setSupportMultipleWindows={false}
            />
          ) : (
            <Text style={{ margin: pad * 2, color: colors.subtle, fontFamily: fonts.regular, fontSize: sw * TYPE.body, textAlign: 'center' }}>
              Escolha um site acima ou digite uma busca. Ligue "Escolher imagens" e toque nas que quiser guardar.
            </Text>
          )}
          {hint !== null && (
            <View pointerEvents="none" style={{ position: 'absolute', left: pad, right: pad, bottom: pad, ...pill, backgroundColor: colors.onLight }}>
              <Text style={{ color: colors.onDark, fontFamily: fonts.regular, fontSize: sw * TYPE.caption * 1.1, textAlign: 'center' }}>{hint}</Text>
            </View>
          )}
        </View>

        <View style={{ flexDirection: 'row', alignItems: 'center', gap: pad, padding: pad, paddingBottom: insets.bottom + pad }}>
          <Pressable onPress={() => setMode(!picking)} style={{ ...pill, backgroundColor: picking ? colors.red : colors.paper }}>
            <Text style={{ color: picking ? colors.onDark : colors.onLight, fontFamily: fonts.bold, fontSize: sw * TYPE.body }}>
              {picking ? 'Escolhendo imagens' : 'Escolher imagens'}
            </Text>
          </Pressable>
          <View style={{ flex: 1 }} />
          <Pressable
            disabled={picks.length === 0}
            onPress={finish}
            style={{ ...pill, backgroundColor: colors.onLight, opacity: picks.length === 0 ? 0.35 : 1 }}
          >
            <Text style={{ color: colors.onDark, fontFamily: fonts.bold, fontSize: sw * TYPE.body }}>
              {picks.length === 0 ? 'Adicionar' : `Adicionar ${picks.length}`}
            </Text>
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.onDark },
});
