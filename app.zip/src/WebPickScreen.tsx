import React, { useRef, useState } from 'react';
import { Modal, Pressable, ScrollView, StyleSheet, Text, TextInput, View, useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { WebView, WebViewMessageEvent } from 'react-native-webview';
import type { StockPhoto } from './stockImages';
import type { WebVideo } from './videoData';
import { domainOf, normalizeUrl } from './linkPreview';
import { colors, fonts, SPACE, TYPE } from './theme';

type Pick = { url: string; w: number; h: number; page: string; video?: { poster: string | null; dur: number | null } };

const SITES = [
  { label: 'Cosmos', url: 'https://www.cosmos.so' },
  { label: 'Pinterest', url: 'https://br.pinterest.com' },
  { label: 'Pexels', url: 'https://www.pexels.com' },
  { label: 'Unsplash', url: 'https://unsplash.com' },
  { label: 'Behance', url: 'https://www.behance.net' },
  { label: 'Dribbble', url: 'https://dribbble.com' },
  { label: 'Savee', url: 'https://savee.it' },
  { label: 'Are.na', url: 'https://www.are.na' },
  { label: 'Pixabay', url: 'https://pixabay.com' },
  { label: 'Flickr', url: 'https://www.flickr.com' },
  { label: 'Freepik', url: 'https://www.freepik.com' },
  { label: 'Lummi', url: 'https://www.lummi.ai' },
  { label: 'Wikimedia', url: 'https://commons.wikimedia.org' },
  { label: 'Google Imagens', url: 'https://www.google.com/imghp' },
  { label: 'Bing Imagens', url: 'https://www.bing.com/images' },
  { label: 'Instagram', url: 'https://www.instagram.com' },
  { label: 'Tumblr', url: 'https://www.tumblr.com/explore' },
  { label: 'ArtStation', url: 'https://www.artstation.com' },
  { label: 'DeviantArt', url: 'https://www.deviantart.com' },
  { label: 'Dezeen', url: 'https://www.dezeen.com' },
  { label: 'Designspiration', url: 'https://www.designspiration.com' },
  { label: 'Mobbin', url: 'https://mobbin.com' },
  { label: 'Awwwards', url: 'https://www.awwwards.com' },
  { label: 'Pond5', url: 'https://www.pond5.com' },
  { label: 'Burst', url: 'https://www.shopify.com/stock-photos' },
  { label: 'StockSnap', url: 'https://stocksnap.io' },
  { label: 'Kaboompics', url: 'https://kaboompics.com' },
  { label: 'Openverse', url: 'https://openverse.org' },
  { label: 'NASA Imagens', url: 'https://images.nasa.gov' },
  { label: 'Museu Met', url: 'https://www.metmuseum.org/art/collection' },
  { label: 'Art Institute', url: 'https://www.artic.edu/collection' },
  { label: 'Rijksmuseum', url: 'https://www.rijksmuseum.nl/en/rijksstudio' },
  { label: 'Library of Congress', url: 'https://www.loc.gov/pictures/' },
  { label: 'Pinterest (EN)', url: 'https://www.pinterest.com' },
];

/**
 * Com o modo "Escolher imagens" ligado, tocar numa imagem da página a marca (ou desmarca) em vez de abrir.
 * Pega a maior versão disponível (srcset) e avisa o app, que guarda a imagem e o endereço da página.
 */
const PICK_JS = String.raw`(function(){
if(window.__pk){return;}window.__pk=1;window.__pickMode=false;var sel={};
function abs(u){try{return new URL(u,location.href).toString();}catch(e){return '';}}
function best(img){
  var s=img.getAttribute('srcset')||'',bestU='',bestW=0;
  if(s){s.split(',').forEach(function(p){var a=p.trim().split(/\s+/);if(!a[0])return;var d=parseFloat(a[1])||1;if(a[1]&&/x$/.test(a[1]))d=d*1000;if(d>=bestW){bestW=d;bestU=a[0];}});}
  var u=abs(bestU||img.currentSrc||img.src);
  if(/pinimg\.com/.test(u))u=u.replace(/\/\d+x\//,'/736x/');
  return u;
}
function vidAt(x,y){
  var els=document.elementsFromPoint(x,y);
  for(var i=0;i<els.length;i++){
    var e=els[i];
    if(e.tagName==='VIDEO')return e;
    if(e.querySelector){var v=e.querySelector('video');if(v){var r=v.getBoundingClientRect();if(x>=r.left&&x<=r.right&&y>=r.top&&y<=r.bottom)return v;}}
  }
  return null;
}
function vsrc(v){
  var u=v.currentSrc||v.src||'';
  if(!u){var s=v.querySelector('source');if(s)u=s.src||s.getAttribute('src')||'';}
  return u?abs(u):'';
}
function okU(u){return !!u&&!/^(data|blob):/.test(u)&&!/\.svg(\?|$)/i.test(u);}
function imgInfo(e){
  var u=best(e);
  if(!okU(u)){
    var alt=e.getAttribute('data-src')||e.getAttribute('data-lazy-src')||e.getAttribute('data-original')||'';
    var ds=e.getAttribute('data-srcset')||'';
    if(!alt&&ds)alt=ds.split(',').pop().trim().split(/\s+/)[0];
    u=abs(alt);
  }
  var pic=e.parentElement&&e.parentElement.tagName==='PICTURE'?e.parentElement:null;
  if(pic){
    var best2='',bw=0;
    pic.querySelectorAll('source').forEach(function(sc){
      var ss=sc.getAttribute('srcset')||'';
      ss.split(',').forEach(function(p){var a=p.trim().split(/\s+/);if(!a[0])return;var d=parseFloat(a[1])||1;if(d>=bw){bw=d;best2=a[0];}});
    });
    if(best2&&!okU(u))u=abs(best2);
  }
  return okU(u)?{el:e,url:u,w:e.naturalWidth||e.clientWidth,h:e.naturalHeight||e.clientHeight}:null;
}
function inRect(e,x,y){var r=e.getBoundingClientRect();return x>=r.left&&x<=r.right&&y>=r.top&&y<=r.bottom&&r.width>20&&r.height>20;}
function deepAt(x,y){
  var out=[];var seen=[];
  function walk(root){
    var els=root.elementsFromPoint(x,y);
    els.forEach(function(e){
      if(seen.indexOf(e)>=0)return;seen.push(e);out.push(e);
      if(e.shadowRoot)walk(e.shadowRoot);
    });
  }
  walk(document);
  return out;
}
function find(x,y){
  var els=deepAt(x,y);
  for(var i=0;i<els.length;i++){
    var e=els[i];
    if(e.tagName==='IMG'){var r0=imgInfo(e);if(r0)return r0;}
  }
  for(var j=0;j<els.length;j++){
    var e2=els[j];
    var bg=getComputedStyle(e2).backgroundImage;
    var re=/url\(["']?([^"')]+)["']?\)/g,m;
    while((m=re.exec(bg||''))){var u=abs(m[1]);if(okU(u))return {el:e2,url:u,w:e2.clientWidth,h:e2.clientHeight};}
  }
  // cartões com camada transparente por cima (ex.: Behance): procura uma imagem dentro do mesmo cartão
  for(var k=0;k<els.length;k++){
    var c=els[k];
    if(!c.querySelectorAll||c===document.body||c===document.documentElement)continue;
    var imgs=c.querySelectorAll('img');
    if(imgs.length>6)continue;
    for(var n=0;n<imgs.length;n++){
      if(inRect(imgs[n],x,y)){var r1=imgInfo(imgs[n]);if(r1)return r1;}
    }
    var par=c.parentElement;
    if(par&&par!==document.body){
      var sib=par.querySelectorAll('img');
      if(sib.length<=6)for(var q=0;q<sib.length;q++){
        if(inRect(sib[q],x,y)){var r2=imgInfo(sib[q]);if(r2)return r2;}
      }
    }
  }
  return null;
}
document.addEventListener('click',function(e){
  if(!window.__pickMode)return;
  var vd=vidAt(e.clientX,e.clientY);
  if(vd){
    e.preventDefault();e.stopPropagation();
    var vu=vsrc(vd);
    if(!vu||/^blob:/.test(vu)){window.ReactNativeWebView.postMessage(JSON.stringify({type:'badvideo'}));return;}
    var von=!sel[vu];sel[vu]=von;
    vd.style.outline=von?'5px solid #FF3030':'';vd.style.outlineOffset=von?'-5px':'';
    window.ReactNativeWebView.postMessage(JSON.stringify({type:'pickvideo',on:von,url:vu,poster:vd.poster?abs(vd.poster):'',w:vd.videoWidth||0,h:vd.videoHeight||0,dur:isFinite(vd.duration)?vd.duration:0,page:location.href}));
    return;
  }
  e.preventDefault();e.stopPropagation();
  var f=find(e.clientX,e.clientY);
  if(!f||!f.url){window.ReactNativeWebView.postMessage(JSON.stringify({type:'nofind'}));return;}
  if(/^(data|blob):/.test(f.url)){window.ReactNativeWebView.postMessage(JSON.stringify({type:'bad'}));return;}
  var on=!sel[f.url];sel[f.url]=on;
  f.el.style.outline=on?'5px solid #FF3030':'';f.el.style.outlineOffset=on?'-5px':'';
  window.ReactNativeWebView.postMessage(JSON.stringify({type:'pick',on:on,url:f.url,w:f.w,h:f.h,page:location.href}));
},true);
})();true;`;

type Props = {
  visible: boolean;
  onClose: () => void;
  onPick: (list: StockPhoto[]) => void;
  /** Vídeos tocados na página (só os que têm endereço direto: mp4, webm, m3u8...). */
  onPickVideos?: (list: WebVideo[]) => void;
};

/** Navegador para buscar imagens na web: liga o modo "Escolher imagens", toca nas que quiser e adiciona todas ao quadro. */
export function WebPickScreen({ visible, onClose, onPick, onPickVideos }: Props) {
  const { width: sw } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const web = useRef<WebView>(null);
  const gsiTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [text, setText] = useState('');
  const [uri, setUri] = useState<string | null>(null);
  const [picking, setPicking] = useState(false);
  const [picks, setPicks] = useState<Pick[]>([]);
  const [hint, setHint] = useState<string | null>(null);

  const go = (raw: string) => {
    const t = raw.trim();
    if (!t) return;
    const u = normalizeUrl(t) ?? `https://www.google.com/search?tbm=isch&q=${encodeURIComponent(t)}`;
    setUri(u);
    setText(u);
  };
  const setMode = (on: boolean) => {
    setPicking(on);
    web.current?.injectJavaScript(`window.__pickMode=${on};true;`);
  };
  const flash = (t: string) => {
    setHint(t);
    setTimeout(() => setHint(null), 2600);
  };
  const onMessage = (e: WebViewMessageEvent) => {
    try {
      const m = JSON.parse(e.nativeEvent.data);
      if (m.type === 'nofind') flash('Não achei imagem aí. Toque direto na foto ou abra o projeto e toque nela.');
      else if (m.type === 'bad') flash('Essa miniatura não tem endereço. Abra a imagem e toque nela de novo.');
      else if (m.type === 'badvideo') flash('Esse site não entrega o arquivo do vídeo. Salve o vídeo na galeria (ou compartilhe com o Ideias) e adicione por lá.');
      else if (m.type === 'pickvideo') {
        setPicks((prev) =>
          m.on
            ? prev.some((p) => p.url === m.url)
              ? prev
              : [
                  ...prev,
                  {
                    url: m.url,
                    w: Number(m.w) || 0,
                    h: Number(m.h) || 0,
                    page: m.page,
                    video: { poster: m.poster ? String(m.poster) : null, dur: Number(m.dur) > 0 ? Number(m.dur) : null },
                  },
                ]
            : prev.filter((p) => p.url !== m.url)
        );
      }
      else if (m.type === 'pick') {
        setPicks((prev) =>
          m.on
            ? prev.some((p) => p.url === m.url)
              ? prev
              : [...prev, { url: m.url, w: Number(m.w) || 0, h: Number(m.h) || 0, page: m.page }]
            : prev.filter((p) => p.url !== m.url)
        );
      }
    } catch {
      // mensagem de outra origem: ignora
    }
  };
  const finish = () => {
    if (picks.length === 0) return;
    const vids = picks.filter((p) => p.video);
    if (vids.length > 0) {
      onPickVideos?.(
        vids.map((p) => ({
          uid: `web:${p.url}`,
          src: p.url,
          poster: p.video?.poster ?? null,
          width: p.w,
          height: p.h,
          duration: p.video?.dur ?? null,
          pageUrl: p.page,
          author: domainOf(p.page),
          caption: `Fonte: ${domainOf(p.page)} · ${p.page}`,
        }))
      );
    }
    const imgs = picks.filter((p) => !p.video);
    if (imgs.length > 0)
    onPick(
      imgs.map((p) => ({
        uid: `web:${p.url}`,
        source: 'link',
        width: p.w,
        height: p.h,
        sizeUnknown: !(p.w > 0 && p.h > 0),
        thumbUrl: p.url,
        fullUrl: p.url,
        pageUrl: p.page,
        author: domainOf(p.page),
        authorUrl: p.page,
        caption: `Fonte: ${domainOf(p.page)} · ${p.page}`,
      }))
    );
    setPicks([]);
    setPicking(false);
  };
  const close = () => {
    setPicks([]);
    setPicking(false);
    onClose();
  };

  const pad = sw * SPACE.md;
  const pill = {
    borderRadius: sw * 0.08,
    paddingHorizontal: sw * 0.04,
    paddingVertical: sw * 0.022,
  };

  return (
    <Modal visible={visible} animationType="slide" statusBarTranslucent onRequestClose={close}>
      <View style={[styles.root, { paddingTop: insets.top }]}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: pad, padding: pad }}>
          <Pressable onPress={close} hitSlop={12}>
            <Text style={{ color: colors.red, fontFamily: fonts.bold, fontSize: sw * TYPE.body }}>Fechar</Text>
          </Pressable>
          <TextInput
            value={text}
            onChangeText={setText}
            onSubmitEditing={() => go(text)}
            placeholder="Buscar ou colar endereço"
            placeholderTextColor={colors.subtle}
            autoCapitalize="none"
            autoCorrect={false}
            returnKeyType="go"
            selectTextOnFocus
            style={{ flex: 1, ...pill, backgroundColor: colors.paper, color: colors.onLight, fontFamily: fonts.regular, fontSize: sw * TYPE.body }}
          />
        </View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ flexGrow: 0 }} contentContainerStyle={{ paddingHorizontal: pad, gap: sw * SPACE.sm, paddingBottom: sw * SPACE.sm }}>
          {SITES.map((s) => (
            <Pressable key={s.label} onPress={() => go(s.url)} style={{ ...pill, backgroundColor: colors.paper }}>
              <Text style={{ color: colors.onLight, fontFamily: fonts.bold, fontSize: sw * TYPE.caption * 1.1 }}>{s.label}</Text>
            </Pressable>
          ))}
        </ScrollView>

        <View style={{ flex: 1, backgroundColor: colors.paper }}>
          {uri ? (
            <WebView
              ref={web}
              source={{ uri }}
              injectedJavaScript={PICK_JS}
              onMessage={onMessage}
              onLoadEnd={() => web.current?.injectJavaScript(`window.__pickMode=${picking};true;`)}
              onNavigationStateChange={(n) => {
                if (!n.url) return;
                setText(n.url);
                // Login com Google: o popup perde a página de origem e trava em branco.
                // Depois de alguns segundos, volta ao Pinterest (a sessão do Google já foi gravada).
                if (n.url.includes('accounts.google.com/gsi/')) {
                  if (gsiTimer.current) clearTimeout(gsiTimer.current);
                  gsiTimer.current = setTimeout(() => {
                    setUri(null);
                    setTimeout(() => {
                      setUri('https://br.pinterest.com');
                      setText('https://br.pinterest.com');
                    }, 50);
                  }, 2500);
                } else if (gsiTimer.current) {
                  clearTimeout(gsiTimer.current);
                  gsiTimer.current = null;
                }
              }}
              javaScriptEnabled
              domStorageEnabled
              setSupportMultipleWindows={false}
            />
          ) : (
            <Text style={{ margin: pad * 2, color: colors.subtle, fontFamily: fonts.regular, fontSize: sw * TYPE.body, textAlign: 'center' }}>
              Escolha um site acima ou digite uma busca. Ligue "Escolher imagens e vídeos" e toque no que quiser guardar. Vídeos só funcionam quando o site entrega o arquivo.
            </Text>
          )}
          {hint !== null && (
            <View pointerEvents="none" style={{ position: 'absolute', left: pad, right: pad, bottom: pad, ...pill, backgroundColor: colors.onLight }}>
              <Text style={{ color: colors.onDark, fontFamily: fonts.regular, fontSize: sw * TYPE.caption * 1.1, textAlign: 'center' }}>{hint}</Text>
            </View>
          )}
        </View>

        <View style={{ flexDirection: 'row', alignItems: 'center', gap: pad, padding: pad, paddingBottom: insets.bottom + pad }}>
          <Pressable onPress={() => setMode(!picking)} style={{ ...pill, backgroundColor: picking ? colors.red : colors.paper }}>
            <Text style={{ color: picking ? colors.onDark : colors.onLight, fontFamily: fonts.bold, fontSize: sw * TYPE.body }}>
              {picking ? 'Escolhendo…' : 'Escolher imagens e vídeos'}
            </Text>
          </Pressable>
          <View style={{ flex: 1 }} />
          <Pressable
            disabled={picks.length === 0}
            onPress={finish}
            style={{ ...pill, backgroundColor: colors.onLight, opacity: picks.length === 0 ? 0.35 : 1 }}
          >
            <Text style={{ color: colors.onDark, fontFamily: fonts.bold, fontSize: sw * TYPE.body }}>
              {picks.length === 0 ? 'Adicionar' : `Adicionar ${picks.length}`}
            </Text>
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.onDark },
});
