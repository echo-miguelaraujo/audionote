import React, { useEffect, useMemo, useState } from 'react';
import { Pressable, ScrollView, Text, View, useWindowDimensions } from 'react-native';
import { DialogActions, DialogInput, DialogShell, DialogTitle } from './DialogBase';
import { normalizeTag, tagKey, uniqueTags } from './tags';
import { colors, fonts, RADIUS, SPACE, TYPE, HIT } from './theme';

type Props = {
  visible: boolean;
  /** Tags da nota. */
  current: string[];
  /** Todas as tags que existem, com a contagem de notas. */
  existing: { key: string; name: string; count: number }[];
  onCancel: () => void;
  onSave: (tags: string[]) => void;
};

export function Chip({ label, on, onPress, sw }: { label: string; on?: boolean; onPress: () => void; sw: number }) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ selected: !!on }}
      onPress={onPress}
      hitSlop={HIT.sm}
      style={{
        borderRadius: sw * RADIUS.pill,
        borderWidth: 1,
        borderColor: on ? colors.red : colors.line,
        backgroundColor: on ? colors.red : 'transparent',
        paddingHorizontal: sw * SPACE.md,
        paddingVertical: sw * SPACE.sm,
      }}
    >
      <Text style={{ color: on ? colors.onDark : colors.onLight, fontFamily: fonts.regular, fontSize: sw * TYPE.label }}>{label}</Text>
    </Pressable>
  );
}

/** Tags de uma nota: marcar/desmarcar as existentes, ou criar na hora digitando. */
export function TagsDialog({ visible, current, existing, onCancel, onSave }: Props) {
  const { width: sw, height: sh } = useWindowDimensions();
  const [picked, setPicked] = useState<string[]>(current);
  const [text, setText] = useState('');

  useEffect(() => {
    if (visible) {
      setPicked(current);
      setText('');
    }
  }, [visible, current]);

  const typed = normalizeTag(text);
  const typedKey = typed ? tagKey(typed) : '';
  const matches = useMemo(
    () => existing.filter((e) => !typedKey || e.key.includes(typedKey)),
    [existing, typedKey]
  );
  const exact = existing.some((e) => e.key === typedKey) || picked.some((t) => tagKey(t) === typedKey);

  const toggle = (name: string) =>
    setPicked((prev) => (prev.some((t) => tagKey(t) === tagKey(name)) ? prev.filter((t) => tagKey(t) !== tagKey(name)) : [...prev, name]));

  return (
    <DialogShell visible={visible} onClose={onCancel} keyboard maxHeight={sh * 0.8}>
      <DialogTitle>Tags</DialogTitle>
      {picked.length > 0 && (
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: sw * SPACE.sm, marginBottom: sw * SPACE.md }}>
          {picked.map((t) => (
            <Chip key={tagKey(t)} label={`${t}  ✕`} on sw={sw} onPress={() => toggle(t)} />
          ))}
        </View>
      )}
      <DialogInput value={text} onChangeText={setText} placeholder="Buscar ou criar tag" maxLength={30} autoCorrect={false} />
      <ScrollView style={{ maxHeight: sh * 0.35, marginTop: sw * SPACE.md }} keyboardShouldPersistTaps="handled">
        {typed && !exact && (
          <Pressable
            accessibilityRole="button"
            onPress={() => {
              toggle(typed);
              setText('');
            }}
            style={{ paddingVertical: sw * SPACE.md }}
          >
            <Text style={{ color: colors.red, fontFamily: fonts.bold, fontSize: sw * TYPE.body }}>{`Criar «${typed}»`}</Text>
          </Pressable>
        )}
        {matches.map((e) => {
          const on = picked.some((t) => tagKey(t) === e.key);
          return (
            <Pressable
              key={e.key}
              accessibilityRole="button"
              accessibilityState={{ selected: on }}
              onPress={() => toggle(e.name)}
              style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: sw * SPACE.md }}
            >
              <Text style={{ color: on ? colors.red : colors.onLight, fontFamily: on ? fonts.bold : fonts.regular, fontSize: sw * TYPE.body }}>
                {e.name}
              </Text>
              <Text style={{ color: colors.subtle, fontFamily: fonts.regular, fontSize: sw * TYPE.label }}>{e.count}</Text>
            </Pressable>
          );
        })}
      </ScrollView>
      <DialogActions onCancel={onCancel} confirmLabel="Salvar" onConfirm={() => onSave(uniqueTags(picked))} />
    </DialogShell>
  );
}
