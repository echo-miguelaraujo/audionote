import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Alert, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Block, deleteBlock, getNoteJson, listBlocks, saveNoteJson } from './db';
import { emptyNote, parseNote } from './note';
import { PromptDialog } from './PromptDialog';
import { SelectorHandle, SelectorList, SelItem } from './SelectorList';
import { colors, fonts } from './theme';

type Props = {
  selectMode: boolean;
  version: number;
  onOpen: (blockId: number) => void;
  onSelect: (blockId: number) => void;
  onChanged: () => void;
};

export function LibraryScreen({ selectMode, version, onOpen, onSelect, onChanged }: Props) {
  const { width: sw } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const [blocks, setBlocks] = useState<Block[] | null>(null);
  const [focus, setFocus] = useState(0);
  const [renaming, setRenaming] = useState<Block | null>(null);
  const listRef = useRef<SelectorHandle>(null);

  const load = useCallback(async () => {
    setBlocks(await listBlocks());
  }, []);

  useEffect(() => {
    load().catch((e) => Alert.alert('Erro ao ler a Biblioteca', String(e)));
  }, [load, version]);

  // Título = assunto da nota; subtítulo = começo do texto (como na imagem de referência).
  const items: SelItem[] = useMemo(
    () =>
      (blocks ?? []).map((b) => ({
        id: b.id,
        title: b.noteTitle || (b.pendingCount > 0 ? 'Transcrevendo…' : b.name),
        subtitle: b.preview || (b.pendingCount > 0 ? 'Aguardando a transcrição…' : 'Nota vazia'),
      })),
    [blocks]
  );

  const onLongPress = (item: SelItem) => {
    const block = blocks?.find((b) => b.id === item.id);
    if (!block) return;
    const shown = block.noteTitle || block.name;
    Alert.alert(shown, undefined, [
      { text: 'Renomear', onPress: () => setRenaming(block) },
      {
        text: 'Apagar',
        style: 'destructive',
        onPress: () =>
          Alert.alert(
            'Apagar item?',
            `"${block.name}" e todos os áudios dentro dele serão apagados.`,
            [
              { text: 'Cancelar', style: 'cancel' },
              {
                text: 'Apagar',
                style: 'destructive',
                onPress: async () => {
                  await deleteBlock(block.id);
                  onChanged();
                },
              },
            ]
          ),
      },
      { text: 'Cancelar', style: 'cancel' },
    ]);
  };

  if (blocks === null) return <View style={styles.flex} />;

  return (
    <View style={styles.flex}>
      {selectMode && (
        <Text
          style={[
            styles.hint,
            { top: insets.top + sw * 0.08, fontSize: sw * 0.05, paddingHorizontal: sw * 0.0587 },
          ]}
        >
          Escolha onde gravar
        </Text>
      )}
      <SelectorList
        key={blocks.length === 0 ? 'empty' : 'list'}
        ref={listRef}
        data={items}
        emptyText={
          selectMode
            ? 'Nenhum item ainda. Volte e use "Gravar Novo".'
            : 'Nada por aqui ainda. Grave seu primeiro áudio na aba Gravação.'
        }
        onFocusIndex={setFocus}
        onPressFocused={(item) => (selectMode ? onSelect(item.id) : onOpen(item.id))}
        onLongPressFocused={onLongPress}
      />
      <PromptDialog
        visible={renaming !== null}
        title="Renomear nota"
        initialValue={renaming ? renaming.noteTitle || renaming.name : ''}
        onCancel={() => setRenaming(null)}
        onSubmit={async (value) => {
          if (renaming) {
            const note = parseNote(await getNoteJson(renaming.id)) ?? emptyNote();
            await saveNoteJson(renaming.id, JSON.stringify({ ...note, title: value.trim() }));
          }
          setRenaming(null);
          onChanged();
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: colors.bg },
  hint: {
    position: 'absolute',
    left: 0,
    zIndex: 5,
    color: colors.red,
    fontFamily: fonts.bold,
    letterSpacing: -1,
  },
});
