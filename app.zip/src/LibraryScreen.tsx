import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { appAlert } from './dialog';
import {
  ActivityIndicator,
  BackHandler,
  Keyboard,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  useWindowDimensions,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { BottomSheet, SheetItem } from './BottomSheet';
import { CategoryDialog } from './CategoryDialog';
import {
  Block,
  Category,
  createBlock,
  createCategory,
  deleteBlock,
  deleteCategory,
  getNoteJson,
  listBlocks,
  listCategories,
  saveNoteJson,
  setBlockCategory,
  setBlockTags,
  setFavorite,
  setPinned,
  updateCategory,
} from './db';
import { DEFAULT_DIR, SortDir, SortKey, blockTitle, sortBlocks } from './blockSort';
import { LibraryFilterSheet } from './LibraryFilterSheet';
import { LibraryGrid, PIN_MARK } from './LibraryGrid';
import { CONTENT_LABEL, LibFilters, NO_FILTERS, PERIOD_LABEL, applyFilters, countActive, tagStats } from './libraryFilters';
import { TagsDialog } from './TagsDialog';
import { LibraryView, getLibraryOrder, getLibraryView, setLibraryOrder, setLibraryView } from './settings';
import { askImages, noteFromImage, readPickedImages } from './imageNote';
import { emptyNote, parseNote } from './note';
import { PromptDialog } from './PromptDialog';
import { SelectorHandle, SelectorList, SelItem } from './SelectorList';
import { Icon } from './Icon';
import { StateMessage } from './StateMessage';
import { colors, fonts, TYPE, SPACE } from './theme';

type Props = {
  version: number;
  onOpen: (blockId: number) => void;
  onChanged: () => void;
};

/** Minúsculas e sem acento, mantendo o mesmo tamanho do texto (para achar o trecho certo). */
function fold(s: string): string {
  try {
    return s.replace(/[\u00C0-\u024F]/g, (c) => c.normalize('NFD')[0]).toLowerCase();
  } catch {
    return s.toLowerCase();
  }
}

/** Pedaço do texto em volta da palavra encontrada, para mostrar na lista de resultados. */
function snippet(body: string, foldedBody: string, term: string): string {
  const i = foldedBody.indexOf(term);
  if (i < 0) return '';
  const start = Math.max(0, i - 25);
  const s = body.slice(start, i + term.length + 70).replace(/\s+/g, ' ').trim();
  return (start > 0 ? '…' : '') + s;
}

export function LibraryScreen({ version, onOpen, onChanged }: Props) {
  const { width: sw } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const [blocks, setBlocks] = useState<Block[] | null>(null);
  const [cats, setCats] = useState<Category[]>([]);
  const [filters, setFilters] = useState<LibFilters>(NO_FILTERS);
  const [sort, setSort] = useState<{ key: SortKey; dir: SortDir }>({ key: 'created', dir: 'desc' });
  const [view, setView] = useState<LibraryView>('list');
  const [filterOpen, setFilterOpen] = useState(false);
  const [tagsFor, setTagsFor] = useState<Block | null>(null);
  const [sheet, setSheet] = useState<'cats' | null>(null);
  const filter = filters.category;
  const [catDialog, setCatDialog] = useState<{ cat: Category | null } | null>(null);
  const [assignFor, setAssignFor] = useState<Block | null>(null);
  const [renaming, setRenaming] = useState<Block | null>(null);
  const [menuFor, setMenuFor] = useState<Block | null>(null);
  const [searching, setSearching] = useState(false);
  const [query, setQuery] = useState('');
  const listRef = useRef<SelectorHandle>(null);

  const closeSearch = useCallback(() => {
    setSearching(false);
    setQuery('');
    Keyboard.dismiss();
  }, []);

  // Botão voltar do Android fecha a busca antes de sair da Biblioteca.
  useEffect(() => {
    if (!searching) return;
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      closeSearch();
      return true;
    });
    return () => sub.remove();
  }, [searching, closeSearch]);

  // Ordem e visualização escolhidas ficam guardadas.
  useEffect(() => {
    getLibraryOrder().then(setSort).catch(() => {});
    getLibraryView().then(setView).catch(() => {});
  }, []);

  const chooseSort = (key: SortKey) => {
    const next = sort.key === key ? { key, dir: (sort.dir === 'asc' ? 'desc' : 'asc') as SortDir } : { key, dir: DEFAULT_DIR[key] };
    setSort(next);
    setLibraryOrder(next.key, next.dir).catch(() => {});
  };
  const chooseView = (v: LibraryView) => {
    setView(v);
    setLibraryView(v).catch(() => {});
  };

  const load = useCallback(async () => {
    const [b, c] = await Promise.all([listBlocks(), listCategories()]);
    setBlocks(b);
    setCats(c);
  }, []);

  useEffect(() => {
    load().catch((e) => appAlert('Erro ao ler a Biblioteca', String(e)));
  }, [load, version]);

  // Se a categoria do filtro foi apagada, volta a mostrar tudo.
  useEffect(() => {
    if (filter !== null && filter !== 0 && !cats.some((c) => c.id === filter)) setFilters((f) => ({ ...f, category: null }));
  }, [cats, filter]);

  const colorOf = useCallback(
    (id: number | null) => cats.find((c) => c.id === id)?.color ?? null,
    [cats]
  );

  const terms = useMemo(() => fold(query).split(/\s+/).filter(Boolean), [query]);

  // Texto sem acento de cada nota, calculado só quando a lista muda (não a cada letra digitada).
  const index = useMemo(() => {
    const m = new Map<number, { head: string; body: string }>();
    for (const b of blocks ?? []) m.set(b.id, { head: fold(`${b.noteTitle} ${b.name} ${b.tags.join(' ')}`), body: fold(b.body) });
    return m;
  }, [blocks]);

  const shown = useMemo(() => {
    const all = applyFilters(blocks ?? [], filters);
    // Todas as palavras digitadas precisam aparecer no título, nas tags ou no texto da nota.
    const found =
      terms.length === 0
        ? all
        : all.filter((b) => {
            const ix = index.get(b.id);
            return !!ix && terms.every((t) => ix.head.includes(t) || ix.body.includes(t));
          });
    return sortBlocks(found, sort.key, sort.dir);
  }, [blocks, filters, terms, index, sort]);

  const snippetOf = useCallback(
    (b: Block): string => {
      if (terms.length === 0) return '';
      const ix = index.get(b.id);
      const t = ix ? terms.find((w) => ix.body.includes(w)) : undefined;
      return ix && t ? snippet(b.body, ix.body, t) : '';
    },
    [terms, index]
  );
  const allTags = useMemo(() => tagStats(blocks ?? []), [blocks]);

  // Título = assunto da nota; subtítulo = começo do texto; barrinha = cor da categoria.
  const items: SelItem[] = useMemo(
    () =>
      shown.map((b) => {
        // Na busca, mostra o trecho onde a palavra aparece.
        const snip = snippetOf(b);
        const base = snip || b.preview || (b.pendingCount > 0 ? 'Aguardando a transcrição…' : 'Nota vazia');
        return {
          id: b.id,
          title: `${b.pinned ? PIN_MARK : ''}${b.favorite ? '★ ' : ''}${b.noteTitle || (b.pendingCount > 0 ? 'Transcrevendo…' : b.name)}`,
          subtitle: b.parentTitle ? `em ${b.parentTitle} · ${base}` : base,
          color: colorOf(b.categoryId),
        };
      }),
    [shown, colorOf, snippetOf]
  );

  const [reading, setReading] = useState(false);

  /** Foto de caderno / print -> nota nova com o texto lido pela IA. */
  const newFromImage = async () => {
    if (reading) return;
    const imgs = await askImages('Nova nota a partir de imagem');
    if (!imgs) return;
    setReading(true);
    try {
      const res = await readPickedImages(imgs, []);
      if (!res.ok) {
        appAlert('Não consegui ler a imagem', res.message);
        return;
      }
      const id = await createBlock();
      await saveNoteJson(id, JSON.stringify(noteFromImage(res)));
      onChanged();
      load().catch(() => {});
      onOpen(id);
    } catch (e) {
      appAlert('Não consegui criar a nota', String(e));
    } finally {
      setReading(false);
    }
  };

  /** Nota nova em branco, para escrever do zero. */
  const newBlank = async () => {
    try {
      const id = await createBlock();
      onChanged();
      load().catch(() => {});
      onOpen(id);
    } catch (e) {
      appAlert('Não consegui criar a nota', String(e));
    }
  };

  /** O "+" pergunta como começar a nota. */
  const newNote = () => {
    appAlert('Nova nota', undefined, [
      { text: 'Nota em branco', onPress: () => newBlank() },
      { text: 'A partir de imagem', onPress: () => newFromImage().catch(() => {}) },
      { text: 'Cancelar', style: 'cancel' },
    ]);
  };

  const refresh = () => {
    load().catch(() => {});
    onChanged();
  };

  const onLongPress = (item: SelItem) => {
    const block = blocks?.find((x) => x.id === item.id);
    if (block) setMenuFor(block);
  };

  const confirmDelete = (block: Block) => {
    const name = block.noteTitle || block.name;
    appAlert('Apagar nota?', `"${name}" e todos os áudios dentro dela serão apagados.`, [
      { text: 'Cancelar', style: 'cancel' },
      {
        text: 'Apagar',
        style: 'destructive',
        onPress: async () => {
          try {
            await deleteBlock(block.id);
          } catch (e) {
            appAlert('Não foi possível apagar', String(e));
          }
          refresh();
        },
      },
    ]);
  };

  // ---- janelas ----
  const catsItems: SheetItem[] =
    cats.length === 0
      ? [{ key: 'empty', label: 'Nenhuma categoria ainda', muted: true }]
      : cats.map((c) => ({
          key: String(c.id),
          label: c.name,
          color: c.color,
          onPress: () => {
            setSheet(null);
            setCatDialog({ cat: c });
          },
        }));

  // O Alert do Android só mostra 3 botões, por isso o menu da nota é uma janela própria.
  const menuItems: SheetItem[] = menuFor
    ? [
        {
          key: 'cat',
          label: 'Categoria',
          onPress: () => {
            const b = menuFor;
            setMenuFor(null);
            setAssignFor(b);
          },
        },
        {
          key: 'pin',
          label: menuFor.pinned ? 'Desafixar do topo' : 'Fixar no topo',
          onPress: async () => {
            const b = menuFor;
            setMenuFor(null);
            await setPinned(b.id, !b.pinned);
            refresh();
          },
        },
        {
          key: 'tags',
          label: 'Tags',
          onPress: () => {
            const b = menuFor;
            setMenuFor(null);
            setTagsFor(b);
          },
        },
        {
          key: 'rename',
          label: 'Renomear',
          onPress: () => {
            const b = menuFor;
            setMenuFor(null);
            setRenaming(b);
          },
        },
        {
          key: 'delete',
          label: 'Apagar',
          selected: true, // texto vermelho
          onPress: () => {
            const b = menuFor;
            setMenuFor(null);
            confirmDelete(b);
          },
        },
      ]
    : [];

  const assignItems: SheetItem[] =
    cats.length === 0
      ? [{ key: 'empty', label: 'Crie uma categoria primeiro', muted: true }]
      : cats.map((c) => ({
          key: String(c.id),
          label: c.name,
          color: c.color,
          selected: assignFor?.categoryId === c.id,
          onPress: async () => {
            if (assignFor) await setBlockCategory(assignFor.id, c.id);
            setAssignFor(null);
            refresh();
          },
        }));

  if (blocks === null) return <View style={styles.flex} />;

  const filterActive = countActive(filters) > 0;
  const emptyText =
    terms.length > 0
      ? 'Nenhuma nota encontrada.'
      : filterActive
      ? 'Nenhuma nota com esses filtros.'
      : 'Nada por aqui ainda. Grave seu primeiro áudio na aba Gravação.';
  const activeChips: { key: string; label: string; clear: () => void }[] = [];
  if (filters.category !== null)
    activeChips.push({
      key: 'cat',
      label: filters.category === 0 ? 'Sem categoria' : cats.find((c) => c.id === filters.category)?.name ?? 'Categoria',
      clear: () => setFilters((f) => ({ ...f, category: null })),
    });
  for (const t of filters.tags)
    activeChips.push({
      key: `tag-${t}`,
      label: allTags.find((x) => x.key === t)?.name ?? t,
      clear: () => setFilters((f) => ({ ...f, tags: f.tags.filter((x) => x !== t) })),
    });
  if (filters.favoritesOnly) activeChips.push({ key: 'fav', label: 'Favoritas', clear: () => setFilters((f) => ({ ...f, favoritesOnly: false })) });
  if (filters.period)
    activeChips.push({
      key: 'period',
      label: `${filters.dateBase === 'created' ? 'Criada' : 'Editada'}: ${PERIOD_LABEL[filters.period]}`,
      clear: () => setFilters((f) => ({ ...f, period: null })),
    });
  if (filters.pendingTasks) activeChips.push({ key: 'tasks', label: 'Tarefas pendentes', clear: () => setFilters((f) => ({ ...f, pendingTasks: false })) });
  for (const c of filters.content)
    activeChips.push({ key: `c-${c}`, label: `Tem ${CONTENT_LABEL[c].toLowerCase()}`, clear: () => setFilters((f) => ({ ...f, content: f.content.filter((x) => x !== c) })) });
  const lineColor = filterActive ? colors.red : colors.text;
  const iconW = sw * 0.045;
  const headerTop = insets.top + sw * 0.1;

  return (
    <View style={styles.flex}>
      {view === 'grid' ? (
        <LibraryGrid
          blocks={shown}
          top={headerTop + sw * (activeChips.length > 0 ? 0.23 : 0.14)}
          colorOf={colorOf}
          snippetOf={snippetOf}
          onOpen={(b) => onOpen(b.id)}
          onLongPress={setMenuFor}
          emptyText={emptyText}
        />
      ) : (
      <SelectorList
        key={`${JSON.stringify(filters)}-${sort.key}${sort.dir}-${terms.join(' ')}-${shown.length === 0 ? 'empty' : 'list'}`}
        ref={listRef}
        data={items}
        emptyText={emptyText}
        onFocusIndex={() => {}}
        onPressFocused={(item) => onOpen(item.id)}
        onLongPressFocused={onLongPress}
      />
      )}

      {!searching && activeChips.length > 0 && (
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
          style={{ position: 'absolute', top: headerTop + sw * 0.1, left: sw * 0.163, right: sw * 0.06, maxHeight: sw * 0.1 }}
          contentContainerStyle={{ gap: sw * SPACE.sm, alignItems: 'center' }}
        >
          {activeChips.map((c) => (
            <Pressable key={c.key} onPress={c.clear} hitSlop={6} style={{ borderRadius: sw * 0.07, borderWidth: 1, borderColor: colors.red, paddingHorizontal: sw * SPACE.md, paddingVertical: sw * 0.012 }}>
              <Text style={{ color: colors.text, fontFamily: fonts.regular, fontSize: sw * TYPE.caption }}>{`${c.label}  ✕`}</Text>
            </Pressable>
          ))}
          <Pressable onPress={() => setFilters(NO_FILTERS)} hitSlop={8}>
            <Text style={{ color: colors.red, fontFamily: fonts.bold, fontSize: sw * TYPE.caption }}>Limpar tudo</Text>
          </Pressable>
        </ScrollView>
      )}

      {!searching && (
      <Pressable
        onPress={() => setSheet('cats')}
        hitSlop={14}
        style={{ position: 'absolute', top: headerTop, left: sw * 0.163 }}
      >
        <Text
          style={{
            color: colors.red,
            fontFamily: fonts.bold,
            fontSize: sw * TYPE.subtitle,
            letterSpacing: -sw * 0.05 * 0.045,
          }}
        >
          Categorias
        </Text>
      </Pressable>
      )}

      {!searching && (
      <Pressable
        onPress={() => setSearching(true)}
        hitSlop={18}
        style={{
          position: 'absolute',
          top: headerTop + sw * 0.004,
          right: sw * 0.2275 + iconW + sw * 0.065,
          width: iconW,
          height: iconW,
        }}
      >
        <View
          style={{
            width: iconW * 0.72,
            height: iconW * 0.72,
            borderRadius: iconW * 0.36,
            borderWidth: sw * 0.0055,
            borderColor: colors.text,
          }}
        />
        <View
          style={{
            position: 'absolute',
            right: 0,
            bottom: iconW * 0.16,
            width: iconW * 0.47,
            height: sw * 0.0055,
            borderRadius: sw * 0.003,
            backgroundColor: colors.text,
            transform: [{ rotate: '45deg' }],
          }}
        />
      </Pressable>
      )}

      {searching && (
        <View
          style={{
            position: 'absolute',
            top: headerTop - sw * 0.012,
            left: sw * 0.163,
            right: sw * 0.163,
            flexDirection: 'row',
            alignItems: 'center',
            borderBottomWidth: 2,
            borderBottomColor: colors.red,
          }}
        >
          <TextInput
            autoFocus
            value={query}
            onChangeText={setQuery}
            placeholder="Buscar nas notas"
            placeholderTextColor={colors.muted}
            returnKeyType="search"
            onSubmitEditing={() => Keyboard.dismiss()}
            autoCorrect={false}
            selectionColor={colors.red}
            style={{
              flex: 1,
              color: colors.text,
              fontFamily: fonts.bold,
              fontSize: sw * TYPE.subtitle,
              letterSpacing: -sw * 0.05 * 0.045,
              paddingVertical: sw * SPACE.xs,
              paddingHorizontal: 0,
            }}
          />
          <Pressable onPress={closeSearch} hitSlop={16} style={{ paddingLeft: sw * SPACE.sm }}>
            <Icon name="close" size={sw * 0.05} color={colors.muted} />
          </Pressable>
        </View>
      )}

      {!searching && (
      <Pressable
        onPress={newNote}
        hitSlop={14}
        accessibilityLabel="Nova nota"
        style={{ position: 'absolute', top: headerTop - sw * 0.016, right: sw * 0.06 }}
      >
        <Text style={{ color: colors.red, fontFamily: fonts.light, fontSize: sw * TYPE.heading, lineHeight: sw * 0.085 }}>+</Text>
      </Pressable>
      )}

      {reading && (
        <View
          style={{
            ...StyleSheet.absoluteFillObject,
            backgroundColor: colors.scrimSoft,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <StateMessage kind="loading" centered>Lendo a imagem…</StateMessage>
        </View>
      )}

      {!searching && (
      <Pressable
        onPress={() => setFilterOpen(true)}
        hitSlop={18}
        style={{
          position: 'absolute',
          top: headerTop + sw * 0.012,
          right: sw * 0.2275,
          width: iconW,
          alignItems: 'center',
          gap: sw * 0.0075,
        }}
      >
        {[1, 0.75, 0.46].map((w, i) => (
          <View
            key={i}
            style={{
              width: iconW * w,
              height: sw * 0.0055,
              borderRadius: sw * 0.003,
              backgroundColor: lineColor,
            }}
          />
        ))}
      </Pressable>
      )}

      <BottomSheet
        visible={menuFor !== null}
        onClose={() => setMenuFor(null)}
        title={menuFor?.favorite ? 'Remover dos favoritos' : 'Adicionar aos favoritos'}
        onTitlePress={async () => {
          const b = menuFor;
          setMenuFor(null);
          if (b) {
            await setFavorite(b.id, !b.favorite);
            onChanged();
          }
        }}
        subtitle={(() => {
          const n = menuFor ? menuFor.noteTitle || menuFor.name : '';
          return n.length > 36 ? `${n.slice(0, 36)}…` : n;
        })()}
        items={menuItems}
        separators
      />

      <BottomSheet
        visible={sheet === 'cats'}
        onClose={() => setSheet(null)}
        title="Criar categoria"
        onTitlePress={() => {
          setSheet(null);
          setCatDialog({ cat: null });
        }}
        subtitle="Editar categorias"
        items={catsItems}
        separators
      />

      <LibraryFilterSheet
        visible={filterOpen}
        onClose={() => setFilterOpen(false)}
        cats={cats}
        tags={allTags}
        filters={filters}
        onFilters={setFilters}
        sort={sort}
        onSort={chooseSort}
        view={view}
        onView={chooseView}
        count={shown.length}
      />

      <TagsDialog
        visible={tagsFor !== null}
        current={tagsFor?.tags ?? []}
        existing={allTags}
        onCancel={() => setTagsFor(null)}
        onSave={async (tags) => {
          const b = tagsFor;
          setTagsFor(null);
          if (b) await setBlockTags(b.id, tags);
          refresh();
        }}
      />

      <BottomSheet
        visible={assignFor !== null}
        onClose={() => setAssignFor(null)}
        title="Sem categoria"
        onTitlePress={async () => {
          if (assignFor) await setBlockCategory(assignFor.id, null);
          setAssignFor(null);
          refresh();
        }}
        subtitle="Escolher categoria"
        items={assignItems}
        separators
      />

      <CategoryDialog
        visible={catDialog !== null}
        category={catDialog?.cat ?? null}
        onCancel={() => setCatDialog(null)}
        onSave={async (name, color) => {
          const target = catDialog?.cat;
          if (target) await updateCategory(target.id, name, color);
          else await createCategory(name, color);
          setCatDialog(null);
          refresh();
        }}
        onDelete={(cat) =>
          appAlert('Excluir categoria?', `"${cat.name}" será removida. As notas ficam sem categoria.`, [
            { text: 'Cancelar', style: 'cancel' },
            {
              text: 'Excluir',
              style: 'destructive',
              onPress: async () => {
                await deleteCategory(cat.id);
                setCatDialog(null);
                refresh();
              },
            },
          ])
        }
      />

      <PromptDialog
        visible={renaming !== null}
        title="Renomear nota"
        initialValue={renaming ? renaming.noteTitle || renaming.name : ''}
        onCancel={() => setRenaming(null)}
        onSubmit={async (value) => {
          if (renaming) {
            const note = parseNote(await getNoteJson(renaming.id)) ?? emptyNote();
            await saveNoteJson(renaming.id, JSON.stringify({ ...note, title: value.trim() }));
          }
          setRenaming(null);
          onChanged();
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: 'transparent' },
});
