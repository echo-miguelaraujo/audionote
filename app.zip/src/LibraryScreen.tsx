import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { appAlert } from './dialog';
import {
  ActivityIndicator,
  BackHandler,
  Keyboard,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
  useWindowDimensions,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { BottomSheet, SheetItem } from './BottomSheet';
import { CategoryDialog } from './CategoryDialog';
import {
  Block,
  Category,
  createBlock,
  createCategory,
  deleteBlock,
  deleteCategory,
  getNoteJson,
  listBlocks,
  listCategories,
  saveNoteJson,
  setBlockCategory,
  setFavorite,
  updateCategory,
} from './db';
import { askImages, noteFromImage, readPickedImages } from './imageNote';
import { emptyNote, parseNote } from './note';
import { PromptDialog } from './PromptDialog';
import { SelectorHandle, SelectorList, SelItem } from './SelectorList';
import { colors, fonts } from './theme';

type Props = {
  version: number;
  onOpen: (blockId: number) => void;
  onChanged: () => void;
};

/** Filtro: null = todas as notas, 0 = sem categoria, outro número = id da categoria. */
type Filter = number | null;

/** Minúsculas e sem acento, mantendo o mesmo tamanho do texto (para achar o trecho certo). */
function fold(s: string): string {
  try {
    return s.replace(/[\u00C0-\u024F]/g, (c) => c.normalize('NFD')[0]).toLowerCase();
  } catch {
    return s.toLowerCase();
  }
}

/** Pedaço do texto em volta da palavra encontrada, para mostrar na lista de resultados. */
function snippet(body: string, foldedBody: string, term: string): string {
  const i = foldedBody.indexOf(term);
  if (i < 0) return '';
  const start = Math.max(0, i - 25);
  const s = body.slice(start, i + term.length + 70).replace(/\s+/g, ' ').trim();
  return (start > 0 ? '…' : '') + s;
}

export function LibraryScreen({ version, onOpen, onChanged }: Props) {
  const { width: sw } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const [blocks, setBlocks] = useState<Block[] | null>(null);
  const [cats, setCats] = useState<Category[]>([]);
  const [filter, setFilter] = useState<Filter>(null);
  const [sheet, setSheet] = useState<'cats' | 'filter' | null>(null);
  const [catDialog, setCatDialog] = useState<{ cat: Category | null } | null>(null);
  const [assignFor, setAssignFor] = useState<Block | null>(null);
  const [renaming, setRenaming] = useState<Block | null>(null);
  const [menuFor, setMenuFor] = useState<Block | null>(null);
  const [searching, setSearching] = useState(false);
  const [query, setQuery] = useState('');
  const listRef = useRef<SelectorHandle>(null);

  const closeSearch = useCallback(() => {
    setSearching(false);
    setQuery('');
    Keyboard.dismiss();
  }, []);

  // Botão voltar do Android fecha a busca antes de sair da Biblioteca.
  useEffect(() => {
    if (!searching) return;
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      closeSearch();
      return true;
    });
    return () => sub.remove();
  }, [searching, closeSearch]);

  const load = useCallback(async () => {
    const [b, c] = await Promise.all([listBlocks(), listCategories()]);
    setBlocks(b);
    setCats(c);
  }, []);

  useEffect(() => {
    load().catch((e) => appAlert('Erro ao ler a Biblioteca', String(e)));
  }, [load, version]);

  // Se a categoria do filtro foi apagada, volta a mostrar tudo.
  useEffect(() => {
    if (filter !== null && filter !== 0 && !cats.some((c) => c.id === filter)) setFilter(null);
  }, [cats, filter]);

  const colorOf = useCallback(
    (id: number | null) => cats.find((c) => c.id === id)?.color ?? null,
    [cats]
  );

  const terms = useMemo(() => fold(query).split(/\s+/).filter(Boolean), [query]);

  // Texto sem acento de cada nota, calculado só quando a lista muda (não a cada letra digitada).
  const index = useMemo(() => {
    const m = new Map<number, { head: string; body: string }>();
    for (const b of blocks ?? []) m.set(b.id, { head: fold(`${b.noteTitle} ${b.name}`), body: fold(b.body) });
    return m;
  }, [blocks]);

  const shown = useMemo(() => {
    let all = blocks ?? [];
    if (filter === 0) all = all.filter((b) => b.categoryId === null);
    else if (filter !== null) all = all.filter((b) => b.categoryId === filter);
    if (terms.length === 0) return all;
    // Todas as palavras digitadas precisam aparecer no título ou no texto da nota.
    return all.filter((b) => {
      const ix = index.get(b.id);
      return !!ix && terms.every((t) => ix.head.includes(t) || ix.body.includes(t));
    });
  }, [blocks, filter, terms, index]);

  // Título = assunto da nota; subtítulo = começo do texto; barrinha = cor da categoria.
  const items: SelItem[] = useMemo(
    () =>
      shown.map((b) => {
        // Na busca, mostra o trecho onde a palavra aparece.
        let snip = '';
        if (terms.length > 0) {
          const ix = index.get(b.id);
          const t = ix ? terms.find((w) => ix.body.includes(w)) : undefined;
          if (ix && t) snip = snippet(b.body, ix.body, t);
        }
        return {
          id: b.id,
          title: `${b.favorite ? '★ ' : ''}${b.noteTitle || (b.pendingCount > 0 ? 'Transcrevendo…' : b.name)}`,
          subtitle: snip || b.preview || (b.pendingCount > 0 ? 'Aguardando a transcrição…' : 'Nota vazia'),
          color: colorOf(b.categoryId),
        };
      }),
    [shown, colorOf, terms, index]
  );

  const [reading, setReading] = useState(false);

  /** Foto de caderno / print -> nota nova com o texto lido pela IA. */
  const newFromImage = async () => {
    if (reading) return;
    const imgs = await askImages('Nova nota a partir de imagem');
    if (!imgs) return;
    setReading(true);
    try {
      const res = await readPickedImages(imgs, []);
      if (!res.ok) {
        appAlert('Não consegui ler a imagem', res.message);
        return;
      }
      const id = await createBlock();
      await saveNoteJson(id, JSON.stringify(noteFromImage(res)));
      onChanged();
      load().catch(() => {});
      onOpen(id);
    } catch (e) {
      appAlert('Não consegui criar a nota', String(e));
    } finally {
      setReading(false);
    }
  };

  /** Nota nova em branco, para escrever do zero. */
  const newBlank = async () => {
    try {
      const id = await createBlock();
      onChanged();
      load().catch(() => {});
      onOpen(id);
    } catch (e) {
      appAlert('Não consegui criar a nota', String(e));
    }
  };

  /** O "+" pergunta como começar a nota. */
  const newNote = () => {
    appAlert('Nova nota', undefined, [
      { text: 'Nota em branco', onPress: () => newBlank() },
      { text: 'A partir de imagem', onPress: () => newFromImage().catch(() => {}) },
      { text: 'Cancelar', style: 'cancel' },
    ]);
  };

  const refresh = () => {
    load().catch(() => {});
    onChanged();
  };

  const onLongPress = (item: SelItem) => {
    const block = blocks?.find((x) => x.id === item.id);
    if (block) setMenuFor(block);
  };

  const confirmDelete = (block: Block) => {
    const name = block.noteTitle || block.name;
    appAlert('Apagar nota?', `"${name}" e todos os áudios dentro dela serão apagados.`, [
      { text: 'Cancelar', style: 'cancel' },
      {
        text: 'Apagar',
        style: 'destructive',
        onPress: async () => {
          try {
            await deleteBlock(block.id);
          } catch (e) {
            appAlert('Não foi possível apagar', String(e));
          }
          refresh();
        },
      },
    ]);
  };

  // ---- janelas ----
  const catsItems: SheetItem[] =
    cats.length === 0
      ? [{ key: 'empty', label: 'Nenhuma categoria ainda', muted: true }]
      : cats.map((c) => ({
          key: String(c.id),
          label: c.name,
          color: c.color,
          onPress: () => {
            setSheet(null);
            setCatDialog({ cat: c });
          },
        }));

  const filterItems: SheetItem[] = [
    {
      key: 'none',
      label: 'Sem categoria',
      selected: filter === 0,
      onPress: () => {
        setFilter(0);
        setSheet(null);
      },
    },
    ...cats.map((c) => ({
      key: String(c.id),
      label: c.name,
      color: c.color,
      selected: filter === c.id,
      onPress: () => {
        setFilter(c.id);
        setSheet(null);
      },
    })),
  ];

  // O Alert do Android só mostra 3 botões, por isso o menu da nota é uma janela própria.
  const menuItems: SheetItem[] = menuFor
    ? [
        {
          key: 'cat',
          label: 'Categoria',
          onPress: () => {
            const b = menuFor;
            setMenuFor(null);
            setAssignFor(b);
          },
        },
        {
          key: 'rename',
          label: 'Renomear',
          onPress: () => {
            const b = menuFor;
            setMenuFor(null);
            setRenaming(b);
          },
        },
        {
          key: 'delete',
          label: 'Apagar',
          selected: true, // texto vermelho
          onPress: () => {
            const b = menuFor;
            setMenuFor(null);
            confirmDelete(b);
          },
        },
      ]
    : [];

  const assignItems: SheetItem[] =
    cats.length === 0
      ? [{ key: 'empty', label: 'Crie uma categoria primeiro', muted: true }]
      : cats.map((c) => ({
          key: String(c.id),
          label: c.name,
          color: c.color,
          selected: assignFor?.categoryId === c.id,
          onPress: async () => {
            if (assignFor) await setBlockCategory(assignFor.id, c.id);
            setAssignFor(null);
            refresh();
          },
        }));

  if (blocks === null) return <View style={styles.flex} />;

  const filterActive = filter !== null;
  const lineColor = filterActive ? colors.red : colors.text;
  const iconW = sw * 0.045;
  const headerTop = insets.top + sw * 0.1;

  return (
    <View style={styles.flex}>
      <SelectorList
        key={`${filter}-${terms.join(' ')}-${shown.length === 0 ? 'empty' : 'list'}`}
        ref={listRef}
        data={items}
        emptyText={
          terms.length > 0
            ? 'Nenhuma nota encontrada.'
            : filterActive
            ? 'Nenhuma nota nessa categoria.'
            : 'Nada por aqui ainda. Grave seu primeiro áudio na aba Gravação.'
        }
        onFocusIndex={() => {}}
        onPressFocused={(item) => onOpen(item.id)}
        onLongPressFocused={onLongPress}
      />

      {!searching && (
      <Pressable
        onPress={() => setSheet('cats')}
        hitSlop={14}
        style={{ position: 'absolute', top: headerTop, left: sw * 0.163 }}
      >
        <Text
          style={{
            color: colors.red,
            fontFamily: fonts.bold,
            fontSize: sw * 0.05,
            letterSpacing: -sw * 0.05 * 0.045,
          }}
        >
          Categorias
        </Text>
      </Pressable>
      )}

      {!searching && (
      <Pressable
        onPress={() => setSearching(true)}
        hitSlop={18}
        style={{
          position: 'absolute',
          top: headerTop + sw * 0.004,
          right: sw * 0.2275 + iconW + sw * 0.065,
          width: iconW,
          height: iconW,
        }}
      >
        <View
          style={{
            width: iconW * 0.72,
            height: iconW * 0.72,
            borderRadius: iconW * 0.36,
            borderWidth: sw * 0.0055,
            borderColor: colors.text,
          }}
        />
        <View
          style={{
            position: 'absolute',
            right: 0,
            bottom: iconW * 0.16,
            width: iconW * 0.47,
            height: sw * 0.0055,
            borderRadius: sw * 0.003,
            backgroundColor: colors.text,
            transform: [{ rotate: '45deg' }],
          }}
        />
      </Pressable>
      )}

      {searching && (
        <View
          style={{
            position: 'absolute',
            top: headerTop - sw * 0.012,
            left: sw * 0.163,
            right: sw * 0.163,
            flexDirection: 'row',
            alignItems: 'center',
            borderBottomWidth: 2,
            borderBottomColor: colors.red,
          }}
        >
          <TextInput
            autoFocus
            value={query}
            onChangeText={setQuery}
            placeholder="Buscar nas notas"
            placeholderTextColor={colors.gray}
            returnKeyType="search"
            onSubmitEditing={() => Keyboard.dismiss()}
            autoCorrect={false}
            selectionColor={colors.red}
            style={{
              flex: 1,
              color: colors.text,
              fontFamily: fonts.bold,
              fontSize: sw * 0.05,
              letterSpacing: -sw * 0.05 * 0.045,
              paddingVertical: sw * 0.012,
              paddingHorizontal: 0,
            }}
          />
          <Pressable onPress={closeSearch} hitSlop={16} style={{ paddingLeft: sw * 0.03 }}>
            <Text style={{ color: colors.gray, fontFamily: fonts.regular, fontSize: sw * 0.055 }}>✕</Text>
          </Pressable>
        </View>
      )}

      {!searching && (
      <Pressable
        onPress={newNote}
        hitSlop={14}
        accessibilityLabel="Nova nota"
        style={{ position: 'absolute', top: headerTop - sw * 0.016, right: sw * 0.06 }}
      >
        <Text style={{ color: colors.red, fontFamily: fonts.light, fontSize: sw * 0.085, lineHeight: sw * 0.085 }}>+</Text>
      </Pressable>
      )}

      {reading && (
        <View
          style={{
            ...StyleSheet.absoluteFillObject,
            backgroundColor: 'rgba(0,0,0,0.6)',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <ActivityIndicator color="#FFFFFF" size="large" />
          <Text style={{ color: '#FFFFFF', fontFamily: fonts.regular, fontSize: sw * 0.045, marginTop: sw * 0.04 }}>
            Lendo a imagem…
          </Text>
        </View>
      )}

      {!searching && (
      <Pressable
        onPress={() => setSheet('filter')}
        hitSlop={18}
        style={{
          position: 'absolute',
          top: headerTop + sw * 0.012,
          right: sw * 0.2275,
          width: iconW,
          alignItems: 'center',
          gap: sw * 0.0075,
        }}
      >
        {[1, 0.75, 0.46].map((w, i) => (
          <View
            key={i}
            style={{
              width: iconW * w,
              height: sw * 0.0055,
              borderRadius: sw * 0.003,
              backgroundColor: lineColor,
            }}
          />
        ))}
      </Pressable>
      )}

      <BottomSheet
        visible={menuFor !== null}
        onClose={() => setMenuFor(null)}
        title={menuFor?.favorite ? 'Remover dos favoritos' : 'Adicionar aos favoritos'}
        onTitlePress={async () => {
          const b = menuFor;
          setMenuFor(null);
          if (b) {
            await setFavorite(b.id, !b.favorite);
            onChanged();
          }
        }}
        subtitle={(() => {
          const n = menuFor ? menuFor.noteTitle || menuFor.name : '';
          return n.length > 36 ? `${n.slice(0, 36)}…` : n;
        })()}
        items={menuItems}
        separators
      />

      <BottomSheet
        visible={sheet === 'cats'}
        onClose={() => setSheet(null)}
        title="Criar categoria"
        onTitlePress={() => {
          setSheet(null);
          setCatDialog({ cat: null });
        }}
        subtitle="Editar categorias"
        items={catsItems}
        separators
      />

      <BottomSheet
        visible={sheet === 'filter'}
        onClose={() => setSheet(null)}
        title="Todas as notas"
        onTitlePress={() => {
          setFilter(null);
          setSheet(null);
        }}
        subtitle="Filtrar por categoria"
        items={filterItems}
        separators
      />

      <BottomSheet
        visible={assignFor !== null}
        onClose={() => setAssignFor(null)}
        title="Sem categoria"
        onTitlePress={async () => {
          if (assignFor) await setBlockCategory(assignFor.id, null);
          setAssignFor(null);
          refresh();
        }}
        subtitle="Escolher categoria"
        items={assignItems}
        separators
      />

      <CategoryDialog
        visible={catDialog !== null}
        category={catDialog?.cat ?? null}
        onCancel={() => setCatDialog(null)}
        onSave={async (name, color) => {
          const target = catDialog?.cat;
          if (target) await updateCategory(target.id, name, color);
          else await createCategory(name, color);
          setCatDialog(null);
          refresh();
        }}
        onDelete={(cat) =>
          appAlert('Excluir categoria?', `"${cat.name}" será removida. As notas ficam sem categoria.`, [
            { text: 'Cancelar', style: 'cancel' },
            {
              text: 'Excluir',
              style: 'destructive',
              onPress: async () => {
                await deleteCategory(cat.id);
                setCatDialog(null);
                refresh();
              },
            },
          ])
        }
      />

      <PromptDialog
        visible={renaming !== null}
        title="Renomear nota"
        initialValue={renaming ? renaming.noteTitle || renaming.name : ''}
        onCancel={() => setRenaming(null)}
        onSubmit={async (value) => {
          if (renaming) {
            const note = parseNote(await getNoteJson(renaming.id)) ?? emptyNote();
            await saveNoteJson(renaming.id, JSON.stringify({ ...note, title: value.trim() }));
          }
          setRenaming(null);
          onChanged();
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: 'transparent' },
});
