import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { BottomSheet, SheetItem } from './BottomSheet';
import { CategoryDialog } from './CategoryDialog';
import {
  Block,
  Category,
  createCategory,
  deleteBlock,
  deleteCategory,
  getNoteJson,
  listBlocks,
  listCategories,
  saveNoteJson,
  setBlockCategory,
  setFavorite,
  updateCategory,
} from './db';
import { emptyNote, parseNote } from './note';
import { PromptDialog } from './PromptDialog';
import { SelectorHandle, SelectorList, SelItem } from './SelectorList';
import { colors, fonts } from './theme';

type Props = {
  version: number;
  onOpen: (blockId: number) => void;
  onChanged: () => void;
};

/** Filtro: null = todas as notas, 0 = sem categoria, outro número = id da categoria. */
type Filter = number | null;

export function LibraryScreen({ version, onOpen, onChanged }: Props) {
  const { width: sw } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const [blocks, setBlocks] = useState<Block[] | null>(null);
  const [cats, setCats] = useState<Category[]>([]);
  const [filter, setFilter] = useState<Filter>(null);
  const [sheet, setSheet] = useState<'cats' | 'filter' | null>(null);
  const [catDialog, setCatDialog] = useState<{ cat: Category | null } | null>(null);
  const [assignFor, setAssignFor] = useState<Block | null>(null);
  const [renaming, setRenaming] = useState<Block | null>(null);
  const listRef = useRef<SelectorHandle>(null);

  const load = useCallback(async () => {
    const [b, c] = await Promise.all([listBlocks(), listCategories()]);
    setBlocks(b);
    setCats(c);
  }, []);

  useEffect(() => {
    load().catch((e) => Alert.alert('Erro ao ler a Biblioteca', String(e)));
  }, [load, version]);

  // Se a categoria do filtro foi apagada, volta a mostrar tudo.
  useEffect(() => {
    if (filter !== null && filter !== 0 && !cats.some((c) => c.id === filter)) setFilter(null);
  }, [cats, filter]);

  const colorOf = useCallback(
    (id: number | null) => cats.find((c) => c.id === id)?.color ?? null,
    [cats]
  );

  const shown = useMemo(() => {
    const all = blocks ?? [];
    if (filter === null) return all;
    if (filter === 0) return all.filter((b) => b.categoryId === null);
    return all.filter((b) => b.categoryId === filter);
  }, [blocks, filter]);

  // Título = assunto da nota; subtítulo = começo do texto; barrinha = cor da categoria.
  const items: SelItem[] = useMemo(
    () =>
      shown.map((b) => ({
        id: b.id,
        title: `${b.favorite ? '★ ' : ''}${b.noteTitle || (b.pendingCount > 0 ? 'Transcrevendo…' : b.name)}`,
        subtitle: b.preview || (b.pendingCount > 0 ? 'Aguardando a transcrição…' : 'Nota vazia'),
        color: colorOf(b.categoryId),
      })),
    [shown, colorOf]
  );

  const refresh = () => {
    load().catch(() => {});
    onChanged();
  };

  const onLongPress = (item: SelItem) => {
    const block = blocks?.find((b) => b.id === item.id);
    if (!block) return;
    const name = block.noteTitle || block.name;
    Alert.alert(name, undefined, [
      {
        text: block.favorite ? 'Remover dos favoritos' : 'Adicionar aos favoritos',
        onPress: async () => {
          await setFavorite(block.id, !block.favorite);
          onChanged();
        },
      },
      { text: 'Categoria', onPress: () => setAssignFor(block) },
      { text: 'Renomear', onPress: () => setRenaming(block) },
      {
        text: 'Apagar',
        style: 'destructive',
        onPress: () =>
          Alert.alert('Apagar item?', `"${block.name}" e todos os áudios dentro dele serão apagados.`, [
            { text: 'Cancelar', style: 'cancel' },
            {
              text: 'Apagar',
              style: 'destructive',
              onPress: async () => {
                await deleteBlock(block.id);
                onChanged();
              },
            },
          ]),
      },
      { text: 'Cancelar', style: 'cancel' },
    ]);
  };

  // ---- janelas ----
  const catsItems: SheetItem[] =
    cats.length === 0
      ? [{ key: 'empty', label: 'Nenhuma categoria ainda', muted: true }]
      : cats.map((c) => ({
          key: String(c.id),
          label: c.name,
          color: c.color,
          onPress: () => {
            setSheet(null);
            setCatDialog({ cat: c });
          },
        }));

  const filterItems: SheetItem[] = [
    {
      key: 'none',
      label: 'Sem categoria',
      selected: filter === 0,
      onPress: () => {
        setFilter(0);
        setSheet(null);
      },
    },
    ...cats.map((c) => ({
      key: String(c.id),
      label: c.name,
      color: c.color,
      selected: filter === c.id,
      onPress: () => {
        setFilter(c.id);
        setSheet(null);
      },
    })),
  ];

  const assignItems: SheetItem[] =
    cats.length === 0
      ? [{ key: 'empty', label: 'Crie uma categoria primeiro', muted: true }]
      : cats.map((c) => ({
          key: String(c.id),
          label: c.name,
          color: c.color,
          selected: assignFor?.categoryId === c.id,
          onPress: async () => {
            if (assignFor) await setBlockCategory(assignFor.id, c.id);
            setAssignFor(null);
            refresh();
          },
        }));

  if (blocks === null) return <View style={styles.flex} />;

  const filterActive = filter !== null;
  const lineColor = filterActive ? colors.red : colors.text;
  const iconW = sw * 0.045;
  const headerTop = insets.top + sw * 0.1;

  return (
    <View style={styles.flex}>
      <Pressable
        onPress={() => setSheet('cats')}
        hitSlop={14}
        style={{ position: 'absolute', top: headerTop, left: sw * 0.163 }}
      >
        <Text
          style={{
            color: colors.red,
            fontFamily: fonts.bold,
            fontSize: sw * 0.05,
            letterSpacing: -sw * 0.05 * 0.045,
          }}
        >
          Categorias
        </Text>
      </Pressable>

      <Pressable
        onPress={() => setSheet('filter')}
        hitSlop={18}
        style={{
          position: 'absolute',
          top: headerTop + sw * 0.012,
          right: sw * 0.2275,
          width: iconW,
          alignItems: 'center',
          gap: sw * 0.0075,
        }}
      >
        {[1, 0.75, 0.46].map((w, i) => (
          <View
            key={i}
            style={{
              width: iconW * w,
              height: sw * 0.0055,
              borderRadius: sw * 0.003,
              backgroundColor: lineColor,
            }}
          />
        ))}
      </Pressable>

      <SelectorList
        key={`${filter}-${shown.length === 0 ? 'empty' : 'list'}`}
        ref={listRef}
        data={items}
        emptyText={
          filterActive
            ? 'Nenhuma nota nessa categoria.'
            : 'Nada por aqui ainda. Grave seu primeiro áudio na aba Gravação.'
        }
        onFocusIndex={() => {}}
        onPressFocused={(item) => onOpen(item.id)}
        onLongPressFocused={onLongPress}
      />

      <BottomSheet
        visible={sheet === 'cats'}
        onClose={() => setSheet(null)}
        title="Criar categoria"
        onTitlePress={() => {
          setSheet(null);
          setCatDialog({ cat: null });
        }}
        subtitle="Editar categorias"
        items={catsItems}
        separators
      />

      <BottomSheet
        visible={sheet === 'filter'}
        onClose={() => setSheet(null)}
        title="Todas as notas"
        onTitlePress={() => {
          setFilter(null);
          setSheet(null);
        }}
        subtitle="Filtrar por categoria"
        items={filterItems}
        separators
      />

      <BottomSheet
        visible={assignFor !== null}
        onClose={() => setAssignFor(null)}
        title="Sem categoria"
        onTitlePress={async () => {
          if (assignFor) await setBlockCategory(assignFor.id, null);
          setAssignFor(null);
          refresh();
        }}
        subtitle="Escolher categoria"
        items={assignItems}
        separators
      />

      <CategoryDialog
        visible={catDialog !== null}
        category={catDialog?.cat ?? null}
        onCancel={() => setCatDialog(null)}
        onSave={async (name, color) => {
          const target = catDialog?.cat;
          if (target) await updateCategory(target.id, name, color);
          else await createCategory(name, color);
          setCatDialog(null);
          refresh();
        }}
        onDelete={(cat) =>
          Alert.alert('Excluir categoria?', `"${cat.name}" será removida. As notas ficam sem categoria.`, [
            { text: 'Cancelar', style: 'cancel' },
            {
              text: 'Excluir',
              style: 'destructive',
              onPress: async () => {
                await deleteCategory(cat.id);
                setCatDialog(null);
                refresh();
              },
            },
          ])
        }
      />

      <PromptDialog
        visible={renaming !== null}
        title="Renomear nota"
        initialValue={renaming ? renaming.noteTitle || renaming.name : ''}
        onCancel={() => setRenaming(null)}
        onSubmit={async (value) => {
          if (renaming) {
            const note = parseNote(await getNoteJson(renaming.id)) ?? emptyNote();
            await saveNoteJson(renaming.id, JSON.stringify({ ...note, title: value.trim() }));
          }
          setRenaming(null);
          onChanged();
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: colors.bg },
});
