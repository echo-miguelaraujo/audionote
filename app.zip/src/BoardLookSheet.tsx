import React from 'react';
import { Pressable, Text, View, useWindowDimensions } from 'react-native';
import { SheetShell } from './DialogBase';
import { SliderRow } from './SliderRow';
import { BoardMode, MIN_DIM, setBoardLook, useBoardLook } from './boardTheme';
import { colors, fonts, HIT, SPACE, TYPE } from './theme';

const MODES: { id: BoardMode; label: string; paper: string; dot: string }[] = [
  { id: 'claro', label: 'Claro', paper: '#FFFFFF', dot: 'rgba(0,0,0,0.45)' },
  { id: 'escuro', label: 'Escuro', paper: '#14161A', dot: 'rgba(255,255,255,0.4)' },
  { id: 'noturno', label: 'Noturno', paper: '#1E1610', dot: 'rgba(255,176,96,0.6)' },
];

/** Janela "Aparência do quadro": tema (claro, escuro, noturno quente) e brilho. Vale para todos os quadros. */
export function BoardLookSheet({ visible, onClose }: { visible: boolean; onClose: () => void }) {
  const { width: sw } = useWindowDimensions();
  const look = useBoardLook();
  const box = sw * 0.2;
  return (
    <SheetShell visible={visible} onClose={onClose}>
      <View style={{ padding: sw * SPACE.xl, paddingBottom: sw * SPACE.lg }}>
        <Text style={{ color: colors.onLight, fontFamily: fonts.bold, fontSize: sw * TYPE.title }}>Aparência do quadro</Text>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: sw * SPACE.lg }}>
          {MODES.map((m) => {
            const on = look.mode === m.id;
            return (
              <Pressable
                key={m.id}
                onPress={() => setBoardLook({ mode: m.id })}
                hitSlop={HIT.sm}
                accessibilityRole="button"
                accessibilityLabel={`Quadro ${m.label}`}
                accessibilityState={{ selected: on }}
                style={{ alignItems: 'center', gap: sw * SPACE.sm }}
              >
                <View
                  style={{
                    width: box,
                    height: box,
                    borderRadius: box * 0.22,
                    backgroundColor: m.paper,
                    borderWidth: on ? 3 : 1,
                    borderColor: on ? colors.red : colors.line,
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Text style={{ color: m.dot, fontFamily: fonts.bold, fontSize: box * 0.4, letterSpacing: box * 0.06 }}>···</Text>
                </View>
                <Text style={{ color: on ? colors.red : colors.onLight, fontFamily: on ? fonts.bold : fonts.regular, fontSize: sw * TYPE.label }}>
                  {m.label}
                </Text>
              </Pressable>
            );
          })}
        </View>
        <SliderRow
          label="Brilho"
          value={look.dim}
          min={MIN_DIM}
          max={1}
          display={`${Math.round(look.dim * 100)}%`}
          onChange={(v) => setBoardLook({ dim: v }, false)}
          onCommit={(v) => setBoardLook({ dim: v })}
        />
        <Text style={{ color: colors.subtle, fontFamily: fonts.regular, fontSize: sw * TYPE.caption, marginTop: sw * SPACE.md }}>
          O Noturno tira o azul da luz. O brilho escurece o quadro inteiro, inclusive os cartões brancos.
        </Text>
      </View>
    </SheetShell>
  );
}
