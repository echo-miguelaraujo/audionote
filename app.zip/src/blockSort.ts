import type { Block } from './db';
import { fold } from './tags';

export type SortKey = 'edited' | 'created' | 'name';
export type SortDir = 'asc' | 'desc';

export const DEFAULT_DIR: Record<SortKey, SortDir> = { edited: 'desc', created: 'desc', name: 'asc' };

/** Título mostrado na Biblioteca: o da nota ou, sem ele, o nome ("Nota 3"). */
export const blockTitle = (b: Block): string => b.noteTitle || b.name;

/**
 * Ordena: fixadas primeiro (sempre), depois pela chave escolhida. Não altera a lista de entrada.
 * Nome ignora acento e maiúscula; empates caem na data de criação e no id.
 */
export function sortBlocks(list: Block[], key: SortKey, dir: SortDir): Block[] {
  const sign = dir === 'asc' ? 1 : -1;
  const val = (b: Block): number | string =>
    key === 'name' ? fold(blockTitle(b)) : key === 'edited' ? b.editedAt : b.createdAt;
  return [...list].sort((a, b) => {
    if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
    const va = val(a);
    const vb = val(b);
    let c = 0;
    if (typeof va === 'string' && typeof vb === 'string') c = va.localeCompare(vb, 'pt-BR');
    else c = (va as number) - (vb as number);
    if (c !== 0) return c * sign;
    return (b.createdAt - a.createdAt) || (b.id - a.id);
  });
}
