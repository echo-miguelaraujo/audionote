import React, { useEffect, useState } from 'react';
import { Modal, Pressable, ScrollView, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { ColorWheel } from './ColorWheel';
import { fonts } from './theme';

type Props = {
  visible: boolean;
  /** Cor atual do cartão (#RRGGBB) ou null. */
  initial: string | null;
  /** Título do diálogo (padrão: "Cor do cartão"). */
  title?: string;
  /** Mostra "Sem cor" (padrão: sim). */
  allowClear?: boolean;
  /** Cores dos cartões de paleta do quadro, oferecidas primeiro. */
  palette: string[];
  onCancel: () => void;
  /** null = "Sem cor" (apaga a cor do cartão). */
  onPick: (hex: string | null) => void;
};

/** Cor do cartão: primeiro as cores da paleta do quadro, depois a roda de cores, e "Sem cor". */
export function CardColorDialog({ visible, initial, title = 'Cor do cartão', allowClear = true, palette, onCancel, onPick }: Props) {
  const { width: sw, height: sh } = useWindowDimensions();
  const start = initial ?? '#FFFFFF';
  const [color, setColor] = useState(start);

  useEffect(() => {
    if (visible) setColor(start);
  }, [visible, start]);

  const sq = sw * 0.085;
  return (
    <Modal visible={visible} transparent animationType="fade" statusBarTranslucent onRequestClose={onCancel}>
      <Pressable style={[styles.overlay, { paddingTop: sh * 0.06 }]} onPress={onCancel}>
        <Pressable
          style={{ width: sw * 0.84, maxHeight: sh * 0.88, borderRadius: sw * 0.074, padding: sw * 0.06, backgroundColor: '#FFFFFF' }}
          onPress={() => {}}
        >
          <ScrollView showsVerticalScrollIndicator={false}>
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
              <Text style={{ color: '#000', fontFamily: fonts.bold, fontSize: sw * 0.06, letterSpacing: -1 }}>{title}</Text>
              <View style={{ width: sq, height: sq, borderRadius: sq * 0.38, backgroundColor: color, borderWidth: 1, borderColor: '#C8C8C8' }} />
            </View>

            {palette.length > 0 && (
              <View style={{ marginTop: sw * 0.045 }}>
                <Text style={{ color: '#808080', fontFamily: fonts.regular, fontSize: sw * 0.036, marginBottom: sw * 0.02 }}>
                  Paleta do quadro
                </Text>
                <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: sw * 0.025 }}>
                  {palette.map((c) => (
                    <Pressable
                      key={c}
                      hitSlop={4}
                      onPress={() => onPick(c)}
                      style={{ width: sq, height: sq, borderRadius: sq * 0.38, backgroundColor: c, borderWidth: 1, borderColor: '#C8C8C8' }}
                    />
                  ))}
                </View>
              </View>
            )}

            <View style={{ marginTop: sw * 0.05 }}>
              <ColorWheel key={start} initial={start} size={sw * 0.6} onChange={setColor} />
            </View>

            <View style={styles.row}>
              {allowClear ? (
                <Pressable onPress={() => onPick(null)} hitSlop={12} style={{ marginRight: 'auto' }}>
                  <Text style={{ color: '#FF3030', fontFamily: fonts.bold, fontSize: sw * 0.045 }}>Sem cor</Text>
                </Pressable>
              ) : (
                <View style={{ marginRight: 'auto' }} />
              )}
              <Pressable onPress={onCancel} hitSlop={12}>
                <Text style={{ color: '#808080', fontFamily: fonts.bold, fontSize: sw * 0.05 }}>Cancelar</Text>
              </Pressable>
              <Pressable onPress={() => onPick(color.toUpperCase())} hitSlop={12}>
                <Text style={{ color: '#000', fontFamily: fonts.bold, fontSize: sw * 0.05 }}>Usar</Text>
              </Pressable>
            </View>
          </ScrollView>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.78)', alignItems: 'center' },
  row: { flexDirection: 'row', alignItems: 'center', gap: 28, marginTop: 28 },
});
