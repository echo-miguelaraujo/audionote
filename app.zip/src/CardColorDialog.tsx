import React, { useEffect, useState } from 'react';
import { Pressable, ScrollView, Text, View, useWindowDimensions } from 'react-native';
import { ColorWheel } from './ColorWheel';
import { ColorChip, DialogActions, DialogShell, DialogTitle } from './DialogBase';
import { colors, fonts, TYPE, SPACE } from './theme';

type Props = {
  visible: boolean;
  /** Cor atual do cartão (#RRGGBB) ou null. */
  initial: string | null;
  /** Título do diálogo (padrão: "Cor do cartão"). */
  title?: string;
  /** Mostra "Sem cor" (padrão: sim). */
  allowClear?: boolean;
  /** Cores dos cartões de paleta do quadro, oferecidas primeiro. */
  palette: string[];
  onCancel: () => void;
  /** null = "Sem cor" (apaga a cor do cartão). */
  onPick: (hex: string | null) => void;
};

/** Cor do cartão: primeiro as cores da paleta do quadro, depois a roda de cores, e "Sem cor". */
export function CardColorDialog({ visible, initial, title = 'Cor do cartão', allowClear = true, palette, onCancel, onPick }: Props) {
  const { width: sw, height: sh } = useWindowDimensions();
  const start = initial ?? colors.paper;
  const [color, setColor] = useState(start);

  useEffect(() => {
    if (visible) setColor(start);
  }, [visible, start]);

  const sq = sw * 0.085;
  return (
    <DialogShell visible={visible} onClose={onCancel} maxHeight={sh * 0.88}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
          <DialogTitle>{title}</DialogTitle>
          <ColorChip color={color} bordered />
        </View>

        {palette.length > 0 && (
          <View style={{ marginTop: sw * SPACE.md }}>
            <Text style={{ color: colors.muted, fontFamily: fonts.regular, fontSize: sw * TYPE.label, marginBottom: sw * SPACE.sm }}>
              Paleta do quadro
            </Text>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: sw * SPACE.sm }}>
              {palette.map((c) => (
                <Pressable
                  key={c}
                  hitSlop={4}
                  onPress={() => onPick(c)}
                  style={{ width: sq, height: sq, borderRadius: sq * 0.38, backgroundColor: c, borderWidth: 1, borderColor: colors.line }}
                />
              ))}
            </View>
          </View>
        )}

        <View style={{ marginTop: sw * SPACE.lg }}>
          <ColorWheel key={start} initial={start} size={sw * 0.6} onChange={setColor} />
        </View>

        <DialogActions
          onCancel={onCancel}
          confirmLabel="Usar"
          onConfirm={() => onPick(color.toUpperCase())}
          extra={allowClear ? { label: 'Sem cor', onPress: () => onPick(null) } : undefined}
        />
      </ScrollView>
    </DialogShell>
  );
}
