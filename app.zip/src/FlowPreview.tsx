import React, { useRef } from 'react';
import { StyleSheet, View } from 'react-native';
import { WebView, WebViewMessageEvent } from 'react-native-webview';
import { Background } from './Background';
import { EDITOR_HTML } from './editorHtml';
import { ScreenHeader } from './ScreenHeader';
import { colors } from './theme';

type Props = { title: string; html: string; onClose: () => void };

const lit = (v: unknown) =>
  JSON.stringify(v).replace(/</g, '\\u003c').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');

/** Prévia somente leitura da versão em nota corrida, sem trocar o layout da nota. */
export function FlowPreview({ title, html, onClose }: Props) {
  const web = useRef<WebView>(null);

  const onMessage = (e: WebViewMessageEvent) => {
    try {
      const m = JSON.parse(e.nativeEvent.data);
      if (m && m.type === 'ready') {
        web.current?.injectJavaScript(`window.initNote(${lit({ title, html, cover: null, editable: false, recent: [] })});true;`);
      }
    } catch {
      /* mensagem inválida: ignora */
    }
  };

  return (
    <View style={styles.root}>
      <Background />
      <ScreenHeader onBack={onClose} title="Como nota corrida" />
      <View style={styles.flex}>
        <WebView
          ref={web}
          originWhitelist={['*']}
          source={{ html: EDITOR_HTML, baseUrl: 'file:///' }}
          onMessage={onMessage}
          javaScriptEnabled
          allowFileAccess
          allowFileAccessFromFileURLs
          allowUniversalAccessFromFileURLs
          mixedContentMode="always"
          setSupportMultipleWindows={false}
          textZoom={100}
          overScrollMode="never"
          onShouldStartLoadWithRequest={(r) => r.url.startsWith('file:') || r.url.startsWith('about:')}
          style={{ backgroundColor: colors.bg }}
          containerStyle={{ backgroundColor: colors.bg }}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { ...StyleSheet.absoluteFillObject, backgroundColor: colors.bg, zIndex: 61 },
  flex: { flex: 1 },
});
