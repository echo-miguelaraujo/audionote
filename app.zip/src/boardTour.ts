import type { MoodItem } from './db';
import { itemBounds, unionBounds } from './boardGeometry';

/** Câmera do quadro: deslocamento (px) e zoom. */
export type View2 = { tx: number; ty: number; z: number };
type Sizes = Record<number, { w: number; h: number }>;

const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));

/**
 * Visão geral: enquadra todos os itens (já girados, tamanho medido) com uma margem de 0.08 u.
 * Lista vazia → null. O zoom nunca passa de `maxZoom` (1 = tamanho natural). Quem chama ainda aplica o clamp do mundo.
 */
export function fitStop(
  items: MoodItem[],
  sizes: Sizes,
  u: number,
  sw: number,
  sh: number,
  minZoom: number,
  maxZoom = 1
): View2 | null {
  const r = unionBounds(items, sizes, u, 0.08);
  if (!r) return null;
  const bw = r.w * u;
  const bh = r.h * u;
  const z = clamp(Math.min(sw / bw, (sh * 0.85) / bh, maxZoom), minZoom, maxZoom);
  const cx = (r.x + r.w / 2) * u;
  const cy = (r.y + r.h / 2) * u;
  return { z, tx: sw / 2 - cx * z, ty: sh / 2 - cy * z };
}

/**
 * Foco num item: ele ocupa ~70% do lado limitante da tela, centralizado (considera o giro).
 * Com legenda, o item sobe um pouco e ocupa menos, para não ficar atrás da faixa do rodapé.
 */
export function focusStop(
  item: MoodItem,
  sizes: Sizes,
  u: number,
  sw: number,
  sh: number,
  minZoom: number,
  maxZoom: number,
  hasCaption: boolean
): View2 {
  const b = itemBounds(item, sizes, u);
  const bw = Math.max(1, b.w * u);
  const bh = Math.max(1, b.h * u);
  const frac = hasCaption ? 0.6 : 0.7;
  const z = clamp(Math.min((sw * 0.7) / bw, (sh * frac) / bh), minZoom, maxZoom);
  const cx = (b.x + b.w / 2) * u;
  const cy = (b.y + b.h / 2) * u;
  const screenCy = hasCaption ? sh * 0.42 : sh * 0.5;
  return { z, tx: sw / 2 - cx * z, ty: screenCy - cy * z };
}
