import React from 'react';
import { View } from 'react-native';
import { SettingRow } from './SettingRow';
import { setPerf, usePerf } from './perf';

/** Liga o painel de diagnóstico de desempenho que aparece sobre o quadro do moodboard. */
export function PerfSection() {
  const f = usePerf();
  return (
    <View>
      <SettingRow
        label="Mostrar diagnóstico no quadro"
        hint="Mostra FPS e permite desligar a grade e as imagens para descobrir o que deixa o quadro lento."
        checked={f.hud}
        onPress={() => setPerf({ hud: !f.hud })}
      />
    </View>
  );
}
