// Ficha do moodboard: cartão solto no quadro, com texto corrido (formatado) ou campos para preencher.

export type FichaField = { id: string; label: string; value: string };
export type Ficha = {
  title: string;
  mode: 'text' | 'fields';
  /** Texto corrido: HTML do editor do quadro (negrito, tamanho, cor). */
  html: string;
  fields: FichaField[];
  /** Ficha vinculada: uuid do item do quadro a que ela está grudada (vazio = solta). */
  link?: string;
};

/** Largura da ficha no quadro (fração da largura do mundo, como o w dos outros cartões). */
export const FICHA_W = 0.62;

export const newFichaId = (): string => Math.random().toString(36).slice(2, 8);

export const emptyFicha = (): Ficha => ({ title: '', mode: 'text', html: '', fields: [] });

export function parseFicha(content: string): Ficha {
  try {
    const j = JSON.parse(content);
    return {
      title: typeof j.title === 'string' ? j.title : '',
      mode: j.mode === 'fields' ? 'fields' : 'text',
      html: typeof j.html === 'string' ? j.html : '',
      fields: Array.isArray(j.fields)
        ? j.fields.map((f: any) => ({
            id: typeof f?.id === 'string' && f.id ? f.id : newFichaId(),
            label: typeof f?.label === 'string' ? f.label : '',
            value: typeof f?.value === 'string' ? f.value : '',
          }))
        : [],
      link: typeof j.link === 'string' && j.link ? j.link : undefined,
    };
  } catch {
    return emptyFicha();
  }
}

export const stringifyFicha = (f: Ficha): string => JSON.stringify(f);

/** Ficha sem nada escrito: não vale a pena criar. */
export const fichaIsEmpty = (f: Ficha): boolean =>
  !f.title.trim() && !f.html.replace(/<[^>]*>/g, '').trim() && f.fields.every((x) => !x.label.trim() && !x.value.trim());
