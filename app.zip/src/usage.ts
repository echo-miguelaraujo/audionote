import { getSetting, setSetting } from './settings';

/**
 * Medição de tokens do Gemini: cada chamada soma o `usageMetadata` num contador por mês e por tipo
 * (áudio, imagem, reorganizar). Fica só no aparelho (tabela meta), sem schema novo.
 */

export type UsageKind = 'audio' | 'image' | 'restructure' | 'other';
export type UsageBucket = { calls: number; input: number; output: number; thoughts: number };
export type UsageMonth = Partial<Record<UsageKind, UsageBucket>>;

const keyFor = (d = new Date()) => `ai_usage_${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;

let chain: Promise<void> = Promise.resolve();

/** Registra o consumo de uma chamada (nunca lança erro e nunca atrasa a chamada principal). */
export function recordUsage(kind: UsageKind, meta: any): void {
  if (!meta || typeof meta !== 'object') return;
  const input = Number(meta.promptTokenCount) || 0;
  const output = Number(meta.candidatesTokenCount) || 0;
  const thoughts = Number(meta.thoughtsTokenCount) || 0;
  chain = chain
    .then(async () => {
      const key = keyFor();
      let cur: UsageMonth = {};
      try {
        cur = JSON.parse((await getSetting(key)) ?? '{}');
      } catch {}
      const b = cur[kind] ?? { calls: 0, input: 0, output: 0, thoughts: 0 };
      cur[kind] = { calls: b.calls + 1, input: b.input + input, output: b.output + output, thoughts: b.thoughts + thoughts };
      await setSetting(key, JSON.stringify(cur));
    })
    .catch(() => {});
}

export async function loadUsage(d = new Date()): Promise<UsageMonth> {
  try {
    return JSON.parse((await getSetting(keyFor(d))) ?? '{}');
  } catch {
    return {};
  }
}

export const USAGE_LABELS: Record<UsageKind, string> = {
  audio: 'Áudios',
  image: 'Imagens',
  restructure: 'Reorganizar',
  other: 'Outros',
};
