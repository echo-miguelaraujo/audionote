import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Keyboard, Pressable, ScrollView, Text, TextInput, View, useWindowDimensions } from 'react-native';
import { SheetShell } from './DialogBase';
import { colors, fonts, HIT, SPACE, TYPE } from './theme';
import { useKeyboardInset } from './useKeyboardInset';

export type SceneInfo = {
  name: string;
  desc: string;
  place: string;
  emotion: string;
  duration: string;
  shot: string;
  dialogue: string;
  date: string;
};
export type SceneField = keyof SceneInfo;
/** Campo da tela -> propriedade da coleção (o título é à parte: renameCollection). */
export const SCENE_FIELD_KEY = {
  desc: 'sceneDesc',
  place: 'scenePlace',
  emotion: 'sceneEmotion',
  duration: 'sceneDuration',
  shot: 'sceneShot',
  dialogue: 'sceneDialogue',
  date: 'sceneDate',
} as const;

export const SCENE_LABELS: { key: SceneField; label: string; placeholder: string; multiline?: boolean }[] = [
  { key: 'name', label: 'Título', placeholder: 'Título da cena' },
  { key: 'desc', label: 'Descrição curta', placeholder: 'O que acontece nesta cena', multiline: true },
  { key: 'place', label: 'Local', placeholder: 'Onde se passa' },
  { key: 'emotion', label: 'Emoção', placeholder: 'Que sensação passar' },
  { key: 'duration', label: 'Duração', placeholder: 'Ex.: 30 s' },
  { key: 'shot', label: 'Plano', placeholder: 'Close, aberto, POV...' },
  { key: 'dialogue', label: 'Falas', placeholder: 'O que será dito', multiline: true },
  { key: 'date', label: 'Data de gravação', placeholder: 'Ex.: 25/10' },
];

/**
 * Janela de baixo com os campos da cena (como as outras janelas do app). Cada campo grava
 * sozinho: ao terminar de digitar, ao sair do campo e ao fechar a janela.
 */
export function SceneSheet({
  visible,
  onClose,
  sceneKey,
  info,
  onSave,
}: {
  visible: boolean;
  onClose: () => void;
  /** Identifica a cena aberta: ao trocar de cena, os rascunhos recomeçam do zero. */
  sceneKey: number | null;
  info: SceneInfo;
  onSave: (field: SceneField, value: string) => void;
}) {
  const { width: sw, height: sh } = useWindowDimensions();
  const kb = useKeyboardInset();
  const [draft, setDraft] = useState<SceneInfo>(info);
  const draftRef = useRef(draft);
  draftRef.current = draft;
  const lastKey = useRef(sceneKey);
  // Só acompanha as props enquanto for a mesma cena: ao trocar, o que estava pendente ainda grava na cena anterior.
  const infoRef = useRef(info);
  const onSaveRef = useRef(onSave);
  if (lastKey.current === sceneKey) {
    infoRef.current = info;
    onSaveRef.current = onSave;
  }
  const focused = useRef<SceneField | null>(null);
  const timers = useRef<Partial<Record<SceneField, ReturnType<typeof setTimeout>>>>({});

  /** Grava o campo se mudou. O título não pode ficar vazio: volta ao que estava. */
  const commit = useCallback((key: SceneField) => {
    const t = timers.current[key];
    if (t) clearTimeout(t);
    delete timers.current[key];
    const v = draftRef.current[key].trim();
    if (key === 'name' && !v) setDraft((d) => ({ ...d, name: infoRef.current.name }));
    else if (v !== infoRef.current[key]) {
      infoRef.current = { ...infoRef.current, [key]: v };
      onSaveRef.current(key, v);
    }
  }, []);
  const commitAll = useCallback(() => {
    (Object.keys(timers.current) as SceneField[]).forEach((k) => commit(k));
    if (focused.current) commit(focused.current);
  }, [commit]);
  const schedule = (key: SceneField) => {
    const t = timers.current[key];
    if (t) clearTimeout(t);
    timers.current[key] = setTimeout(() => commit(key), 600);
  };

  // Outra cena: grava o que estava pendente da anterior (o `onSave` ainda aponta para ela) e recomeça.
  useEffect(() => {
    if (lastKey.current !== sceneKey) {
      commitAll();
      lastKey.current = sceneKey;
      focused.current = null;
      infoRef.current = info;
      onSaveRef.current = onSave;
      setDraft(info);
    }
  }); // eslint-disable-line react-hooks/exhaustive-deps

  // Mudou por fora (sincronização, outro aparelho): atualiza os rascunhos, menos o campo que está sendo digitado.
  useEffect(() => {
    if (lastKey.current !== sceneKey) return;
    setDraft((d) => {
      const n = { ...info };
      if (focused.current) n[focused.current] = d[focused.current];
      return n;
    });
  }, [info.name, info.desc, info.place, info.emotion, info.duration, info.shot, info.dialogue, info.date]); // eslint-disable-line react-hooks/exhaustive-deps

  // Ao sair da tela com algo ainda pendente, grava (antes se perdia o texto).
  useEffect(() => () => commitAll(), [commitAll]);

  const close = () => {
    Keyboard.dismiss();
    commitAll();
    onClose();
  };

  return (
    <SheetShell visible={visible} onClose={close} lift={kb} maxHeight={Math.max(sh * 0.4, Math.min(sh * 0.72, sh - kb - sw * 0.2))}>
      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'space-between',
          paddingTop: sw * SPACE.xl,
          paddingHorizontal: sw * SPACE.xl,
        }}
      >
        <Text style={{ color: colors.onLight, fontFamily: fonts.bold, fontSize: sw * TYPE.subtitle }}>Detalhes da cena</Text>
        <Pressable onPress={close} hitSlop={HIT.md} accessibilityRole="button" accessibilityLabel="Fechar detalhes da cena">
          <Text style={{ color: colors.subtle, fontFamily: fonts.bold, fontSize: sw * TYPE.subtitle }}>Pronto</Text>
        </Pressable>
      </View>
      <View style={{ height: 3, backgroundColor: colors.bg, marginTop: sw * SPACE.md, marginHorizontal: sw * 0.1145 }} />
      <ScrollView
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={{ padding: sw * SPACE.xl, paddingTop: sw * SPACE.md, gap: sw * 0.03 }}
      >
        {SCENE_LABELS.map((f) => (
          <View key={f.key}>
            <Text style={{ fontFamily: fonts.regular, fontSize: sw * TYPE.caption, color: colors.subtle }}>{f.label}</Text>
            <TextInput
              value={draft[f.key]}
              onChangeText={(t) => {
                draftRef.current = { ...draftRef.current, [f.key]: t };
                setDraft(draftRef.current);
                schedule(f.key);
              }}
              onFocus={() => (focused.current = f.key)}
              onBlur={() => {
                if (focused.current === f.key) focused.current = null;
                commit(f.key);
              }}
              onEndEditing={() => commit(f.key)}
              placeholder={f.placeholder}
              placeholderTextColor={colors.subtle}
              multiline={f.multiline}
              accessibilityLabel={f.label}
              style={{
                fontFamily: fonts.regular,
                fontSize: sw * TYPE.body,
                color: colors.onLight,
                borderBottomWidth: 1,
                borderBottomColor: colors.line,
                paddingVertical: sw * 0.015,
                maxHeight: sw * 0.4,
              }}
            />
          </View>
        ))}
      </ScrollView>
    </SheetShell>
  );
}
