import React, { useEffect, useState } from 'react';
import { Pressable, Text, TextInput, View } from 'react-native';
import { colors, fonts, HIT } from './theme';

export type SceneInfo = { name: string; desc: string; place: string; emotion: string };
export type SceneField = 'name' | 'desc' | 'place' | 'emotion';

const LABELS: { key: SceneField; label: string; placeholder: string; multiline?: boolean }[] = [
  { key: 'name', label: 'Título', placeholder: 'Título da cena' },
  { key: 'desc', label: 'Descrição curta', placeholder: 'O que acontece nesta cena', multiline: true },
  { key: 'place', label: 'Local', placeholder: 'Onde se passa' },
  { key: 'emotion', label: 'Emoção', placeholder: 'Que sensação passar' },
];

/**
 * Campos da cena, no topo da tela da cena. Recolhido mostra um resumo de uma linha;
 * tocando, abre os quatro campos. Cada campo grava ao terminar de editar.
 */
export function SceneFields({
  u,
  top,
  info,
  onSave,
}: {
  u: number;
  top: number;
  info: SceneInfo;
  onSave: (field: SceneField, value: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState<SceneInfo>(info);
  // Mudou por fora (sincronização, outro aparelho): atualiza os rascunhos.
  useEffect(() => setDraft(info), [info.name, info.desc, info.place, info.emotion]); // eslint-disable-line react-hooks/exhaustive-deps

  const summary = [info.desc, info.place, info.emotion].filter(Boolean).join(' · ');
  return (
    <View
      style={{
        position: 'absolute',
        left: u * 0.04,
        right: u * 0.04,
        top,
        backgroundColor: colors.glass,
        borderWidth: 1,
        borderColor: colors.glassLine,
        borderRadius: u * 0.04,
        paddingHorizontal: u * 0.04,
        paddingVertical: u * 0.025,
      }}
    >
      <Pressable onPress={() => setOpen((o) => !o)} hitSlop={HIT.sm} accessibilityRole="button" accessibilityLabel="Dados da cena">
        <Text numberOfLines={1} style={{ fontFamily: fonts.regular, fontSize: u * 0.038, color: summary ? colors.onLight : colors.subtle }}>
          {summary || 'Toque para descrever a cena'}
        </Text>
      </Pressable>
      {open && (
        <View style={{ marginTop: u * 0.02, gap: u * 0.02 }}>
          {LABELS.map((f) => (
            <View key={f.key}>
              <Text style={{ fontFamily: fonts.regular, fontSize: u * 0.03, color: colors.subtle }}>{f.label}</Text>
              <TextInput
                value={draft[f.key]}
                onChangeText={(t) => setDraft((d) => ({ ...d, [f.key]: t }))}
                onEndEditing={() => {
                  const v = draft[f.key].trim();
                  // O título não pode ficar vazio: volta ao que estava.
                  if (f.key === 'name' && !v) setDraft((d) => ({ ...d, name: info.name }));
                  else if (v !== info[f.key]) onSave(f.key, v);
                }}
                placeholder={f.placeholder}
                placeholderTextColor={colors.subtle}
                multiline={f.multiline}
                style={{
                  fontFamily: fonts.regular,
                  fontSize: u * 0.042,
                  color: colors.onLight,
                  borderBottomWidth: 1,
                  borderBottomColor: colors.line,
                  paddingVertical: u * 0.012,
                  maxHeight: u * 0.3,
                }}
              />
            </View>
          ))}
        </View>
      )}
    </View>
  );
}
