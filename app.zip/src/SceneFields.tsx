import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Keyboard, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { colors, fonts, HIT } from './theme';

export type SceneInfo = {
  name: string;
  desc: string;
  place: string;
  emotion: string;
  duration: string;
  shot: string;
  dialogue: string;
  date: string;
};
export type SceneField = keyof SceneInfo;
/** Campo da tela -> propriedade da coleção (o título é à parte: renameCollection). */
export const SCENE_FIELD_KEY = {
  desc: 'sceneDesc',
  place: 'scenePlace',
  emotion: 'sceneEmotion',
  duration: 'sceneDuration',
  shot: 'sceneShot',
  dialogue: 'sceneDialogue',
  date: 'sceneDate',
} as const;

const LABELS: { key: SceneField; label: string; placeholder: string; multiline?: boolean }[] = [
  { key: 'name', label: 'Título', placeholder: 'Título da cena' },
  { key: 'desc', label: 'Descrição curta', placeholder: 'O que acontece nesta cena', multiline: true },
  { key: 'place', label: 'Local', placeholder: 'Onde se passa' },
  { key: 'emotion', label: 'Emoção', placeholder: 'Que sensação passar' },
  { key: 'duration', label: 'Duração', placeholder: 'Ex.: 30 s' },
  { key: 'shot', label: 'Plano', placeholder: 'Close, aberto, POV...' },
  { key: 'dialogue', label: 'Falas', placeholder: 'O que será dito', multiline: true },
  { key: 'date', label: 'Data de gravação', placeholder: 'Ex.: 25/10' },
];

/**
 * Campos da cena, no topo da tela da cena. Recolhido mostra um resumo de uma linha;
 * tocando, abre os quatro campos. Cada campo grava ao terminar de editar.
 */
export function SceneFields({
  u,
  top,
  info,
  onSave,
}: {
  u: number;
  top: number;
  info: SceneInfo;
  onSave: (field: SceneField, value: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState<SceneInfo>(info);
  const draftRef = useRef(draft);
  draftRef.current = draft;
  const infoRef = useRef(info);
  infoRef.current = info;
  const onSaveRef = useRef(onSave);
  onSaveRef.current = onSave;
  const focused = useRef<SceneField | null>(null);
  const timers = useRef<Partial<Record<SceneField, ReturnType<typeof setTimeout>>>>({});

  // Mudou por fora (sincronização, outro aparelho): atualiza os rascunhos, menos o campo que está sendo digitado.
  useEffect(() => {
    setDraft((d) => {
      const n = { ...info };
      if (focused.current) n[focused.current] = d[focused.current];
      return n;
    });
  }, [info.name, info.desc, info.place, info.emotion, info.duration, info.shot, info.dialogue, info.date]); // eslint-disable-line react-hooks/exhaustive-deps

  /** Grava o campo se mudou. O título não pode ficar vazio: volta ao que estava. */
  const commit = useCallback((key: SceneField) => {
    const t = timers.current[key];
    if (t) clearTimeout(t);
    delete timers.current[key];
    const v = draftRef.current[key].trim();
    if (key === 'name' && !v) setDraft((d) => ({ ...d, name: infoRef.current.name }));
    else if (v !== infoRef.current[key]) {
      infoRef.current = { ...infoRef.current, [key]: v };
      onSaveRef.current(key, v);
    }
  }, []);
  const schedule = (key: SceneField) => {
    const t = timers.current[key];
    if (t) clearTimeout(t);
    timers.current[key] = setTimeout(() => commit(key), 600);
  };
  // Ao sair da tela com algo ainda pendente, grava (antes se perdia o texto).
  useEffect(
    () => () => {
      (Object.keys(timers.current) as SceneField[]).forEach((k) => commit(k));
    },
    [commit]
  );

  const summary = [info.desc, info.place, info.emotion, info.duration].filter(Boolean).join(' · ');
  return (
    <>
      {/* Aberto: tocar fora fecha (e grava), em vez de mexer nos cartões por baixo. */}
      {open && <Pressable style={StyleSheet.absoluteFill} onPress={() => { Keyboard.dismiss(); setOpen(false); }} accessibilityLabel="Fechar dados da cena" />}
    <View
      style={{
        position: 'absolute',
        left: u * 0.04,
        right: u * 0.04,
        top,
        backgroundColor: colors.glass,
        borderWidth: 1,
        borderColor: colors.glassLine,
        borderRadius: u * 0.04,
        paddingHorizontal: u * 0.04,
        paddingVertical: u * 0.025,
      }}
    >
      <Pressable onPress={() => setOpen((o) => !o)} hitSlop={HIT.sm} accessibilityRole="button" accessibilityLabel="Dados da cena">
        <Text numberOfLines={1} style={{ fontFamily: fonts.regular, fontSize: u * 0.038, color: summary ? colors.onLight : colors.subtle }}>
          {summary || 'Toque para descrever a cena'}
        </Text>
      </Pressable>
      {open && (
        <ScrollView style={{ maxHeight: u * 1.1 }} keyboardShouldPersistTaps="handled" contentContainerStyle={{ marginTop: u * 0.02, gap: u * 0.02 }}>
          {LABELS.map((f) => (
            <View key={f.key}>
              <Text style={{ fontFamily: fonts.regular, fontSize: u * 0.03, color: colors.subtle }}>{f.label}</Text>
              <TextInput
                value={draft[f.key]}
                onChangeText={(t) => {
                  draftRef.current = { ...draftRef.current, [f.key]: t };
                  setDraft(draftRef.current);
                  schedule(f.key);
                }}
                onFocus={() => (focused.current = f.key)}
                onBlur={() => {
                  if (focused.current === f.key) focused.current = null;
                  commit(f.key);
                }}
                onEndEditing={() => commit(f.key)}
                placeholder={f.placeholder}
                placeholderTextColor={colors.subtle}
                multiline={f.multiline}
                style={{
                  fontFamily: fonts.regular,
                  fontSize: u * 0.042,
                  color: colors.onLight,
                  borderBottomWidth: 1,
                  borderBottomColor: colors.line,
                  paddingVertical: u * 0.012,
                  maxHeight: u * 0.3,
                }}
              />
            </View>
          ))}
        </ScrollView>
      )}
    </View>
    </>
  );
}
