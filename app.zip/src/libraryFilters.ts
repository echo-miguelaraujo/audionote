import type { Block } from './db';
import { tagKey } from './tags';

export type DateBase = 'created' | 'edited';
export type DatePeriod = 'today' | '7d' | '30d' | 'year';
export type ContentKind = 'image' | 'audio' | 'attachment';

/** Filtros da Biblioteca. Todos combinam (E) entre si e com a busca de texto. */
export type LibFilters = {
  /** null = todas, 0 = sem categoria, n = id da categoria. */
  category: number | null;
  /** A nota precisa ter TODAS as tags marcadas (chaves sem acento/maiúscula). */
  tags: string[];
  favoritesOnly: boolean;
  dateBase: DateBase;
  period: DatePeriod | null;
  pendingTasks: boolean;
  /** Qualquer um dos tipos marcados. */
  content: ContentKind[];
};

export const NO_FILTERS: LibFilters = {
  category: null,
  tags: [],
  favoritesOnly: false,
  dateBase: 'created',
  period: null,
  pendingTasks: false,
  content: [],
};

export function countActive(f: LibFilters): number {
  return (
    (f.category !== null ? 1 : 0) +
    f.tags.length +
    (f.favoritesOnly ? 1 : 0) +
    (f.period ? 1 : 0) +
    (f.pendingTasks ? 1 : 0) +
    f.content.length
  );
}

/** Início do período (ms). */
export function periodStart(p: DatePeriod, now = Date.now()): number {
  const d = new Date(now);
  if (p === 'today') return new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
  if (p === '7d') return now - 7 * 86400000;
  if (p === '30d') return now - 30 * 86400000;
  return new Date(d.getFullYear(), 0, 1).getTime();
}

export function applyFilters(list: Block[], f: LibFilters, now = Date.now()): Block[] {
  const since = f.period ? periodStart(f.period, now) : null;
  return list.filter((b) => {
    if (f.category === 0 && b.categoryId !== null) return false;
    if (f.category !== null && f.category !== 0 && b.categoryId !== f.category) return false;
    if (f.favoritesOnly && !b.favorite) return false;
    if (f.tags.length > 0) {
      const keys = b.tags.map(tagKey);
      if (!f.tags.every((t) => keys.includes(t))) return false;
    }
    if (since !== null && (f.dateBase === 'created' ? b.createdAt : b.editedAt) < since) return false;
    if (f.pendingTasks && b.taskTotal - b.taskDone <= 0) return false;
    if (f.content.length > 0) {
      const ok = f.content.some((c) =>
        c === 'image' ? b.hasImage : c === 'audio' ? b.audioCount > 0 : b.hasAttachment
      );
      if (!ok) return false;
    }
    return true;
  });
}

export const PERIOD_LABEL: Record<DatePeriod, string> = {
  today: 'Hoje',
  '7d': '7 dias',
  '30d': '30 dias',
  year: 'Este ano',
};
export const CONTENT_LABEL: Record<ContentKind, string> = {
  image: 'Imagem',
  audio: 'Áudio',
  attachment: 'Anexo',
};

/** Todas as tags das notas, com a contagem e a grafia da primeira ocorrência. Ordem alfabética. */
export function tagStats(list: Block[]): { key: string; name: string; count: number }[] {
  const m = new Map<string, { key: string; name: string; count: number }>();
  for (const b of list)
    for (const t of b.tags) {
      const k = tagKey(t);
      const cur = m.get(k);
      if (cur) cur.count++;
      else m.set(k, { key: k, name: t, count: 1 });
    }
  return [...m.values()].sort((a, b) => a.key.localeCompare(b.key, 'pt-BR'));
}
