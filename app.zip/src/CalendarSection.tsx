import React, { useEffect, useState } from 'react';
import { Pressable, Text, View, useWindowDimensions } from 'react-native';
import { appAlert, appError, confirmDelete } from './dialog';
import { SettingRow } from './SettingRow';
import { CalOption, ensureCalendarPermission, listWritableCalendars, removeCreatedEvent } from './calendar';
import { CalendarRecord, listRecentCalendarRecords } from './db';
import { formatDateTime } from './format';
import { getCalendarAuto, getCalendarId, setCalendarAuto, setCalendarId } from './settings';
import { colors, fonts, HIT, MIN_TOUCH, SPACE, TYPE } from './theme';

/** Criação automática de compromissos a partir do áudio: liga/desliga, qual agenda usar e o que já foi criado. */
export function CalendarSection() {
  const { width: sw } = useWindowDimensions();
  const [calAuto, setCalAuto] = useState(true);
  const [calId, setCalIdState] = useState<string | null>(null);
  const [cals, setCals] = useState<CalOption[] | null>(null);
  const [records, setRecords] = useState<CalendarRecord[]>([]);

  useEffect(() => {
    getCalendarAuto().then(setCalAuto).catch(() => {});
    getCalendarId().then(setCalIdState).catch(() => {});
    listRecentCalendarRecords(8).then(setRecords).catch(() => {});
  }, []);

  const toggleCalendar = async () => {
    const v = !calAuto;
    if (v && !(await ensureCalendarPermission())) {
      appAlert('Permissão necessária', 'Permita o acesso à agenda nas configurações do Android para criar compromissos.');
      return;
    }
    setCalAuto(v);
    await setCalendarAuto(v);
  };

  const chooseCalendar = async () => {
    if (!(await ensureCalendarPermission())) {
      appAlert('Permissão necessária', 'Permita o acesso à agenda nas configurações do Android.');
      return;
    }
    try {
      const list = await listWritableCalendars();
      setCals(list);
      if (list.length === 0) appAlert('Nenhuma agenda', 'Não encontrei agendas que aceitem novos compromissos neste celular.');
    } catch (e) {
      appError('Erro ao ler as agendas', e);
    }
  };

  const removeRecord = (r: CalendarRecord) =>
    confirmDelete('Excluir compromisso?', `"${r.title}" será apagado também da agenda do celular.`, async () => {
      await removeCreatedEvent(r);
      setRecords(await listRecentCalendarRecords(8));
    });

  const rowStyle = { paddingVertical: sw * SPACE.sm, minHeight: MIN_TOUCH, justifyContent: 'center' as const };

  return (
    <View>
      <SettingRow
        label="Criar compromissos pelo áudio"
        hint="Quando você citar uma data na gravação, o app cria o compromisso na agenda."
        checked={calAuto}
        onPress={() => toggleCalendar().catch(() => {})}
      />

      {calAuto && (
        <View style={{ marginTop: sw * SPACE.md }}>
          <Pressable onPress={() => chooseCalendar().catch(() => {})} hitSlop={HIT.sm} accessibilityRole="button" style={{ minHeight: MIN_TOUCH, justifyContent: 'center' }}>
            <Text style={{ color: colors.muted, fontFamily: fonts.regular, fontSize: sw * TYPE.label }}>
              Agenda usada: {cals?.find((c) => c.id === calId)?.title ?? (calId ? 'escolhida' : 'automática (Google)')} · Trocar
            </Text>
          </Pressable>
          {cals && cals.length > 0 && (
            <View style={{ marginTop: sw * SPACE.sm }}>
              {cals.map((c) => (
                <Pressable
                  key={c.id}
                  accessibilityRole="button"
                  accessibilityState={{ selected: c.id === calId }}
                  onPress={async () => {
                    setCalIdState(c.id);
                    await setCalendarId(c.id);
                    setCals(null);
                  }}
                  style={rowStyle}
                >
                  <Text style={{ color: c.id === calId ? colors.red : colors.text, fontFamily: fonts.regular, fontSize: sw * TYPE.body }}>
                    {c.title}
                    {c.account ? `  (${c.account})` : ''}
                  </Text>
                </Pressable>
              ))}
            </View>
          )}
        </View>
      )}

      {records.length > 0 && (
        <View style={{ marginTop: sw * SPACE.lg }}>
          <Text style={{ color: colors.muted, fontFamily: fonts.regular, fontSize: sw * TYPE.label }}>Criados pelo app (toque para remover)</Text>
          {records.map((r) => (
            <Pressable key={r.id} onPress={() => removeRecord(r)} accessibilityRole="button" accessibilityLabel={`Remover ${r.title}`} style={rowStyle}>
              <Text style={{ color: colors.text, fontFamily: fonts.regular, fontSize: sw * TYPE.label }}>{r.title}</Text>
              <Text style={{ color: colors.muted, fontFamily: fonts.regular, fontSize: sw * TYPE.caption }}>
                {r.allDay ? formatDateTime(r.startAt).slice(0, 10) : formatDateTime(r.startAt)}
              </Text>
            </Pressable>
          ))}
        </View>
      )}
    </View>
  );
}
