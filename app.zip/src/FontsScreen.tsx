import React, { useCallback, useEffect, useRef, useState } from 'react';
import { BackHandler, FlatList, Pressable, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { WebView, WebViewMessageEvent, WebViewNavigation } from 'react-native-webview';
import { Background } from './Background';
import { Button } from './Button';
import { HeaderAction, ScreenHeader } from './ScreenHeader';
import { appError, appToast, confirmDelete } from './dialog';
import { downloadGoogleFont, familyFromUrl, nativeFontName, removeFont, useSavedFonts } from './fonts';
import { colors, fonts, HIT, MIN_TOUCH, SPACE, TYPE } from './theme';

type Props = {
  onClose: () => void;
  /** Por onde começa: o site do Google Fonts ou a lista "Minhas fontes". */
  initialMode?: 'browse' | 'list';
};

const START_URL = 'https://fonts.google.com/';

/** Só o Google Fonts (e o que ele precisa para abrir) fica acessível nesta janela. */
const HOST_OK = /^(?:[\w-]+\.)*(?:google\.com|gstatic\.com|googleapis\.com|googleusercontent\.com)$/i;

/** Avisa o app de toda mudança de endereço, inclusive as do site que não recarregam a página. */
const WATCH_JS = String.raw`(function(){
if(window.__fw)return;window.__fw=1;var last='';
function s(){var u=location.href;if(u!==last){last=u;try{window.ReactNativeWebView.postMessage(u);}catch(e){}}}
['pushState','replaceState'].forEach(function(k){var o=history[k];history[k]=function(){var r=o.apply(this,arguments);setTimeout(s,0);return r;};});
window.addEventListener('popstate',s);window.addEventListener('hashchange',s);
setInterval(s,500);s();
})();true;`;

/**
 * Janela do Google Fonts dentro do app: você pesquisa normalmente e, ao abrir a página de uma fonte,
 * aparece "Usar essa fonte". Ao tocar, a fonte é baixada para o aparelho e vai para "Minhas fontes".
 */
export function FontsScreen({ onClose, initialMode = 'browse' }: Props) {
  const { width: sw } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const web = useRef<WebView>(null);
  const [mode, setMode] = useState<'browse' | 'list'>(initialMode);
  const [family, setFamily] = useState<string | null>(null);
  const [canGoBack, setCanGoBack] = useState(false);
  const [busy, setBusy] = useState(false);
  const saved = useSavedFonts();
  const has = family !== null && saved.some((f) => f.family === family);

  const onUrl = useCallback((url: string) => setFamily(familyFromUrl(url)), []);

  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (mode === 'browse' && canGoBack) web.current?.goBack();
      else if (mode === 'browse' && initialMode === 'list') setMode('list');
      else onClose();
      return true;
    });
    return () => sub.remove();
  }, [mode, canGoBack, initialMode, onClose]);

  const use = async () => {
    if (!family || busy) return;
    setBusy(true);
    try {
      await downloadGoogleFont(family);
      appToast('Fonte adicionada', `${family} já está em "Minhas fontes".`);
    } catch (e) {
      appError('Não consegui baixar a fonte', e);
    } finally {
      setBusy(false);
    }
  };

  const onMessage = (e: WebViewMessageEvent) => {
    const d = e.nativeEvent.data;
    if (typeof d === 'string' && d.startsWith('http')) onUrl(d);
  };

  const onNav = (n: WebViewNavigation) => {
    setCanGoBack(n.canGoBack);
    if (n.url) onUrl(n.url);
  };

  return (
    <View style={styles.root}>
      <Background />
      <ScreenHeader
        onBack={() => {
          if (mode === 'browse' && canGoBack) web.current?.goBack();
          else if (mode === 'browse' && initialMode === 'list') setMode('list');
          else onClose();
        }}
        title={mode === 'browse' ? 'Google Fonts' : 'Minhas fontes'}
        right={
          mode === 'browse' ? (
            <HeaderAction label={saved.length > 0 ? `Minhas fontes (${saved.length})` : 'Minhas fontes'} onPress={() => setMode('list')} />
          ) : (
            <HeaderAction label="Buscar" tone="accent" onPress={() => setMode('browse')} />
          )
        }
      />

      {/* A janela do site fica sempre montada (só escondida), para não perder a pesquisa ao ver a lista. */}
      <View style={[styles.flex, mode !== 'browse' && styles.hidden]}>
        <WebView
          ref={web}
          source={{ uri: START_URL }}
          onMessage={onMessage}
          onNavigationStateChange={onNav}
          injectedJavaScriptBeforeContentLoaded={WATCH_JS}
          injectedJavaScript={WATCH_JS}
          javaScriptEnabled
          domStorageEnabled
          setSupportMultipleWindows={false}
          textZoom={100}
          startInLoadingState
          onShouldStartLoadWithRequest={(r) => {
            try {
              const u = new URL(r.url);
              return u.protocol === 'https:' && HOST_OK.test(u.hostname);
            } catch {
              return r.url.startsWith('about:');
            }
          }}
          style={{ backgroundColor: colors.paper }}
          containerStyle={{ backgroundColor: colors.paper }}
        />
        {family !== null && (
          <View style={[styles.bar, { paddingBottom: insets.bottom + sw * 0.03, paddingHorizontal: sw * SPACE.lg, paddingTop: sw * 0.03 }]}>
            <Text numberOfLines={1} style={{ color: colors.muted, fontFamily: fonts.regular, fontSize: sw * TYPE.caption, marginBottom: sw * 0.02 }}>
              {family}
            </Text>
            {has ? (
              <Button icon="check" label="Já está em Minhas fontes" variant="secondary" onPress={() => setMode('list')} />
            ) : (
              <Button label="Usar essa fonte" loading={busy} onPress={use} />
            )}
          </View>
        )}
      </View>

      {mode === 'list' && (
        <FlatList
          style={styles.flex}
          data={saved}
          keyExtractor={(f) => f.family}
          contentContainerStyle={{ paddingHorizontal: sw * SPACE.xl, paddingBottom: insets.bottom + sw * 0.1 }}
          ListEmptyComponent={
            <View style={{ paddingTop: sw * 0.12, gap: sw * 0.05 }}>
              <Text style={{ color: colors.mutedLight, fontFamily: fonts.regular, fontSize: sw * TYPE.body, lineHeight: sw * TYPE.body * 1.4 }}>
                Você ainda não tem fontes. Abra o Google Fonts, entre na página de uma fonte e toque em "Usar essa fonte".
              </Text>
              <Button label="Buscar no Google Fonts" onPress={() => setMode('browse')} />
            </View>
          }
          renderItem={({ item }) => {
            const native = nativeFontName(item.family, false, false);
            return (
              <View style={[styles.row, { minHeight: MIN_TOUCH * 1.4, paddingVertical: sw * 0.03 }]}>
                <View style={styles.flex}>
                  <Text numberOfLines={1} style={{ color: colors.muted, fontFamily: fonts.regular, fontSize: sw * TYPE.caption }}>
                    {item.family}
                  </Text>
                  <Text
                    numberOfLines={1}
                    style={{ color: colors.onDark, fontFamily: native ?? fonts.regular, fontSize: sw * 0.07, marginTop: sw * 0.008 }}
                  >
                    Aa Bb Cc — Minha ideia
                  </Text>
                </View>
                <Pressable
                  hitSlop={HIT.md}
                  accessibilityRole="button"
                  accessibilityLabel={`Excluir a fonte ${item.family}`}
                  onPress={() =>
                    confirmDelete('Excluir fonte?', `"${item.family}" sai do aparelho. Textos que a usam voltam à fonte padrão.`, () =>
                      removeFont(item.family)
                    )
                  }
                >
                  <Text style={{ color: colors.red, fontFamily: fonts.bold, fontSize: sw * TYPE.body }}>Excluir</Text>
                </Pressable>
              </View>
            );
          }}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { ...StyleSheet.absoluteFillObject, backgroundColor: colors.bg, zIndex: 60 },
  flex: { flex: 1 },
  hidden: { display: 'none' },
  bar: { backgroundColor: colors.bg, borderTopWidth: 1, borderTopColor: colors.lineDark },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, borderBottomWidth: 1, borderBottomColor: colors.lineDark },
});
