import { Directory, File, Paths } from 'expo-file-system';

function audioDir(): Directory {
  const dir = new Directory(Paths.document, 'audios');
  if (!dir.exists) dir.create({ idempotent: true, intermediates: true });
  return dir;
}

export function audioFileExists(fileName: string): boolean {
  if (!fileName) return false;
  try {
    return new File(audioDir(), fileName).exists;
  } catch {
    return false;
  }
}

export function audioFileSize(fileName: string): number {
  try {
    return new File(audioDir(), fileName).size ?? 0;
  } catch {
    return 0;
  }
}

export async function audioBase64(fileName: string): Promise<string> {
  return new File(audioDir(), fileName).base64();
}

export function audioUri(fileName: string): string {
  return new File(audioDir(), fileName).uri;
}

/** Move a gravação temporária para a pasta permanente do app. Retorna o nome do arquivo. */
export function importRecording(sourceUri: string): string {
  const ext = sourceUri.split('.').pop()?.split('?')[0] || 'm4a';
  const fileName = `rec_${Date.now()}.${ext}`;
  new File(sourceUri).move(new File(audioDir(), fileName));
  return fileName;
}

export function removeAudioFile(fileName: string): void {
  if (!fileName) return; // evita apagar a pasta inteira
  try {
    const f = new File(audioDir(), fileName);
    if (f.exists) f.delete();
  } catch {
    // ignora: arquivo já não existe
  }
}
