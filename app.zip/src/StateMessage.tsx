import React from 'react';
import { ActivityIndicator, StyleProp, Text, View, ViewStyle, useWindowDimensions } from 'react-native';
import { colors, fonts, TYPE, SPACE } from './theme';

type Props = {
  /** `empty`: nada para mostrar (cinza). `info`: aviso neutro. `loading`: trabalhando (com indicador). `error`: algo falhou (vermelho). */
  kind: 'empty' | 'loading' | 'error' | 'info';
  children: React.ReactNode;
  /** Sobre fundo escuro (padrão) ou claro. Define a cor do texto de `loading`. */
  surface?: 'dark' | 'light';
  /** Centraliza o texto (estados que ocupam a área toda). */
  centered?: boolean;
  /** Tamanho do texto em relação à largura da tela. */
  size?: number;
  style?: StyleProp<ViewStyle>;
};

/**
 * Mensagem de estado padrão: vazio, carregando ou erro. Todas as telas usam esta,
 * para cor, tamanho e espaçamento serem iguais.
 */
export function StateMessage({ kind, children, surface = 'dark', centered, size = TYPE.body, style }: Props) {
  const { width: sw } = useWindowDimensions();
  const color =
    kind === 'error' ? colors.red : kind === 'empty' ? colors.muted : surface === 'dark' ? colors.onDark : colors.onLight;
  const fontSize = sw * size;

  return (
    <View style={[{ alignItems: centered ? 'center' : 'flex-start' }, style]}>
      {kind === 'loading' && <ActivityIndicator color={color} size="large" style={{ marginBottom: sw * SPACE.md }} />}
      <Text
        style={{
          color,
          fontFamily: fonts.regular,
          fontSize,
          lineHeight: fontSize * 1.38,
          textAlign: centered ? 'center' : 'left',
        }}
      >
        {children}
      </Text>
    </View>
  );
}
