import React from 'react';
import { Image, View } from 'react-native';
import { mediaUri } from './media';

// Cada capa da colagem: posição e tamanho (em unidades de largura da tela) e giro. Da de trás para a da frente.
const LAYERS = [
  { l: 0.0, t: 0.07, w: 0.12, h: 0.16, r: -8 },
  { l: 0.2, t: 0.1, w: 0.19, h: 0.26, r: 14 },
  { l: 0.11, t: 0.0, w: 0.2, h: 0.28, r: 0 },
  { l: 0.02, t: 0.15, w: 0.23, h: 0.31, r: -14 },
];

export function Collage({ covers, sw }: { covers: string[]; sw: number }) {
  // Com menos de 4 imagens, usa só as capas da frente.
  const layers = LAYERS.slice(LAYERS.length - covers.length);
  // covers[0] é a mais recente: vai na frente (última camada).
  const ordered = [...covers].reverse();
  return (
    <View style={{ width: sw * 0.42, height: sw * 0.48 }}>
      {covers.length === 0 && (
        <View
          style={{
            position: 'absolute',
            left: sw * 0.08,
            top: sw * 0.06,
            width: sw * 0.22,
            height: sw * 0.3,
            borderRadius: sw * 0.02,
            borderWidth: 1.5,
            borderColor: 'rgba(0,0,0,0.25)',
            borderStyle: 'dashed',
          }}
        />
      )}
      {ordered.map((name, i) => {
        const L = layers[i];
        return (
          <Image
            key={`${name}-${i}`}
            source={{ uri: mediaUri(name) }}
            resizeMode="cover"
            style={{
              position: 'absolute',
              left: L.l * sw,
              top: L.t * sw,
              width: L.w * sw,
              height: L.h * sw,
              transform: [{ rotate: `${L.r}deg` }],
            }}
          />
        );
      })}
    </View>
  );
}
