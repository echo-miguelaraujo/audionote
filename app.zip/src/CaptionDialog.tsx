import React, { useEffect, useState } from 'react';
import { Text, TextInput, useWindowDimensions } from 'react-native';
import { DialogActions, DialogShell, DialogTitle } from './DialogBase';
import { colors, fonts, TYPE, SPACE } from './theme';

export const CAPTION_MAX = 280;

type Props = {
  visible: boolean;
  initialValue: string;
  onCancel: () => void;
  /** Texto já aparado; vazio apaga a legenda. */
  onSubmit: (value: string) => void;
};

/** Legenda de um item (mostrada na apresentação): várias linhas, até 280 caracteres; vazio apaga. */
export function CaptionDialog({ visible, initialValue, onCancel, onSubmit }: Props) {
  const { width: sw, height: sh } = useWindowDimensions();
  const [value, setValue] = useState(initialValue);

  useEffect(() => {
    if (visible) setValue(initialValue);
  }, [visible, initialValue]);

  const empty = !value.trim();

  return (
    <DialogShell visible={visible} onClose={onCancel} keyboard>
      <DialogTitle>Legenda</DialogTitle>
      <TextInput
        value={value}
        onChangeText={setValue}
        autoFocus
        multiline
        maxLength={CAPTION_MAX}
        placeholder="Aparece na apresentação, junto do item"
        accessibilityLabel="Legenda"
        placeholderTextColor={colors.subtle}
        style={{
          marginTop: sw * SPACE.md,
          minHeight: sw * 0.3,
          maxHeight: sh * 0.3,
          textAlignVertical: 'top',
          color: colors.onLight,
          fontFamily: fonts.regular,
          fontSize: sw * TYPE.body,
          borderWidth: 1,
          borderColor: colors.line,
          borderRadius: sw * 0.03,
          padding: sw * SPACE.sm,
        }}
      />
      <Text style={{ color: colors.subtle, fontFamily: fonts.regular, fontSize: sw * TYPE.caption, marginTop: sw * SPACE.xs, textAlign: 'right' }}>
        {value.length}/{CAPTION_MAX}
      </Text>
      <DialogActions
        onCancel={onCancel}
        confirmLabel={empty ? 'Excluir' : 'Salvar'}
        confirmTone={empty ? 'danger' : 'default'}
        onConfirm={() => onSubmit(value.trim())}
      />
    </DialogShell>
  );
}
