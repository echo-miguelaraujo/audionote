import React, { useEffect, useState } from 'react';
import { Modal, Pressable, StyleSheet, Text, TextInput, View, useWindowDimensions } from 'react-native';
import { fonts } from './theme';

export const CAPTION_MAX = 280;

type Props = {
  visible: boolean;
  initialValue: string;
  onCancel: () => void;
  /** Texto já aparado; vazio apaga a legenda. */
  onSubmit: (value: string) => void;
};

/** Legenda de um item (mostrada na apresentação): várias linhas, até 280 caracteres; vazio apaga. */
export function CaptionDialog({ visible, initialValue, onCancel, onSubmit }: Props) {
  const { width: sw, height: sh } = useWindowDimensions();
  const [value, setValue] = useState(initialValue);

  useEffect(() => {
    if (visible) setValue(initialValue);
  }, [visible, initialValue]);

  return (
    <Modal visible={visible} transparent animationType="fade" statusBarTranslucent onRequestClose={onCancel}>
      <Pressable style={[styles.overlay, { paddingTop: sh * 0.15 }]} onPress={onCancel}>
        <Pressable style={{ width: sw * 0.88, borderRadius: sw * 0.074, padding: sw * 0.06, backgroundColor: '#fff' }} onPress={() => {}}>
          <Text style={{ color: '#000', fontFamily: fonts.bold, fontSize: sw * 0.06, letterSpacing: -1 }}>Legenda</Text>
          <TextInput
            value={value}
            onChangeText={setValue}
            autoFocus
            multiline
            maxLength={CAPTION_MAX}
            placeholder="Aparece na apresentação, junto do item"
            placeholderTextColor="#808080"
            style={{
              marginTop: sw * 0.04,
              minHeight: sw * 0.3,
              maxHeight: sh * 0.3,
              textAlignVertical: 'top',
              color: '#000',
              fontFamily: fonts.regular,
              fontSize: sw * 0.045,
              borderWidth: 1,
              borderColor: '#C8C8C8',
              borderRadius: sw * 0.03,
              padding: sw * 0.03,
            }}
          />
          <Text style={{ color: '#808080', fontFamily: fonts.regular, fontSize: sw * 0.032, marginTop: sw * 0.015, textAlign: 'right' }}>
            {value.length}/{CAPTION_MAX}
          </Text>
          <View style={styles.row}>
            <Pressable onPress={onCancel} hitSlop={12}>
              <Text style={{ color: '#808080', fontFamily: fonts.bold, fontSize: sw * 0.05 }}>Cancelar</Text>
            </Pressable>
            <Pressable onPress={() => onSubmit(value.trim())} hitSlop={12}>
              <Text style={{ color: '#FF3030', fontFamily: fonts.bold, fontSize: sw * 0.05 }}>{value.trim() ? 'Salvar' : 'Apagar'}</Text>
            </Pressable>
          </View>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.78)', alignItems: 'center' },
  row: { flexDirection: 'row', justifyContent: 'flex-end', gap: 28, marginTop: 16 },
});
