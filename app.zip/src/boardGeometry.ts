import { colors } from './theme';
import type { MoodItem } from './db';

/** Retângulo em unidades do mundo (1 = lado menor da tela). */
export type Rect = { x: number; y: number; w: number; h: number };

/** Tamanho aproximado do item, em unidades (usado antes de ele ser medido na tela). */
export const boxOf = (it: MoodItem): { w: number; h: number } =>
  it.kind === 'text' ? { w: it.h || 0.6, h: 0.25 } : { w: it.w, h: it.h };

/**
 * Retângulo que contém o item inteiro, já girado (4 cantos girados em torno do centro).
 * Usa o tamanho medido (px → unidades, `u` = lado menor da tela em px) e cai em `boxOf` se ainda não foi medido.
 * `rot` em graus.
 */
export function itemBounds(
  it: MoodItem,
  sizes: Record<number, { w: number; h: number }>,
  u: number
): Rect {
  const m = sizes[it.id];
  const b = m && m.w > 0 && m.h > 0 && u > 0 ? { w: m.w / u, h: m.h / u } : boxOf(it);
  const cx = it.x + b.w / 2;
  const cy = it.y + b.h / 2;
  const a = (it.rot * Math.PI) / 180;
  const cos = Math.cos(a);
  const sin = Math.sin(a);
  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;
  for (const [dx, dy] of [
    [-b.w / 2, -b.h / 2],
    [b.w / 2, -b.h / 2],
    [b.w / 2, b.h / 2],
    [-b.w / 2, b.h / 2],
  ]) {
    const px = cx + dx * cos - dy * sin;
    const py = cy + dx * sin + dy * cos;
    minX = Math.min(minX, px);
    maxX = Math.max(maxX, px);
    minY = Math.min(minY, py);
    maxY = Math.max(maxY, py);
  }
  return { x: minX, y: minY, w: maxX - minX, h: maxY - minY };
}

/** União dos retângulos de vários itens, com margem. Lista vazia → null. */
export function unionBounds(
  items: MoodItem[],
  sizes: Record<number, { w: number; h: number }>,
  u: number,
  margin = 0
): Rect | null {
  if (items.length === 0) return null;
  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;
  for (const it of items) {
    const r = itemBounds(it, sizes, u);
    minX = Math.min(minX, r.x);
    minY = Math.min(minY, r.y);
    maxX = Math.max(maxX, r.x + r.w);
    maxY = Math.max(maxY, r.y + r.h);
  }
  return { x: minX - margin, y: minY - margin, w: maxX - minX + 2 * margin, h: maxY - minY + 2 * margin };
}

/** Amplia o retângulo (sem cortar nada) até ter a proporção `ratio` (largura / altura), mantendo o centro. */
export function frameToRatio(r: Rect, ratio: number): Rect {
  const cx = r.x + r.w / 2;
  const cy = r.y + r.h / 2;
  let w = r.w;
  let h = r.h;
  if (w / h < ratio) w = h * ratio;
  else h = w / ratio;
  return { x: cx - w / 2, y: cy - h / 2, w, h };
}

/** Cor de texto legível sobre um fundo #RRGGBB (luminância relativa > 0.5 → preto, senão branco). */
export function readableOn(hex: string): typeof colors.onLight | typeof colors.onDark {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex.trim());
  if (!m) return colors.onLight;
  const n = parseInt(m[1], 16);
  const lin = (c: number) => {
    const v = c / 255;
    return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
  };
  const L = 0.2126 * lin((n >> 16) & 255) + 0.7152 * lin((n >> 8) & 255) + 0.0722 * lin(n & 255);
  return L > 0.5 ? colors.onLight : colors.onDark;
}
