import { colors } from './theme';
import type { MoodItem } from './db';

/** Retângulo em unidades do mundo (1 = lado menor da tela). */
export type Rect = { x: number; y: number; w: number; h: number };

/** Tamanho aproximado do item, em unidades (usado antes de ele ser medido na tela). */
export const boxOf = (it: MoodItem): { w: number; h: number } =>
  it.kind === 'text' ? { w: it.h || 0.6, h: 0.25 } : { w: it.w, h: it.h };

/**
 * Retângulo que contém o item inteiro, já girado (4 cantos girados em torno do centro).
 * Usa o tamanho medido (px → unidades, `u` = lado menor da tela em px) e cai em `boxOf` se ainda não foi medido.
 * `rot` em graus.
 */
export function itemBounds(
  it: MoodItem,
  sizes: Record<number, { w: number; h: number }>,
  u: number
): Rect {
  const m = sizes[it.id];
  const b = m && m.w > 0 && m.h > 0 && u > 0 ? { w: m.w / u, h: m.h / u } : boxOf(it);
  const cx = it.x + b.w / 2;
  const cy = it.y + b.h / 2;
  const a = (it.rot * Math.PI) / 180;
  const cos = Math.cos(a);
  const sin = Math.sin(a);
  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;
  for (const [dx, dy] of [
    [-b.w / 2, -b.h / 2],
    [b.w / 2, -b.h / 2],
    [b.w / 2, b.h / 2],
    [-b.w / 2, b.h / 2],
  ]) {
    const px = cx + dx * cos - dy * sin;
    const py = cy + dx * sin + dy * cos;
    minX = Math.min(minX, px);
    maxX = Math.max(maxX, px);
    minY = Math.min(minY, py);
    maxY = Math.max(maxY, py);
  }
  return { x: minX, y: minY, w: maxX - minX, h: maxY - minY };
}

/** União dos retângulos de vários itens, com margem. Lista vazia → null. */
export function unionBounds(
  items: MoodItem[],
  sizes: Record<number, { w: number; h: number }>,
  u: number,
  margin = 0
): Rect | null {
  if (items.length === 0) return null;
  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;
  for (const it of items) {
    const r = itemBounds(it, sizes, u);
    minX = Math.min(minX, r.x);
    minY = Math.min(minY, r.y);
    maxX = Math.max(maxX, r.x + r.w);
    maxY = Math.max(maxY, r.y + r.h);
  }
  return { x: minX - margin, y: minY - margin, w: maxX - minX + 2 * margin, h: maxY - minY + 2 * margin };
}

/** Amplia o retângulo (sem cortar nada) até ter a proporção `ratio` (largura / altura), mantendo o centro. */
export function frameToRatio(r: Rect, ratio: number): Rect {
  const cx = r.x + r.w / 2;
  const cy = r.y + r.h / 2;
  let w = r.w;
  let h = r.h;
  if (w / h < ratio) w = h * ratio;
  else h = w / ratio;
  return { x: cx - w / 2, y: cy - h / 2, w, h };
}

/** Cor de texto legível sobre um fundo #RRGGBB (luminância relativa > 0.5 → preto, senão branco). */
export function readableOn(hex: string): typeof colors.onLight | typeof colors.onDark {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex.trim());
  if (!m) return colors.onLight;
  const n = parseInt(m[1], 16);
  const lin = (c: number) => {
    const v = c / 255;
    return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
  };
  const L = 0.2126 * lin((n >> 16) & 255) + 0.7152 * lin((n >> 8) & 255) + 0.0722 * lin(n & 255);
  return L > 0.5 ? colors.onLight : colors.onDark;
}

/** Largura mediana das imagens já no quadro (null se não há nenhuma). Serve de tamanho para as novas. */
export function medianImageWidth(items: MoodItem[]): number | null {
  const ws = items.filter((i) => i.kind === 'image' && i.w > 0).map((i) => i.w).sort((a, b) => a - b);
  if (ws.length === 0) return null;
  const m = Math.floor(ws.length / 2);
  return ws.length % 2 ? ws[m] : (ws[m - 1] + ws[m]) / 2;
}

const overlaps = (a: Rect, b: Rect, gap: number): boolean =>
  a.x < b.x + b.w + gap && a.x + a.w + gap > b.x && a.y < b.y + b.h + gap && a.y + a.h + gap > b.y;

/**
 * Acha o lugar livre mais perto de `near` onde cabe um retângulo `w`×`h` sem tocar em nenhum de `taken`
 * (com `gap` de respiro). Sem lugar livre, devolve o ponto mais perto do alvo (último recurso).
 * Devolve o canto superior esquerdo.
 */
export function findFreeSpot(
  w: number,
  h: number,
  taken: Rect[],
  near: { x: number; y: number },
  world: { w: number; h: number },
  gap = 0.06,
  step = 0.05
): { x: number; y: number } {
  const maxX = Math.max(0, world.w - w);
  const maxY = Math.max(0, world.h - h);
  const clampPt = (x: number, y: number) => ({ x: Math.min(maxX, Math.max(0, x)), y: Math.min(maxY, Math.max(0, y)) });
  const want = clampPt(near.x - w / 2, near.y - h / 2);
  const cands: { x: number; y: number; d: number }[] = [];
  for (let x = 0; x <= maxX + 1e-6; x += step) {
    for (let y = 0; y <= maxY + 1e-6; y += step) {
      cands.push({ x, y, d: (x - want.x) ** 2 + (y - want.y) ** 2 });
    }
  }
  cands.sort((a, b) => a.d - b.d);
  for (const c of cands) {
    const r = { x: c.x, y: c.y, w, h };
    if (!taken.some((t) => overlaps(r, t, gap))) return { x: c.x, y: c.y };
  }
  return want;
}
