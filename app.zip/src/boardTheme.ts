import { useEffect, useState } from 'react';
import { colors } from './theme';
import { getSetting, setSetting } from './settings';

/** Aparência do quadro do moodboard: claro (padrão), escuro ou noturno quente. */
export type BoardMode = 'claro' | 'escuro' | 'noturno';
export type BoardLook = { mode: BoardMode; /** Brilho de 0.3 a 1 (1 = sem escurecer). */ dim: number };

export const MIN_DIM = 0.3;
const KEY = 'board_look';

type Palette = { paper: string; dot: string; dark: boolean; tint: string | null; /** Fundo dos cartões sem cor própria. */ card: string };

const PALETTES: Record<BoardMode, Palette> = {
  claro: { paper: colors.paper, dot: colors.inkSoft, dark: false, tint: null, card: colors.paper },
  escuro: { paper: '#14161A', dot: 'rgba(255,255,255,0.22)', dark: true, tint: null, card: '#26282D' },
  // Fundo marrom-café, pontos âmbar e um véu laranja bem leve: tira o azul da luz.
  noturno: { paper: '#1E1610', dot: 'rgba(255,176,96,0.30)', dark: true, tint: 'rgba(255,140,40,0.10)', card: '#33261B' },
};

let look: BoardLook = { mode: 'claro', dim: 1 };
let loaded = false;
const subs = new Set<() => void>();

const clampDim = (v: number) => Math.min(1, Math.max(MIN_DIM, v));

async function load() {
  if (loaded) return;
  loaded = true;
  try {
    const raw = await getSetting(KEY);
    if (raw) {
      const j = JSON.parse(raw);
      const mode: BoardMode = j.mode === 'escuro' || j.mode === 'noturno' ? j.mode : 'claro';
      look = { mode, dim: Number.isFinite(j.dim) ? clampDim(j.dim) : 1 };
      subs.forEach((f) => f());
    }
  } catch {
    // configuração ilegível: segue com o padrão
  }
}

/** Muda a aparência na hora (todas as telas do quadro) e guarda; `save: false` enquanto arrasta o controle. */
export function setBoardLook(p: Partial<BoardLook>, save = true) {
  look = { ...look, ...p, dim: clampDim(p.dim ?? look.dim) };
  subs.forEach((f) => f());
  if (save) setSetting(KEY, JSON.stringify(look)).catch(() => {});
}

export function useBoardLook(): BoardLook & Palette {
  const [, tick] = useState(0);
  useEffect(() => {
    const f = () => tick((n) => n + 1);
    subs.add(f);
    load();
    return () => {
      subs.delete(f);
    };
  }, []);
  return { ...look, ...PALETTES[look.mode] };
}
