/**
 * Editor de notas (estilo Notion): um único texto editável dentro de uma WebView.
 * Fala com o React Native por mensagens (ReactNativeWebView.postMessage) e recebe
 * comandos por funções globais (window.initNote, window.applyLink, ...).
 */
export const EDITOR_HTML = String.raw`<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<style>
:root{--red:#FF3030;--gray:#808080;--line:#2A2A2A;--panel:#1C1C1E}
*{box-sizing:border-box}
html,body{margin:0;background:#000;color:#fff;font-family:Roboto,"Segoe UI",system-ui,sans-serif;-webkit-text-size-adjust:100%}
body{padding:0 22px 90px 22px;font-size:19px;line-height:1.5;letter-spacing:-0.01em;word-wrap:break-word;overflow-wrap:anywhere}
body.editing{padding-bottom:300px}
[contenteditable]{outline:none;-webkit-tap-highlight-color:transparent;caret-color:var(--red)}
::selection{background:rgba(255,48,48,.45)}
#cover{margin:0 -22px;height:0;background-size:cover;background-position:center;position:relative;transition:height .15s}
#cover.has{height:180px}
#coverbtns{display:none;position:absolute;right:12px;bottom:10px;gap:8px}
body.editing #cover.has #coverbtns{display:flex}
.cbtn{background:rgba(0,0,0,.65);color:#fff;border-radius:14px;padding:6px 12px;font-size:14px;font-weight:700}
#addcover{display:none;color:var(--gray);font-size:15px;font-weight:700;padding:14px 0 0}
body.editing #addcover.show{display:block}
#title{font-size:2.3em;font-weight:800;letter-spacing:-0.04em;line-height:1.1;margin:.55em 0 .2em;min-height:1.1em}
#title:empty:before{content:attr(data-ph);color:var(--gray)}
#doc{min-height:40vh}
#doc>*:first-child{margin-top:0}
p{margin:.35em 0}
h1,h2,h3,h4,h5{font-weight:800;letter-spacing:-0.035em;line-height:1.15;margin:1.1em 0 .3em}
h1{font-size:1.9em}h2{font-size:1.55em}h3{font-size:1.3em}h4{font-size:1.12em}
h5{font-size:1em;color:#cfcfcf;text-transform:uppercase;letter-spacing:.04em}
blockquote{margin:.7em 0;padding:.1em 0 .1em 16px;border-left:4px solid #fff;color:#e6e6e6;font-style:italic}
.callout{margin:.7em 0;padding:14px 16px;border-radius:14px;background:#1E1416;border-left:5px solid var(--red);font-size:1.05em;font-weight:600}
.callout+.callout{margin-top:-.5em;border-top-left-radius:0;border-top-right-radius:0}
ul,ol{margin:.4em 0;padding-left:1.4em}
li{margin:.15em 0}
ul.todo{list-style:none;padding-left:0}
ul.todo li{position:relative;padding-left:34px;min-height:1.5em}
ul.todo li:before{content:"";position:absolute;left:2px;top:.22em;width:21px;height:21px;border:2px solid #8a8a8a;border-radius:6px}
ul.todo li[data-done="true"]:before{background:var(--red);border-color:var(--red);content:"✓";color:#fff;font-size:15px;font-weight:800;line-height:17px;text-align:center}
ul.todo li[data-done="true"]{color:var(--gray);text-decoration:line-through}
a{color:#6db3ff;text-decoration:underline}
hr{border:0;border-top:2px solid var(--line);margin:1.2em 0}
img{max-width:100%;height:auto;border-radius:12px;display:block;margin:.6em 0}
video{max-width:100%;border-radius:12px;display:block;margin:.6em 0;background:#111}
table{border-collapse:collapse;display:block;overflow-x:auto;max-width:100%;margin:.7em 0}
th,td{border:1px solid #3a3a3a;padding:8px 10px;min-width:96px;vertical-align:top;font-size:.92em}
th{background:#1c1c1e;font-weight:700;text-align:left}
td.cur,th.cur{outline:1px dashed var(--red)}
.filechip{display:inline-block;margin:.4em 0;padding:10px 14px;border-radius:12px;background:#1c1c1e;color:#fff;text-decoration:none;font-weight:600;font-size:.9em}
.vidcard{position:relative;margin:.7em 0;border-radius:14px;overflow:hidden;background:#111;border:1px solid var(--line)}
.vidcard img{margin:0;border-radius:0;width:100%;max-height:220px;object-fit:cover}
.vidcard .play{position:absolute;left:50%;top:42%;transform:translate(-50%,-50%);width:58px;height:58px;border-radius:29px;background:rgba(255,48,48,.92);text-align:center;line-height:58px;font-size:24px}
.vidcard .vt{padding:10px 14px;font-size:.85em;color:#bbb}
.vidcard.noimg{padding-top:18px}
.toc{margin:.8em 0;padding:14px 16px;border-radius:14px;background:#141414;border:1px solid var(--line);font-size:.92em}
.toc .th{font-weight:800;letter-spacing:-.02em;margin-bottom:6px}
.toc .it{padding:4px 0;color:#d6d6d6}
.toc .it.l2{padding-left:14px}.toc .it.l3{padding-left:28px}.toc .it.l4{padding-left:42px}.toc .it.l5{padding-left:56px}
.toc .none{color:var(--gray)}
#bar{display:none;position:fixed;left:0;right:0;bottom:0;background:#111;border-top:1px solid var(--line);z-index:20}
body.editing #bar{display:block}
#row{display:flex;gap:6px;overflow-x:auto;padding:8px 10px;-webkit-overflow-scrolling:touch}
#row::-webkit-scrollbar{display:none}
.b{flex:0 0 auto;min-width:42px;height:42px;padding:0 10px;border-radius:21px;background:#1C1C1E;color:#fff;font-size:17px;font-weight:700;display:flex;align-items:center;justify-content:center;border:0;font-family:inherit}
.b.on{background:#fff;color:#000}
.sep{flex:0 0 1px;background:#333;margin:6px 2px}
#tblrow{display:none;gap:6px;overflow-x:auto;padding:0 10px 8px}
#tblrow.show{display:flex}
#tblrow .b{font-size:14px;background:#2a1517}
#panel{display:none;position:fixed;left:0;right:0;bottom:60px;max-height:46%;overflow-y:auto;background:var(--panel);border-radius:18px 18px 0 0;padding:12px 12px 8px;z-index:19;box-shadow:0 -8px 24px rgba(0,0,0,.6)}
#panel.show{display:block}
#panel .grid{display:flex;flex-wrap:wrap;gap:8px}
#panel .opt{background:#2a2a2d;border-radius:12px;padding:11px 14px;font-size:16px;font-weight:600;color:#fff}
#panel .opt small{display:block;color:var(--gray);font-size:12px;font-weight:500}
#panel .ttl{color:var(--gray);font-size:13px;font-weight:700;margin:2px 2px 8px}
.sw{width:42px;height:42px;border-radius:21px;border:2px solid #444}
</style>
</head>
<body>
<div id="cover"><div id="coverbtns"><span class="cbtn" data-a="cover">Trocar capa</span><span class="cbtn" data-a="nocover">Remover</span></div></div>
<div id="addcover" data-a="cover">＋ Adicionar capa</div>
<div id="title" data-ph="Título" spellcheck="true"></div>
<div id="doc" spellcheck="true"></div>

<div id="panel"></div>
<div id="bar">
  <div id="tblrow">
    <button class="b" data-t="rowadd">+ Linha</button>
    <button class="b" data-t="coladd">+ Coluna</button>
    <button class="b" data-t="rowdel">− Linha</button>
    <button class="b" data-t="coldel">− Coluna</button>
    <button class="b" data-t="tbldel">Excluir tabela</button>
  </div>
  <div id="row">
    <button class="b" data-c="undo">↶</button>
    <button class="b" data-c="redo">↷</button>
    <div class="sep"></div>
    <button class="b" data-p="block" id="bBlock">Aa</button>
    <button class="b" data-c="bold" id="bB"><b>B</b></button>
    <button class="b" data-c="italic" id="bI"><i>I</i></button>
    <button class="b" data-c="underline" id="bU"><u>U</u></button>
    <button class="b" data-p="color">A●</button>
    <div class="sep"></div>
    <button class="b" data-l="ul">•</button>
    <button class="b" data-l="ol">1.</button>
    <button class="b" data-l="todo">☑</button>
    <div class="sep"></div>
    <button class="b" data-c="link">🔗</button>
    <button class="b" data-c="image">🖼</button>
    <button class="b" data-p="insert">＋</button>
  </div>
</div>

<script>
(function(){
var RN=window.ReactNativeWebView;
function post(o){try{RN.postMessage(JSON.stringify(o));}catch(e){}}
function $(id){return document.getElementById(id);}
var doc=$('doc'),titleEl=$('title'),coverEl=$('cover'),panel=$('panel'),addCover=$('addcover');
var editable=false,lastRange=null,saveT=null,tocT=null,hasCover=false;
try{document.execCommand('defaultParagraphSeparator',false,'p');}catch(e){}
try{document.execCommand('styleWithCSS',false,true);}catch(e){}

/* ---------- utilidades ---------- */
function sel(){return window.getSelection();}
function inDoc(n){return n&&doc.contains(n);}
function saveSel(){
  var s=sel();
  if(s&&s.rangeCount){var r=s.getRangeAt(0);if(inDoc(r.commonAncestorContainer))lastRange=r.cloneRange();}
}
function restoreSel(){
  var s=sel();
  if(s&&s.rangeCount&&inDoc(s.getRangeAt(0).commonAncestorContainer))return;
  doc.focus();
  if(lastRange){s.removeAllRanges();s.addRange(lastRange);}
  else{caretEnd(doc.lastElementChild||doc);}
}
function caretEnd(el){
  var r=document.createRange();r.selectNodeContents(el);r.collapse(false);
  var s=sel();s.removeAllRanges();s.addRange(r);
}
function caretStart(el){
  var r=document.createRange();r.selectNodeContents(el);r.collapse(true);
  var s=sel();s.removeAllRanges();s.addRange(r);
}
function elOf(n){return n&&n.nodeType===3?n.parentNode:n;}
function closest(n,sel2){
  n=elOf(n);
  while(n&&n!==doc){if(n.matches&&n.matches(sel2))return n;n=n.parentNode;}
  return null;
}
function topBlock(n){while(n&&n.parentNode!==doc)n=n.parentNode;return n;}
function curBlock(){
  var s=sel();if(!s||!s.rangeCount)return null;
  var n=elOf(s.anchorNode);
  while(n&&n!==doc){
    if(/^(P|H[1-5]|BLOCKQUOTE|DIV|LI)$/.test(n.tagName)&&n.parentNode)return n;
    n=n.parentNode;
  }
  return null;
}
function isEmptyBlock(b){
  return b&&b.textContent.replace(/\s|\u200B/g,'')===''&&!b.querySelector('img,video,table,hr,.vidcard,.filechip');
}
function ensureTail(){
  var l=doc.lastElementChild;
  var ok=l&&(/^(P|H[1-5]|BLOCKQUOTE)$/.test(l.tagName)||(l.tagName==='DIV'&&l.classList.contains('callout')));
  if(!ok){var p=document.createElement('p');p.innerHTML='<br>';doc.appendChild(p);}
}

/* ---------- salvar / avisar o app ---------- */
function cleanHtml(){
  var c=doc.cloneNode(true);
  var h=c.innerHTML;
  if(c.textContent.replace(/\s/g,'')===''&&!c.querySelector('img,video,table,hr,.vidcard,.filechip'))return '';
  return h;
}
function changed(){
  clearTimeout(tocT);tocT=setTimeout(buildToc,350);
  clearTimeout(saveT);
  saveT=setTimeout(function(){
    post({type:'change',title:titleEl.textContent.replace(/\n/g,' ').trim(),html:cleanHtml()});
  },250);
}

/* ---------- índice (a partir de títulos e subtítulos) ---------- */
function buildToc(){
  var tocs=doc.querySelectorAll('.toc');
  if(!tocs.length)return;
  var hs=doc.querySelectorAll('h1,h2,h3,h4,h5');
  var html='<div class="th">Índice</div>';
  if(!hs.length)html+='<div class="none">Adicione títulos e subtítulos para aparecerem aqui.</div>';
  for(var i=0;i<hs.length;i++){
    var lvl=hs[i].tagName.charAt(1);
    var t=hs[i].textContent.trim();if(!t)continue;
    html+='<div class="it l'+lvl+'" data-i="'+i+'">'+t.replace(/&/g,'&amp;').replace(/</g,'&lt;')+'</div>';
  }
  for(var k=0;k<tocs.length;k++){tocs[k].setAttribute('contenteditable','false');tocs[k].innerHTML=html;}
}

/* ---------- blocos ---------- */
function convertBlock(tag,cls){
  restoreSel();
  var b=curBlock();if(!b)return;
  if(b.tagName==='LI'){
    var l=b.parentNode.tagName==='OL'?'insertOrderedList':'insertUnorderedList';
    document.execCommand(l);
    b=curBlock();if(!b)return;
  }
  if(b.parentNode!==doc&&b.tagName==='DIV'&&!/callout/.test(b.className)){/* div solto */}
  var s=sel(),an=s.anchorNode,ao=s.anchorOffset,fn=s.focusNode,fo=s.focusOffset;
  var n=document.createElement(tag);if(cls)n.className=cls;
  while(b.firstChild)n.appendChild(b.firstChild);
  if(!n.firstChild)n.appendChild(document.createElement('br'));
  b.parentNode.replaceChild(n,b);
  if(an&&an!==b&&fn!==b&&n.contains(an)&&n.contains(fn)){try{s.setBaseAndExtent(an,ao,fn,fo);}catch(e){caretEnd(n);}}
  else caretEnd(n);
  changed();updateState();
}
function toggleBlock(tag,cls){
  var b=curBlock();
  var same=b&&b.tagName.toLowerCase()===tag&&((cls&&b.classList.contains(cls))||(!cls&&!/callout/.test(b.className)));
  if(same)convertBlock('p');else convertBlock(tag,cls);
}
function listCmd(kind){
  restoreSel();
  var li=closest(sel().anchorNode,'li'),list=li?li.parentNode:null;
  if(kind==='ul'){
    if(list&&list.tagName==='UL'&&list.classList.contains('todo')){
      list.classList.remove('todo');
      var ls=list.children;for(var i=0;i<ls.length;i++)ls[i].removeAttribute('data-done');
    }else document.execCommand('insertUnorderedList');
  }else if(kind==='ol'){
    document.execCommand('insertOrderedList');
  }else{
    if(list&&list.tagName==='UL'&&list.classList.contains('todo')){document.execCommand('insertUnorderedList');}
    else{
      if(!(list&&list.tagName==='UL'))document.execCommand('insertUnorderedList');
      li=closest(sel().anchorNode,'li');list=li?li.parentNode:null;
      if(list){list.classList.add('todo');
        var items=list.children;for(var j=0;j<items.length;j++)if(!items[j].hasAttribute('data-done'))items[j].setAttribute('data-done','false');}
    }
  }
  changed();updateState();
}
function insertBlock(html){
  restoreSel();
  var s=sel();
  var anchor=s&&s.rangeCount?topBlock(elOf(s.anchorNode)):null;
  var tmp=document.createElement('div');tmp.innerHTML=html;
  var frag=document.createDocumentFragment();
  while(tmp.firstChild)frag.appendChild(tmp.firstChild);
  var tail=document.createElement('p');tail.innerHTML='<br>';frag.appendChild(tail);
  if(anchor&&anchor.parentNode===doc){
    if(anchor.tagName==='P'&&isEmptyBlock(anchor))doc.replaceChild(frag,anchor);
    else doc.insertBefore(frag,anchor.nextSibling);
  }else doc.appendChild(frag);
  caretStart(tail);
  try{tail.scrollIntoView({block:'center'});}catch(e){}
  buildToc();changed();
}
function esc(t){return String(t).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}

function insertTable(){
  var rows='';
  for(var r=0;r<3;r++){
    rows+='<tr>';
    for(var c=0;c<3;c++)rows+=(r===0?'<th>':'<td>')+'<br>'+(r===0?'</th>':'</td>');
    rows+='</tr>';
  }
  insertBlock('<table><tbody>'+rows+'</tbody></table>');
}
function tableOp(op){
  restoreSel();
  var cell=closest(sel().anchorNode,'td,th');if(!cell)return;
  var tr=cell.parentNode,table=closest(cell,'table'),idx=Array.prototype.indexOf.call(tr.children,cell);
  var rows=table.rows;
  function mk(tag){var c=document.createElement(tag);c.innerHTML='<br>';return c;}
  if(op==='rowadd'){
    var nr=document.createElement('tr');
    for(var i=0;i<tr.children.length;i++)nr.appendChild(mk('td'));
    tr.parentNode.insertBefore(nr,tr.nextSibling);caretStart(nr.firstChild);
  }else if(op==='coladd'){
    for(var r=0;r<rows.length;r++){
      var ref=rows[r].children[idx];
      var nc=mk(ref&&ref.tagName==='TH'?'th':'td');
      rows[r].insertBefore(nc,ref?ref.nextSibling:null);
    }
    caretStart(tr.children[idx+1]);
  }else if(op==='rowdel'){
    if(rows.length<=1){table.parentNode.removeChild(table);}
    else{var nx=tr.nextElementSibling||tr.previousElementSibling;tr.parentNode.removeChild(tr);if(nx)caretStart(nx.children[Math.min(idx,nx.children.length-1)]);}
  }else if(op==='coldel'){
    if(tr.children.length<=1){table.parentNode.removeChild(table);}
    else{for(var q=0;q<rows.length;q++){if(rows[q].children[idx])rows[q].removeChild(rows[q].children[idx]);}
      caretStart(tr.children[Math.min(idx,tr.children.length-1)]);}
  }else if(op==='tbldel'){
    table.parentNode.removeChild(table);
  }
  ensureTail();changed();updateState();
}

/* ---------- mídia (chamadas pelo app) ---------- */
function ytId(u){var m=String(u).match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?(?:.*&)?v=|shorts\/|embed\/|live\/))([\w-]{11})/);return m?m[1]:null;}
window.insertImage=function(uri){insertBlock('<p><img src="'+esc(uri)+'"></p>');};
window.insertVideoFile=function(uri){insertBlock('<p><video controls playsinline preload="metadata" src="'+esc(uri)+'"></video></p>');};
window.insertVideoUrl=function(url){
  url=String(url).trim();if(!/^https?:\/\//i.test(url))url='https://'+url;
  var id=ytId(url);
  if(/\.(mp4|webm|m4v|mov)(\?|$)/i.test(url)){insertBlock('<p><video controls playsinline preload="metadata" src="'+esc(url)+'"></video></p>');return;}
  var thumb=id?'<img src="https://img.youtube.com/vi/'+id+'/hqdefault.jpg" alt="">':'';
  insertBlock('<div class="vidcard'+(id?'':' noimg')+'" contenteditable="false" data-url="'+esc(url)+'">'+thumb+'<div class="play">▶</div><div class="vt">'+esc(url)+'</div></div>');
};
window.insertFile=function(uri,name){
  insertBlock('<p><a class="filechip" contenteditable="false" href="'+esc(uri)+'" data-name="'+esc(name)+'">📎 '+esc(name)+'</a></p>');
};
window.applyLink=function(url){
  restoreSel();
  url=String(url).trim();if(!url)return;
  if(!/^[a-z][a-z0-9+.-]*:/i.test(url))url='https://'+url;
  var s=sel();
  if(s.isCollapsed){document.execCommand('insertHTML',false,'<a href="'+esc(url)+'">'+esc(url)+'</a>&nbsp;');}
  else document.execCommand('createLink',false,url);
  changed();
};
window.removeLink=function(){restoreSel();document.execCommand('unlink');changed();};
window.setCover=function(uri){
  hasCover=!!uri;
  coverEl.style.backgroundImage=uri?'url("'+uri+'")':'';
  coverEl.classList.toggle('has',!!uri);
  addCover.classList.toggle('show',!uri);
};
window.setEditable=function(b){
  editable=!!b;
  doc.contentEditable=editable?'true':'false';
  titleEl.contentEditable=editable?'plaintext-only':'false';
  document.body.classList.toggle('editing',editable);
  if(!editable){closePanel();window.getSelection().removeAllRanges();}
  else{ensureTail();}
  updateState();
};
window.exportDoc=function(){
  post({type:'export',title:titleEl.textContent.replace(/\n/g,' ').trim(),html:cleanHtml()});
};
window.flushNow=function(){
  clearTimeout(saveT);
  post({type:'change',title:titleEl.textContent.replace(/\n/g,' ').trim(),html:cleanHtml()});
};
window.initNote=function(p){
  titleEl.textContent=p.title||'';
  doc.innerHTML=p.html||'';
  var ts=doc.querySelectorAll('ul.todo>li:not([data-done])');for(var i=0;i<ts.length;i++)ts[i].setAttribute('data-done','false');
  if(!doc.firstElementChild){var e=document.createElement('p');e.innerHTML='<br>';doc.appendChild(e);}
  window.setCover(p.cover||null);
  window.setEditable(!!p.editable);
  buildToc();
};

/* ---------- barra e painéis ---------- */
var BLOCKS=[['Texto','p'],['Título 1','h1'],['Título 2','h2'],['Título 3','h3'],['Título 4','h4'],['Título 5','h5'],['Citação','blockquote'],['Frase de destaque','callout']];
var COLORS=[['Branco','#FFFFFF'],['Vermelho','#FF3030'],['Amarelo','#FFD60A'],['Verde','#32D74B'],['Azul','#4DA3FF']];
var INSERTS=[['🖼 Imagem','image'],['🎬 Vídeo (link)','videourl'],['📹 Vídeo (arquivo)','videofile'],['📎 Arquivo','file'],['▦ Tabela','table'],['― Divisor','hr'],['☰ Índice','toc'],['🌄 Capa','cover']];
var openName=null;
function closePanel(){panel.className='';panel.innerHTML='';openName=null;}
function openPanel(name){
  if(openName===name){closePanel();return;}
  openName=name;var h='';
  if(name==='block'){
    h='<div class="ttl">Tipo de texto</div><div class="grid">';
    for(var i=0;i<BLOCKS.length;i++)h+='<div class="opt" data-blk="'+BLOCKS[i][1]+'">'+BLOCKS[i][0]+'</div>';
    h+='</div>';
  }else if(name==='color'){
    h='<div class="ttl">Cor do texto</div><div class="grid">';
    for(var j=0;j<COLORS.length;j++)h+='<div class="sw" data-col="'+COLORS[j][1]+'" style="background:'+COLORS[j][1]+'"></div>';
    h+='</div>';
  }else if(name==='insert'){
    h='<div class="ttl">Inserir</div><div class="grid">';
    for(var k=0;k<INSERTS.length;k++)h+='<div class="opt" data-ins="'+INSERTS[k][1]+'">'+INSERTS[k][0]+'</div>';
    h+='</div>';
  }
  panel.innerHTML=h;panel.className='show';
}
function runInsert(w){
  restoreSel();
  if(w==='image')post({type:'pickImage'});
  else if(w==='videourl')post({type:'askVideoUrl'});
  else if(w==='videofile')post({type:'pickVideo'});
  else if(w==='file')post({type:'pickFile'});
  else if(w==='table')insertTable();
  else if(w==='hr')insertBlock('<hr>');
  else if(w==='toc'){insertBlock('<div class="toc" contenteditable="false"></div>');buildToc();}
  else if(w==='cover')post({type:'pickCover'});
}
function command(c){
  restoreSel();
  if(c==='undo'||c==='redo'){document.execCommand(c);changed();}
  else if(c==='link'){
    var a=closest(sel().anchorNode,'a');
    post({type:'askLink',current:a?a.getAttribute('href'):null,hasSelection:!sel().isCollapsed});
  }
  else if(c==='image')post({type:'pickImage'});
  else{document.execCommand(c);changed();}
  updateState();
}
function updateState(){
  if(!editable)return;
  var st=function(c){try{return document.queryCommandState(c);}catch(e){return false;}};
  $('bB').classList.toggle('on',st('bold'));
  $('bI').classList.toggle('on',st('italic'));
  $('bU').classList.toggle('on',st('underline'));
  var b=curBlock(),lab='Aa';
  if(b){
    if(/^H[1-5]$/.test(b.tagName))lab='T'+b.tagName.charAt(1);
    else if(b.tagName==='BLOCKQUOTE')lab='❝';
    else if(/callout/.test(b.className))lab='★';
  }
  $('bBlock').textContent=lab;
  var cell=closest(sel().rangeCount?sel().anchorNode:null,'td,th');
  $('tblrow').classList.toggle('show',!!cell);
}
document.addEventListener('selectionchange',function(){saveSel();updateState();});

// Os botões não podem roubar o foco do texto (senão o teclado fecha e a seleção some).
$('bar').addEventListener('mousedown',function(e){e.preventDefault();});
panel.addEventListener('mousedown',function(e){e.preventDefault();});
$('bar').addEventListener('click',function(e){
  var t=e.target.closest?e.target.closest('[data-c],[data-p],[data-l],[data-t]'):null;if(!t)return;
  if(t.dataset.c){closePanel();command(t.dataset.c);}
  else if(t.dataset.p)openPanel(t.dataset.p);
  else if(t.dataset.l){closePanel();listCmd(t.dataset.l);}
  else if(t.dataset.t)tableOp(t.dataset.t);
});
panel.addEventListener('click',function(e){
  var t=e.target;
  if(t.dataset.blk){
    var k=t.dataset.blk;
    if(k==='callout')toggleBlock('div','callout');else if(k==='p')convertBlock('p');else toggleBlock(k);
    closePanel();
  }else if(t.dataset.col){
    restoreSel();document.execCommand('foreColor',false,t.dataset.col);changed();closePanel();
  }else if(t.dataset.ins){var w=t.dataset.ins;closePanel();runInsert(w);}
});
document.body.addEventListener('click',function(e){
  var a=e.target.closest?e.target.closest('[data-a]'):null;
  if(a&&editable){e.preventDefault();post({type:a.dataset.a==='cover'?'pickCover':'removeCover'});return;}
  var it=e.target.closest?e.target.closest('.toc .it'):null;
  if(it){
    var hs=doc.querySelectorAll('h1,h2,h3,h4,h5'),h=hs[+it.getAttribute('data-i')];
    if(h)h.scrollIntoView({behavior:'smooth',block:'start'});
    return;
  }
  var li=e.target.closest?e.target.closest('ul.todo>li'):null;
  if(li&&inDoc(li)){
    var rect=li.getBoundingClientRect();
    if(e.clientX-rect.left<34){
      li.setAttribute('data-done',li.getAttribute('data-done')==='true'?'false':'true');
      changed();e.preventDefault();return;
    }
  }
  var link=e.target.closest?e.target.closest('a'):null;
  if(link){
    e.preventDefault();
    if(!editable){
      if(link.classList.contains('filechip'))post({type:'openFile',uri:link.getAttribute('href'),name:link.getAttribute('data-name')});
      else post({type:'openLink',url:link.getAttribute('href')});
    }
    return;
  }
  var vc=e.target.closest?e.target.closest('.vidcard'):null;
  if(vc&&!editable){post({type:'openLink',url:vc.getAttribute('data-url')});}
});

/* ---------- digitação ---------- */
doc.addEventListener('input',function(e){
  if(e.inputType==='insertParagraph'){
    var li=closest(sel().anchorNode,'ul.todo>li');
    if(li)li.setAttribute('data-done','false');
  }
  if(!doc.firstElementChild){var p=document.createElement('p');p.innerHTML='<br>';doc.appendChild(p);caretStart(p);}
  changed();
});
// Enter numa citação/destaque vazio sai do bloco (como no Notion).
doc.addEventListener('beforeinput',function(e){
  if(e.inputType!=='insertParagraph')return;
  var b=curBlock();
  if(b&&isEmptyBlock(b)&&(b.tagName==='BLOCKQUOTE'||/callout/.test(b.className))){
    e.preventDefault();convertBlock('p');
  }
});
titleEl.addEventListener('beforeinput',function(e){
  if(e.inputType==='insertParagraph'||e.inputType==='insertLineBreak'){
    e.preventDefault();doc.focus();
    var f=doc.firstElementChild;if(f)caretStart(f);
  }
});
titleEl.addEventListener('input',changed);

/* ---------- colar: limpa o HTML de fora, mantém o básico ---------- */
var ALLOWED={P:1,H1:1,H2:1,H3:1,H4:1,H5:1,BLOCKQUOTE:1,UL:1,OL:1,LI:1,B:1,STRONG:1,I:1,EM:1,U:1,A:1,BR:1,HR:1,TABLE:1,TBODY:1,THEAD:1,TR:1,TD:1,TH:1,IMG:1,DIV:1,SPAN:1};
function clean(node){
  var kids=Array.prototype.slice.call(node.childNodes);
  for(var i=0;i<kids.length;i++){
    var k=kids[i];
    if(k.nodeType===8){node.removeChild(k);continue;}
    if(k.nodeType!==1)continue;
    var tg=k.tagName;
    if(/^(SCRIPT|STYLE|META|LINK|TITLE|IFRAME|OBJECT|EMBED|FORM|INPUT|BUTTON)$/.test(tg)){node.removeChild(k);continue;}
    clean(k);
    if(!ALLOWED[tg]){while(k.firstChild)node.insertBefore(k.firstChild,k);node.removeChild(k);continue;}
    var keep={};
    if(tg==='A'&&k.getAttribute('href')&&!/^javascript:/i.test(k.getAttribute('href')))keep.href=k.getAttribute('href');
    if(tg==='IMG'&&k.getAttribute('src'))keep.src=k.getAttribute('src');
    if(k.getAttribute('colspan'))keep.colspan=k.getAttribute('colspan');
    if(k.getAttribute('rowspan'))keep.rowspan=k.getAttribute('rowspan');
    if(k.classList.contains('callout'))keep['class']='callout';
    if(k.classList.contains('todo'))keep['class']='todo';
    if(k.hasAttribute('data-done'))keep['data-done']=k.getAttribute('data-done');
    var st=k.getAttribute('style'),cm=st&&st.match(/(?:^|;)\s*color\s*:\s*([^;]+)/i);
    if(cm&&tg==='SPAN')keep.style='color:'+cm[1];
    while(k.attributes.length)k.removeAttribute(k.attributes[0].name);
    for(var a in keep)k.setAttribute(a,keep[a]);
    if((tg==='SPAN'||tg==='DIV')&&!k.attributes.length){while(k.firstChild)node.insertBefore(k.firstChild,k);node.removeChild(k);}
  }
}
doc.addEventListener('paste',function(e){
  var cd=e.clipboardData;if(!cd)return;
  var html=cd.getData('text/html'),txt=cd.getData('text/plain');
  e.preventDefault();
  if(html){
    var t=document.createElement('div');t.innerHTML=html;clean(t);
    document.execCommand('insertHTML',false,t.innerHTML);
  }else if(txt)document.execCommand('insertText',false,txt);
  changed();
});

window.addEventListener('error',function(e){post({type:'jserror',message:String(e.message)});});
post({type:'ready'});
})();
</script>
</body>
</html>`;
