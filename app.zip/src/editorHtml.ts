/**
 * Editor de notas (estilo Notion): um único texto editável dentro de uma WebView.
 * Fala com o React Native por mensagens (ReactNativeWebView.postMessage) e recebe
 * comandos por funções globais (window.initNote, window.applyLink, ...).
 */
import { colors } from './theme';
import { ICON_CSS, icon, iconMap, iconMask, iconUrl } from './htmlIcons';
import { PILL_CSS, TB_SEP, tbBtn, tbPlus } from './toolbarKit';

export const EDITOR_HTML = String.raw`<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<style>
:root{--scale:1;--red:${colors.red};--gray:${colors.muted};--line:${colors.lineDark};--panel:${colors.surface}}
${ICON_CSS}
*{box-sizing:border-box}
html,body{height:100%;margin:0;background:#000;color:#fff;font-family:Roboto,"Segoe UI",system-ui,sans-serif;-webkit-text-size-adjust:100%}
body{display:flex;flex-direction:column;overflow:hidden;font-size:calc(19px * var(--scale,1));line-height:1.5;letter-spacing:-0.01em;word-wrap:break-word;overflow-wrap:anywhere}
/* A nota rola dentro de #scroller e a barra (#dock) fica abaixo dele, no fluxo: com o teclado aberto ou fechado,
   a barra nunca cobre o texto e nunca deixa buraco embaixo. */
#scroller{flex:1 1 auto;min-height:0;overflow-y:auto;overflow-x:hidden;-webkit-overflow-scrolling:touch;overscroll-behavior:contain;touch-action:pan-y;padding:0 16px 90px 16px}
body.editing #scroller{padding-bottom:48px}
#dock{flex:none;position:relative;z-index:20}
[contenteditable]{outline:none;-webkit-tap-highlight-color:transparent;caret-color:var(--red)}
::selection{background:rgba(255,48,48,.45)}
#cover{margin:0 -16px;height:0;background-size:cover;background-position:center;position:relative;transition:height .15s}
#cover.has{height:180px}
#coverbtns{display:none;position:absolute;right:12px;bottom:10px;gap:8px}
body.editing #cover.has #coverbtns{display:flex}
.cbtn{background:rgba(0,0,0,.65);color:#fff;border-radius:14px;padding:6px 12px;font-size:14px;font-weight:700}
#addcover{display:none;color:var(--gray);font-size:15px;font-weight:700;padding:14px 0 0}
body.editing #addcover.show{display:block}
#title{font-size:2.3em;font-weight:800;letter-spacing:-0.04em;line-height:1.1;margin:.55em 0 .2em;min-height:1.1em}
#title:empty:before{content:attr(data-ph);color:var(--gray)}
#doc{min-height:40vh}
#sug:empty{display:none}
#sug{margin:0 0 1em;font-size:16px;letter-spacing:0;line-height:1.35}
.sughead{display:flex;align-items:center;gap:10px;margin:.2em 0 10px}
.sugall{display:flex;align-items:center;gap:12px;font-size:17px;flex:1}
.sgc{width:30px;height:30px;border-radius:50%;background:#2C2C2E;display:inline-flex;align-items:center;justify-content:center;flex:none}
.sgc.on{background:var(--red)}
.sgc.on:after{content:"\2713";color:#fff;font-size:16px;font-weight:800}
.sugapply{background:#3A3A3C;color:#8E8E93;border-radius:10px;padding:6px 14px;font-size:15px;font-weight:700}
.sugapply.on{background:#fff;color:#000}
.sugcard{background:var(--panel);border-radius:22px;padding:6px 12px}
.sugrow{display:flex;gap:12px;align-items:center;padding:9px 0}
.sugtx{min-width:0;flex:1}
.sugl1{font-size:15px;color:#fff}
.sugl2{font-size:14px;color:#BDBDBD;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.sugprev{max-height:42vh;overflow:auto;font-size:15px;line-height:1.4;margin:6px 0 4px;padding:8px 10px;border-radius:12px;background:rgba(255,255,255,.06)}
.sugprev>*:first-child{margin-top:0}
.sugmsg{color:var(--gray);font-size:15px;padding:4px 0}
#doc>*:first-child{margin-top:0}
p{margin:.35em 0}
h1,h2,h3,h4,h5{font-weight:800;letter-spacing:-0.035em;line-height:1.15;margin:1.1em 0 .3em}
h1{font-size:1.9em}h2{font-size:1.55em}h3{font-size:1.3em}h4{font-size:1.12em}
h5{font-size:1em;color:#cfcfcf;text-transform:uppercase;letter-spacing:.04em}
blockquote{margin:.7em 0;padding:.1em 0 .1em 16px;border-left:4px solid #fff;color:#e6e6e6;font-style:italic}
.callout{margin:.7em 0;padding:14px 16px;border-radius:14px;background:#1E1416;border-left:5px solid var(--red);font-size:1.05em;font-weight:600}
.callout+.callout{margin-top:-.5em;border-top-left-radius:0;border-top-right-radius:0}
ul,ol{margin:.4em 0;padding-left:1.4em}
li{margin:.15em 0}
ul.todo{list-style:none;padding-left:0}
ul.todo li{position:relative;padding-left:34px;min-height:1.5em}
ul.todo li:before{content:"";position:absolute;left:2px;top:.22em;width:21px;height:21px;border:2px solid #8a8a8a;border-radius:6px}
ul.todo li[data-done="true"]:before{background:var(--red);border-color:var(--red);content:"";background-image:${iconUrl('check', '#fff')};background-size:70%;background-repeat:no-repeat;background-position:center}
ul.todo li[data-done="true"]{color:var(--gray);text-decoration:line-through}
a{color:#6db3ff;text-decoration:underline}
hr{border:0;border-top:2px solid var(--line);margin:1.2em 0}
img{max-width:100%;height:auto;border-radius:12px;display:block;margin:.6em 0}
video{max-width:100%;border-radius:12px;display:block;margin:.6em 0;background:#111}
table{border-collapse:collapse;display:block;overflow-x:auto;max-width:100%;margin:.7em 0}
th,td{border:1px solid #3a3a3a;padding:8px 10px;min-width:96px;vertical-align:top;font-size:.92em}
th{background:#1c1c1e;font-weight:700;text-align:left}
td.cur,th.cur{outline:1px dashed var(--red)}
.filechip{display:inline-block;margin:.4em 0;padding:10px 14px;border-radius:12px;background:#1c1c1e;color:#fff;text-decoration:none;font-weight:600;font-size:.9em}
.vidcard{position:relative;margin:.7em 0;border-radius:14px;overflow:hidden;background:#111;border:1px solid var(--line)}
.vidcard img{margin:0;border-radius:0;width:100%;max-height:220px;object-fit:cover}
.vidcard .play{position:absolute;left:50%;top:42%;transform:translate(-50%,-50%);width:58px;height:58px;border-radius:29px;background:rgba(255,48,48,.92);text-align:center;line-height:58px;font-size:0}
.vidcard .play::before{content:"";position:absolute;left:50%;top:50%;width:26px;height:26px;transform:translate(-50%,-50%);background:#fff;-webkit-mask:${iconMask('play')} center/contain no-repeat;mask:${iconMask('play')} center/contain no-repeat}
.vidcard .vt{padding:10px 14px;font-size:.85em;color:#bbb}
.vidcard.noimg{padding-top:18px}
a.lkcard{display:flex;flex-direction:column;margin:.7em 0;border-radius:14px;overflow:hidden;background:var(--panel);border:1px solid var(--line);color:#fff;text-decoration:none;max-width:440px}
a.lkcard img{margin:0;border-radius:0;width:100%;max-height:240px;object-fit:cover;flex:none}
a.lkcard.sq{flex-direction:row;align-items:stretch}
a.lkcard.sq img{width:104px;height:104px;max-height:none}
a.lkcard .lk-b{display:flex;flex-direction:column;justify-content:center;gap:3px;padding:10px 14px;min-width:0;flex:1}
.lk-t{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;font-weight:700;font-size:.92em;line-height:1.25;letter-spacing:-0.01em}
.lk-d{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;font-size:.8em;line-height:1.3;color:#bdbdbd}
.lk-s{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:.75em;font-weight:700;color:var(--red)}
a.lkcard[data-state="loading"] .lk-s:after{content:" · carregando…";color:#8e8e93;font-weight:400}
a.lkcard[data-state="fail"] .lk-s:after{content:" · sem prévia";color:#8e8e93;font-weight:400}
.toc{margin:.8em 0;padding:14px 16px;border-radius:14px;background:#141414;border:1px solid var(--line);font-size:.92em}
.toc .th{font-weight:800;letter-spacing:-.02em;margin-bottom:6px}
.toc .it{padding:4px 0;color:#d6d6d6}
.toc .it.l2{padding-left:14px}.toc .it.l3{padding-left:28px}.toc .it.l4{padding-left:42px}.toc .it.l5{padding-left:56px}
.toc .none{color:var(--gray)}
#bar{display:none;margin:0 10px 8px}
body.editing #bar{display:block}
#tblrow{display:none;gap:6px;overflow-x:auto;padding:0 10px 8px}
#tblrow.show{display:flex}
#panel{display:none;position:relative;max-height:42vh;overflow-y:auto;z-index:19}
#panel.show{display:block}
#panel .grid{display:flex;flex-wrap:wrap;gap:8px}
#panel .opt small{display:block;color:var(--gray);font-size:12px;font-weight:500}
#panel.ins{max-height:50vh}
#panel.ins .ttl{font-size:14px;font-weight:400;margin:10px 4px 8px}
#panel.ins .grid{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}
#panel.ins .opt{background:#F2F2F2;color:#000;border-radius:20px;padding:0;min-height:86px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;font-size:13px;font-weight:700;line-height:1.1;text-align:center}
#panel.ins .opt svg{width:23px;height:23px;flex:none}
.szsel{outline:2px solid var(--red);outline-offset:3px}
#panel.ins .szrow{display:flex;align-items:center;gap:8px;margin:0 0 8px}
#panel.ins .szrow .opt{min-height:52px;flex:1;font-size:22px}
#panel.ins .szrow .szv{flex:2;text-align:center;font-size:20px;font-weight:700;color:#000}
#panel.ins .grid.g4{grid-template-columns:repeat(4,1fr)}
#panel.ins .opt.sm{min-height:52px;font-size:15px}
#panel .ttl{color:var(--gray);font-size:13px;font-weight:700;margin:2px 2px 8px}
#panel .opt.dim{opacity:.4}
html{scroll-padding-top:70px}
.sw{width:42px;height:42px;border-radius:21px}
${PILL_CSS}
#findbar{display:none;position:fixed;top:0;left:0;right:0;z-index:25;align-items:center;gap:6px;padding:8px 10px;background:var(--panel);box-shadow:0 6px 20px rgba(0,0,0,.6)}
#findbar.show{display:flex}
#findq{flex:1;min-width:0;background:#000;color:#fff;border:1px solid var(--line);border-radius:10px;padding:9px 10px;font-size:16px;outline:none}
#findn{color:var(--gray);font-size:14px;min-width:42px;text-align:center}
.fb{background:none;border:0;color:#fff;font-size:18px;padding:6px 8px}
::highlight(find){background:#6b5d00;color:#fff}
::highlight(find-cur){background:#FF3030;color:#fff}
a.notelink{color:#FF3030;text-decoration:none;border-bottom:1px solid rgba(255,48,48,.4)}
a.notelink.gone{color:var(--gray);text-decoration:line-through;border:0;font-size:0}
a.notelink.gone::after{content:"nota excluída";font-size:16px}
.subnote{display:flex;align-items:center;gap:12px;margin:.5em 0;padding:12px 14px;border:1px solid var(--line);border-radius:14px;background:#0d0d0d}
.subnote::before{content:"";flex:0 0 auto;width:14px;height:18px;border:2px solid #fff;border-radius:3px}
.subnote .t{font-weight:700}
.subnote.gone .t{color:var(--gray);text-decoration:line-through}
#bl{display:none;margin:36px 0 90px;padding-top:14px;border-top:1px solid var(--line)}
#bl.show{display:block}
.blh{color:var(--gray);font-size:13px;font-weight:700;margin-bottom:6px}
.blr{padding:10px 0;color:#fff}
#panel small{color:var(--gray);font-weight:400}
#panel .col1{flex-direction:column}
#panel .col1 .opt{width:100%}
.toggle{margin:.6em 0;border-left:2px solid var(--line);padding-left:4px}
.tg-head{position:relative;padding-left:28px;font-weight:700;min-height:1.5em}
.tg-head::before{content:"";position:absolute;left:0;top:0;width:26px;height:26px;background:var(--gray);-webkit-mask:${iconMask('caretRight')} center/14px 14px no-repeat;mask:${iconMask('caretRight')} center/14px 14px no-repeat;-webkit-user-select:none;user-select:none}
.toggle[data-open="true"]>.tg-head::before{-webkit-mask-image:${iconMask('caretDown')};mask-image:${iconMask('caretDown')}}
.tg-body{padding-left:28px}
.toggle[data-open="false"]>.tg-body{display:none}
.cols{display:flex;gap:12px;overflow-x:auto;margin:.7em 0;-webkit-overflow-scrolling:touch;touch-action:pan-x pan-y}
.cols::-webkit-scrollbar{display:none}
.col{flex:0 0 max(150px,calc((100% - (var(--n,2) - 1) * 12px) / var(--n,2)));min-width:0;border:1px dashed #2f2f2f;border-radius:10px;padding:4px 10px}
.col img{width:100%}
.cols[data-n="2"]{--n:2}.cols[data-n="3"]{--n:3}
ul.todo[data-prog]::before{content:attr(data-prog);display:block;font-size:.7em;font-weight:700;color:var(--gray);margin-bottom:.25em;pointer-events:none;-webkit-user-select:none;user-select:none}
#colrow{display:none;gap:6px;overflow-x:auto;padding:0 10px 8px}
#colrow.show{display:flex}
s,strike{text-decoration:line-through}
span[style*="background-color"]{color:#111;border-radius:3px}
[data-indent="1"]{margin-left:1.4em}[data-indent="2"]{margin-left:2.8em}[data-indent="3"]{margin-left:4.2em}
[data-indent="4"]{margin-left:5.6em}[data-indent="5"]{margin-left:7em}[data-indent="6"]{margin-left:8.4em}
</style>
</head>
<body>
<div id="scroller">
<div id="cover"><div id="coverbtns"><span class="cbtn" data-a="cover">Trocar capa</span><span class="cbtn" data-a="nocover">Remover</span></div></div>
<div id="addcover" data-a="cover">＋ Adicionar capa</div>
<div id="title" data-ph="Título" spellcheck="true"></div>
<div id="sug"></div>
<div id="doc" spellcheck="true"></div>
<div id="bl"></div>
</div>

<div id="findbar"><input id="findq" type="text" placeholder="Localizar na nota" autocomplete="off" autocapitalize="off"><span id="findn">0/0</span><button class="fb" id="findp">${icon('caretUp')}</button><button class="fb" id="findx">${icon('caretDown')}</button><button class="fb" id="findc">${icon('close')}</button></div>
<div id="dock">
<div id="panel"></div>
<div id="bar">
  <div id="tblrow">
    <button class="b" data-t="rowadd">+ Linha</button>
    <button class="b" data-t="coladd">+ Coluna</button>
    <button class="b" data-t="rowdel">− Linha</button>
    <button class="b" data-t="coldel">− Coluna</button>
    <button class="b" data-t="tbldel">Excluir tabela</button>
  </div>
  <div id="colrow">
    <button class="b" data-k="add">+ Coluna</button>
    <button class="b" data-k="rem">− Coluna</button>
    <button class="b" data-k="del">Excluir colunas</button>
  </div>
  <div id="rw">
    <div id="row">
      ${tbPlus}
      ${TB_SEP}
      ${tbBtn('undo', 'Desfazer', 'data-c="undo" id="bUndo"')}
      ${tbBtn('redo', 'Refazer', 'data-c="redo" id="bRedo"')}
      ${TB_SEP}
      ${tbBtn('heading', 'Tipo de texto', 'data-p="block" id="bBlock"')}
      ${tbBtn('type', 'Fonte', 'data-p="font" id="bFont"')}
      ${tbBtn('size', 'Tamanho', 'data-p="size" id="bSize"')}
      ${tbBtn('palette', 'Cor do texto', 'data-p="color"')}
      ${tbBtn('highlight', 'Marca-texto', 'data-p="hilite"')}
      ${TB_SEP}
      ${tbBtn('underline', 'Sublinhado', 'data-c="underline" id="bU"')}
      ${tbBtn('para', 'Parágrafo', 'data-p="para" id="bPara"')}
      ${tbBtn('ul', 'Lista', 'data-l="ul"')}
      ${tbBtn('ol', 'Lista numerada', 'data-l="ol"')}
      ${tbBtn('todo', 'Lista de tarefas', 'data-l="todo"')}
      ${tbBtn('paint', 'Formatação e blocos', 'data-p="paint" id="bPaint"')}
    </div>
  </div>
</div>
</div>

<script>
(function(){
var RN=window.ReactNativeWebView;
function post(o){try{RN.postMessage(JSON.stringify(o));}catch(e){}}
function $(id){return document.getElementById(id);}
var doc=$('doc'),titleEl=$('title'),coverEl=$('cover'),panel=$('panel'),addCover=$('addcover'),scEl=$('scroller');
var editable=false,lastRange=null,saveT=null,tocT=null,hasCover=false;
try{document.execCommand('defaultParagraphSeparator',false,'p');}catch(e){}
try{document.execCommand('styleWithCSS',false,true);}catch(e){}

/* ---------- utilidades ---------- */
function sel(){return window.getSelection();}
function inDoc(n){return n&&doc.contains(n);}
function saveSel(){
  var s=sel();
  if(s&&s.rangeCount){var r=s.getRangeAt(0);if(inDoc(r.commonAncestorContainer))lastRange=r.cloneRange();}
}
function restoreSel(){
  var s=sel();
  if(s&&s.rangeCount&&inDoc(s.getRangeAt(0).commonAncestorContainer))return;
  doc.focus();
  if(lastRange){s.removeAllRanges();s.addRange(lastRange);}
  else{caretEnd(doc.lastElementChild||doc);}
}
function caretEnd(el){
  var r=document.createRange();r.selectNodeContents(el);r.collapse(false);
  var s=sel();s.removeAllRanges();s.addRange(r);
}
function caretStart(el){
  var r=document.createRange();r.selectNodeContents(el);r.collapse(true);
  var s=sel();s.removeAllRanges();s.addRange(r);
}
function elOf(n){return n&&n.nodeType===3?n.parentNode:n;}
function closest(n,sel2){
  n=elOf(n);
  while(n&&n!==doc){if(n.matches&&n.matches(sel2))return n;n=n.parentNode;}
  return null;
}
function topBlock(n){while(n&&n.parentNode!==doc)n=n.parentNode;return n;}
var SPECIAL=/(^|\s)(tg-head|tg-body|toggle|cols|col|toc|vidcard|subnote|ai-block|ai-h|ai-c)(\s|$)/;
function curBlock(){
  var s=sel();if(!s||!s.rangeCount)return null;
  var n=elOf(s.anchorNode);
  while(n&&n!==doc){
    if(/^(P|H[1-5]|BLOCKQUOTE|DIV|LI)$/.test(n.tagName)&&n.parentNode&&!SPECIAL.test(n.className||''))return n;
    n=n.parentNode;
  }
  return null;
}
function isEmptyBlock(b){
  return b&&b.textContent.replace(/\s|\u200B/g,'')===''&&!b.querySelector('img,video,table,hr,.vidcard,.filechip,.lkcard');
}
function ensureTail(){
  var l=doc.lastElementChild;
  var ok=l&&(/^(P|H[1-5]|BLOCKQUOTE)$/.test(l.tagName)||(l.tagName==='DIV'&&l.classList.contains('callout')));
  if(!ok){var p=document.createElement('p');p.innerHTML='<br>';doc.appendChild(p);}
}

/* ---------- salvar / avisar o app ---------- */
function cleanHtml(){
  var c=doc.cloneNode(true);
  var gn=c.querySelectorAll('.gone');for(var g2=0;g2<gn.length;g2++){gn[g2].classList.remove('gone');if(!gn[g2].getAttribute('class'))gn[g2].removeAttribute('class');}
  var dp=c.querySelectorAll('[data-prog]');for(var q=0;q<dp.length;q++)dp[q].removeAttribute('data-prog');
  var zs=c.querySelectorAll('.szsel');for(var z2=0;z2<zs.length;z2++){zs[z2].classList.remove('szsel');if(!zs[z2].getAttribute('class'))zs[z2].removeAttribute('class');}
  var du=c.querySelectorAll('[data-ui]');for(var q2=0;q2<du.length;q2++)du[q2].parentNode.removeChild(du[q2]);
  var h=c.innerHTML.replace(/<(\/?)strike\b/gi,'<$1s');
  if(c.textContent.replace(/\s/g,'')===''&&!c.querySelector('img,video,table,hr,.vidcard,.filechip,.lkcard'))return '';
  return h;
}
function changed(){
  updateProgress();
  clearTimeout(tocT);tocT=setTimeout(buildToc,350);
  clearTimeout(saveT);
  saveT=setTimeout(function(){
    post({type:'change',title:titleEl.textContent.replace(/\n/g,' ').trim(),html:cleanHtml()});
  },250);
}

/* ---------- índice (a partir de títulos e subtítulos) ---------- */
function tocInner(bare){
  var hs=doc.querySelectorAll('h1,h2,h3,h4,h5');
  var html=bare?'':'<div class="th">Índice</div>';
  if(!hs.length)html+='<div class="none">Adicione títulos e subtítulos para aparecerem aqui.</div>';
  for(var i=0;i<hs.length;i++){
    var lvl=hs[i].tagName.charAt(1);
    var t=hs[i].textContent.trim();if(!t)continue;
    html+='<div class="it l'+lvl+'" data-i="'+i+'">'+t.replace(/&/g,'&amp;').replace(/</g,'&lt;')+'</div>';
  }
  return html;
}
function buildToc(){
  var tocs=doc.querySelectorAll('.toc');
  if(!tocs.length)return;
  var html=tocInner(false);
  for(var k=0;k<tocs.length;k++){tocs[k].setAttribute('contenteditable','false');tocs[k].innerHTML=html;}
}

/* ---------- blocos ---------- */
function convertBlock(tag,cls){
  restoreSel();
  var b=curBlock();if(!b)return;
  if(b.tagName==='LI'){
    var l=b.parentNode.tagName==='OL'?'insertOrderedList':'insertUnorderedList';
    document.execCommand(l);
    b=curBlock();if(!b)return;
  }
  if(b.parentNode!==doc&&b.tagName==='DIV'&&!/callout/.test(b.className)){/* div solto */}
  var s=sel(),an=s.anchorNode,ao=s.anchorOffset,fn=s.focusNode,fo=s.focusOffset;
  var n=document.createElement(tag);if(cls)n.className=cls;
  if(b.style&&b.style.textAlign)n.style.textAlign=b.style.textAlign;
  if(b.getAttribute('data-indent'))n.setAttribute('data-indent',b.getAttribute('data-indent'));
  while(b.firstChild)n.appendChild(b.firstChild);
  if(!n.firstChild)n.appendChild(document.createElement('br'));
  b.parentNode.replaceChild(n,b);
  if(an&&an!==b&&fn!==b&&n.contains(an)&&n.contains(fn)){try{s.setBaseAndExtent(an,ao,fn,fo);}catch(e){caretEnd(n);}}
  else caretEnd(n);
  changed();updateState();
}
function toggleBlock(tag,cls){
  var b=curBlock();
  var same=b&&b.tagName.toLowerCase()===tag&&((cls&&b.classList.contains(cls))||(!cls&&!/callout/.test(b.className)));
  if(same)convertBlock('p');else convertBlock(tag,cls);
}
function listCmd(kind){
  restoreSel();
  var li=closest(sel().anchorNode,'li'),list=li?li.parentNode:null;
  if(kind==='ul'){
    if(list&&list.tagName==='UL'&&list.classList.contains('todo')){
      list.classList.remove('todo');
      var ls=list.children;for(var i=0;i<ls.length;i++)ls[i].removeAttribute('data-done');
    }else document.execCommand('insertUnorderedList');
  }else if(kind==='ol'){
    document.execCommand('insertOrderedList');
  }else{
    if(list&&list.tagName==='UL'&&list.classList.contains('todo')){document.execCommand('insertUnorderedList');}
    else{
      if(!(list&&list.tagName==='UL'))document.execCommand('insertUnorderedList');
      li=closest(sel().anchorNode,'li');list=li?li.parentNode:null;
      if(list){list.classList.add('todo');
        var items=list.children;for(var j=0;j<items.length;j++)if(!items[j].hasAttribute('data-done'))items[j].setAttribute('data-done','false');}
    }
  }
  changed();updateState();
}
function containerOf(n){
  n=elOf(n);
  while(n&&n!==doc){if(n.classList&&(n.classList.contains('tg-body')||n.classList.contains('col')))return n;n=n.parentNode;}
  return doc;
}
function childIn(cont,n){
  n=elOf(n);
  while(n&&n.parentNode!==cont)n=n.parentNode;
  return n&&n.parentNode===cont?n:null;
}
/* Insere um bloco depois do bloco atual. Tabela, índice e colunas não entram em colunas; colunas não entram em recolhível. */
function insertBlock(html){
  restoreSel();
  var s=sel(),cont=doc,anchor=null;
  if(s&&s.rangeCount){
    cont=containerOf(s.anchorNode);
    var isCols=/class="cols"/.test(html);
    if(cont!==doc&&(isCols||(cont.classList.contains('col')&&/<table|class="toc"/.test(html))))cont=doc;
    anchor=childIn(cont,s.anchorNode);
  }
  var tmp=document.createElement('div');tmp.innerHTML=html;
  var frag=document.createDocumentFragment();
  while(tmp.firstChild)frag.appendChild(tmp.firstChild);
  var first=frag.firstChild;
  var tail=document.createElement('p');tail.innerHTML='<br>';frag.appendChild(tail);
  if(anchor){
    if(anchor.tagName==='P'&&isEmptyBlock(anchor))cont.replaceChild(frag,anchor);
    else cont.insertBefore(frag,anchor.nextSibling);
  }else cont.appendChild(frag);
  normalizeStructure();
  caretStart(tail);
  try{tail.scrollIntoView({block:'center'});}catch(e){}
  buildToc();changed();
  return first;
}
function esc(t){return String(t).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}

function insertTable(){
  var rows='';
  for(var r=0;r<3;r++){
    rows+='<tr>';
    for(var c=0;c<3;c++)rows+=(r===0?'<th>':'<td>')+'<br>'+(r===0?'</th>':'</td>');
    rows+='</tr>';
  }
  insertBlock('<table><tbody>'+rows+'</tbody></table>');
}
function tableOp(op){
  restoreSel();
  var cell=closest(sel().anchorNode,'td,th');if(!cell)return;
  var tr=cell.parentNode,table=closest(cell,'table'),idx=Array.prototype.indexOf.call(tr.children,cell);
  var rows=table.rows;
  function mk(tag){var c=document.createElement(tag);c.innerHTML='<br>';return c;}
  if(op==='rowadd'){
    var nr=document.createElement('tr');
    for(var i=0;i<tr.children.length;i++)nr.appendChild(mk('td'));
    tr.parentNode.insertBefore(nr,tr.nextSibling);caretStart(nr.firstChild);
  }else if(op==='coladd'){
    for(var r=0;r<rows.length;r++){
      var ref=rows[r].children[idx];
      var nc=mk(ref&&ref.tagName==='TH'?'th':'td');
      rows[r].insertBefore(nc,ref?ref.nextSibling:null);
    }
    caretStart(tr.children[idx+1]);
  }else if(op==='rowdel'){
    if(rows.length<=1){table.parentNode.removeChild(table);}
    else{var nx=tr.nextElementSibling||tr.previousElementSibling;tr.parentNode.removeChild(tr);if(nx)caretStart(nx.children[Math.min(idx,nx.children.length-1)]);}
  }else if(op==='coldel'){
    if(tr.children.length<=1){table.parentNode.removeChild(table);}
    else{for(var q=0;q<rows.length;q++){if(rows[q].children[idx])rows[q].removeChild(rows[q].children[idx]);}
      caretStart(tr.children[Math.min(idx,tr.children.length-1)]);}
  }else if(op==='tbldel'){
    table.parentNode.removeChild(table);
  }
  ensureTail();changed();updateState();
}

/* ---------- localizar na nota: não altera o texto salvo (usa CSS Custom Highlight; sem ela, só marca a atual por seleção) ---------- */
var findOpen=false,findRanges=[],findCur=-1,findOpened=[],findT=null;
var HL=(window.CSS&&CSS.highlights&&window.Highlight)?true:false;
function foldMap(t){
  var f='',m=[];
  for(var i=0;i<t.length;i++){
    var c=t.charAt(i).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
    for(var j=0;j<c.length;j++){f+=c.charAt(j);m.push(i);}
  }
  return {f:f,m:m};
}
function findRestore(){
  for(var i=0;i<findOpened.length;i++)findOpened[i].setAttribute('data-open','false');
  findOpened=[];
}
function findClearHl(){
  if(HL){CSS.highlights.delete('find');CSS.highlights.delete('find-cur');}
}
function findPaint(){
  if(!HL)return;
  var others=[];
  for(var i=0;i<findRanges.length;i++)if(i!==findCur)others.push(findRanges[i]);
  CSS.highlights.set('find',new Highlight(...others));
  if(findCur>=0)CSS.highlights.set('find-cur',new Highlight(findRanges[findCur]));else CSS.highlights.delete('find-cur');
}
function findRun(keep){
  findRestore();findClearHl();
  var q=fold($('findq').value.trim());
  findRanges=[];findCur=-1;
  if(q){
    var w=document.createTreeWalker(doc,NodeFilter.SHOW_TEXT,null),n;
    while((n=w.nextNode())){
      if(n.parentElement&&n.parentElement.closest('[data-ui],.toc'))continue;
      var fm=foldMap(n.nodeValue),at=0,k;
      while((k=fm.f.indexOf(q,at))>=0){
        var r=document.createRange();
        r.setStart(n,fm.m[k]);r.setEnd(n,fm.m[k+q.length-1]+1);
        findRanges.push(r);at=k+q.length;
      }
    }
    if(findRanges.length)findCur=keep>=0&&keep<findRanges.length?keep:0;
  }
  findShow();
}
function findShow(){
  $('findn').textContent=findRanges.length?(findCur+1)+'/'+findRanges.length:'0/0';
  if(findCur<0){findPaint();return;}
  var r=findRanges[findCur],el=r.startContainer.parentElement;
  // texto dentro de recolhível fechado: abre só enquanto a busca está aberta
  var tg=el&&el.closest('.toggle[data-open="false"]');
  while(tg){tg.setAttribute('data-open','true');findOpened.push(tg);tg=tg.parentElement&&tg.parentElement.closest('.toggle[data-open="false"]');}
  findPaint();
  if(!HL){var s0=sel();s0.removeAllRanges();s0.addRange(r.cloneRange());}
  try{el.scrollIntoView({block:'center',inline:'center'});}catch(e){}
}
function findStep(d){
  if(!findRanges.length)return;
  findCur=(findCur+d+findRanges.length)%findRanges.length;findShow();
}
function findSched(){clearTimeout(findT);findT=setTimeout(function(){findRun(-1);},120);}
window.openOutline=function(){openPanel('outline');};
window.openFind=function(){
  findOpen=true;$('findbar').classList.add('show');closePanel();
  post({type:'findState',open:true});
  var q=$('findq');q.focus();q.select();if(q.value)findRun(-1);
};
window.closeFind=function(){
  findOpen=false;findRestore();findClearHl();findRanges=[];findCur=-1;
  $('findbar').classList.remove('show');$('findq').blur();
  post({type:'findState',open:false});
};
$('findq').addEventListener('input',findSched);
$('findq').addEventListener('keydown',function(e){if(e.key==='Enter'){e.preventDefault();findStep(e.shiftKey?-1:1);}});
$('findp').addEventListener('click',function(){findStep(-1);});
$('findx').addEventListener('click',function(){findStep(1);});
$('findc').addEventListener('click',function(){window.closeFind();});
['touchstart','touchmove','touchend'].forEach(function(ev){$('findbar').addEventListener(ev,function(e){e.stopPropagation();},{passive:true});});

/* ---------- estruturas (índice, recolhível, colunas) ---------- */
function normalizeStructure(){
  var i,a,c;
  a=doc.querySelectorAll('.toc,.subnote');for(i=0;i<a.length;i++)a[i].setAttribute('contenteditable','false');
  a=doc.querySelectorAll('.cols');
  for(i=0;i<a.length;i++){
    a[i].setAttribute('contenteditable','false');
    var n=Math.max(2,Math.min(3,a[i].children.length));
    a[i].setAttribute('data-n',String(n));
  }
  a=doc.querySelectorAll('.col');
  for(i=0;i<a.length;i++){
    a[i].setAttribute('contenteditable',editable?'true':'false');
    if(!a[i].firstElementChild)a[i].innerHTML='<p><br></p>';
  }
  a=doc.querySelectorAll('.toggle');
  for(i=0;i<a.length;i++){
    var t=a[i];
    if(t.getAttribute('data-open')!=='false')t.setAttribute('data-open','true');
    var hd=null,bd=null;
    for(c=0;c<t.children.length;c++){
      if(!hd&&t.children[c].classList.contains('tg-head'))hd=t.children[c];
      else if(!bd&&t.children[c].classList.contains('tg-body'))bd=t.children[c];
    }
    if(!hd){hd=document.createElement('div');hd.className='tg-head';hd.innerHTML='<br>';t.insertBefore(hd,t.firstChild);}
    if(!bd){bd=document.createElement('div');bd.className='tg-body';bd.innerHTML='<p><br></p>';t.appendChild(bd);}
    if(!bd.firstElementChild)bd.innerHTML='<p><br></p>';
  }
}
/* "3 de 8 concluídas" acima de cada lista de tarefas com 2 ou mais itens. É só um atributo temporário (não é salvo). */
function updateProgress(){
  var ls=doc.querySelectorAll('ul.todo');
  for(var i=0;i<ls.length;i++){
    var ul=ls[i];
    if(ul.parentNode&&ul.parentNode.tagName==='LI'){ul.removeAttribute('data-prog');continue;}
    var its=ul.querySelectorAll(':scope>li'),d=0;
    for(var j=0;j<its.length;j++)if(its[j].getAttribute('data-done')==='true')d++;
    if(its.length>=2)ul.setAttribute('data-prog',d+' de '+its.length+' concluídas');else ul.removeAttribute('data-prog');
  }
}
function insertToggle(){
  var first=insertBlock('<div class="toggle" data-open="true"><div class="tg-head"><br></div><div class="tg-body"><p><br></p></div></div>');
  var h=first&&first.querySelector?first.querySelector('.tg-head'):null;
  if(h)caretStart(h);
}
function newCol(){
  var c=document.createElement('div');c.className='col';
  c.setAttribute('contenteditable',editable?'true':'false');c.innerHTML='<p><br></p>';
  return c;
}
function insertCols(n){
  var h='<div class="cols" data-n="'+n+'" contenteditable="false">';
  for(var i=0;i<n;i++)h+='<div class="col" contenteditable="true"><p><br></p></div>';
  h+='</div>';
  var first=insertBlock(h);
  var p=first&&first.querySelector?first.querySelector('.col p'):null;
  if(p)caretStart(p);
}
function colHasContent(box){
  var cs=box.children;
  for(var i=0;i<cs.length;i++){
    var bs=cs[i].children;
    if(bs.length>1)return true;
    if(bs.length===1&&!isEmptyBlock(bs[0]))return true;
  }
  return false;
}
function colOp(op){
  restoreSel();
  var col=closest(sel().anchorNode,'.col');if(!col)return;
  var box=col.parentNode;
  if(op==='add'){
    if(box.children.length>=3)return;
    var nc=newCol();box.insertBefore(nc,col.nextSibling);
    box.setAttribute('data-n',String(box.children.length));caretStart(nc.firstChild);
  }else if(op==='rem'){
    if(box.children.length<=2)return; // com 2 colunas, use "Excluir colunas"
    var last=box.lastElementChild,prev=last.previousElementSibling;
    if(!(last.children.length===1&&isEmptyBlock(last.firstElementChild))){
      // o conteúdo da coluna removida vai para o fim da anterior
      if(prev.children.length===1&&isEmptyBlock(prev.firstElementChild))prev.innerHTML='';
      while(last.firstChild)prev.appendChild(last.firstChild);
    }
    box.removeChild(last);
    box.setAttribute('data-n',String(box.children.length));
    caretEnd(prev.lastElementChild||prev);
  }else if(op==='del'){
    if(colHasContent(box))post({type:'askDeleteCols'});else window.deleteCols();
    return;
  }
  changed();updateState();
}
window.deleteCols=function(){
  restoreSel();
  var box=closest(sel().anchorNode,'.cols');if(!box)return;
  var nx=box.nextElementSibling||box.previousElementSibling;
  box.parentNode.removeChild(box);
  ensureTail();
  if(nx&&nx.parentNode)caretStart(nx);else caretEnd(doc.lastElementChild||doc);
  changed();updateState();
};

/* ---------- mídia (chamadas pelo app) ---------- */
function ytId(u){var m=String(u).match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?(?:.*&)?v=|shorts\/|embed\/|live\/))([\w-]{11})/);return m?m[1]:null;}
window.insertHtml=function(h){insertBlock(h);};
window.insertImage=function(uri){insertBlock('<p><img src="'+esc(uri)+'"></p>');};
window.insertVideoFile=function(uri){insertBlock('<p><video controls playsinline preload="metadata" src="'+esc(uri)+'"></video></p>');};
window.insertVideoUrl=function(url){
  url=String(url).trim();if(!/^https?:\/\//i.test(url))url='https://'+url;
  var id=ytId(url);
  if(/\.(mp4|webm|m4v|mov)(\?|$)/i.test(url)){insertBlock('<p><video controls playsinline preload="metadata" src="'+esc(url)+'"></video></p>');return;}
  var thumb=id?'<img src="https://img.youtube.com/vi/'+id+'/hqdefault.jpg" alt="">':'';
  insertBlock('<div class="vidcard'+(id?'':' noimg')+'" contenteditable="false" data-url="'+esc(url)+'">'+thumb+'<div class="play">▶</div><div class="vt">'+esc(url)+'</div></div>');
};
window.insertFile=function(uri,name){
  insertBlock('<p><a class="filechip" contenteditable="false" href="'+esc(uri)+'" data-name="'+esc(name)+'">📎 '+esc(name)+'</a></p>');
};
/* ---------- cards de link (capa, título, site) ---------- */
function hostOf(u){var m=/^https?:\/\/([^\/?#:]+)/i.exec(String(u));return m?m[1].toLowerCase().replace(/^www\./,''):String(u);}
function newLid(){return 'l'+Date.now().toString(36)+Math.random().toString(36).slice(2,6);}
function cardHtml(url,d){
  d=d||{};
  var sq=!!d.img&&d.ar>0.85&&d.ar<1.2;
  return '<p><a class="lkcard'+(sq?' sq':'')+'" contenteditable="false" href="'+esc(url)+'" data-lid="'+esc(d.lid||newLid())+'" data-state="'+(d.state||'loading')+'">'
    +(d.img?'<img src="'+esc(d.img)+'" alt="">':'')
    +'<span class="lk-b"><span class="lk-t">'+esc(d.title||hostOf(url))+'</span>'
    +(d.desc?'<span class="lk-d">'+esc(d.desc)+'</span>':'')
    +'<span class="lk-s">'+esc(d.site||hostOf(url))+'</span></span></a></p>';
}
function cardOf(lid){return doc.querySelector('a.lkcard[data-lid="'+String(lid).replace(/[^\w-]/g,'')+'"]');}
function insertLinkCard(url){
  var lid=newLid();
  insertBlock(cardHtml(url,{lid:lid,state:'loading'}));
  post({type:'linkCard',lid:lid,url:url});
  return lid;
}
window.insertLinkCard=function(url){
  url=String(url).trim();if(!url)return;
  if(!/^[a-z][a-z0-9+.-]*:/i.test(url))url='https://'+url;
  insertLinkCard(url);
};
/* O app buscou a prévia: preenche o card (capa, título, descrição, site). */
window.fillLinkCard=function(lid,d){
  var cs=doc.querySelectorAll('a.lkcard[data-lid="'+String(lid).replace(/[^\w-]/g,'')+'"]');
  for(var i=0;i<cs.length;i++){
    var c=cs[i],url=c.getAttribute('href');
    var tmp=document.createElement('div');
    tmp.innerHTML=cardHtml(url,{lid:lid,state:d&&d.ok?'ok':'fail',title:d&&d.title,desc:d&&d.desc,site:d&&d.site,img:d&&d.img,ar:d&&d.ar});
    var n=tmp.querySelector('a.lkcard');
    c.className=n.className;c.setAttribute('data-state',n.getAttribute('data-state'));c.innerHTML=n.innerHTML;
  }
  changed();
};
window.refreshLinkCard=function(lid){
  var c=cardOf(lid);if(!c)return;
  c.setAttribute('data-state','loading');
  post({type:'linkCard',lid:String(lid),url:c.getAttribute('href')});
};
window.cardToLink=function(lid){
  var c=cardOf(lid);if(!c)return;
  var u=c.getAttribute('href'),p=c.parentNode;
  var a=document.createElement('a');a.setAttribute('href',u);a.textContent=u;
  if(p&&p.tagName==='P'&&p.parentNode===doc){p.innerHTML='';p.appendChild(a);}else p.replaceChild(a,c);
  changed();
};
window.removeLinkCard=function(lid){
  var c=cardOf(lid);if(!c)return;
  var p=c.parentNode;
  if(p&&p.tagName==='P'&&p.children.length===1&&p.textContent.replace(/\s|\u200B/g,'')==='')p.parentNode.removeChild(p);else p.removeChild(c);
  ensureTail();changed();
};
/* Link de texto que já existe na nota vira card (o texto do link some se era só o endereço). */
window.linkToCard=function(){
  restoreSel();
  var a=closest(sel().anchorNode,'a');if(!a)return;
  var u=a.getAttribute('href')||'';if(!/^https?:\/\//i.test(u))return;
  var t=a.textContent.trim(),bare=t===u.trim()||t===u.trim().replace(/^https?:\/\//i,'');
  var blk=a.parentNode;
  insertLinkCard(u);
  if(bare&&a.parentNode){
    a.parentNode.removeChild(a);
    if(blk&&blk!==doc&&blk.parentNode&&blk.tagName==='P'&&blk.textContent.replace(/\s|\u200B/g,'')===''&&!blk.querySelector('img,.lkcard,.filechip,.vidcard'))blk.parentNode.removeChild(blk);
  }
  changed();
};
/* Cards que ficaram "carregando" (app fechado no meio): pede a prévia de novo ao abrir a nota. */
function resumeCards(){
  var cs=doc.querySelectorAll('a.lkcard[data-state="loading"]');
  for(var i=0;i<cs.length;i++){
    var lid=cs[i].getAttribute('data-lid');
    if(!lid){lid=newLid();cs[i].setAttribute('data-lid',lid);}
    post({type:'linkCard',lid:lid,url:cs[i].getAttribute('href')});
  }
}
window.applyLink=function(url){
  restoreSel();
  url=String(url).trim();if(!url)return;
  if(!/^[a-z][a-z0-9+.-]*:/i.test(url))url='https://'+url;
  var s=sel();
  if(s.isCollapsed&&/^https?:\/\//i.test(url)){insertLinkCard(url);return;}
  if(s.isCollapsed){document.execCommand('insertHTML',false,'<a href="'+esc(url)+'">'+esc(url)+'</a>&nbsp;');}
  else document.execCommand('createLink',false,url);
  changed();
};
window.removeLink=function(){restoreSel();document.execCommand('unlink');changed();};
window.setCover=function(uri){
  hasCover=!!uri;
  coverEl.style.backgroundImage=uri?'url("'+uri+'")':'';
  coverEl.classList.toggle('has',!!uri);
  addCover.classList.toggle('show',!uri);
};
/* Teclado minimizado: as funções da barra não podem trazê-lo de volta. Com inputmode=none o foco/seleção
   não abre o teclado; um toque no texto (sem arrastar) libera de novo. */
var kbOff=false,kbTapRestore=false,kbX=0,kbY=0;
function setKbOff(v){
  kbOff=!!v;
  var a=document.querySelectorAll('[contenteditable]:not([contenteditable="false"])');
  for(var i=0;i<a.length;i++){if(kbOff)a[i].setAttribute('inputmode','none');else a[i].removeAttribute('inputmode');}
}
window.kbHidden=function(h){setKbOff(!!h);};
/* área de transferência do app: só o pincel da nota corrida interessa aqui */
var CLIPF=null;
window.setClip=function(c){CLIPF=(c&&c.frame)||null;FPAINT=(c&&c.style&&c.style.kind==='flow')?c.style.fmt:null;if(openName==='paint'){openName=null;openPanel('paint');}};
/* Mantém o cursor à vista, acima da barra: ao digitar e quando o teclado abre ou fecha. */
function keepCaret(){
  if(!editable)return;
  var s=window.getSelection();if(!s||!s.rangeCount)return;
  var n=s.anchorNode;if(!n||!(doc.contains(n)||titleEl.contains(n)))return;
  var b=null,rc=s.getRangeAt(0).getClientRects();
  if(rc.length)b=rc[rc.length-1];
  if(!b||(!b.height&&!b.width)){var el=n.nodeType===1?n:n.parentElement;if(el)b=el.getBoundingClientRect();}
  if(!b)return;
  var sb=scEl.getBoundingClientRect(),pad=28;
  if(b.bottom>sb.bottom-pad)scEl.scrollTop+=b.bottom-sb.bottom+pad;
  else if(b.top<sb.top+pad)scEl.scrollTop-=sb.top+pad-b.top;
}
doc.addEventListener('input',function(){keepCaret();});
titleEl.addEventListener('input',function(){keepCaret();});
window.addEventListener('resize',function(){setTimeout(keepCaret,90);});
function inEditArea(t){return t&&(doc.contains(t)||titleEl.contains(t));}
document.addEventListener('touchstart',function(e){
  if(!kbOff||e.touches.length!==1||!inEditArea(e.target))return;
  kbTapRestore=true;kbX=e.touches[0].clientX;kbY=e.touches[0].clientY;setKbOff(false);
},true);
document.addEventListener('touchmove',function(e){
  if(!kbTapRestore||!e.touches.length)return;
  if(Math.abs(e.touches[0].clientX-kbX)>10||Math.abs(e.touches[0].clientY-kbY)>10){kbTapRestore=false;setKbOff(true);}
},true);
document.addEventListener('touchend',function(){kbTapRestore=false;},true);
window.setEditable=function(b){
  editable=!!b;
  if(editable)setKbOff(false);
  doc.contentEditable=editable?'true':'false';
  titleEl.contentEditable=editable?'plaintext-only':'false';
  document.body.classList.toggle('editing',editable);
  normalizeStructure();
  if(!editable){closePanel();window.getSelection().removeAllRanges();}
  else{ensureTail();}
  updateState();
};
window.exportDoc=function(){
  post({type:'export',title:titleEl.textContent.replace(/\n/g,' ').trim(),html:cleanHtml()});
};
window.flushNow=function(){
  clearTimeout(saveT);
  post({type:'change',title:titleEl.textContent.replace(/\n/g,' ').trim(),html:cleanHtml()});
};
var scale=1;
window.setScale=function(v){
  v=Math.max(0.6,Math.min(2.6,+v||1));scale=v;
  document.documentElement.style.setProperty('--scale',v);
};
/* ---------- sugestões de estrutura (dentro da própria nota) ---------- */
var sugEl=$('sug'),SUG=[],SUGON={},sugBusy=false,sugT=null;
function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}
function sugCount(){var n=0;for(var k in SUGON)if(SUGON[k])n++;return n;}
function sugMsg(t,red){clearTimeout(sugT);sugEl.innerHTML='<div class="sugmsg"'+(red?' style="color:var(--red)"':'')+'>'+esc(t)+'</div>';}
function setSugBusy(b){sugBusy=b;}
function sugClose(){clearTimeout(sugT);SUG=[];SUGON={};sugEl.innerHTML='';setSugBusy(false);post({type:'suggestClose'});}
/* O botão ✦ do cabeçalho abre e fecha o painel de sugestões. */
window.toggleSuggest=function(){
  if(sugBusy)return;
  if(sugEl.innerHTML){sugClose();return;}
  post({type:'suggest',sel:(lastRange&&!lastRange.collapsed)?lastRange.toString():''});
};
function renderSug(){
  var n=sugCount(),all=n===SUG.length;
  var h='<div class="sughead"><div class="sugall" data-sg="all"><span class="sgc'+(all?' on':'')+'"></span>Selecionar todos</div>';
  h+='<div class="sugapply'+(n?' on':'')+'" data-sg="apply">Aplicar'+(n?' ('+n+')':'')+'</div></div><div class="sugcard">';
  for(var i=0;i<SUG.length;i++){
    h+='<div class="sugrow" data-sg="t" data-i="'+i+'"><span class="sgc'+(SUGON[i]?' on':'')+'"></span><div class="sugtx"><div class="sugl1">'+esc(SUG[i].label)+'</div>'+(SUG[i].html?'<div class="sugprev">'+SUG[i].html+'</div>':'<div class="sugl2">'+esc(SUG[i].preview)+'</div>')+'</div></div>';
  }
  sugEl.innerHTML=h+'</div>';
}
window.suggestState=function(s){
  if(s==='loading'){setSugBusy(true);sugMsg('Analisando a nota…');}
  else if(s==='applying'){sugMsg('Aplicando…');}
};
window.showSuggestions=function(p){
  setSugBusy(false);SUG=(p&&p.items)||[];SUGON={};
  if(p&&p.failed){sugMsg(p.failed,true);return;}
  if(!SUG.length){sugMsg((p&&p.empty)||'Não encontrei nada para melhorar nesta nota.');sugT=setTimeout(function(){sugEl.innerHTML='';},4000);return;}
  renderSug();
};
window.suggestDone=function(t){SUG=[];SUGON={};sugMsg(t);sugT=setTimeout(function(){sugEl.innerHTML='';},4000);};
document.addEventListener('click',function(e){
  var el=e.target&&e.target.closest?e.target:null;if(!el)return;
  var t=el.closest('[data-sg]');if(!t)return;
  var a=t.getAttribute('data-sg');
  if(a==='t'){var i=+t.getAttribute('data-i');SUGON[i]=!SUGON[i];renderSug();}
  else if(a==='all'){var all=sugCount()===SUG.length;for(var j=0;j<SUG.length;j++)SUGON[j]=!all;renderSug();}
  else if(a==='apply'){
    var ids=[];for(var k=0;k<SUG.length;k++)if(SUGON[k])ids.push(SUG[k].id);
    if(ids.length)post({type:'suggestApply',ids:ids});
  }else if(a==='close'){sugClose();}
});
window.initNote=function(p){
  if(p.scale)window.setScale(p.scale);
  window.setRecentColors(p.recent||[]);
  titleEl.textContent=p.title||'';
  doc.innerHTML=p.html||'';
  var ts=doc.querySelectorAll('ul.todo>li:not([data-done])');for(var i=0;i<ts.length;i++)ts[i].setAttribute('data-done','false');
  if(!doc.firstElementChild){var e=document.createElement('p');e.innerHTML='<br>';doc.appendChild(e);}
  window.setCover(p.cover||null);
  window.setEditable(!!p.editable);
  normalizeStructure();updateProgress();
  buildToc();
  resumeCards();
};

/* ---------- barra e painéis ---------- */
var BLOCKS=[['Texto','p'],['Título 1','h1'],['Título 2','h2'],['Título 3','h3'],['Título 4','h4'],['Título 5','h5'],['Citação','blockquote'],['Frase de destaque','callout']];
var COLORS=[['Branco','#FFFFFF'],['Cinza claro','#BDBDBD'],['Cinza','#808080'],['Cinza escuro','#4A4A4A'],['Preto','#000000'],['Vermelho','#FF3030'],['Laranja','#FF7A1A'],['Amarelo','#FFD60A'],['Lima','#C3FF6B'],['Verde','#32D74B'],['Turquesa','#00B3A4'],['Azul claro','#4DA3FF'],['Azul','#0055FF'],['Violeta','#7A4DFF'],['Roxo','#B24DFF'],['Rosa','#FF4FA3'],['Marrom','#8B5A2B'],['Areia','#D9C3A5']];
var HILITES=[['Amarelo','#FFE066'],['Verde','#9BE564'],['Azul','#8CCBFF'],['Rosa','#FF9EC4'],['Laranja','#FFB36B'],['Roxo','#D2A8FF']];
var RECENT=[];
function isHex(c){return /^#[0-9A-Fa-f]{6}$/.test(c);}
window.setRecentColors=function(a){RECENT=(a||[]).filter(isHex).slice(0,3);};
function swatches(list,attr){
  var h='';
  for(var q=0;q<list.length;q++){var c=Array.isArray(list[q])?list[q][1]:list[q];h+='<div class="sw" data-'+attr+'="'+c+'" style="background:'+c+'"></div>';}
  return h;
}
var IC=${iconMap(['image','video','film','clip','text','table','divider','ul','ol','todo','toggle','columns','close','palette','alignL','alignC','alignR','indent','outdent'])};
var INSERTS=[['Imagem','image'],['Vídeo (link)','videourl'],['Vídeo (arquivo)','videofile'],['Arquivo','file'],['Texto de uma imagem','ocr'],['Tabela','table'],['Divisor','hr'],['Índice','toc'],['Recolhível','toggle'],['Colunas (2)','cols2'],['Colunas (3)','cols3'],['Link para nota','notelink'],['Subnota','subnote'],['Capa','cover']];
var INS_IC={image:'image',videourl:'video',videofile:'film',file:'clip',ocr:'text',table:'table',hr:'divider',toc:'ul',toggle:'toggle',cols2:'columns',cols3:'columns',notelink:'clip',subnote:'text',cover:'image'};
function slashIcon(k){var p=k.split(':');if(p[0]==='ins')return IC[INS_IC[p[1]]]||'';if(p[0]==='list')return IC[p[1]]||'';return '';}
var SLASH=[['Texto','blk:p','texto paragrafo'],['Título 1','blk:h1','titulo h1'],['Título 2','blk:h2','titulo subtitulo h2'],['Título 3','blk:h3','titulo h3'],['Título 4','blk:h4','titulo h4'],['Título 5','blk:h5','titulo h5'],['Citação','blk:blockquote','citacao'],['Frase de destaque','blk:callout','destaque callout'],['Lista com marcadores','list:ul','lista marcadores topicos'],['Lista numerada','list:ol','lista numerada'],['Lista de tarefas','list:todo','lista tarefas todo checklist']];
for(var si=0;si<INSERTS.length;si++)SLASH.push([INSERTS[si][0],'ins:'+INSERTS[si][1],INSERTS[si][0]]);
function fold(t){return String(t).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();}
var SIZES=[['Pequeno',0.8],['Normal',1],['Grande',1.3],['Maior',1.7],['Enorme',2.2]];
var openName=null;
var sizeEl=null;
function clearSizeSel(){if(sizeEl){sizeEl.classList.remove('szsel');if(!sizeEl.getAttribute('class'))sizeEl.removeAttribute('class');sizeEl=null;}}
function closePanel(){clearSizeSel();panel.className='';panel.innerHTML='';openName=null;}
/* ---------- tamanho de imagem, vídeo e cards ---------- */
function sizeKind(el){return el.tagName==='IMG'?'Imagem':el.tagName==='VIDEO'?'Vídeo':el.classList.contains('vidcard')?'Vídeo (link)':el.classList.contains('lkcard')?'Link':'Item';}
function sizePct(el){
  var w=parseInt(el.getAttribute('data-w'),10);if(w>=10&&w<=100)return w;
  var par=el.parentNode&&el.parentNode.clientWidth?el.parentNode.clientWidth:doc.clientWidth;
  return Math.max(10,Math.min(100,Math.round(el.getBoundingClientRect().width/par*100)));
}
function setSizePct(el,p){
  p=Math.max(10,Math.min(100,Math.round(p)));
  el.setAttribute('data-w',String(p));
  el.style.width=p+'%';
  if(el.tagName==='IMG'||el.tagName==='VIDEO')el.style.height='auto';
  if(el.classList.contains('lkcard'))el.style.maxWidth='none';
  changed();
}
function resetSize(el){
  el.removeAttribute('data-w');
  el.style.width='';el.style.height='';el.style.maxWidth='';
  if(!el.getAttribute('style'))el.removeAttribute('style');
  changed();
}
function showSizePanel(el){
  if(sizeEl&&sizeEl!==el)clearSizeSel();
  sizeEl=el;el.classList.add('szsel');
  var pct=sizePct(el),h='<div class="ttl">Tamanho · '+sizeKind(el)+'</div>';
  h+='<div class="szrow"><div class="opt" data-szd="-10" aria-label="Diminuir">−</div><div class="szv">'+pct+'%</div><div class="opt" data-szd="10" aria-label="Aumentar">+</div></div>';
  h+='<div class="grid g4"><div class="opt sm" data-szp="25">25%</div><div class="opt sm" data-szp="50">50%</div><div class="opt sm" data-szp="75">75%</div><div class="opt sm" data-szp="100">100%</div></div>';
  h+='<div class="grid" style="margin-top:8px;grid-template-columns:1fr"><div class="opt sm" data-szr="1">Tamanho original</div></div>';
  panel.innerHTML=h;panel.className='show ins';openName='sizeEl';
  try{el.scrollIntoView({block:'nearest'});}catch(_){}
}
window.openSizeFor=function(lid){var el=cardOf(lid);if(el)showSizePanel(el);};
function openPanel(name){
  if(openName===name){closePanel();return;}
  openName=name;var h='';
  if(name==='block'){
    h='<div class="ttl">Tipo de texto</div><div class="grid">';
    for(var i=0;i<BLOCKS.length;i++)h+='<div class="opt" data-blk="'+BLOCKS[i][1]+'">'+BLOCKS[i][0]+'</div>';
    h+='</div>';
  }else if(name==='color'){
    h='<div class="ttl">Cor do texto</div><div class="grid">'+swatches(COLORS,'col')+'</div>';
    h+='<div class="ttl" style="margin-top:12px">Personalizada</div><div class="grid">'+swatches(RECENT,'col')+'<div class="opt" data-pick="text">'+IC.palette+'Escolher cor…</div></div>';
  }else if(name==='hilite'){
    h='<div class="ttl">Marca-texto</div><div class="grid">'+swatches(HILITES,'hl')+'<div class="opt" data-hl="none">Sem marca</div></div>';
    h+='<div class="ttl" style="margin-top:12px">Personalizada</div><div class="grid">'+swatches(RECENT,'hl')+'<div class="opt" data-pick="hilite">'+IC.palette+'Escolher cor…</div></div>';
  }else if(name==='paint'){
    h='<div class="ttl">Pincel de formatação</div><div class="grid">'
      +'<div class="opt" data-fp="copy">Copiar formatação<small>do trecho ou cursor</small></div>'
      +'<div class="opt'+(FPAINT?'':' dim')+'" data-fp="paste">Colar formatação<small>'+(FPAINT?fmtSummary(FPAINT):'nada copiado ainda')+'</small></div>'
      +'<div class="opt" data-fp="copyblk">Copiar bloco</div><div class="opt" data-fp="pasteblk">Colar caixa</div></div>';
  }else if(name==='para'){
    var pb=curBlock(),al=(pb&&pb.style&&pb.style.textAlign)||'left';
    h='<div class="ttl">Alinhamento</div><div class="grid">';
    h+='<div class="opt'+(al==='left'?' on':'')+'" data-al="Left" aria-label="Esquerda">'+IC.alignL+'</div>';
    h+='<div class="opt'+(al==='center'?' on':'')+'" data-al="Center" aria-label="Centro">'+IC.alignC+'</div>';
    h+='<div class="opt'+(al==='right'?' on':'')+'" data-al="Right" aria-label="Direita">'+IC.alignR+'</div></div>';
    h+='<div class="ttl" style="margin-top:12px">Recuo</div><div class="grid"><div class="opt" data-ind="1" aria-label="Recuar">'+IC.indent+'</div><div class="opt" data-ind="-1" aria-label="Diminuir recuo">'+IC.outdent+'</div></div>';
  }else if(name==='size'){
    h='<div class="ttl">Tamanho do texto selecionado</div>';
    var ss=sel();
    if(!ss||!ss.rangeCount||ss.isCollapsed||!inDoc(ss.getRangeAt(0).commonAncestorContainer))
      h+='<div class="ttl" style="color:#111;font-size:15px;margin-bottom:10px">Selecione um trecho do texto primeiro.</div>';
    h+='<div class="grid"><div class="opt" data-step="0.87" aria-label="Menor">A−</div><div class="opt" data-step="1.15" aria-label="Maior">A+</div></div>';
    h+='<div class="ttl" style="margin-top:12px">Tamanhos prontos</div><div class="grid">';
    for(var z=0;z<SIZES.length;z++)h+='<div class="opt" data-sz="'+SIZES[z][1]+'">'+SIZES[z][0]+'</div>';
    h+='</div>';
  }else if(name==='font'){
    h='<div class="ttl">Fonte do texto selecionado</div>';
    var fs2=sel();
    if(!fs2||!fs2.rangeCount||fs2.isCollapsed||!inDoc(fs2.getRangeAt(0).commonAncestorContainer))
      h+='<div class="ttl" style="color:#111;font-size:15px;margin-bottom:10px">Selecione um trecho do texto primeiro.</div>';
    h+='<div class="ttl" style="margin-top:4px">Minhas fontes</div><div class="grid"><div class="opt" data-fnt="">Padrão</div>';
    for(var fi=0;fi<FONTS.length;fi++)h+='<div class="opt" data-fnt="'+FONTS[fi]+'" style="font-family:\''+FONTS[fi]+'\'">'+FONTS[fi]+'</div>';
    h+='</div><div class="grid" style="margin-top:12px"><div class="opt" data-fntget="1">+ Buscar no Google Fonts</div></div>';
  }else if(name==='outline'){
    h='<div class="toc" style="margin:0;background:none;border:0;padding:0">'+tocInner(true)+'</div>';
  }else if(name==='insert'){
    h='<div class="ttl">Inserir</div><div class="grid">';
    for(var k=0;k<INSERTS.length;k++)h+='<div class="opt" data-ins="'+INSERTS[k][1]+'">'+slashIcon('ins:'+INSERTS[k][1])+INSERTS[k][0]+'</div>';
    h+='</div>';
  }
  panel.innerHTML=h;panel.className='show'+(name==='insert'?' ins':(name==='outline'?'':' sub'));
}
var BLOCK_RE=/^(P|H[1-5]|BLOCKQUOTE|DIV|LI|TD|TH)$/;
function blockOf(n){n=elOf(n);while(n&&n!==doc){if(BLOCK_RE.test(n.tagName))return n;n=n.parentNode;}return doc;}
function px(el){return parseFloat(getComputedStyle(el).fontSize)||16;}
/* mode 'step': multiplica o tamanho atual; mode 'preset': multiplica o tamanho do bloco (1 = tamanho normal do texto) */
function applySize(mode,f){
  restoreSel();
  var s=sel();
  if(!s.rangeCount||s.isCollapsed)return;
  var r=s.getRangeAt(0);
  if(!inDoc(r.commonAncestorContainer)&&r.commonAncestorContainer!==doc)return;
  var startEl=elOf(r.startContainer);
  var target=mode==='step'?px(startEl)*f:px(blockOf(startEl))*f;
  target=Math.max(8,Math.min(160,target));
  var MARK='xxx-large';
  document.execCommand('styleWithCSS',false,true);
  document.execCommand('fontSize',false,'7');
  var made=doc.querySelectorAll('span[style*="'+MARK+'"],font[size="7"]');
  for(var i=0;i<made.length;i++){
    var el=made[i];
    if(el.tagName==='FONT'){
      var sp=document.createElement('span');
      while(el.firstChild)sp.appendChild(el.firstChild);
      el.parentNode.replaceChild(sp,el);el=sp;
    }
    var inner=el.querySelectorAll('[style*="font-size"]');
    for(var k=0;k<inner.length;k++){inner[k].style.fontSize='';if(!inner[k].getAttribute('style'))inner[k].removeAttribute('style');}
    var parentPx=px(el.parentNode.nodeType===1?el.parentNode:doc);
    var em=target/parentPx;
    if(Math.abs(em-1)<0.02){
      el.style.fontSize='';
      if(!el.getAttribute('style')){while(el.firstChild)el.parentNode.insertBefore(el.firstChild,el);el.parentNode.removeChild(el);}
    }else el.style.fontSize=(Math.round(em*1000)/1000)+'em';
  }
  changed();updateState();
}
/* Fontes do Google Fonts baixadas no aparelho (Minhas fontes): o app manda o CSS e a lista. */
var FONTS=[];
window.setFonts=function(p){
  var st=document.getElementById('gfonts');
  if(!st){st=document.createElement('style');st.id='gfonts';document.head.appendChild(st);}
  st.textContent=(p&&p.css)||'';
  FONTS=((p&&p.list)||[]).filter(function(n){return /^[A-Za-z0-9][A-Za-z0-9 ]{0,59}$/.test(n);});
  if(openName==='font'){openName=null;openPanel('font');}
};
function dropFamily(el){
  el.style.fontFamily='';
  if(!el.getAttribute('style'))el.removeAttribute('style');
  if(el.tagName==='SPAN'&&!el.attributes.length){var pr=el.parentNode;while(el.firstChild)pr.insertBefore(el.firstChild,el);pr.removeChild(el);}
}
/* Aplica a fonte (ou "Padrão", name vazio) ao trecho selecionado; fica como <span style="font-family:...">. */
function applyFont(name){
  restoreSel();
  var s=sel();
  if(!s.rangeCount||s.isCollapsed)return;
  var r=s.getRangeAt(0);
  if(!inDoc(r.commonAncestorContainer)&&r.commonAncestorContainer!==doc)return;
  if(name&&FONTS.indexOf(name)<0)return;
  var MK='__gfont__';
  document.execCommand('styleWithCSS',false,true);
  document.execCommand('fontName',false,MK);
  var made=doc.querySelectorAll('span[style*="'+MK+'"],font[face="'+MK+'"]');
  for(var i=0;i<made.length;i++){
    var el=made[i];
    if(el.tagName==='FONT'){
      var sp=document.createElement('span');
      while(el.firstChild)sp.appendChild(el.firstChild);
      el.parentNode.replaceChild(sp,el);el=sp;
    }
    var inner=el.querySelectorAll('[style*="font-family"]');
    for(var k=0;k<inner.length;k++)dropFamily(inner[k]);
    if(name)el.style.fontFamily="'"+name+"'";else dropFamily(el);
  }
  changed();updateState();
}
/* Marca-texto: dentro de texto colorido, o fundo herda a cor do texto; "sem marca" remove os restos. */
function fixHilite(){
  var sp=doc.querySelectorAll('span[style*="background"]');
  for(var i=0;i<sp.length;i++){
    var el=sp[i],bg=el.style.backgroundColor;
    if(!bg||bg==='transparent'||/^rgba\(\s*0,\s*0,\s*0,\s*0\s*\)$/.test(bg)){
      el.style.backgroundColor='';
      if(!el.getAttribute('style')){var pr=el.parentNode;while(el.firstChild)pr.insertBefore(el.firstChild,el);pr.removeChild(el);}
      continue;
    }
    if(!el.style.color){
      var a=el.parentElement;
      while(a&&a!==doc){if(a.style&&a.style.color){el.style.color=a.style.color;break;}a=a.parentElement;}
    }
  }
}
/* ---------- pincel de formatação ---------- */
var FPAINT=null;
function rgb2hex(c){var m=/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/.exec(c||'');if(!m)return '';if(m[4]!==undefined&&parseFloat(m[4])===0)return '';return '#'+[1,2,3].map(function(i){return ('0'+parseInt(m[i],10).toString(16)).slice(-2);}).join('').toUpperCase();}
function qs(c){try{return document.queryCommandState(c);}catch(e){return false;}}
function fmtSummary(f){
  var a=[];if(f.b)a.push('Negrito');if(f.i)a.push('Itálico');if(f.u)a.push('Sublinhado');if(f.s)a.push('Riscado');
  if(f.col)a.push('cor '+f.col);if(f.bg)a.push('marca-texto');if(f.fam)a.push(f.fam);if(Math.abs((f.r||1)-1)>0.02)a.push(Math.round(f.r*100)+'%');
  return a.length?a.join(' · '):'texto normal';
}
function captureFormat(){
  var s=sel();if(!s.rangeCount)return null;
  var el=elOf(s.anchorNode);if(!el||!(doc.contains(el)||el===doc))return null;
  var blk=blockOf(el),cs=getComputedStyle(el),bs=getComputedStyle(blk);
  var col=rgb2hex(cs.color),base=rgb2hex(bs.color);
  var bg='',a=el;while(a&&a!==doc){var b2=rgb2hex(getComputedStyle(a).backgroundColor);if(b2){bg=b2;break;}a=a.parentElement;}
  var fam='';a=el;while(a&&a!==doc){if(a.style&&a.style.fontFamily){fam=a.style.fontFamily.split(',')[0].replace(/["']/g,'').trim();break;}a=a.parentElement;}
  var heading=/^H[1-5]$/.test(blk.tagName);
  return {b:(parseInt(cs.fontWeight,10)||400)>=600&&!heading,i:qs('italic'),u:qs('underline'),s:qs('strikeThrough'),col:col!==base?col:'',bg:bg,fam:FONTS.indexOf(fam)>=0?fam:'',r:Math.round(px(el)/px(blk)*100)/100};
}
function applyFormat(f){
  restoreSel();
  var s=sel();if(!s.rangeCount||s.isCollapsed){return false;}
  var r=s.getRangeAt(0);if(!inDoc(r.commonAncestorContainer)&&r.commonAncestorContainer!==doc)return false;
  var el=elOf(r.startContainer),blk=blockOf(el),heading=/^H[1-5]$/.test(blk.tagName);
  function ensure(cmd,want){if(qs(cmd)!==!!want)document.execCommand(cmd);}
  try{document.execCommand('styleWithCSS',false,true);}catch(e){}
  if(f.b&&!qs('bold'))document.execCommand('bold');else if(!f.b&&qs('bold')&&!heading)document.execCommand('bold');
  ensure('italic',f.i);ensure('underline',f.u);
  try{document.execCommand('styleWithCSS',false,false);ensure('strikeThrough',f.s);document.execCommand('styleWithCSS',false,true);}catch(e){}
  if(f.col)applyColor('text',f.col);
  if(f.bg)applyColor('hilite',f.bg);else{var a=elOf(sel().anchorNode),has=false;while(a&&a!==doc){if(rgb2hex(getComputedStyle(a).backgroundColor)){has=true;break;}a=a.parentElement;}if(has)applyColor('hilite','none');}
  applySize('preset',f.r||1);
  applyFont(f.fam||'');
  changed();updateState();return true;
}
function applyColor(kind,hex){
  if(!(isHex(hex)||(kind==='hilite'&&hex==='none')))return;
  restoreSel();
  try{document.execCommand('styleWithCSS',false,true);}catch(e){}
  if(kind==='text')document.execCommand('foreColor',false,hex);
  else document.execCommand('hiliteColor',false,hex==='none'?'transparent':hex);
  fixHilite();changed();updateState();
}
window.applyColor=function(kind,hex){
  applyColor(kind,hex);
  if(isHex(hex)){RECENT=[hex.toUpperCase()].concat(RECENT.filter(function(c){return c.toUpperCase()!==hex.toUpperCase();})).slice(0,3);}
};
function blocksInSel(){
  var s0=sel();if(!s0||!s0.rangeCount)return [];
  var r=s0.getRangeAt(0),all=doc.querySelectorAll('p,h1,h2,h3,h4,h5,blockquote,div.callout,li'),out=[];
  for(var i=0;i<all.length;i++){var el=all[i];if(el.closest('.toc'))continue;if(r.intersectsNode(el))out.push(el);}
  if(!out.length){var b=curBlock();if(b)out.push(b);}
  return out;
}
/* Recuo: em lista usa o recuo nativo (aninha); nos demais blocos usa data-indent (nunca blockquote). */
function indentCmd(dir){
  restoreSel();
  var bs=blocksInSel(),lists=false;
  for(var i=0;i<bs.length;i++){
    var b=bs[i];
    if(b.tagName==='LI'){lists=true;continue;}
    var n=Math.max(0,Math.min(6,(parseInt(b.getAttribute('data-indent')||'0',10)||0)+dir));
    if(n)b.setAttribute('data-indent',String(n));else b.removeAttribute('data-indent');
  }
  if(lists){try{document.execCommand(dir>0?'indent':'outdent');}catch(e){}}
  changed();updateState();
}
function alignCmd(a){
  restoreSel();
  try{document.execCommand('styleWithCSS',false,true);}catch(e){}
  document.execCommand('justify'+a);
  changed();updateState();
}
function runInsert(w){
  restoreSel();
  if(w==='image')post({type:'pickImage'});
  else if(w==='videourl')post({type:'askVideoUrl'});
  else if(w==='videofile')post({type:'pickVideo'});
  else if(w==='file')post({type:'pickFile'});
  else if(w==='ocr')post({type:'pickOcr'});
  else if(w==='table')insertTable();
  else if(w==='hr')insertBlock('<hr>');
  else if(w==='toc'){insertBlock('<div class="toc" contenteditable="false"></div>');buildToc();}
  else if(w==='toggle')insertToggle();
  else if(w==='notelink'){restoreSel();document.execCommand('insertText',false,'[[');}
  else if(w==='subnote')post({type:'newSubnote'});
  else if(w==='cols2')insertCols(2);
  else if(w==='cols3')insertCols(3);
  else if(w==='cover')post({type:'pickCover'});
}
/* ---------- copiar/colar entre os modos (nota corrida <-> layout livre) ---------- */
function copyBlocks(){
  var bl=blocksInSel(),items=[];
  bl.forEach(function(b){
    var card=b.querySelector('a.lkcard');
    if(card){
      var tx=function(c){var e=card.querySelector('.'+c);return e?e.textContent:'';};
      var im0=card.querySelector('img');
      items.push({k:'link',url:card.getAttribute('href')||'',title:tx('lk-t'),desc:tx('lk-d'),site:tx('lk-s'),img:im0?im0.getAttribute('src')||'':'',state:card.getAttribute('data-state')||'ok'});
      return;
    }
    var im=b.querySelector('img');
    var cl=b.cloneNode(true);
    var brs=cl.querySelectorAll('br');for(var i=0;i<brs.length;i++)brs[i].parentNode.replaceChild(document.createTextNode('\n'),brs[i]);
    var t=cl.textContent.replace(/\u200B/g,'');
    if(!t.trim()){if(im&&im.getAttribute('src'))items.push({k:'image',src:im.getAttribute('src')});return;}
    var lks=[],as=cl.querySelectorAll('a[href]');
    for(var j=0;j<as.length;j++){
      var r=document.createRange();r.setStart(cl,0);r.setEnd(as[j],0);
      var s0=r.toString().replace(/\u200B/g,'').length,l0=as[j].textContent.replace(/\u200B/g,'').length;
      if(l0>0)lks.push({s:s0,e:s0+l0,url:as[j].getAttribute('href')||''});
    }
    if(b.tagName==='LI')t='• '+t;
    items.push({k:'text',tag:b.tagName,txt:t,lks:lks});
  });
  if(!items.length){post({type:'toast',text:'Nada para copiar'});return;}
  post({type:'clip',what:'frame',data:{t:'flowblocks',items:items}});
}
function runsHtml(txt,lks,from,to){
  var h='',at=from,ls=(lks||[]).slice().sort(function(a,b){return a.s-b.s;});
  for(var i=0;i<ls.length;i++){
    var s=Math.max(ls[i].s,from),e=Math.min(ls[i].e,to);
    if(e<=s||s<at||!/^(https?:|mailto:|tel:)/i.test(ls[i].url||''))continue;
    h+=esc(txt.slice(at,s))+'<a href="'+esc(ls[i].url)+'">'+esc(txt.slice(s,e))+'</a>';at=e;
  }
  return h+esc(txt.slice(at,to));
}
function frameToHtml(f){
  if(!f)return '';
  if(f.t==='multi'){return (f.multi||[]).slice().sort(function(a,b){return a.y-b.y||a.x-b.x;}).map(frameToHtml).join('');}
  if(f.t==='image')return f.src?'<p><img src="'+esc(f.src)+'" alt=""></p>':'';
  if(f.t==='link'&&f.url)return cardHtml(f.url,{title:f.lt,desc:f.ld,site:f.lsite,img:f.src,state:f.lst==='ok'?'ok':f.lst==='fail'?'fail':'loading'});
  if(f.t!=='text'||!(f.txt||'').trim())return '';
  var tag='p';
  if(f.role==='h'){var fs=f.fs||32;tag=fs>=60?'h1':fs>=44?'h2':fs>=34?'h3':'h4';}
  var txt=f.txt,off=0,out='';
  txt.split('\n').forEach(function(line){
    var inner=line?runsHtml(txt,f.lks,off,off+line.length):'<br>';
    out+='<'+tag+'>'+inner+'</'+tag+'>';off+=line.length+1;
  });
  return out;
}
function pasteFrames(){
  var html=frameToHtml(CLIPF);
  if(!html){post({type:'toast',text:CLIPF?'Essa caixa não tem conteúdo para colar':'Copie uma caixa do layout livre'});return;}
  insertBlock(html);changed();resumeCards();
}
function command(c){
  restoreSel();
  if(c==='undo'||c==='redo'){document.execCommand(c);changed();updateState();}
  else if(c==='link'){
    var a=closest(sel().anchorNode,'a');
    post({type:'askLink',current:a?a.getAttribute('href'):null,hasSelection:!sel().isCollapsed});
  }
  else if(c==='image')post({type:'pickImage'});
  else if(c==='copyBlk')copyBlocks();
  else if(c==='pasteBlk')pasteFrames();
  else if(c==='strikeThrough'){
    // Sem CSS: gera <strike>, que vira <s> ao salvar e ao colar.
    try{document.execCommand('styleWithCSS',false,false);}catch(e){}
    document.execCommand(c);
    try{document.execCommand('styleWithCSS',false,true);}catch(e){}
    changed();
  }
  else{document.execCommand(c);changed();}
  updateState();
}
/* ---------- menu "/" (usa o painel de baixo; detecta pelo texto antes do cursor, porque o teclado do Android não manda keydown confiável) ---------- */
var slashLen=0;
function slashQuery(){
  var s0=sel();if(!s0||!s0.rangeCount||!s0.isCollapsed)return null;
  var r=s0.getRangeAt(0),b=curBlock();if(!b||!b.contains(r.startContainer))return null;
  var pre=document.createRange();pre.selectNodeContents(b);pre.setEnd(r.startContainer,r.startOffset);
  var m=pre.toString().match(/(?:^|\s)\/(\S*)$/);
  return m?{q:m[1],len:m[1].length+1}:null;
}
function renderSlash(q){
  var f=fold(q),h='<div class="ttl">Inserir  /'+esc(q)+'</div><div class="grid col1">',n=0;
  for(var i=0;i<SLASH.length;i++){
    if(!f||fold(SLASH[i][0]+' '+SLASH[i][2]).indexOf(f)>=0){h+='<div class="opt" data-sl="'+SLASH[i][1]+'">'+slashIcon(SLASH[i][1])+SLASH[i][0]+'</div>';n++;}
  }
  if(!n)h+='<div class="ttl">Nada encontrado</div>';
  panel.innerHTML=h+'</div>';panel.className='show';openName='slash';
}
function checkSlash(){
  if(!editable)return;
  var q=slashQuery();
  if(q){slashLen=q.len;renderSlash(q.q);}
  else if(openName==='slash')closePanel();
}
function removeBefore(len){
  var s0=sel();if(!s0.rangeCount)return;
  var r=s0.getRangeAt(0),n=r.startContainer,o=r.startOffset;
  if(n.nodeType===3&&o>=len){var rg=document.createRange();rg.setStart(n,o-len);rg.setEnd(n,o);rg.deleteContents();}
  else{for(var i=0;i<len;i++)s0.modify('extend','backward','character');document.execCommand('delete');}
}
function removeSlashText(){removeBefore(slashLen);}
/* ---------- link para outra nota: "[[" ---------- */
var wikiLen=0,wikiQ='',wikiRes=[],wikiT=null;
function wikiQuery(){
  var s0=sel();if(!s0||!s0.rangeCount||!s0.isCollapsed)return null;
  var r=s0.getRangeAt(0),b=curBlock();if(!b||!b.contains(r.startContainer))return null;
  var pre=document.createRange();pre.selectNodeContents(b);pre.setEnd(r.startContainer,r.startOffset);
  var m=pre.toString().match(/\[\[([^\]\n]*)$/);
  return m?{q:m[1],len:m[1].length+2}:null;
}
function renderWiki(list,q){
  var h='<div class="ttl">Link para nota</div><div class="grid col1">';
  for(var i=0;i<list.length;i++)h+='<div class="opt" data-wk="'+i+'">'+esc(list[i].title)+(list[i].sub?'<br><small>'+esc(list[i].sub)+'</small>':'')+'</div>';
  if(q.trim())h+='<div class="opt" data-wk="new">＋ Criar nota «'+esc(q.trim())+'»</div>';
  if(!list.length&&!q.trim())h+='<div class="ttl">Digite o título da nota</div>';
  panel.innerHTML=h+'</div>';panel.className='show';openName='wiki';
}
function checkWiki(){
  if(!editable)return;
  var w=wikiQuery();
  if(w){
    wikiLen=w.len;wikiQ=w.q;
    if(openName!=='wiki')renderWiki([],w.q);
    clearTimeout(wikiT);wikiT=setTimeout(function(){post({type:'searchNotes',q:w.q});},150);
  }else if(openName==='wiki')closePanel();
}
window.setNoteResults=function(list){wikiRes=list||[];if(openName==='wiki')renderWiki(wikiRes,wikiQ);};
function noteLinkHtml(uuid,title){return '<a class="notelink" data-note="'+uuid+'" href="#">'+esc(title)+'</a>&nbsp;';}
function pickWiki(k){
  restoreSel();removeBefore(wikiLen);closePanel();
  if(k==='new')post({type:'createNoteLink',title:wikiQ.trim()});
  else{var n=wikiRes[parseInt(k,10)];if(n)document.execCommand('insertHTML',false,noteLinkHtml(n.uuid,n.title));}
  changed();
}
window.insertNoteLink=function(uuid,title){restoreSel();document.execCommand('insertHTML',false,noteLinkHtml(uuid,title));changed();};
window.insertSubnote=function(uuid,title){
  insertBlock('<div class="subnote" contenteditable="false" data-note="'+uuid+'"><span class="t">'+esc(title)+'</span></div>');
};
/* Títulos atuais (e notas excluídas) sem marcar a nota como alterada. */
window.refreshNoteLinks=function(m){
  var els=doc.querySelectorAll('a.notelink,.subnote');
  for(var i=0;i<els.length;i++){
    var el=els[i],u=el.getAttribute('data-note');
    if(!(u in m))continue;
    var t=m[u];
    if(t===null){el.classList.add('gone');}
    else{el.classList.remove('gone');var tn=el.classList.contains('subnote')?el.querySelector('.t'):el;if(tn&&tn.textContent!==t)tn.textContent=t;}
  }
};
window.setBacklinks=function(list){
  var b=$('bl');
  if(!list||!list.length){b.innerHTML='';b.className='';return;}
  var h='<div class="blh">Mencionada em</div>';
  for(var i=0;i<list.length;i++)h+='<div class="blr" data-bid="'+list[i].id+'">'+esc(list[i].title)+'</div>';
  b.innerHTML=h;b.className='show';
};
window.scrollToBacklinks=function(){var b=$('bl');if(b.className)b.scrollIntoView({block:'start'});};

function runSlash(id){
  restoreSel();removeSlashText();closePanel();changed();
  var p=id.split(':'),k=p[0],v=p[1];
  if(k==='blk'){if(v==='callout')toggleBlock('div','callout');else if(v==='p')convertBlock('p');else toggleBlock(v);}
  else if(k==='list')listCmd(v);
  else if(k==='ins')runInsert(v);
}
function updateState(){
  if(!editable)return;
  var st=function(c){try{return document.queryCommandState(c);}catch(e){return false;}};
  try{$('bUndo').classList.toggle('dim',!document.queryCommandEnabled('undo'));$('bRedo').classList.toggle('dim',!document.queryCommandEnabled('redo'));}catch(e){}
  $('bU').classList.toggle('on',st('underline'));
  var cb=curBlock(),cta=cb&&cb.style?cb.style.textAlign:'';
  $('bPara').classList.toggle('on',cta==='center'||cta==='right'||!!(cb&&cb.getAttribute('data-indent')));
  var b=curBlock(),lab='Aa';
  if(b){
    if(/^H[1-5]$/.test(b.tagName))lab='T'+b.tagName.charAt(1);
    else if(b.tagName==='BLOCKQUOTE')lab='❝';
    else if(/callout/.test(b.className))lab='★';
  }
  $('bBlock').classList.toggle('on',lab!=='Aa');
  var cell=closest(sel().rangeCount?sel().anchorNode:null,'td,th');
  $('tblrow').classList.toggle('show',!!cell);
  $('colrow').classList.toggle('show',!!closest(sel().rangeCount?sel().anchorNode:null,'.col'));
}
document.addEventListener('selectionchange',function(){saveSel();updateState();if(openName==='slash'&&!slashQuery())closePanel();if(openName==='wiki'&&!wikiQuery())closePanel();});

// Os botões não podem roubar o foco do texto (senão o teclado fecha e a seleção some).
$('bar').addEventListener('mousedown',function(e){e.preventDefault();});
panel.addEventListener('mousedown',function(e){e.preventDefault();});
$('bar').addEventListener('click',function(e){
  var t=e.target.closest?e.target.closest('[data-c],[data-p],[data-l],[data-t],[data-k]'):null;if(!t)return;
  if(t.dataset.c){closePanel();command(t.dataset.c);}
  else if(t.dataset.p)openPanel(t.dataset.p);
  else if(t.dataset.l){closePanel();listCmd(t.dataset.l);}
  else if(t.dataset.t)tableOp(t.dataset.t);
  else if(t.dataset.k)colOp(t.dataset.k);
});
panel.addEventListener('click',function(e){
  var t=e.target;
  var oi=t.closest?t.closest('.toc .it'):null;
  if(oi){var hs0=doc.querySelectorAll('h1,h2,h3,h4,h5'),h0=hs0[+oi.getAttribute('data-i')];closePanel();if(h0)h0.scrollIntoView({behavior:'smooth',block:'start'});e.stopPropagation();return;}
  if(sizeEl&&(t.dataset.szp||t.dataset.szd||t.dataset.szr)){
    if(t.dataset.szr)resetSize(sizeEl);
    else if(t.dataset.szp)setSizePct(sizeEl,parseInt(t.dataset.szp,10));
    else setSizePct(sizeEl,sizePct(sizeEl)+parseInt(t.dataset.szd,10));
    var keep=sizeEl;sizeEl=null;showSizePanel(keep);
    return;
  }
  if(t.dataset.fp==='copyblk'){copyBlocks();closePanel();return;}
  if(t.dataset.fp==='pasteblk'){pasteFrames();closePanel();return;}
  if(t.dataset.fp){
    if(t.dataset.fp==='copy'){var cf=captureFormat();if(cf){FPAINT=cf;post({type:'clip',what:'style',data:{kind:'flow',fmt:cf}});}closePanel();}
    else if(FPAINT){if(!applyFormat(FPAINT))post({type:'toast',text:'Selecione o texto para colar a formatação'});closePanel();}
    return;
  }
  if(t.dataset.blk){
    var k=t.dataset.blk;
    if(k==='callout')toggleBlock('div','callout');else if(k==='p')convertBlock('p');else toggleBlock(k);
    closePanel();
  }else if(t.dataset.fntget){
    saveSel();closePanel();post({type:'openFonts'});
  }else if(t.dataset.fnt!==undefined){
    applyFont(t.dataset.fnt);closePanel();
  }else if(t.dataset.step){
    applySize('step',parseFloat(t.dataset.step));
  }else if(t.dataset.sz){
    applySize('preset',parseFloat(t.dataset.sz));closePanel();
  }else if(t.dataset.col){
    applyColor('text',t.dataset.col);closePanel();
  }else if(t.dataset.hl){
    applyColor('hilite',t.dataset.hl);closePanel();
  }else if(t.dataset.pick){
    var kind=t.dataset.pick;saveSel();closePanel();post({type:'pickColor','for':kind});
  }else if(t.dataset.al){
    alignCmd(t.dataset.al);openName=null;openPanel('para');
  }else if(t.dataset.ind){
    indentCmd(parseInt(t.dataset.ind,10));openName=null;openPanel('para');
  }else if(t.dataset.sl){runSlash(t.dataset.sl);
  }else if(t.dataset.wk){pickWiki(t.dataset.wk);
  }else if(t.dataset.ins){var w=t.dataset.ins;closePanel();runInsert(w);}
});
document.body.addEventListener('click',function(e){
  var a=e.target.closest?e.target.closest('[data-a]'):null;
  if(a&&editable){e.preventDefault();post({type:a.dataset.a==='cover'?'pickCover':'removeCover'});return;}
  var it=e.target.closest?e.target.closest('.toc .it'):null;
  if(it){
    var hs=doc.querySelectorAll('h1,h2,h3,h4,h5'),h=hs[+it.getAttribute('data-i')];
    if(h)h.scrollIntoView({behavior:'smooth',block:'start'});
    return;
  }
  var tgh=e.target.closest?e.target.closest('.tg-head'):null;
  if(tgh&&inDoc(tgh)&&e.clientX-tgh.getBoundingClientRect().left<30){
    var tg0=tgh.parentNode;tg0.setAttribute('data-open',tg0.getAttribute('data-open')==='true'?'false':'true');
    changed();e.preventDefault();return;
  }
  var li=e.target.closest?e.target.closest('ul.todo>li'):null;
  if(li&&inDoc(li)){
    var rect=li.getBoundingClientRect();
    if(e.clientX-rect.left<34){
      li.setAttribute('data-done',li.getAttribute('data-done')==='true'?'false':'true');
      changed();e.preventDefault();return;
    }
  }
  var br=e.target.closest?e.target.closest('.blr'):null;
  if(br){post({type:'openNote',id:parseInt(br.getAttribute('data-bid'),10)});return;}
  var nl=e.target.closest?e.target.closest('a.notelink,.subnote'):null;
  if(nl&&inDoc(nl)){e.preventDefault();post({type:'openNote',uuid:nl.getAttribute('data-note'),gone:nl.classList.contains('gone')});return;}
  if(editable&&e.target.closest){
    var rz=e.target.closest('img,video,.vidcard,a.lkcard');
    if(rz&&rz.tagName==='IMG'){var rp=rz.closest('.vidcard,a.lkcard');if(rp)rz=rp;}
    if(rz&&inDoc(rz)&&!rz.classList.contains('lkcard')){e.preventDefault();showSizePanel(rz);return;}
  }
  var lk=e.target.closest?e.target.closest('a.lkcard'):null;
  if(lk&&inDoc(lk)){
    e.preventDefault();
    var lkid=lk.getAttribute('data-lid');
    if(!lkid){lkid=newLid();lk.setAttribute('data-lid',lkid);}
    if(editable)post({type:'cardMenu',lid:lkid,url:lk.getAttribute('href'),state:lk.getAttribute('data-state')||''});
    else post({type:'openLink',url:lk.getAttribute('href')});
    return;
  }
  var link=e.target.closest?e.target.closest('a'):null;
  if(link){
    e.preventDefault();
    if(!editable){
      if(link.classList.contains('filechip'))post({type:'openFile',uri:link.getAttribute('href'),name:link.getAttribute('data-name')});
      else post({type:'openLink',url:link.getAttribute('href')});
    }
    return;
  }
  var vc=e.target.closest?e.target.closest('.vidcard'):null;
  if(vc&&!editable){post({type:'openLink',url:vc.getAttribute('data-url')});}
});

/* ---------- digitação ---------- */
doc.addEventListener('input',function(e){
  if(e.inputType==='insertParagraph'){
    var li=closest(sel().anchorNode,'ul.todo>li');
    if(li)li.setAttribute('data-done','false');
  }
  if(!doc.firstElementChild){var p=document.createElement('p');p.innerHTML='<br>';doc.appendChild(p);caretStart(p);}
  changed();
  checkSlash();
  checkWiki();
  if(findOpen)findSched();
});
function unwrapEmptyToggle(tg){
  var hd=tg.querySelector(':scope>.tg-head'),bd=tg.querySelector(':scope>.tg-body');
  if(hd&&bd&&hd.textContent.replace(/\s|\u200B/g,'')===''&&bd.children.length===1&&isEmptyBlock(bd.firstElementChild)){
    var p=document.createElement('p');p.innerHTML='<br>';tg.parentNode.replaceChild(p,tg);caretStart(p);changed();
  }
}
// Recolhível: Enter no título vai para o corpo; Backspace não deixa o título fundir com o que vem antes.
doc.addEventListener('beforeinput',function(e){
  var s0=sel();if(!s0||!s0.rangeCount)return;
  var head=closest(s0.anchorNode,'.tg-head');
  if(head){
    if(e.inputType==='insertParagraph'||e.inputType==='insertLineBreak'){
      e.preventDefault();
      var tg=head.parentNode;tg.setAttribute('data-open','true');
      var bd=tg.querySelector(':scope>.tg-body'),f=bd&&bd.firstElementChild;
      if(f)caretStart(f);
      changed();return;
    }
    if(e.inputType==='deleteContentBackward'&&s0.isCollapsed){
      var pre=document.createRange();pre.selectNodeContents(head);pre.setEnd(s0.anchorNode,s0.anchorOffset);
      if(pre.toString()===''){e.preventDefault();unwrapEmptyToggle(head.parentNode);}
    }
    return;
  }
  var body=closest(s0.anchorNode,'.tg-body');
  if(body&&e.inputType==='deleteContentBackward'&&s0.isCollapsed){
    var b0=curBlock();
    if(b0&&b0.parentNode===body&&b0===body.firstElementChild){
      var pr=document.createRange();pr.selectNodeContents(b0);pr.setEnd(s0.anchorNode,s0.anchorOffset);
      if(pr.toString()===''){
        e.preventDefault();
        if(isEmptyBlock(b0)&&body.children.length===1){var h2=body.parentNode.querySelector(':scope>.tg-head');if(h2)caretEnd(h2);}
      }
    }
  }
});
// Enter numa citação/destaque vazio sai do bloco (como no Notion).
doc.addEventListener('beforeinput',function(e){
  if(e.inputType!=='insertParagraph')return;
  var b=curBlock();
  if(b&&isEmptyBlock(b)&&(b.tagName==='BLOCKQUOTE'||/callout/.test(b.className))){
    e.preventDefault();convertBlock('p');
  }
});
titleEl.addEventListener('beforeinput',function(e){
  if(e.inputType==='insertParagraph'||e.inputType==='insertLineBreak'){
    e.preventDefault();doc.focus();
    var f=doc.firstElementChild;if(f)caretStart(f);
  }
});
titleEl.addEventListener('input',changed);

/* ---------- colar: limpa o HTML de fora, mantém o básico ---------- */
var ALLOWED={P:1,H1:1,H2:1,H3:1,H4:1,H5:1,BLOCKQUOTE:1,UL:1,OL:1,LI:1,B:1,STRONG:1,I:1,EM:1,U:1,S:1,STRIKE:1,A:1,BR:1,HR:1,TABLE:1,TBODY:1,THEAD:1,TR:1,TD:1,TH:1,IMG:1,DIV:1,SPAN:1};
function okColor(v){return /^\s*(#[0-9a-f]{3,8}|rgba?\(\s*[\d.]+\s*(,\s*[\d.]+%?\s*){2,3}\))\s*$/i.test(v);}
function clean(node){
  var kids=Array.prototype.slice.call(node.childNodes);
  for(var i=0;i<kids.length;i++){
    var k=kids[i];
    if(k.nodeType===8){node.removeChild(k);continue;}
    if(k.nodeType!==1)continue;
    var tg=k.tagName;
    if(/^(SCRIPT|STYLE|META|LINK|TITLE|IFRAME|OBJECT|EMBED|FORM|INPUT|BUTTON)$/.test(tg)){node.removeChild(k);continue;}
    clean(k);
    if(tg==='STRIKE'){var sn=document.createElement('s');while(k.firstChild)sn.appendChild(k.firstChild);node.replaceChild(sn,k);k=sn;tg='S';}
    if(!ALLOWED[tg]){while(k.firstChild)node.insertBefore(k.firstChild,k);node.removeChild(k);continue;}
    var keep={};
    if(tg==='A'&&k.getAttribute('href')&&!/^javascript:/i.test(k.getAttribute('href')))keep.href=k.getAttribute('href');
    if(tg==='IMG'&&k.getAttribute('src'))keep.src=k.getAttribute('src');
    if(k.getAttribute('colspan'))keep.colspan=k.getAttribute('colspan');
    if(k.getAttribute('rowspan'))keep.rowspan=k.getAttribute('rowspan');
    var kc=[],wl=['callout','todo','toggle','tg-head','tg-body','cols','col','notelink','subnote','ai-block','ai-h','ai-c','lkcard','sq','lk-b','lk-t','lk-d','lk-s'];
    for(var wc=0;wc<wl.length;wc++)if(k.classList.contains(wl[wc]))kc.push(wl[wc]);
    if(kc.length)keep['class']=kc.join(' ');
    if(tg==='A'&&k.classList.contains('lkcard')){
      keep.contenteditable='false';
      var dsx=k.getAttribute('data-state');if(dsx==='loading'||dsx==='ok'||dsx==='fail')keep['data-state']=dsx;
      var dlx=k.getAttribute('data-lid');if(dlx&&/^[\w-]{4,40}$/.test(dlx))keep['data-lid']=dlx;
    }
    var dwx=parseInt(k.getAttribute('data-w'),10);
    if(dwx>=10&&dwx<=100&&(tg==='IMG'||(tg==='A'&&k.classList.contains('lkcard')))){keep['data-w']=String(dwx);keep.style='width:'+dwx+'%'+(tg==='IMG'?';height:auto':';max-width:none');}
    var dop=k.getAttribute('data-open');if(dop==='true'||dop==='false')keep['data-open']=dop;
    var dnn=k.getAttribute('data-n');if(dnn==='2'||dnn==='3')keep['data-n']=dnn;
    var dnt=k.getAttribute('data-note');if(dnt&&/^[0-9a-fA-F-]{8,40}$/.test(dnt))keep['data-note']=dnt;
    var dai=k.getAttribute('data-ai');if(dai==='organize'||dai==='tasks')keep['data-ai']=dai;
    if(k.hasAttribute('data-done'))keep['data-done']=k.getAttribute('data-done');
    var st=k.getAttribute('style')||'';
    if(tg==='SPAN'&&st){
      var parts=[],cm=st.match(/(?:^|;)\s*color\s*:\s*([^;]+)/i);
      if(cm&&okColor(cm[1]))parts.push('color:'+cm[1].trim());
      var bm=st.match(/(?:^|;)\s*background(?:-color)?\s*:\s*([^;]+)/i);
      if(bm&&okColor(bm[1]))parts.push('background-color:'+bm[1].trim());
      var ff=st.match(/(?:^|;)\s*font-family\s*:\s*([^;]+)/i);
      if(ff){var fn=ff[1].split(',')[0].replace(/&quot;|["']/g,'').trim();if(FONTS.indexOf(fn)>=0)parts.push("font-family:'"+fn+"'");}
      var fm=st.match(/(?:^|;)\s*font-size\s*:\s*([\d.]+)em/i);
      if(fm){var fz=parseFloat(fm[1]);if(fz>=0.4&&fz<=5)parts.push('font-size:'+fz+'em');}
      if(parts.length)keep.style=parts.join(';');
      // Negrito, itálico, sublinhado e tachado que vieram como estilo viram as marcas de sempre.
      var wr=[];
      if(/font-weight\s*:\s*(bold|[6-9]00)/i.test(st))wr.push('b');
      if(/font-style\s*:\s*italic/i.test(st))wr.push('i');
      if(/text-decoration[^;]*underline/i.test(st))wr.push('u');
      if(/text-decoration[^;]*line-through/i.test(st))wr.push('s');
      for(var wi=0;wi<wr.length;wi++){var wn=document.createElement(wr[wi]);while(k.firstChild)wn.appendChild(k.firstChild);k.appendChild(wn);}
    }
    if(/^(P|H[1-5]|LI|BLOCKQUOTE|DIV)$/.test(tg)&&(tg!=='DIV'||k.classList.contains('callout'))){
      var tam=st.match(/(?:^|;)\s*text-align\s*:\s*(left|center|right)/i);
      if(tam)keep.style='text-align:'+tam[1].toLowerCase();
      var di=parseInt(k.getAttribute('data-indent'),10);
      if(di>=1&&di<=6)keep['data-indent']=String(di);
    }
    while(k.attributes.length)k.removeAttribute(k.attributes[0].name);
    for(var a in keep)k.setAttribute(a,keep[a]);
    if((tg==='SPAN'||tg==='DIV')&&!k.attributes.length){while(k.firstChild)node.insertBefore(k.firstChild,k);node.removeChild(k);}
  }
}
doc.addEventListener('paste',function(e){
  var cd=e.clipboardData;if(!cd)return;
  var html=cd.getData('text/html'),txt=cd.getData('text/plain');
  e.preventDefault();
  var onlyUrl=/^https?:\/\/\S+$/i.test((txt||'').trim())?txt.trim():null;
  if(onlyUrl&&!closest(sel().rangeCount?sel().anchorNode:null,'a')&&sel().isCollapsed){insertLinkCard(onlyUrl);return;}
  if(html){
    var t=document.createElement('div');t.innerHTML=html;clean(t);
    // Dentro de coluna não entram tabela, índice nem colunas; dentro de recolhível não entram colunas.
    var an=sel().rangeCount?sel().anchorNode:null,bad=[];
    if(closest(an,'.col'))bad=t.querySelectorAll('table,.toc,.cols');
    else if(closest(an,'.tg-body'))bad=t.querySelectorAll('.cols');
    for(var bi=0;bi<bad.length;bi++)if(bad[bi].parentNode)bad[bi].parentNode.removeChild(bad[bi]);
    document.execCommand('insertHTML',false,t.innerHTML);
    normalizeStructure();
  }else if(txt)document.execCommand('insertText',false,txt);
  changed();
});

/* ---------- gestos: pinça (zoom geral) e duplo toque (editar) ---------- */
var pinch=null,pinchRaf=0,lastTap=null,moved=false,startXY=null;
function dist(t){var dx=t[0].clientX-t[1].clientX,dy=t[0].clientY-t[1].clientY;return Math.sqrt(dx*dx+dy*dy);}
document.addEventListener('touchstart',function(e){
  if(e.touches.length===2){
    pinch={d:dist(e.touches),s:scale,top:scEl.scrollTop};
    lastTap=null;
  }else if(e.touches.length===1){
    moved=false;startXY=[e.touches[0].clientX,e.touches[0].clientY];
  }
},{passive:true});
document.addEventListener('touchmove',function(e){
  if(pinch&&e.touches.length===2){
    e.preventDefault();
    var ns=pinch.s*dist(e.touches)/pinch.d;
    cancelAnimationFrame(pinchRaf);
    pinchRaf=requestAnimationFrame(function(){window.setScale(ns);});
  }else if(startXY&&e.touches.length===1){
    var dx=e.touches[0].clientX-startXY[0],dy=e.touches[0].clientY-startXY[1];
    if(dx*dx+dy*dy>100)moved=true;
  }
},{passive:false});
document.addEventListener('touchend',function(e){
  if(pinch){
    if(e.touches.length<2){pinch=null;post({type:'scale',value:scale});}
    return;
  }
  if(editable||e.touches.length>0||moved||!e.changedTouches.length)return;
  var t=e.changedTouches[0],now=Date.now();
  var ign=e.target.closest?e.target.closest('a,.vidcard,.toc,[data-a],#bar,#panel,video'):null;
  if(ign){lastTap=null;return;}
  var li=e.target.closest?e.target.closest('ul.todo>li'):null;
  if(li&&t.clientX-li.getBoundingClientRect().left<34){lastTap=null;return;}
  var tgh2=e.target.closest?e.target.closest('.tg-head'):null;
  if(tgh2&&t.clientX-tgh2.getBoundingClientRect().left<30){lastTap=null;return;}
  if(lastTap&&now-lastTap.t<320&&Math.abs(t.clientX-lastTap.x)<30&&Math.abs(t.clientY-lastTap.y)<30){
    lastTap=null;
    e.preventDefault();
    startEditFromTap(t.clientX,t.clientY);
  }else lastTap={t:now,x:t.clientX,y:t.clientY};
},{passive:false});
function startEditFromTap(x,y){
  var rng=null;
  try{
    if(document.caretRangeFromPoint)rng=document.caretRangeFromPoint(x,y);
    else if(document.caretPositionFromPoint){var cp=document.caretPositionFromPoint(x,y);if(cp){rng=document.createRange();rng.setStart(cp.offsetNode,cp.offset);rng.collapse(true);}}
  }catch(er){}
  window.setEditable(true);
  var inTitle=rng&&titleEl.contains(rng.startContainer);
  var inBody=rng&&doc.contains(rng.startContainer);
  (inTitle?titleEl:doc).focus();
  try{
    var s=sel();s.removeAllRanges();
    if(inTitle||inBody)s.addRange(rng);
    else caretEnd(doc.lastElementChild||doc);
  }catch(er2){caretEnd(doc.lastElementChild||doc);}
  post({type:'editing'});
}

window.addEventListener('error',function(e){post({type:'jserror',message:String(e.message)});});
post({type:'ready'});
})();
</script>
</body>
</html>`;
