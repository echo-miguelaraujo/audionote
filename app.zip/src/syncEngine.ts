import { parseLink } from './linkPreview';
import { videoFiles } from './videoData';
import { parseTextBox } from './textBox';
import type * as SQLite from 'expo-sqlite';
import type { SupabaseClient } from '@supabase/supabase-js';
import { SYNC_TABLES, SyncTable } from './syncSchema';

/**
 * Motor de sincronização SQLite <-> Supabase (uma tabela por vez, sem chaves estrangeiras na nuvem).
 *
 * Fluxo de cada rodada:
 *   1. PULL: busca na nuvem o que mudou desde o último cursor (updated_at do servidor).
 *   2. APLICA numa transação só, resolvendo conflitos por "última escrita vence":
 *        - linha local pendente (dirty) com updated_at MAIS NOVO que o da nuvem -> a local vence (será enviada);
 *        - senão a da nuvem vence e sobrescreve a local.
 *      Exclusão: remota (deleted_at) apaga a local; exclusão local (lápide) vence só se for mais nova
 *      que a última alteração remota.
 *   3. PUSH: envia as linhas pendentes (upsert por id) e as exclusões (deleted_at).
 *
 * Os ids inteiros locais nunca saem do aparelho: referências (categoria, coleção-pai, coleção do item,
 * destino de um cartão de nota/coleção) viajam como UUID e são convertidas aqui.
 */

type Db = SQLite.SQLiteDatabase;
type Row = Record<string, any>;

export type SyncStats = { pulled: number; applied: number; deleted: number; localWon: number; pushed: number; pushedDeletes: number };

export type SyncDeps = {
  db: Db;
  client: SupabaseClient;
  /** Chamado (depois do commit) com o nome dos arquivos de áudio de notas apagadas pela nuvem. */
  removeAudioFile?: (fileName: string) => void;
};

type Kind = 'plain' | 'bool' | { ref: SyncTable };
type Field = { local: string; remote: string; kind: Kind };

const SPECS: Record<SyncTable, Field[]> = {
  categories: [
    { local: 'name', remote: 'name', kind: 'plain' },
    { local: 'color', remote: 'color', kind: 'plain' },
    { local: 'created_at', remote: 'created_at', kind: 'plain' },
  ],
  blocks: [
    { local: 'name', remote: 'name', kind: 'plain' },
    { local: 'created_at', remote: 'created_at', kind: 'plain' },
    { local: 'audio_counter', remote: 'audio_counter', kind: 'plain' },
    { local: 'note_json', remote: 'note_json', kind: 'plain' },
    { local: 'favorite', remote: 'favorite', kind: 'bool' },
    { local: 'category_id', remote: 'category_id', kind: { ref: 'categories' } },
    { local: 'pinned', remote: 'pinned', kind: 'bool' },
    { local: 'tags', remote: 'tags', kind: 'plain' },
    { local: 'parent_id', remote: 'parent_id', kind: { ref: 'blocks' } },
    { local: 'is_template', remote: 'is_template', kind: 'bool' },
    { local: 'edited_at', remote: 'edited_at', kind: 'plain' },
  ],
  mood_collections: [
    { local: 'name', remote: 'name', kind: 'plain' },
    { local: 'parent_id', remote: 'parent_id', kind: { ref: 'mood_collections' } },
    { local: 'pos_x', remote: 'pos_x', kind: 'plain' },
    { local: 'pos_y', remote: 'pos_y', kind: 'plain' },
    { local: 'scene_desc', remote: 'scene_desc', kind: 'plain' },
    { local: 'scene_place', remote: 'scene_place', kind: 'plain' },
    { local: 'scene_emotion', remote: 'scene_emotion', kind: 'plain' },
    { local: 'scene_done', remote: 'scene_done', kind: 'bool' },
    { local: 'scene_status', remote: 'scene_status', kind: 'plain' },
    { local: 'scene_statuses', remote: 'scene_statuses', kind: 'plain' },
    { local: 'scene_order', remote: 'scene_order', kind: 'plain' },
    { local: 'scene_duration', remote: 'scene_duration', kind: 'plain' },
    { local: 'scene_shot', remote: 'scene_shot', kind: 'plain' },
    { local: 'scene_dialogue', remote: 'scene_dialogue', kind: 'plain' },
    { local: 'scene_date', remote: 'scene_date', kind: 'plain' },
    { local: 'scene_transition', remote: 'scene_transition', kind: 'plain' },
    { local: 'scene_hook', remote: 'scene_hook', kind: 'plain' },
    { local: 'scene_cover', remote: 'scene_cover', kind: 'plain' },
    { local: 'script_note_uuid', remote: 'script_note_uuid', kind: 'plain' },
    { local: 'created_at', remote: 'created_at', kind: 'plain' },
  ],
  mood_items: [
    { local: 'collection_id', remote: 'collection_id', kind: { ref: 'mood_collections' } },
    { local: 'kind', remote: 'kind', kind: 'plain' },
    // 'content' é tratado à parte: vira UUID quando kind = 'collection' ou 'note'.
    { local: 'x', remote: 'x', kind: 'plain' },
    { local: 'y', remote: 'y', kind: 'plain' },
    { local: 'w', remote: 'w', kind: 'plain' },
    { local: 'h', remote: 'h', kind: 'plain' },
    { local: 'rot', remote: 'rot', kind: 'plain' },
    { local: 'z', remote: 'z', kind: 'plain' },
    { local: 'bold', remote: 'bold', kind: 'bool' },
    { local: 'caption', remote: 'caption', kind: 'plain' },
    { local: 'color', remote: 'color', kind: 'plain' },
    { local: 'box', remote: 'box', kind: 'plain' },
    { local: 'created_at', remote: 'created_at', kind: 'plain' },
  ],
  agenda_items: [
    { local: 'title', remote: 'title', kind: 'plain' },
    { local: 'start_at', remote: 'start_at', kind: 'plain' },
    { local: 'all_day', remote: 'all_day', kind: 'bool' },
    { local: 'category_id', remote: 'category_id', kind: { ref: 'categories' } },
    { local: 'notes', remote: 'notes', kind: 'plain' },
    { local: 'created_at', remote: 'created_at', kind: 'plain' },
  ],
};

const PAGE = 1000;
const PUSH_CHUNK = 200;
/** Folga ao reler o cursor: transações lentas no servidor podem confirmar com updated_at um pouco antigo. */
const CURSOR_MARGIN_MS = 5000;

const cursorKey = (t: string) => `sync_cursor_${t}`;

async function getMeta(db: Db, key: string): Promise<string | null> {
  const r = await db.getFirstAsync<{ value: string }>(`SELECT value FROM meta WHERE key = ?`, key);
  return r ? r.value : null;
}
async function setMeta(db: Db, key: string, value: string): Promise<void> {
  await db.runAsync(`INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)`, key, value);
}

/** Conversão id local <-> uuid, com cache (as tabelas são lidas por consulta simples). */
class RefMap {
  private idToUuid = new Map<string, string | null>();
  private uuidToId = new Map<string, number | null>();
  constructor(private db: Db) {}
  async uuidOf(tbl: SyncTable, id: number): Promise<string | null> {
    const k = `${tbl}:${id}`;
    if (this.idToUuid.has(k)) return this.idToUuid.get(k)!;
    const r = await this.db.getFirstAsync<{ uuid: string }>(`SELECT uuid FROM ${tbl} WHERE id = ?`, id);
    const v = r?.uuid ?? null;
    this.idToUuid.set(k, v);
    return v;
  }
  async idOf(tbl: SyncTable, uuid: string): Promise<number | null> {
    const k = `${tbl}:${uuid}`;
    const hit = this.uuidToId.get(k);
    if (hit !== undefined && hit !== null) return hit;
    const r = await this.db.getFirstAsync<{ id: number }>(`SELECT id FROM ${tbl} WHERE uuid = ?`, uuid);
    const v = r?.id ?? null;
    this.uuidToId.set(k, v);
    return v;
  }
  forget(tbl: SyncTable, uuid: string) {
    this.uuidToId.delete(`${tbl}:${uuid}`);
  }
}

// ---------------------------------------------------------------- PULL

async function fetchChanges(client: SupabaseClient, tbl: SyncTable, cursor: string | null): Promise<Row[]> {
  const out: Row[] = [];
  const since = cursor ? new Date(Date.parse(cursor) - CURSOR_MARGIN_MS).toISOString() : null;
  for (let from = 0; ; from += PAGE) {
    let q = client
      .from(tbl)
      .select('*')
      .order('updated_at', { ascending: true })
      .order('id', { ascending: true })
      .range(from, from + PAGE - 1);
    if (since) q = q.gt('updated_at', since);
    const { data, error } = await q;
    if (error) throw new Error(`${tbl}: ${error.message}`);
    out.push(...(data ?? []));
    if (!data || data.length < PAGE) break;
  }
  return out;
}

/** Colunas locais (sem as de controle) a partir de uma linha da nuvem; null = não dá para aplicar (destino sumiu). */
async function fromRemote(tbl: SyncTable, r: Row, refs: RefMap): Promise<Row | null> {
  const out: Row = {};
  for (const f of SPECS[tbl]) {
    const v = r[f.remote];
    if (f.kind === 'plain') out[f.local] = v ?? null;
    else if (f.kind === 'bool') out[f.local] = v ? 1 : 0;
    else if (v === null || v === undefined) out[f.local] = null;
    else {
      const id = await refs.idOf(f.kind.ref, v);
      if (id === null) {
        // coleção-pai ainda não chegou: resolvido depois (veja pendingParents); o resto é obrigatório.
        if ((tbl === 'mood_collections' || tbl === 'blocks') && f.local === 'parent_id') out[f.local] = null;
        else if (tbl === 'mood_items') return null;
        else out[f.local] = null; // categoria que não existe mais -> sem categoria
      } else out[f.local] = id;
    }
  }
  if (tbl === 'mood_items') {
    const kind = r.kind;
    if (kind === 'collection' || kind === 'note') {
      const id = await refs.idOf(kind === 'collection' ? 'mood_collections' : 'blocks', String(r.content));
      if (id === null) return null;
      out.content = String(id);
    } else out.content = r.content ?? '';
  }
  return out;
}

async function deleteLocal(db: Db, tbl: SyncTable, id: number, uuid: string, stats: SyncStats, audioFiles: string[]) {
  if (tbl === 'blocks') {
    const files = await db.getAllAsync<{ file_name: string }>(`SELECT file_name FROM audios WHERE block_id = ?`, id);
    files.forEach((f) => f.file_name && audioFiles.push(f.file_name));
    await db.runAsync(`DELETE FROM audios WHERE block_id = ?`, id);
    await db.runAsync(`DELETE FROM mood_items WHERE kind = 'note' AND content = ?`, String(id));
    // Subnotas da nota apagada pela nuvem viram notas de topo.
    await db.runAsync(`UPDATE blocks SET parent_id = NULL, sync_rev = sync_rev + 1 WHERE parent_id = ?`, id);
  } else if (tbl === 'categories') {
    await db.runAsync(`UPDATE blocks SET category_id = NULL, sync_rev = sync_rev + 1 WHERE category_id = ?`, id);
    await db.runAsync(`UPDATE agenda_items SET category_id = NULL, sync_rev = sync_rev + 1 WHERE category_id = ?`, id);
  } else if (tbl === 'mood_collections') {
    await db.runAsync(`DELETE FROM mood_items WHERE kind = 'collection' AND content = ?`, String(id));
  }
  await db.runAsync(`DELETE FROM ${tbl} WHERE id = ?`, id); // mood_items da coleção saem por cascata
  // A exclusão veio da nuvem: não é para devolvê-la.
  await db.runAsync(`DELETE FROM sync_tombstones WHERE tbl = ? AND uuid = ?`, tbl, uuid);
  stats.deleted++;
}

/** Filho que chegou antes do pai (coleção dentro de coleção, subnota dentro de nota): o vínculo é refeito no fim do pull. */
type PendingParent = { tbl: 'mood_collections' | 'blocks'; uuid: string; parent: string };

async function applyRemote(
  db: Db,
  tbl: SyncTable,
  r: Row,
  refs: RefMap,
  stats: SyncStats,
  audioFiles: string[],
  pendingParents: PendingParent[]
): Promise<void> {
  const remoteMs = Date.parse(r.updated_at);
  const local = await db.getFirstAsync<{ id: number; dirty: number; updated_at: number }>(
    `SELECT id, dirty, updated_at FROM ${tbl} WHERE uuid = ?`,
    r.id
  );
  const tomb = await db.getFirstAsync<{ deleted_at: number }>(
    `SELECT deleted_at FROM sync_tombstones WHERE tbl = ? AND uuid = ?`,
    tbl,
    r.id
  );

  if (r.deleted_at) {
    if (tomb) await db.runAsync(`DELETE FROM sync_tombstones WHERE tbl = ? AND uuid = ?`, tbl, r.id);
    if (!local) return;
    if (local.dirty && local.updated_at > remoteMs) {
      stats.localWon++;
      return;
    }
    await deleteLocal(db, tbl, local.id, r.id, stats, audioFiles);
    refs.forget(tbl, r.id);
    return;
  }

  if (tomb) {
    if (tomb.deleted_at > remoteMs) {
      stats.localWon++; // apaguei aqui depois da última edição de lá: a exclusão vence
      return;
    }
    await db.runAsync(`DELETE FROM sync_tombstones WHERE tbl = ? AND uuid = ?`, tbl, r.id); // editada depois: volta
  }
  if (local && !local.dirty && local.updated_at === remoteMs) return; // já está igual
  if (local && local.dirty && local.updated_at > remoteMs) {
    stats.localWon++;
    return;
  }

  const vals = await fromRemote(tbl, r, refs);
  if (!vals) return;
  const cols = Object.keys(vals);
  if (local) {
    await db.runAsync(
      `UPDATE ${tbl} SET ${cols.map((c) => `${c} = ?`).join(', ')}, dirty = 0, updated_at = ?, sync_rev = sync_rev + 1 WHERE id = ?`,
      ...cols.map((c) => vals[c]),
      remoteMs,
      local.id
    );
  } else {
    await db.runAsync(
      `INSERT INTO ${tbl} (${cols.join(', ')}, uuid, updated_at, dirty, sync_rev) VALUES (${cols.map(() => '?').join(', ')}, ?, ?, 0, 1)`,
      ...cols.map((c) => vals[c]),
      r.id,
      remoteMs
    );
    refs.forget(tbl, r.id);
  }
  stats.applied++;
  if ((tbl === 'mood_collections' || tbl === 'blocks') && r.parent_id) pendingParents.push({ tbl, uuid: r.id, parent: r.parent_id });
}

async function pullAndApply(deps: SyncDeps, stats: SyncStats): Promise<void> {
  const { db, client } = deps;
  const fetched = new Map<SyncTable, Row[]>();
  for (const t of SYNC_TABLES) {
    fetched.set(t, await fetchChanges(client, t, await getMeta(db, cursorKey(t))));
  }
  const audioFiles: string[] = [];
  await db.withTransactionAsync(async () => {
    const refs = new RefMap(db);
    const pendingParents: PendingParent[] = [];
    for (const t of SYNC_TABLES) {
      const rows = fetched.get(t)!;
      stats.pulled += rows.length;
      for (const r of rows) await applyRemote(db, t, r, refs, stats, audioFiles, pendingParents);
      if (rows.length > 0) {
        const max = rows.reduce((m, r) => (Date.parse(r.updated_at) > Date.parse(m) ? r.updated_at : m), rows[0].updated_at);
        await setMeta(db, cursorKey(t), max);
      }
    }
    // Filhos (coleções ou subnotas) que chegaram antes dos pais.
    for (const p of pendingParents) {
      const parentId = await refs.idOf(p.tbl, p.parent);
      if (parentId !== null)
        await db.runAsync(`UPDATE ${p.tbl} SET parent_id = ?, sync_rev = sync_rev + 1 WHERE uuid = ?`, parentId, p.uuid);
    }
  });
  audioFiles.forEach((f) => deps.removeAudioFile?.(f));
}

// ---------------------------------------------------------------- PUSH

async function toRemote(tbl: SyncTable, row: Row, refs: RefMap): Promise<Row | null> {
  const out: Row = { id: row.uuid, deleted_at: null }; // deleted_at null: editar de novo "ressuscita"
  for (const f of SPECS[tbl]) {
    const v = row[f.local];
    if (f.kind === 'plain') out[f.remote] = v ?? null;
    else if (f.kind === 'bool') out[f.remote] = !!v;
    else if (v === null || v === undefined) out[f.remote] = null;
    else {
      const u = await refs.uuidOf(f.kind.ref, v);
      if (u === null && tbl === 'mood_items') return null; // item solto: não envia
      out[f.remote] = u;
    }
  }
  if (tbl === 'mood_items') {
    if (row.kind === 'collection' || row.kind === 'note') {
      const u = await refs.uuidOf(row.kind === 'collection' ? 'mood_collections' : 'blocks', Number(row.content));
      if (u === null) return null;
      out.content = u;
    } else out.content = row.content ?? '';
  }
  return out;
}

async function pushDirty(deps: SyncDeps, stats: SyncStats): Promise<void> {
  const { db, client } = deps;
  const refs = new RefMap(db);
  for (const t of SYNC_TABLES) {
    const rows = await db.getAllAsync<Row>(`SELECT * FROM ${t} WHERE dirty = 1 ORDER BY id`);
    for (let i = 0; i < rows.length; i += PUSH_CHUNK) {
      const chunk = rows.slice(i, i + PUSH_CHUNK);
      const payload: Row[] = [];
      const sent: Row[] = [];
      for (const row of chunk) {
        const p = await toRemote(t, row, refs);
        if (p) {
          payload.push(p);
          sent.push(row);
        }
      }
      const stamps = new Map<string, number>();
      if (payload.length > 0) {
        // select() devolve o updated_at que o servidor carimbou: guardá-lo evita reaplicar a própria linha no próximo pull.
        const { data, error } = await client.from(t).upsert(payload, { onConflict: 'id' }).select('id, updated_at');
        if (error) throw new Error(`${t}: ${error.message}`);
        for (const d of data ?? []) stamps.set(d.id, Date.parse(d.updated_at));
      }
      // Só limpa o "pendente" se a linha não mudou durante o envio (sync_rev igual).
      for (const row of sent) {
        const ms = stamps.get(row.uuid);
        await db.runAsync(
          ms ? `UPDATE ${t} SET dirty = 0, updated_at = ?, sync_rev = sync_rev + 1 WHERE id = ? AND sync_rev = ?`
             : `UPDATE ${t} SET dirty = 0, sync_rev = sync_rev + 1 WHERE id = ? AND sync_rev = ?`,
          ...(ms ? [ms] : []), row.id, row.sync_rev
        );
      }
      stats.pushed += sent.length;
    }
  }

  const tombs = await db.getAllAsync<{ tbl: SyncTable; uuid: string; deleted_at: number }>(`SELECT * FROM sync_tombstones`);
  for (const t of SYNC_TABLES) {
    const mine = tombs.filter((x) => x.tbl === t);
    for (let i = 0; i < mine.length; i += 100) {
      const chunk = mine.slice(i, i + 100);
      // Mesma data para o lote; o servidor carimba updated_at por conta própria.
      const when = new Date(Math.max(...chunk.map((c) => c.deleted_at))).toISOString();
      const { error } = await client.from(t).update({ deleted_at: when }).in('id', chunk.map((c) => c.uuid));
      if (error) throw new Error(`${t}: ${error.message}`);
      for (const c of chunk) await db.runAsync(`DELETE FROM sync_tombstones WHERE tbl = ? AND uuid = ?`, t, c.uuid);
      stats.pushedDeletes += chunk.length;
    }
  }
}

/** Uma rodada completa: baixa, aplica, envia. Lança erro se algo falhar (os pendentes continuam pendentes). */
export async function syncOnce(deps: SyncDeps): Promise<SyncStats> {
  const stats: SyncStats = { pulled: 0, applied: 0, deleted: 0, localWon: 0, pushed: 0, pushedDeletes: 0 };
  await pullAndApply(deps, stats);
  await pushDirty(deps, stats);
  return stats;
}

/** Zera cursores e marca tudo como pendente (usado quando o aparelho passa a sincronizar com OUTRA conta). */
export async function resetForNewAccount(db: Db): Promise<void> {
  await db.withTransactionAsync(async () => {
    for (const t of SYNC_TABLES) {
      await db.runAsync(`DELETE FROM meta WHERE key = ?`, cursorKey(t));
      await db.runAsync(`UPDATE ${t} SET dirty = 1, sync_rev = sync_rev + 1`);
    }
    await db.runAsync(`DELETE FROM sync_tombstones`);
  });
}

export async function pendingCount(db: Db): Promise<number> {
  let n = 0;
  for (const t of SYNC_TABLES) {
    n += (await db.getFirstAsync<{ n: number }>(`SELECT COUNT(*) AS n FROM ${t} WHERE dirty = 1`))?.n ?? 0;
  }
  n += (await db.getFirstAsync<{ n: number }>(`SELECT COUNT(*) AS n FROM sync_tombstones`))?.n ?? 0;
  return n;
}

// ---------------------------------------------------------------- IMAGENS (nomes de arquivo usados)

/** Nomes dos arquivos de media usados por notas (capa e app-media:// no texto) e pelos cartões de imagem. */
export async function collectMediaRefs(db: Db): Promise<Set<string>> {
  const names = new Set<string>();
  const add = (n: string) => {
    if (!n) return;
    try {
      names.add(decodeURIComponent(n));
    } catch {
      names.add(n);
    }
  };
  const notes = await db.getAllAsync<{ note_json: string | null }>(`SELECT note_json FROM blocks WHERE note_json IS NOT NULL`);
  for (const n of notes) {
    try {
      const j = JSON.parse(n.note_json!);
      if (typeof j?.cover === 'string') add(j.cover);
      if (typeof j?.html === 'string') for (const m of j.html.matchAll(/app-media:\/\/([^"'\s)<>]+)/g)) add(m[1]);
    } catch {
      /* nota ilegível: ignora */
    }
  }
  const imgs = await db.getAllAsync<{ content: string }>(`SELECT content FROM mood_items WHERE kind = 'image'`);
  imgs.forEach((i) => {
    if (!/^https?:\/\//i.test(i.content)) add(i.content);
  });
  const links = await db.getAllAsync<{ content: string }>(`SELECT content FROM mood_items WHERE kind = 'link'`);
  links.forEach((l) => {
    const img = parseLink(l.content).img;
    if (img) add(img);
  });
  const boxes = await db.getAllAsync<{ box: string }>(`SELECT box FROM mood_items WHERE kind = 'text' AND box IS NOT NULL`);
  boxes.forEach((b) => {
    const img = parseTextBox({ box: b.box, color: null }).img;
    if (img) add(img);
  });
  const vids = await db.getAllAsync<{ content: string }>(`SELECT content FROM mood_items WHERE kind = 'video'`);
  vids.forEach((v) => videoFiles(v.content).forEach(add));
  return names;
}
