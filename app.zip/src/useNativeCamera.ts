import { useEffect, useMemo } from 'react';
import { Animated } from 'react-native';

/**
 * Câmera do quadro (pan e zoom) na thread de UI.
 *
 * Com o Animated "no JavaScript", cada `setValue` do gesto refaz a árvore de views do quadro inteiro
 * (centenas de views), três vezes por toque: a thread JS satura e a tela fica parada por segundos.
 * Com o driver nativo, o movimento é aplicado direto na view, sem passar pelo JS.
 *
 * Os valores viram nativos ao rodar uma animação nativa de duração zero. Depois disso só dá para animá-los
 * com `useNativeDriver: true` (ex.: voo da câmera na apresentação).
 *
 * Devolve as translações já corrigidas para girar em torno do canto superior esquerdo usando a origem
 * padrão (centro) da view: translação + (zoom - 1) × metade do tamanho do quadro.
 */
export function useNativeCamera(tx: Animated.Value, ty: Animated.Value, z: Animated.Value, worldW: number, worldH: number) {
  useEffect(() => {
    for (const v of [tx, ty, z]) {
      Animated.timing(v, { toValue: (v as any).__getValue(), duration: 0, useNativeDriver: true }).start();
    }
  }, [tx, ty, z]);

  const camTx = useMemo(() => Animated.add(tx, Animated.multiply(Animated.subtract(z, 1), worldW / 2)), [tx, z, worldW]);
  const camTy = useMemo(() => Animated.add(ty, Animated.multiply(Animated.subtract(z, 1), worldH / 2)), [ty, z, worldH]);
  return { camTx, camTy };
}
