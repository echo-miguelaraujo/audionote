import 'react-native-url-polyfill/auto';
import { AppState } from 'react-native';
import { createClient } from '@supabase/supabase-js';
import * as Linking from 'expo-linking';
import * as WebBrowser from 'expo-web-browser';
// Guarda a sessão num banco SQLite à parte (não entra no backup do ideias.db).
import Storage from 'expo-sqlite/kv-store';
import { SUPABASE_ANON_KEY, SUPABASE_URL, supabaseConfigured } from './supabaseConfig';

WebBrowser.maybeCompleteAuthSession();

export const supabase = createClient(
  supabaseConfigured() ? SUPABASE_URL : 'https://placeholder.supabase.co',
  supabaseConfigured() ? SUPABASE_ANON_KEY : 'placeholder-placeholder-placeholder-placeholder-key',
  {
    auth: {
      storage: Storage,
      autoRefreshToken: true,
      persistSession: true,
      detectSessionInUrl: false,
      flowType: 'pkce',
    },
  }
);

// No celular o timer de renovação do token deve rodar só com o app aberto.
AppState.addEventListener('change', (st) => {
  if (st === 'active') supabase.auth.startAutoRefresh();
  else supabase.auth.stopAutoRefresh();
});
supabase.auth.startAutoRefresh();

/** URL para onde o Google/Supabase devolve o usuário: ideias://auth-callback (cadastre no Supabase). */
export const REDIRECT_URL = Linking.createURL('auth-callback');

export async function signInWithGoogle(): Promise<{ ok: boolean; message?: string }> {
  if (!supabaseConfigured()) return { ok: false, message: 'Preencha a URL e a chave anon em src/supabaseConfig.ts.' };
  const { data, error } = await supabase.auth.signInWithOAuth({
    provider: 'google',
    options: { redirectTo: REDIRECT_URL, skipBrowserRedirect: true },
  });
  if (error || !data?.url) return { ok: false, message: error?.message ?? 'Não foi possível iniciar o login.' };

  const res = await WebBrowser.openAuthSessionAsync(data.url, REDIRECT_URL);
  if (res.type !== 'success') return { ok: false, message: 'Login cancelado.' };

  const url = new URL(res.url);
  const err = url.searchParams.get('error_description') || url.searchParams.get('error');
  if (err) return { ok: false, message: err };
  const code = url.searchParams.get('code');
  if (!code) return { ok: false, message: 'O Google não devolveu o código de login.' };
  const ex = await supabase.auth.exchangeCodeForSession(code);
  if (ex.error) return { ok: false, message: ex.error.message };
  return { ok: true };
}

export async function signOut(): Promise<void> {
  await supabase.auth.signOut();
}

export async function currentUser(): Promise<{ id: string; email: string | null } | null> {
  const { data } = await supabase.auth.getSession();
  const u = data.session?.user;
  return u ? { id: u.id, email: u.email ?? null } : null;
}
