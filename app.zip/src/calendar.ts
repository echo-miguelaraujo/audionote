import { Platform } from 'react-native';
import * as Calendar from 'expo-calendar';
import { CalendarRecord, DetectedEvent, addCalendarRecord, deleteCalendarRecord, listCalendarRecords } from './db';
import { getCalendarAuto, getCalendarId } from './settings';

export type CalOption = { id: string; title: string; account: string };

/** "2026-10-17T15:00" (hora local) -> Date. */
export function parseLocal(iso: string): Date | null {
  const m = iso.match(/^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2}))?/);
  if (!m) return null;
  const d = new Date(+m[1], +m[2] - 1, +m[3], m[4] ? +m[4] : 0, m[5] ? +m[5] : 0, 0, 0);
  return isNaN(d.getTime()) ? null : d;
}

export async function ensureCalendarPermission(): Promise<boolean> {
  try {
    const cur = await Calendar.getCalendarPermissionsAsync();
    if (cur.granted) return true;
    const r = await Calendar.requestCalendarPermissionsAsync();
    return r.granted;
  } catch {
    return false;
  }
}

/** Agendas do celular que aceitam novos eventos (Google Agenda, Samsung etc.). */
export async function listWritableCalendars(): Promise<CalOption[]> {
  const cals = await Calendar.getCalendarsAsync(Calendar.EntityTypes.EVENT);
  return cals
    .filter((c) => c.allowsModifications)
    .map((c) => ({
      id: c.id,
      title: c.title,
      account: (c.source as any)?.name || (c as any).ownerAccount || '',
    }));
}

async function pickCalendarId(): Promise<string | null> {
  const cals = (await Calendar.getCalendarsAsync(Calendar.EntityTypes.EVENT)).filter((c) => c.allowsModifications);
  if (cals.length === 0) return null;
  const chosen = await getCalendarId();
  if (chosen && cals.some((c) => c.id === chosen)) return chosen;
  // Sem escolha: prefere a agenda principal da conta Google, depois qualquer agenda "principal".
  const google = cals.filter((c) => /google/i.test(String((c.source as any)?.type ?? '') + String((c.source as any)?.name ?? '')));
  const primary = (google.length ? google : cals).find((c) => (c as any).isPrimary);
  return (primary ?? google[0] ?? cals[0]).id;
}

export type CalendarOutcome = { created: number; skipped: number; note?: string };

/**
 * Cria na agenda os compromissos detectados no áudio. Seguro para repetir:
 * o que já foi criado para este áudio não é duplicado.
 */
export async function createEventsFor(
  audioId: number,
  blockId: number,
  blockLabel: string,
  events: DetectedEvent[]
): Promise<CalendarOutcome> {
  if (Platform.OS !== 'android' || events.length === 0) return { created: 0, skipped: events.length };
  if (!(await getCalendarAuto())) return { created: 0, skipped: events.length, note: 'desligado' };
  if (!(await ensureCalendarPermission())) return { created: 0, skipped: events.length, note: 'sem permissão' };
  const calId = await pickCalendarId();
  if (!calId) return { created: 0, skipped: events.length, note: 'sem agenda' };

  const done = await listCalendarRecords(audioId);
  let created = 0;
  let skipped = 0;
  for (const e of events) {
    const start = parseLocal(e.start);
    if (!start) {
      skipped++;
      continue;
    }
    if (done.some((d) => d.title === e.title && d.startAt === start.getTime())) {
      skipped++;
      continue;
    }
    const end = new Date(start.getTime() + (e.allDay ? 24 * 3600 * 1000 : 60 * 60 * 1000));
    try {
      const eventId = await Calendar.createEventAsync(calId, {
        title: e.title,
        startDate: start,
        endDate: end,
        allDay: e.allDay,
        timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'America/Sao_Paulo',
        notes: `Criado pelo app Ideias a partir da nota "${blockLabel}".${e.excerpt ? `\n\nVocê disse: "${e.excerpt}"` : ''}`,
        alarms: e.allDay ? [] : [{ relativeOffset: -15 }],
      });
      await addCalendarRecord({
        audioId,
        blockId,
        title: e.title,
        startAt: start.getTime(),
        allDay: e.allDay,
        calendarEventId: eventId,
      });
      created++;
    } catch {
      skipped++;
    }
  }
  return { created, skipped };
}

/** Remove um compromisso criado pelo app (da agenda do celular e do registro). */
export async function removeCreatedEvent(r: CalendarRecord): Promise<void> {
  try {
    if (r.calendarEventId && (await Calendar.getCalendarPermissionsAsync()).granted) {
      await Calendar.deleteEventAsync(r.calendarEventId);
    }
  } catch {
    // já foi apagado na agenda
  }
  await deleteCalendarRecord(r.id);
}
