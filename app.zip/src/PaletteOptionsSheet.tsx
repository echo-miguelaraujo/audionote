import React from 'react';
import { Pressable, ScrollView, Text, View, useWindowDimensions } from 'react-native';
import { DialogAction, SheetShell } from './DialogBase';
import type { PaletteOption } from './palette';
import { colors, fonts, SPACE, TYPE } from './theme';

type Props = {
  visible: boolean;
  onClose: () => void;
  options: PaletteOption[];
  /** Chamado com as cores da opção tocada; a janela fecha sozinha antes. */
  onPick: (colors: string[]) => void;
};

/** Janela que sobe de baixo com várias opções de paleta: role a lista e toque na que quiser. */
export function PaletteOptionsSheet({ visible, onClose, options, onPick }: Props) {
  const { width: sw, height: sh } = useWindowDimensions();
  return (
    <SheetShell visible={visible} onClose={onClose} maxHeight={sh * 0.75}>
      <Text
        style={{
          color: colors.onLight,
          fontFamily: fonts.bold,
          fontSize: sw * TYPE.title,
          paddingTop: sw * SPACE.lg,
          paddingHorizontal: sw * SPACE.xl,
        }}
      >
        Escolha uma paleta
      </Text>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingVertical: sw * SPACE.md, paddingHorizontal: sw * SPACE.xl, gap: sw * SPACE.lg }}
      >
        {options.map((o) => (
          <Pressable
            key={o.name + o.colors.join('')}
            accessibilityRole="button"
            accessibilityLabel={`${o.name}: ${o.colors.join(', ')}`}
            onPress={() => {
              onClose();
              onPick(o.colors);
            }}
          >
            <Text style={{ color: colors.subtle, fontFamily: fonts.regular, fontSize: sw * TYPE.caption, marginBottom: sw * 0.015 }}>
              {o.name}
            </Text>
            <View style={{ flexDirection: 'row', height: sw * 0.17, borderRadius: sw * 0.03, overflow: 'hidden', borderWidth: 1, borderColor: colors.hairline }}>
              {o.colors.map((c) => (
                <View key={c} style={{ flex: 1, backgroundColor: c }} />
              ))}
            </View>
            <View style={{ flexDirection: 'row', marginTop: sw * 0.012 }}>
              {o.colors.map((c) => (
                <Text key={c} numberOfLines={1} style={{ flex: 1, textAlign: 'center', color: colors.subtle, fontFamily: fonts.regular, fontSize: sw * TYPE.caption }}>
                  {c}
                </Text>
              ))}
            </View>
          </Pressable>
        ))}
      </ScrollView>
      <View style={{ padding: sw * SPACE.md, alignItems: 'center', borderTopWidth: 1, borderTopColor: colors.hairline }}>
        <DialogAction label="Cancelar" tone="cancel" onPress={onClose} />
      </View>
    </SheetShell>
  );
}
