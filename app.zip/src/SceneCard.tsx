import React, { memo, useEffect, useState } from 'react';
import { Image, Text, View } from 'react-native';
import type { MoodCollection, MoodItem } from './db';
import { Icon } from './Icon';
import type { Live } from './ItemView';
import { mediaUri } from './media';
import { colors, fonts } from './theme';

/** Status da cena, na ordem do fluxo de produção. O índice é o que se guarda (scene_status). */
export const SCENE_STATUS = [
  { label: 'Ideia', color: null },
  { label: 'Roteirizada', color: '#E0A100' },
  { label: 'Gravada', color: null }, // usa colors.red
  { label: 'Editada', color: '#2F6FDE' },
  { label: 'Publicada', color: '#2E9E5B' },
] as const;

/** Tamanho do check, como fração da largura do cartão, e a margem dele até o canto. */
const CHECK_FRAC = 0.26;
const CHECK_MARGIN = 0.04;

/** O ponto (px, py), em unidades do mundo relativas ao canto do cartão, está na área do check? (com folga para o dedo) */
export function sceneCheckHit(px: number, py: number, cardW: number, cardH: number, slop: number): boolean {
  const cs = cardW * CHECK_FRAC;
  const left = cardW - cardW * CHECK_MARGIN - cs;
  const top = cardH - cardW * CHECK_MARGIN - cs;
  return px >= left - slop && px <= cardW + slop && py >= top - slop && py <= cardH + slop;
}

/** Cartão de uma cena na visão Cenas: número, imagem principal, título e check de "Gravada". Só desenha; o toque é do quadro. */
export const SceneCard = memo(function SceneCard({
  item,
  col,
  number,
  sw,
  live,
  onSize,
  onLoaded,
}: {
  item: MoodItem;
  col?: MoodCollection;
  number: number;
  sw: number;
  live: Live | null;
  onSize: (id: number, w: number, h: number) => void;
  /** Avisa quando a capa terminou de carregar (ou falhou). Usado na exportação. */
  onLoaded?: (id: number) => void;
}) {
  const L = live ?? { dx: 0, dy: 0, s: 1, r: 0 };
  const W = item.w * sw;
  const H = item.h * sw;
  const [coverFailed, setCoverFailed] = useState(false);
  const wanted = col?.sceneCover ?? col?.covers[0] ?? null;
  // A capa escolhida sumiu (ex.: veio de outro aparelho): cai para a primeira imagem da cena.
  const cover = coverFailed ? (col?.covers[0] !== wanted ? col?.covers[0] ?? null : null) : wanted;
  useEffect(() => setCoverFailed(false), [wanted]);
  useEffect(() => {
    if (!cover) onLoaded?.(item.id);
  }, [cover]); // eslint-disable-line react-hooks/exhaustive-deps
  const status = col?.sceneStatus ?? 0;
  const done = status > 0;
  const statusColor = SCENE_STATUS[status]?.color ?? colors.red;
  const cs = W * CHECK_FRAC;
  const fs = W * 0.1;
  return (
    <View
      pointerEvents="none"
      onLayout={(e) => onSize(item.id, e.nativeEvent.layout.width, e.nativeEvent.layout.height)}
      style={{
        position: 'absolute',
        left: item.x * sw,
        top: item.y * sw,
        width: W,
        height: H,
        backgroundColor: colors.paper,
        borderRadius: W * 0.05,
        borderWidth: 1,
        borderColor: colors.line,
        overflow: 'hidden',
        transform: [{ translateX: L.dx }, { translateY: L.dy }, { scale: L.s }],
      }}
    >
      <View style={{ flex: 1, backgroundColor: colors.hairline }}>
        {!!cover && <Image
            source={{ uri: mediaUri(cover) }}
            resizeMode="cover"
            style={{ width: '100%', height: '100%' }}
            onLoadEnd={() => onLoaded?.(item.id)}
            onError={() => setCoverFailed(true)}
          />}
      </View>
      <View style={{ paddingHorizontal: W * 0.06, paddingVertical: W * 0.05, paddingRight: cs + W * CHECK_MARGIN * 2, minHeight: cs + W * CHECK_MARGIN * 2 }}>
        <Text numberOfLines={2} style={{ fontFamily: fonts.bold, fontSize: fs, color: colors.onLight }}>
          {col?.name || `Cena ${number}`}
        </Text>
        <Text style={{ fontFamily: fonts.regular, fontSize: fs * 0.75, color: colors.subtle }}>{SCENE_STATUS[status]?.label ?? 'Ideia'}</Text>
      </View>
      <View
        style={{
          position: 'absolute',
          left: W * 0.04,
          top: W * 0.04,
          minWidth: W * 0.18,
          height: W * 0.18,
          paddingHorizontal: W * 0.04,
          borderRadius: W * 0.09,
          backgroundColor: colors.onLight,
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Text style={{ fontFamily: fonts.bold, fontSize: fs * 0.9, color: colors.onDark }}>{number}</Text>
      </View>
      <View
        style={{
          position: 'absolute',
          right: W * CHECK_MARGIN,
          bottom: W * CHECK_MARGIN,
          width: cs,
          height: cs,
          borderRadius: cs / 2,
          borderWidth: 2,
          borderColor: done ? statusColor : colors.line,
          backgroundColor: done ? statusColor : colors.paper,
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        {done && <Icon name="check" size={cs * 0.6} color={colors.onDark} />}
      </View>
    </View>
  );
});
