import React, { memo } from 'react';
import { Image, Text, View } from 'react-native';
import type { MoodCollection, MoodItem } from './db';
import { Icon } from './Icon';
import type { Live } from './ItemView';
import { mediaUri } from './media';
import { colors, fonts } from './theme';

/** Tamanho do check, como fração da largura do cartão, e a margem dele até o canto. */
const CHECK_FRAC = 0.26;
const CHECK_MARGIN = 0.04;

/** O ponto (px, py), em unidades do mundo relativas ao canto do cartão, está na área do check? (com folga para o dedo) */
export function sceneCheckHit(px: number, py: number, cardW: number, cardH: number, slop: number): boolean {
  const cs = cardW * CHECK_FRAC;
  const left = cardW - cardW * CHECK_MARGIN - cs;
  const top = cardH - cardW * CHECK_MARGIN - cs;
  return px >= left - slop && px <= cardW + slop && py >= top - slop && py <= cardH + slop;
}

/** Cartão de uma cena na visão Cenas: número, imagem principal, título e check de "Gravada". Só desenha; o toque é do quadro. */
export const SceneCard = memo(function SceneCard({
  item,
  col,
  number,
  sw,
  live,
  onSize,
}: {
  item: MoodItem;
  col?: MoodCollection;
  number: number;
  sw: number;
  live: Live | null;
  onSize: (id: number, w: number, h: number) => void;
}) {
  const L = live ?? { dx: 0, dy: 0, s: 1, r: 0 };
  const W = item.w * sw;
  const H = item.h * sw;
  const cover = col?.sceneCover ?? col?.covers[0] ?? null;
  const done = col?.sceneDone ?? false;
  const cs = W * CHECK_FRAC;
  const fs = W * 0.1;
  return (
    <View
      pointerEvents="none"
      onLayout={(e) => onSize(item.id, e.nativeEvent.layout.width, e.nativeEvent.layout.height)}
      style={{
        position: 'absolute',
        left: item.x * sw,
        top: item.y * sw,
        width: W,
        height: H,
        backgroundColor: colors.paper,
        borderRadius: W * 0.05,
        borderWidth: 1,
        borderColor: colors.line,
        overflow: 'hidden',
        transform: [{ translateX: L.dx }, { translateY: L.dy }, { scale: L.s }],
      }}
    >
      <View style={{ flex: 1, backgroundColor: colors.hairline }}>
        {!!cover && <Image source={{ uri: mediaUri(cover) }} resizeMode="cover" style={{ width: '100%', height: '100%' }} />}
      </View>
      <View style={{ paddingHorizontal: W * 0.06, paddingVertical: W * 0.05, paddingRight: cs + W * CHECK_MARGIN * 2, minHeight: cs + W * CHECK_MARGIN * 2 }}>
        <Text numberOfLines={2} style={{ fontFamily: fonts.bold, fontSize: fs, color: colors.onLight }}>
          {col?.name ?? ''}
        </Text>
        <Text style={{ fontFamily: fonts.regular, fontSize: fs * 0.75, color: colors.subtle }}>{done ? 'Gravada' : 'Ideia'}</Text>
      </View>
      <View
        style={{
          position: 'absolute',
          left: W * 0.04,
          top: W * 0.04,
          minWidth: W * 0.18,
          height: W * 0.18,
          paddingHorizontal: W * 0.04,
          borderRadius: W * 0.09,
          backgroundColor: colors.onLight,
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Text style={{ fontFamily: fonts.bold, fontSize: fs * 0.9, color: colors.onDark }}>{number}</Text>
      </View>
      <View
        style={{
          position: 'absolute',
          right: W * CHECK_MARGIN,
          bottom: W * CHECK_MARGIN,
          width: cs,
          height: cs,
          borderRadius: cs / 2,
          borderWidth: 2,
          borderColor: done ? colors.red : colors.line,
          backgroundColor: done ? colors.red : colors.paper,
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        {done && <Icon name="check" size={cs * 0.6} color={colors.onDark} />}
      </View>
    </View>
  );
});
