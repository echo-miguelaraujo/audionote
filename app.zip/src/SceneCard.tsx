import React, { memo, useEffect, useState } from 'react';
import { Image, Text, View } from 'react-native';
import type { MoodCollection, MoodItem } from './db';
import { Icon } from './Icon';
import type { Live } from './ItemView';
import { SCENE_LABELS, SceneInfo } from './SceneFields';
import { mediaUri } from './media';
import { colors, fonts } from './theme';

/** Status da cena, na ordem do fluxo de produção. O índice é o que se guarda (scene_status). */
export const SCENE_STATUS = [
  { label: 'Ideia', color: null },
  { label: 'Roteirizada', color: '#E0A100' },
  { label: 'Gravada', color: null }, // usa colors.red
  { label: 'Editada', color: '#2F6FDE' },
  { label: 'Publicada', color: '#2E9E5B' },
] as const;

/** Tamanho do check, como fração da largura do cartão, e a margem dele até o canto. */
const CHECK_FRAC = 0.26;
const CHECK_MARGIN = 0.04;

/** O ponto (px, py), em unidades do mundo relativas ao canto do cartão, está na área do check? (com folga para o dedo) */
export function sceneCheckHit(px: number, py: number, cardW: number, cardH: number, slop: number): boolean {
  const cs = cardW * CHECK_FRAC;
  const left = cardW - cardW * CHECK_MARGIN - cs;
  const top = cardH - cardW * CHECK_MARGIN - cs;
  return px >= left - slop && px <= cardW + slop && py >= top - slop && py <= cardH + slop;
}

/** Máximo de imagens do carrossel de um cartão de cena. */
const MAX_PAGES = 8;
/** Parte da largura do cartão que a próxima imagem "espia" na borda direita. */
const PEEK = 0.065;
/** Altura mínima do rodapé (título + check), como fração da largura do cartão. */
const FOOTER_MIN = 0.34;

/** Imagens do carrossel: a capa primeiro, depois as outras imagens da cena. */
export function sceneImages(col?: MoodCollection): string[] {
  if (!col) return [];
  const first = col.sceneCover ?? col.covers[0] ?? null;
  const rest = col.covers.filter((c) => c !== first);
  return (first ? [first, ...rest] : rest).slice(0, MAX_PAGES);
}

/** Toque nas bordas da imagem: -1 volta, 1 avança, 0 não é do carrossel. (px, py) relativos ao canto do cartão. */
export function sceneCarouselHit(px: number, py: number, cardW: number, cardH: number): -1 | 0 | 1 {
  const imgH = cardH - cardW * FOOTER_MIN;
  if (px < 0 || px > cardW || py < 0 || py > imgH) return 0;
  if (px < cardW * 0.28) return -1;
  if (px > cardW * 0.72) return 1;
  return 0;
}

/** Cartão de uma cena na visão Cenas: número, imagem principal, título e check de "Gravada". Só desenha; o toque é do quadro. */
export const SceneCard = memo(function SceneCard({
  item,
  col,
  number,
  sw,
  live,
  onSize,
  onLoaded,
  page,
}: {
  item: MoodItem;
  col?: MoodCollection;
  number: number;
  sw: number;
  live: Live | null;
  onSize: (id: number, w: number, h: number) => void;
  /** Avisa quando a capa terminou de carregar (ou falhou). Usado na exportação. */
  onLoaded?: (id: number) => void;
  /** Imagem mostrada no carrossel. Sem isto (exportação), mostra só a capa, sem pontinhos nem contador. */
  page?: number;
}) {
  const L = live ?? { dx: 0, dy: 0, s: 1, r: 0 };
  const W = item.w * sw;
  const H = item.h * sw;
  const [failed, setFailed] = useState<string[]>([]);
  const all = sceneImages(col);
  const imgs = all.filter((u) => !failed.includes(u));
  const carousel = page !== undefined && imgs.length > 1;
  const idx = carousel ? Math.min(Math.max(page ?? 0, 0), imgs.length - 1) : 0;
  const cover = imgs[idx] ?? null;
  const next = carousel && idx < imgs.length - 1 ? imgs[idx + 1] : null;
  useEffect(() => setFailed([]), [col?.sceneCover, col?.covers.length]);
  useEffect(() => {
    if (!cover) onLoaded?.(item.id);
  }, [cover]); // eslint-disable-line react-hooks/exhaustive-deps
  const status = col?.sceneStatus ?? 0;
  const done = status > 0;
  const statusColor = SCENE_STATUS[status]?.color ?? colors.red;
  const cs = W * CHECK_FRAC;
  const fs = W * 0.1;
  return (
    <View
      pointerEvents="none"
      onLayout={(e) => onSize(item.id, e.nativeEvent.layout.width, e.nativeEvent.layout.height)}
      style={{
        position: 'absolute',
        left: item.x * sw,
        top: item.y * sw,
        width: W,
        height: H,
        backgroundColor: colors.paper,
        borderRadius: W * 0.05,
        borderWidth: 1,
        borderColor: colors.line,
        overflow: 'hidden',
        transform: [{ translateX: L.dx }, { translateY: L.dy }, { scale: L.s }],
      }}
    >
      <View style={{ flex: 1, backgroundColor: colors.hairline, overflow: 'hidden' }}>
        {!!cover && (
          <Image
            source={{ uri: mediaUri(cover) }}
            resizeMode="cover"
            style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: next ? W * (1 - PEEK) : W }}
            onLoadEnd={() => onLoaded?.(item.id)}
            onError={() => setFailed((f) => [...f, cover])}
          />
        )}
        {!!next && (
          <Image
            source={{ uri: mediaUri(next) }}
            resizeMode="cover"
            style={{ position: 'absolute', top: 0, bottom: 0, left: W * (1 - PEEK) + W * 0.012, width: W * (1 - PEEK) }}
            onError={() => setFailed((f) => [...f, next])}
          />
        )}
        {carousel && (
          <>
            <View
              style={{
                position: 'absolute',
                right: W * 0.04,
                top: W * 0.04,
                paddingHorizontal: W * 0.035,
                height: W * 0.12,
                borderRadius: W * 0.06,
                backgroundColor: colors.onLight,
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Text style={{ fontFamily: fonts.bold, fontSize: fs * 0.7, color: colors.onDark }}>{`${idx + 1}/${imgs.length}`}</Text>
            </View>
            {imgs.length <= 6 && (
              <View style={{ position: 'absolute', left: 0, right: 0, bottom: W * 0.035, flexDirection: 'row', justifyContent: 'center', gap: W * 0.016 }}>
                {imgs.map((u, i) => (
                  <View
                    key={u}
                    style={{
                      width: W * 0.024,
                      height: W * 0.024,
                      borderRadius: W * 0.012,
                      backgroundColor: i === idx ? '#fff' : 'rgba(255,255,255,0.55)',
                    }}
                  />
                ))}
              </View>
            )}
          </>
        )}
      </View>
      <View style={{ paddingHorizontal: W * 0.06, paddingVertical: W * 0.05, paddingRight: cs + W * CHECK_MARGIN * 2, minHeight: cs + W * CHECK_MARGIN * 2 }}>
        <Text numberOfLines={2} style={{ fontFamily: fonts.bold, fontSize: fs, color: colors.onLight }}>
          {col?.name || `Cena ${number}`}
        </Text>
        <Text style={{ fontFamily: fonts.regular, fontSize: fs * 0.75, color: colors.subtle }}>{SCENE_STATUS[status]?.label ?? 'Ideia'}</Text>
      </View>
      <View
        style={{
          position: 'absolute',
          left: W * 0.04,
          top: W * 0.04,
          minWidth: W * 0.18,
          height: W * 0.18,
          paddingHorizontal: W * 0.04,
          borderRadius: W * 0.09,
          backgroundColor: colors.onLight,
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Text style={{ fontFamily: fonts.bold, fontSize: fs * 0.9, color: colors.onDark }}>{number}</Text>
      </View>
      <View
        style={{
          position: 'absolute',
          right: W * CHECK_MARGIN,
          bottom: W * CHECK_MARGIN,
          width: cs,
          height: cs,
          borderRadius: cs / 2,
          borderWidth: 2,
          borderColor: done ? statusColor : colors.line,
          backgroundColor: done ? statusColor : colors.paper,
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        {done && <Icon name="check" size={cs * 0.6} color={colors.onDark} />}
      </View>
    </View>
  );
});

/** Cartão de detalhes ao lado da cena: largura como fração da largura do cartão da cena, e a distância entre os dois. */
export const DETAIL_W = 1.35;
export const DETAIL_GAP = 0.06;
/** Altura da linha de botões, como fração da largura do cartão de detalhes. */
const DETAIL_BTN = 0.16;

/** Toque dentro do cartão de detalhes (px relativos ao canto dele): em qual botão caiu? */
export function sceneDetailHit(lx: number, ly: number, w: number, h: number): 'open' | 'edit' | 'card' | null {
  if (lx < 0 || ly < 0 || lx > w || ly > h) return null;
  if (ly >= h - w * DETAIL_BTN) return lx < w / 2 ? 'open' : 'edit';
  return 'card';
}

/**
 * Cartão vinculado à cena: resumo dos detalhes e dois botões (abrir a cena, editar os detalhes).
 * Fica no quadro, ao lado do cartão da cena, e anda e dá zoom junto. Só desenha; o toque é do quadro.
 */
export const SceneDetailCard = memo(function SceneDetailCard({
  x,
  y,
  w,
  side,
  status,
  info,
  onLayout,
}: {
  x: number;
  y: number;
  w: number;
  /** De que lado da cena o cartão está (a pontinha de ligação aponta para ela). */
  side: 'left' | 'right';
  status: number;
  info: SceneInfo;
  onLayout: (w: number, h: number) => void;
}) {
  const fs = w * 0.055;
  const rows = SCENE_LABELS.filter((f) => f.key !== 'name' && !!info[f.key]);
  const btnH = w * DETAIL_BTN;
  const statusColor = SCENE_STATUS[status]?.color ?? colors.red;
  const nub = w * 0.05;
  return (
    <View
      pointerEvents="none"
      onLayout={(e) => onLayout(e.nativeEvent.layout.width, e.nativeEvent.layout.height)}
      style={{
        position: 'absolute',
        left: x,
        top: y,
        width: w,
        backgroundColor: colors.paper,
        borderRadius: w * 0.05,
        borderWidth: 1,
        borderColor: colors.line,
        overflow: 'visible',
      }}
    >
      {/* Pontinha que liga o cartão de detalhes à cena. */}
      <View
        style={{
          position: 'absolute',
          top: w * 0.07,
          [side === 'right' ? 'left' : 'right']: -nub / 2 - 1,
          width: nub,
          height: nub,
          borderRadius: nub / 2,
          backgroundColor: colors.onLight,
        }}
      />
      <View style={{ padding: w * 0.06, paddingBottom: btnH + w * 0.04 }}>
        <Text numberOfLines={2} style={{ fontFamily: fonts.bold, fontSize: fs * 1.25, color: colors.onLight }}>
          {info.name}
        </Text>
        <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: w * 0.012, marginBottom: w * 0.03 }}>
          <View style={{ width: fs * 0.6, height: fs * 0.6, borderRadius: fs * 0.3, backgroundColor: status > 0 ? statusColor : colors.line, marginRight: fs * 0.4 }} />
          <Text style={{ fontFamily: fonts.regular, fontSize: fs * 0.9, color: colors.subtle }}>{SCENE_STATUS[status]?.label ?? 'Ideia'}</Text>
        </View>
        {rows.length === 0 ? (
          <Text style={{ fontFamily: fonts.regular, fontSize: fs, color: colors.subtle }}>
            Sem detalhes ainda. Toque em Editar para preencher.
          </Text>
        ) : (
          rows.map((f) => (
            <View key={f.key} style={{ marginBottom: w * 0.025 }}>
              <Text style={{ fontFamily: fonts.regular, fontSize: fs * 0.8, color: colors.subtle }}>{f.label}</Text>
              <Text numberOfLines={f.multiline ? 3 : 1} style={{ fontFamily: fonts.regular, fontSize: fs, color: colors.onLight }}>
                {info[f.key]}
              </Text>
            </View>
          ))
        )}
      </View>
      <View
        style={{
          position: 'absolute',
          left: 0,
          right: 0,
          bottom: 0,
          height: btnH,
          flexDirection: 'row',
          borderTopWidth: 1,
          borderTopColor: colors.line,
        }}
      >
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', borderRightWidth: 1, borderRightColor: colors.line }}>
          <Text style={{ fontFamily: fonts.bold, fontSize: fs, color: colors.onLight }}>Abrir cena</Text>
        </View>
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          <Text style={{ fontFamily: fonts.bold, fontSize: fs, color: colors.red }}>Editar</Text>
        </View>
      </View>
    </View>
  );
});
