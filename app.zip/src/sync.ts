import { AppState } from 'react-native';
import { File } from 'expo-file-system';
import { getDb } from './db';
import { mediaFile, mimeFor } from './media';
import { removeAudioFile } from './storage';
import { currentUser, supabase } from './supabase';
import { supabaseConfigured } from './supabaseConfig';
import { getPerf, perfMark } from './perf';
import { setUrgent, waitForIdle } from './activity';
import { collectMediaRefs, pendingCount, resetForNewAccount, syncOnce } from './syncEngine';

export type SyncState = {
  /** 'off' = Supabase não configurado; 'signed-out' = sem login; */
  phase: 'off' | 'signed-out' | 'idle' | 'syncing' | 'error';
  email: string | null;
  lastSyncAt: number | null;
  error: string | null;
  pending: number;
  /** Resumo da última rodada, para mostrar na tela. */
  lastSummary: string | null;
};

let state: SyncState = {
  phase: supabaseConfigured() ? 'signed-out' : 'off',
  email: null,
  lastSyncAt: null,
  error: null,
  pending: 0,
  lastSummary: null,
};
const listeners = new Set<() => void>();
const set = (p: Partial<SyncState>) => {
  state = { ...state, ...p };
  listeners.forEach((l) => l());
};
export const getSyncState = (): SyncState => state;
export function subscribeSync(fn: () => void): () => void {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

const KEY_USER = 'sync_user';
const MEDIA_BUCKET = 'media';
const MAX_MEDIA_BYTES = 100 * 1024 * 1024; // limite do bucket
const MEDIA_CHECK_EVERY_MS = 10 * 60 * 1000;

let running = false;
let queued = false;
let lastMediaCheck = 0;
let onRemoteChange: (() => void) | null = null;
let timer: ReturnType<typeof setTimeout> | null = null;

const friendly = (e: unknown): string => {
  const m = e instanceof Error ? e.message : String(e);
  if (/network request failed|failed to fetch|timeout|offline/i.test(m)) return 'Sem conexão. Tento de novo em instantes.';
  return m;
};

// ---------------------------------------------------------------- imagens/anexos (bucket "media")

/** Envia o que só existe aqui e baixa o que só existe na nuvem. Caminho no bucket: <user_id>/<nome-do-arquivo>. */
async function syncMedia(userId: string): Promise<string> {
  const db = await getDb();
  await waitForIdle();
  const names = await collectMediaRefs(db);
  if (names.size === 0) return '';

  const remote = new Set<string>();
  for (let offset = 0; ; offset += 1000) {
    const { data, error } = await supabase.storage.from(MEDIA_BUCKET).list(userId, { limit: 1000, offset });
    if (error) throw new Error(`imagens: ${error.message}`);
    (data ?? []).forEach((o) => remote.add(o.name));
    if (!data || data.length < 1000) break;
  }

  let up = 0;
  let down = 0;
  const failed: string[] = [];
  for (const name of names) {
    await waitForIdle(800); // não compete com o quadro: um arquivo por vez, só com a tela parada
    const path = `${userId}/${name}`;
    try {
      const f = mediaFile(name);
      if (f.exists && !remote.has(name)) {
        if ((f.size ?? 0) > MAX_MEDIA_BYTES) {
          failed.push(`${name} (maior que 100 MB)`);
          continue;
        }
        const bytes = await f.bytes();
        const body = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) as ArrayBuffer;
        const mime = mimeFor(name);
        const { error } = await supabase.storage
          .from(MEDIA_BUCKET)
          .upload(path, body, { contentType: mime === '*/*' ? 'application/octet-stream' : mime, upsert: false });
        if (error && !/already exists|duplicate/i.test(error.message)) throw new Error(error.message);
        up++;
      } else if (!f.exists && remote.has(name)) {
        const { data, error } = await supabase.storage.from(MEDIA_BUCKET).createSignedUrl(path, 300);
        if (error || !data?.signedUrl) throw new Error(error?.message ?? 'sem link');
        await File.downloadFileAsync(data.signedUrl, f);
        down++;
      }
    } catch (e) {
      failed.push(`${name}: ${friendly(e)}`);
    }
  }
  lastMediaCheck = Date.now();
  let out = '';
  if (up || down) out = `Imagens: ${up} enviada(s), ${down} baixada(s).`;
  if (failed.length) out += `${out ? ' ' : ''}Falharam ${failed.length}: ${failed.slice(0, 2).join('; ')}${failed.length > 2 ? '…' : ''}`;
  return out;
}

// ---------------------------------------------------------------- rodada de sincronização

async function runOnce(forceMedia: boolean): Promise<void> {
  if (!supabaseConfigured()) {
    set({ phase: 'off' });
    return;
  }
  const user = await currentUser();
  if (!user) {
    set({ phase: 'signed-out', email: null, pending: 0 });
    return;
  }
  await waitForIdle(); // começa só com a tela parada
  const db = await getDb();
  set({ phase: 'syncing', email: user.email, error: null });

  // Outra conta Google neste aparelho: manda tudo para a conta nova (os cursores da antiga não valem).
  const prev = await db.getFirstAsync<{ value: string }>(`SELECT value FROM meta WHERE key = ?`, KEY_USER);
  if (prev && prev.value !== user.id) await resetForNewAccount(db);
  if (!prev || prev.value !== user.id) {
    await db.runAsync(`INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)`, KEY_USER, user.id);
  }

  const stats = await syncOnce({ db, client: supabase, removeAudioFile });

  let mediaMsg = '';
  const changed = stats.applied + stats.deleted + stats.pushed + stats.pushedDeletes > 0;
  if (forceMedia || changed || Date.now() - lastMediaCheck > MEDIA_CHECK_EVERY_MS) mediaMsg = await syncMedia(user.id);

  const parts: string[] = [];
  if (stats.pushed + stats.pushedDeletes > 0) parts.push(`${stats.pushed + stats.pushedDeletes} enviado(s)`);
  if (stats.applied + stats.deleted > 0) parts.push(`${stats.applied + stats.deleted} recebido(s)`);
  if (mediaMsg) parts.push(mediaMsg);
  set({
    phase: 'idle',
    lastSyncAt: Date.now(),
    pending: await pendingCount(db),
    lastSummary: parts.length ? parts.join(' · ') : 'Tudo em dia.',
  });
  if (stats.applied + stats.deleted > 0) onRemoteChange?.();
}

/** Pede uma sincronização. Se já houver uma rodando, faz outra logo depois (uma só, não importa quantos pedidos). */
/** Depois de uma falha, o relógio e as edições não tentam de novo na hora (cada tentativa baixa e processa muita coisa). */
let failStreak = 0;
let retryNotBefore = 0;

export async function requestSync(opts: { media?: boolean; now?: boolean } = {}): Promise<void> {
  if (!getPerf().sync || !getPerf().bg) return; // teste de desempenho: sincronização pausada
  if (!opts.media && Date.now() < retryNotBefore) return; // em espera após erro (login e "sincronizar agora" ignoram)
  perfMark('sincronização');
  if (running) {
    queued = true;
    return;
  }
  running = true;
  if (opts.now) setUrgent(true);
  try {
    do {
      queued = false;
      try {
        await runOnce(!!opts.media);
        failStreak = 0;
        retryNotBefore = 0;
      } catch (e) {
        failStreak = Math.min(failStreak + 1, 6);
        retryNotBefore = Date.now() + Math.min(10 * 60_000, 30_000 * 2 ** (failStreak - 1));
        set({ phase: 'error', error: friendly(e), pending: await getDb().then(pendingCount).catch(() => state.pending) });
      }
    } while (queued);
  } finally {
    running = false;
    setUrgent(false);
  }
}

/** Depois que o usuário muda algo: espera alguns segundos (juntando várias edições) e sincroniza, se houver pendências. */
export function scheduleSyncIfPending(delayMs = 5000): void {
  if (state.phase === 'off' || state.phase === 'signed-out') return;
  if (timer) clearTimeout(timer);
  timer = setTimeout(async () => {
    timer = null;
    try {
      const db = await getDb();
      const n = await pendingCount(db);
      set({ pending: n });
      if (n > 0) requestSync();
    } catch {
      /* tenta na próxima */
    }
  }, delayMs);
}

/** Liga tudo: sessão, login/logout, volta ao app e relógio de 60 s. Retorna a função que desliga. */
export function initSync(onRemote: () => void): () => void {
  onRemoteChange = onRemote;
  if (!supabaseConfigured()) {
    set({ phase: 'off' });
    return () => {};
  }
  currentUser()
    .then((u) => {
      set({ email: u?.email ?? null, phase: u ? 'idle' : 'signed-out' });
      if (u) requestSync({ media: true });
    })
    .catch(() => {});

  // Não chamar o supabase direto dentro do callback (pode travar); por isso o setTimeout.
  const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
    setTimeout(() => {
      if (event === 'SIGNED_OUT') set({ phase: 'signed-out', email: null, pending: 0, lastSummary: null, error: null });
      else if (event === 'SIGNED_IN' && session) {
        set({ email: session.user.email ?? null, phase: 'idle' });
        requestSync({ media: true });
      }
    }, 0);
  });

  const appSub = AppState.addEventListener('change', (st) => {
    if (st === 'active') requestSync();
  });
  const interval = setInterval(() => {
    if (AppState.currentState === 'active') requestSync();
  }, 60000);

  return () => {
    onRemoteChange = null;
    sub.subscription.unsubscribe();
    appSub.remove();
    clearInterval(interval);
    if (timer) clearTimeout(timer);
  };
}
