import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, Modal, Pressable, ScrollView, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { AnalyzeResult, Proposal, applyProposals, proposeForNotes } from './restructure';
import { colors, fonts } from './theme';

type Props = {
  visible: boolean;
  /** Uma nota, várias ou todas. */
  blockIds: number[] | 'all';
  onClose: () => void;
};

type Phase = 'loading' | 'review' | 'applying' | 'done';

/**
 * Mostra o que a IA sugere mudar nas notas (citações, listas, subtítulos).
 * Nada é alterado até o usuário permitir; só o que está marcado é aplicado.
 */
export function RestructureDialog({ visible, blockIds, onClose }: Props) {
  const { width: sw } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const [phase, setPhase] = useState<Phase>('loading');
  const [progress, setProgress] = useState({ done: 0, total: 0 });
  const [result, setResult] = useState<AnalyzeResult | null>(null);
  const [allowed, setAllowed] = useState<Set<string>>(new Set());
  const [summary, setSummary] = useState('');
  const runId = useRef(0);

  useEffect(() => {
    if (!visible) return;
    const id = ++runId.current;
    setPhase('loading');
    setResult(null);
    setAllowed(new Set());
    setProgress({ done: 0, total: 0 });
    proposeForNotes(blockIds, (done, total) => {
      if (runId.current === id) setProgress({ done, total });
    })
      .then((r) => {
        if (runId.current !== id) return;
        setResult(r);
        setPhase('review');
      })
      .catch((e) => {
        if (runId.current !== id) return;
        setResult({ proposals: [], analyzed: 0, failed: String(e) });
        setPhase('review');
      });
    return () => {
      runId.current++;
    };
  }, [visible, blockIds]);

  const groups = useMemo(() => {
    const m = new Map<number, { title: string; items: Proposal[] }>();
    for (const p of result?.proposals ?? []) {
      const g = m.get(p.blockId) ?? { title: p.noteTitle, items: [] };
      g.items.push(p);
      m.set(p.blockId, g);
    }
    return [...m.entries()];
  }, [result]);

  const total = result?.proposals.length ?? 0;
  const toggle = (id: string) =>
    setAllowed((prev) => {
      const n = new Set(prev);
      if (n.has(id)) n.delete(id);
      else n.add(id);
      return n;
    });
  const toggleGroup = (items: Proposal[]) =>
    setAllowed((prev) => {
      const n = new Set(prev);
      const all = items.every((p) => n.has(p.id));
      items.forEach((p) => (all ? n.delete(p.id) : n.add(p.id)));
      return n;
    });
  const allOn = total > 0 && allowed.size === total;

  const apply = async () => {
    const chosen = (result?.proposals ?? []).filter((p) => allowed.has(p.id));
    if (chosen.length === 0) return;
    setPhase('applying');
    try {
      const r = await applyProposals(chosen);
      setSummary(
        `${r.applied} ${r.applied === 1 ? 'mudança aplicada' : 'mudanças aplicadas'}.` +
          (r.skipped > 0 ? ` ${r.skipped} não ${r.skipped === 1 ? 'foi aplicada' : 'foram aplicadas'} porque o texto mudou.` : '')
      );
    } catch (e) {
      setSummary(`Não consegui aplicar: ${String(e).slice(0, 120)}`);
    }
    setPhase('done');
  };

  const f = sw * 0.04;
  const txt = (extra: object = {}) => ({ color: colors.text, fontFamily: fonts.regular, fontSize: f, ...extra });

  return (
    <Modal visible={visible} animationType="slide" statusBarTranslucent onRequestClose={onClose}>
      <View style={[styles.root, { paddingTop: insets.top + sw * 0.03 }]}>
        <View style={[styles.header, { paddingHorizontal: sw * 0.06 }]}>
          <Pressable onPress={onClose} hitSlop={14}>
            <Text style={txt({ fontFamily: fonts.bold, fontSize: sw * 0.047 })}>← Voltar</Text>
          </Pressable>
          {phase === 'review' && total > 0 && (
            <Pressable onPress={() => setAllowed(allOn ? new Set() : new Set(result!.proposals.map((p) => p.id)))} hitSlop={14}>
              <Text style={txt({ fontFamily: fonts.bold, color: colors.red, fontSize: sw * 0.042 })}>
                {allOn ? 'Tirar todas' : 'Permitir todas'}
              </Text>
            </Pressable>
          )}
        </View>

        {phase === 'loading' && (
          <View style={styles.center}>
            <ActivityIndicator color="#FFFFFF" size="large" />
            <Text style={txt({ marginTop: sw * 0.04, fontSize: sw * 0.045 })}>
              Analisando{progress.total > 1 ? ` (${Math.min(progress.done + 1, progress.total)} de ${progress.total})` : ''}…
            </Text>
          </View>
        )}

        {phase === 'applying' && (
          <View style={styles.center}>
            <ActivityIndicator color="#FFFFFF" size="large" />
            <Text style={txt({ marginTop: sw * 0.04, fontSize: sw * 0.045 })}>Aplicando…</Text>
          </View>
        )}

        {phase === 'done' && (
          <View style={styles.center}>
            <Text style={txt({ fontSize: sw * 0.05, textAlign: 'center', paddingHorizontal: sw * 0.08 })}>{summary}</Text>
            <Pressable onPress={onClose} style={[styles.btn, { marginTop: sw * 0.07 }]}>
              <Text style={txt({ fontFamily: fonts.bold, color: '#000000' })}>Fechar</Text>
            </Pressable>
          </View>
        )}

        {phase === 'review' && result && (
          <>
            <ScrollView contentContainerStyle={{ paddingHorizontal: sw * 0.06, paddingBottom: sw * 0.06 }}>
              {result.failed && (
                <Text style={txt({ color: colors.red, marginTop: sw * 0.04, lineHeight: f * 1.4 })}>{result.failed}</Text>
              )}
              {total === 0 && !result.failed && (
                <Text style={txt({ color: colors.gray, marginTop: sw * 0.06, lineHeight: f * 1.4 })}>
                  Não encontrei nada para melhorar{result.analyzed > 1 ? ` em ${result.analyzed} notas` : ' nessa nota'}.
                </Text>
              )}
              {total > 0 && (
                <Text style={txt({ color: colors.gray, marginTop: sw * 0.03, lineHeight: f * 1.4 })}>
                  {total} {total === 1 ? 'sugestão' : 'sugestões'}. Marque o que você permite; só isso será aplicado.
                  O texto não é reescrito.
                </Text>
              )}
              {groups.map(([blockId, g]) => (
                <View key={blockId} style={{ marginTop: sw * 0.06 }}>
                  <Pressable onPress={() => toggleGroup(g.items)} style={styles.groupHead}>
                    <Text numberOfLines={1} style={txt({ fontFamily: fonts.bold, fontSize: sw * 0.048, flex: 1 })}>
                      {g.title}
                    </Text>
                    <Text style={txt({ color: colors.gray, fontSize: sw * 0.036 })}>
                      {g.items.every((p) => allowed.has(p.id)) ? 'tirar' : 'permitir'} todas
                    </Text>
                  </Pressable>
                  {g.items.map((p) => {
                    const on = allowed.has(p.id);
                    return (
                      <Pressable
                        key={p.id}
                        onPress={() => toggle(p.id)}
                        style={[styles.row, { borderColor: on ? colors.red : '#2A2A2A' }]}
                      >
                        <View style={[styles.box, { borderColor: on ? colors.red : '#FFFFFF', backgroundColor: on ? colors.red : 'transparent' }]}>
                          {on && <Text style={{ color: '#FFFFFF', fontFamily: fonts.bold, fontSize: sw * 0.035 }}>✓</Text>}
                        </View>
                        <View style={{ flex: 1 }}>
                          <Text style={txt({ fontFamily: fonts.bold, fontSize: sw * 0.04 })}>{p.label}</Text>
                          <Text
                            style={txt({
                              color: '#BDBDBD',
                              fontSize: sw * 0.036,
                              lineHeight: sw * 0.052,
                              marginTop: sw * 0.012,
                              fontFamily: p.kind === 'quote' ? fonts.italic : fonts.regular,
                            })}
                          >
                            {p.kind === 'heading' ? `antes de: ${p.preview}` : p.preview}
                          </Text>
                        </View>
                      </Pressable>
                    );
                  })}
                </View>
              ))}
            </ScrollView>
            {total > 0 && (
              <View style={{ paddingHorizontal: sw * 0.06, paddingBottom: insets.bottom + sw * 0.04, paddingTop: sw * 0.03 }}>
                <Pressable
                  onPress={() => apply().catch(() => {})}
                  disabled={allowed.size === 0}
                  style={[styles.btn, { opacity: allowed.size === 0 ? 0.35 : 1 }]}
                >
                  <Text style={txt({ fontFamily: fonts.bold, color: '#000000', fontSize: sw * 0.045 })}>
                    {allowed.size === 0 ? 'Aplicar' : `Aplicar ${allowed.size} ${allowed.size === 1 ? 'permitida' : 'permitidas'}`}
                  </Text>
                </Pressable>
              </View>
            )}
          </>
        )}
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingBottom: 8 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  groupHead: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingBottom: 8 },
  row: { flexDirection: 'row', gap: 14, borderWidth: 1.5, borderRadius: 14, padding: 14, marginTop: 10 },
  box: { width: 24, height: 24, borderWidth: 2, borderRadius: 6, alignItems: 'center', justifyContent: 'center', marginTop: 1 },
  btn: { backgroundColor: '#FFFFFF', borderRadius: 14, paddingVertical: 15, paddingHorizontal: 28, alignItems: 'center' },
});
