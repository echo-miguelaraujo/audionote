/**
 * Atividade do usuário na tela. O trabalho de fundo (sincronização) roda no mesmo thread JS que desenha o quadro;
 * por isso ele espera o usuário parar de tocar na tela e cede a vez entre um passo e outro.
 */
let lastTouch = 0;

/** Chamado a cada toque na tela (barato: só guarda a hora). */
export const markTouch = (): void => {
  lastTouch = Date.now();
};

/** Devolve o turno ao JS por um instante, para a tela processar toques e desenhar. */
export const yieldNow = (): Promise<void> => new Promise((r) => setTimeout(r, 0));

/** Espera ficar `quietMs` sem nenhum toque. Sem toques, volta quase na hora. */
export async function waitForIdle(quietMs = 1500): Promise<void> {
  for (;;) {
    const gap = Date.now() - lastTouch;
    if (gap >= quietMs) break;
    await new Promise((r) => setTimeout(r, quietMs - gap + 50));
  }
  await yieldNow();
}
