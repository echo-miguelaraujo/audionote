/**
 * Atividade do usuário na tela. O trabalho de fundo (sincronização) roda no mesmo thread JS que desenha o quadro;
 * por isso ele espera o usuário parar de tocar na tela e cede a vez entre um passo e outro.
 */
let lastTouch = 0;
let boardOpen = false;
let urgent = false;

/** "Sincronizar agora": o usuário pediu, então não espera tela parada nem quadro fechar. */
export const setUrgent = (v: boolean): void => {
  urgent = v;
};

/** Um quadro do moodboard está aberto na tela: o trabalho de fundo espera até ele fechar. */
export const setBoardOpen = (v: boolean): void => {
  boardOpen = v;
};

/** Chamado a cada toque na tela (barato: só guarda a hora). */
export const markTouch = (): void => {
  lastTouch = Date.now();
};

/** Devolve o turno ao JS por um instante, para a tela processar toques e desenhar. */
export const yieldNow = (): Promise<void> => new Promise((r) => setTimeout(r, 0));

/** Espera ficar `quietMs` sem nenhum toque. Sem toques, volta quase na hora. */
export async function waitForIdle(quietMs = 1500): Promise<void> {
  for (;;) {
    if (urgent) break;
    if (boardOpen) {
      await new Promise((r) => setTimeout(r, 1000));
      continue;
    }
    const gap = Date.now() - lastTouch;
    if (gap >= quietMs) break;
    await new Promise((r) => setTimeout(r, quietMs - gap + 50));
  }
  await yieldNow();
}
