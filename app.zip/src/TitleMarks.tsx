import React from 'react';
import { View } from 'react-native';
import { Icon } from './Icon';
import { colors } from './theme';

/** Marcas antes do título de uma nota: fixada (alfinete) e favorita (estrela). Nada se não houver. */
export function TitleMarks({ pinned, favorite, size, color = colors.red }: { pinned?: boolean; favorite?: boolean; size: number; color?: string }) {
  if (!pinned && !favorite) return null;
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: size * 0.2, marginRight: size * 0.3 }}>
      {pinned ? <Icon name="pin" size={size} color={color} /> : null}
      {favorite ? <Icon name="star" size={size} color={color} /> : null}
    </View>
  );
}
