/**
 * Fonte única das cores do app. Troque o valor aqui e o app inteiro acompanha.
 * Nomes por função, não por aparência: `onLight` é o texto sobre superfície clara, `onDark` sobre escura.
 */
export const colors = {
  // Fundos
  bg: '#000000', // fundo das telas
  surface: '#1C1C1E', // painéis e toasts sobre o fundo preto
  paper: '#FFFFFF', // superfícies claras: diálogos, quadros, editor
  circle: '#EDF2F5', // botões redondos do gravador

  // Texto e ícones
  text: '#FFFFFF', // texto sobre o fundo escuro (igual a onDark)
  onDark: '#FFFFFF',
  onLight: '#000000',
  muted: '#808080', // legendas e dicas, SÓ sobre escuro (5,3:1 no preto; sobre branco dá 3,95:1: use `subtle`)
  mutedLight: '#B0B0B0', // texto secundário sobre escuro (sobre branco dá 2,2:1: não use)
  subtle: '#666666', // texto secundário, "Cancelar" e placeholders sobre superfície clara (5,7:1 no branco)

  // Linhas e contornos
  line: '#C8C8C8', // contorno em superfície clara
  lineDark: '#2A2A2A', // divisória em superfície escura
  hairline: '#E6E6E6', // divisórias finas e placeholders em superfície clara

  // Destaque
  red: '#FF3030',

  // Véus atrás de janelas
  scrim: 'rgba(0,0,0,0.78)',
  scrimSoft: 'rgba(0,0,0,0.6)',
  scrimStrong: 'rgba(0,0,0,0.88)', // toasts e avisos sobre qualquer fundo

  // Botões redondos translúcidos sobre o quadro
  glass: 'rgba(255,255,255,0.92)',
  glassLine: 'rgba(0,0,0,0.15)',

  // Contornos e véus translúcidos (nomes por função)
  edgeOnDark: 'rgba(255,255,255,0.18)', // contorno de miniaturas sobre fundo escuro
  ringOnDark: 'rgba(255,255,255,0.5)', // anel das amostras de cor
  edgeOnLight: 'rgba(0,0,0,0.25)', // contorno de colagens sobre superfície clara
  inkSoft: 'rgba(0,0,0,0.55)', // marcas discretas (pontilhado) sobre o quadro claro
  circleRing: '#DDE3EE', // anel do botão redondo do gravador
  overlayButton: 'rgba(0,0,0,0.35)', // botões de canto da apresentação
  overlayButtonStrong: 'rgba(0,0,0,0.55)', // botões de navegação da apresentação
  overlayCaption: 'rgba(0,0,0,0.72)', // faixa da legenda na apresentação
} as const;

/** Cores das listras de uma amostra de paleta quando o conteúdo é inválido. */
export const swatchFallback = ['#BDBDBD', '#D6D6D6', '#EBEBEB'] as const;

export const fonts = {
  light: 'Inter_300Light',
  regular: 'Inter_400Regular',
  bold: 'Inter_700Bold',
  black: 'Inter_800ExtraBold',
  italic: 'Inter_400Regular_Italic',
  boldItalic: 'Inter_700Bold_Italic',
};

/** Cores disponíveis para as categorias (as 4 primeiras são as das imagens de referência). */
export const categoryColors = [
  '#FF3030',
  '#0055FF',
  '#CFF1FB',
  '#C3FF6B',
  '#FFB020',
  '#B24DFF',
  '#FF4FA3',
  '#3D4A50',
];

/**
 * Escala de tipografia, como fração da largura da tela (`sw * TYPE.body`).
 * Poucos níveis de propósito: se um tamanho novo parece necessário, use o nível mais próximo.
 */
export const TYPE = {
  caption: 0.034, // legendas, contadores, dicas
  label: 0.04, // rótulos, botões compactos
  body: 0.045, // texto corrido, botões principais
  subtitle: 0.05, // campos e ações de diálogo
  title: 0.06, // títulos de diálogo
  heading: 0.075, // título de tela dentro de uma coleção
  display: 0.11, // título grande de tela (Fila, Configurações)
} as const;

/** Passo de espaçamento, também como fração da largura (`sw * SPACE.md`). */
export const SPACE = {
  xs: 0.01,
  sm: 0.02,
  md: 0.04,
  lg: 0.06,
  xl: 0.08,
} as const;

/** Raios de borda, como fração da largura. */
export const RADIUS = {
  dialog: 0.074, // diálogos e janelas de baixo
  sheet: 0.088, // janelas que sobem de baixo
  pill: 0.07, // botões em pílula
} as const;

/**
 * Área extra de toque (`hitSlop`), em dp. Três níveis em vez de um número por arquivo:
 * `sm` para controles já grandes ou vizinhos, `md` para texto solto, `lg` para ícones pequenos isolados.
 */
export const HIT = { sm: 10, md: 16, lg: 20 } as const;

/** Menor alto de toque confortável (dp, não fração da largura: o dedo não muda com a tela). */
export const MIN_TOUCH = 48;

/** Espaçamento entre letras usado nos títulos (negativo, proporcional ao tamanho). */
export const tracking = (size: number, k = 0.04) => -size * k;

/** Altura de linha de texto corrido, como múltiplo do tamanho da fonte. */
export const LEADING = 1.4;

/** Mesma cor `#RRGGBB` com transparência `a` (0 a 1), para valores que variam em tempo de execução. */
export const alpha = (hex: string, a: number) =>
  `rgba(${parseInt(hex.slice(1, 3), 16)},${parseInt(hex.slice(3, 5), 16)},${parseInt(hex.slice(5, 7), 16)},${a})`;
