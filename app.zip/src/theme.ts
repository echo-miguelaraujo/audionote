export const colors = {
  bg: '#000000',
  text: '#FFFFFF',
  red: '#FF3030',
  gray: '#808080',
  circle: '#EDF2F5',
};

export const fonts = {
  light: 'Inter_300Light',
  regular: 'Inter_400Regular',
  bold: 'Inter_700Bold',
  black: 'Inter_800ExtraBold',
  italic: 'Inter_400Regular_Italic',
  boldItalic: 'Inter_700Bold_Italic',
};

/** Cores disponíveis para as categorias (as 4 primeiras são as das imagens de referência). */
export const categoryColors = [
  '#FF3030',
  '#0055FF',
  '#CFF1FB',
  '#C3FF6B',
  '#FFB020',
  '#B24DFF',
  '#FF4FA3',
  '#3D4A50',
];
