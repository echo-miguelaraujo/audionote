/**
 * Fonte única das cores do app. Troque o valor aqui e o app inteiro acompanha.
 * Nomes por função, não por aparência: `onLight` é o texto sobre superfície clara, `onDark` sobre escura.
 */
export const colors = {
  // Fundos
  bg: '#000000', // fundo das telas
  surface: '#1C1C1E', // painéis e toasts sobre o fundo preto
  paper: '#FFFFFF', // superfícies claras: diálogos, quadros, editor
  circle: '#EDF2F5', // botões redondos do gravador

  // Texto e ícones
  text: '#FFFFFF', // texto sobre o fundo escuro (igual a onDark)
  onDark: '#FFFFFF',
  onLight: '#000000',
  muted: '#808080', // legendas, "Cancelar", placeholders
  mutedLight: '#B0B0B0', // texto secundário sobre escuro / placeholder em campo claro
  subtle: '#666666', // texto secundário sobre superfície clara

  // Linhas e contornos
  line: '#C8C8C8', // contorno em superfície clara
  lineDark: '#2A2A2A', // divisória em superfície escura
  hairline: '#E6E6E6', // divisórias finas e placeholders em superfície clara

  // Destaque
  red: '#FF3030',

  // Véus atrás de janelas
  scrim: 'rgba(0,0,0,0.78)',
  scrimSoft: 'rgba(0,0,0,0.6)',
  scrimStrong: 'rgba(0,0,0,0.88)', // toasts e avisos sobre qualquer fundo

  // Botões redondos translúcidos sobre o quadro
  glass: 'rgba(255,255,255,0.92)',
  glassLine: 'rgba(0,0,0,0.15)',
} as const;

export const fonts = {
  light: 'Inter_300Light',
  regular: 'Inter_400Regular',
  bold: 'Inter_700Bold',
  black: 'Inter_800ExtraBold',
  italic: 'Inter_400Regular_Italic',
  boldItalic: 'Inter_700Bold_Italic',
};

/** Cores disponíveis para as categorias (as 4 primeiras são as das imagens de referência). */
export const categoryColors = [
  '#FF3030',
  '#0055FF',
  '#CFF1FB',
  '#C3FF6B',
  '#FFB020',
  '#B24DFF',
  '#FF4FA3',
  '#3D4A50',
];

/**
 * Escala de tipografia, como fração da largura da tela (`sw * TYPE.body`).
 * Poucos níveis de propósito: se um tamanho novo parece necessário, use o nível mais próximo.
 */
export const TYPE = {
  caption: 0.034, // legendas, contadores, dicas
  label: 0.04, // rótulos, botões compactos
  body: 0.045, // texto corrido, botões principais
  subtitle: 0.05, // campos e ações de diálogo
  title: 0.06, // títulos de diálogo
  heading: 0.075, // título de tela dentro de uma coleção
  display: 0.11, // título grande de tela (Fila, Configurações)
} as const;

/** Passo de espaçamento, também como fração da largura (`sw * SPACE.md`). */
export const SPACE = {
  xs: 0.01,
  sm: 0.02,
  md: 0.04,
  lg: 0.06,
  xl: 0.08,
} as const;

/** Raios de borda, como fração da largura. */
export const RADIUS = {
  dialog: 0.074, // diálogos e janelas de baixo
  sheet: 0.088, // janelas que sobem de baixo
  pill: 0.07, // botões em pílula
} as const;

/** Espaçamento entre letras usado nos títulos (negativo, proporcional ao tamanho). */
export const tracking = (size: number, k = 0.04) => -size * k;
