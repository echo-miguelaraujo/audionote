export const colors = {
  bg: '#000000',
  text: '#FFFFFF',
  red: '#FF3030',
  gray: '#808080',
  circle: '#EDF2F5',
};

export const fonts = {
  light: 'Inter_300Light',
  regular: 'Inter_400Regular',
  bold: 'Inter_700Bold',
  black: 'Inter_800ExtraBold',
  italic: 'Inter_400Regular_Italic',
  boldItalic: 'Inter_700Bold_Italic',
};
