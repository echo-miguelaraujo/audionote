import { PermissionsAndroid, Platform } from 'react-native';
import { IdeiasWidget } from '../modules/ideias-widget';
import { addAudio, createBlock, getBlock, listBlocks } from './db';
import { audioFileExists, removeAudioFile } from './storage';

/** Quantas notas recentes o widget mostra. */
const WIDGET_NOTES = 3;

/** Envia ao widget as notas mais recentes (título = assunto da nota). */
export async function syncWidgetNotes(): Promise<void> {
  if (!IdeiasWidget) return;
  try {
    const blocks = await listBlocks();
    const notes = blocks
      .slice(0, WIDGET_NOTES)
      .map((b) => ({ id: b.id, title: b.noteTitle || (b.pendingCount > 0 ? 'Transcrevendo…' : b.name) }));
    IdeiasWidget.setNotes(JSON.stringify(notes));
  } catch {
    // o widget só fica com a lista antiga
  }
}

type PendingRecording = { file: string; blockId: number; durationMs: number };

/**
 * Importa as gravações feitas pelo widget (sem abrir o app): cada uma vira um áudio pendente
 * na nota escolhida, ou numa nota nova ("Gravar Novo"). Retorna quantas foram importadas.
 */
export async function importWidgetRecordings(): Promise<number> {
  if (!IdeiasWidget) return 0;
  let list: PendingRecording[] = [];
  try {
    const parsed = JSON.parse(IdeiasWidget.consumePending());
    if (Array.isArray(parsed)) list = parsed;
  } catch {
    return 0;
  }
  let imported = 0;
  for (const rec of list) {
    try {
      if (!rec.file || !audioFileExists(rec.file)) continue;
      let blockId: number;
      if (rec.blockId > 0 && (await getBlock(rec.blockId))) blockId = rec.blockId;
      else blockId = await createBlock();
      await addAudio(blockId, rec.file, rec.durationMs);
      imported++;
    } catch {
      // mantém o arquivo no disco; não apaga gravação por causa de um erro
    }
  }
  return imported;
}

/** Android 13+: sem essa permissão a notificação "Gravando…" não aparece na barra. */
export async function askNotificationPermission(): Promise<void> {
  if (Platform.OS !== 'android' || Platform.Version < 33) return;
  try {
    await PermissionsAndroid.request('android.permission.POST_NOTIFICATIONS' as any);
  } catch {
    // segue sem notificação visível
  }
}
