import { PermissionsAndroid, Platform } from 'react-native';
import { IdeiasWidget } from '../modules/ideias-widget';
import { addDays, dayKey, loadEntries, pad2, startOfDay, timeLabel, WEEKDAYS_SHORT } from './agenda';
import { addAudio, createBlock, getBlock, listBlocks, listCategories } from './db';
import { audioFileExists, removeAudioFile } from './storage';

/** Quantas notas recentes o widget mostra. */
const WIDGET_NOTES = 3;

/** Envia ao widget as notas mais recentes (título = assunto da nota). */
export async function syncWidgetNotes(): Promise<void> {
  if (!IdeiasWidget) return;
  try {
    const blocks = await listBlocks();
    const notes = blocks
      .slice(0, WIDGET_NOTES)
      .map((b) => ({ id: b.id, title: b.noteTitle || (b.pendingCount > 0 ? 'Transcrevendo…' : b.name) }));
    IdeiasWidget.setNotes(JSON.stringify(notes));
  } catch {
    // o widget só fica com a lista antiga
  }
}

/** Envia ao widget os próximos compromissos (página Agenda) e os dias marcados (página Calendário). */
export async function syncWidgetAgenda(): Promise<void> {
  if (!IdeiasWidget?.setAgenda) return;
  try {
    const now = new Date();
    const today = startOfDay(now);
    const todayKey = dayKey(today);
    const tomorrowKey = dayKey(addDays(today, 1));
    const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
    const map = await loadEntries(monthStart, addDays(today, 60), await listCategories());
    const keys = Array.from(map.keys()).sort();

    const upcoming: { day: string; title: string; when: string }[] = [];
    for (const k of keys) {
      if (k < todayKey) continue;
      const [y, m, d] = k.split('-').map(Number);
      const label =
        k === todayKey ? 'hoje' : k === tomorrowKey ? 'amanhã' : `${WEEKDAYS_SHORT[new Date(y, m - 1, d).getDay()]}, ${pad2(d)}/${pad2(m)}`;
      for (const e of map.get(k) ?? []) {
        // Hoje, esconde o que já passou há mais de meia hora.
        if (k === todayKey && !e.allDay && e.startMs < now.getTime() - 30 * 60 * 1000) continue;
        upcoming.push({ day: pad2(d), title: e.title, when: e.allDay ? label : `${label} · ${timeLabel(e.startMs)}` });
        if (upcoming.length >= 3) break;
      }
      if (upcoming.length >= 3) break;
    }
    IdeiasWidget.setAgenda(JSON.stringify({ upcoming, marks: keys }));
  } catch {
    // o widget só fica com os dados antigos
  }
}

type PendingRecording = { file: string; blockId: number; durationMs: number };

/**
 * Importa as gravações feitas pelo widget (sem abrir o app): cada uma vira um áudio pendente
 * na nota escolhida, ou numa nota nova ("Gravar Novo"). Retorna quantas foram importadas.
 */
export async function importWidgetRecordings(): Promise<number> {
  if (!IdeiasWidget) return 0;
  let list: PendingRecording[] = [];
  try {
    const parsed = JSON.parse(IdeiasWidget.consumePending());
    if (Array.isArray(parsed)) list = parsed;
  } catch {
    return 0;
  }
  let imported = 0;
  for (const rec of list) {
    try {
      if (!rec.file || !audioFileExists(rec.file)) continue;
      let blockId: number;
      if (rec.blockId > 0 && (await getBlock(rec.blockId))) blockId = rec.blockId;
      else blockId = await createBlock();
      await addAudio(blockId, rec.file, rec.durationMs);
      imported++;
    } catch {
      // mantém o arquivo no disco; não apaga gravação por causa de um erro
    }
  }
  return imported;
}

/** Android 13+: sem essa permissão a notificação "Gravando…" não aparece na barra. */
export async function askNotificationPermission(): Promise<void> {
  if (Platform.OS !== 'android' || Platform.Version < 33) return;
  try {
    await PermissionsAndroid.request('android.permission.POST_NOTIFICATIONS' as any);
  } catch {
    // segue sem notificação visível
  }
}
