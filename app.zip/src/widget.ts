import { PermissionsAndroid, Platform } from 'react-native';
import { getPerf, perfMark } from './perf';
import { waitForIdle } from './activity';
import { IdeiasWidget } from '../modules/ideias-widget';
import { addDays, dayKey, loadEntries, pad2, startOfDay, timeLabel, WEEKDAYS_SHORT } from './agenda';
import { addAudio, createBlock, getBlock, listBlocks, listCategories } from './db';
import { audioFileExists } from './storage';

/** Quantas notas recentes o widget mostra. */
const WIDGET_NOTES = 3;

/** Envia ao widget as notas mais recentes (título = assunto da nota). */
export async function syncWidgetNotes(): Promise<void> {
  if (!IdeiasWidget) return;
  if (!getPerf().bg) return; // teste de desempenho
  perfMark('widget: notas');
  await waitForIdle(1000);
  try {
    const blocks = await listBlocks();
    const notes = blocks
      .slice(0, WIDGET_NOTES)
      .map((b) => ({ id: b.id, title: b.noteTitle || (b.pendingCount > 0 ? 'Transcrevendo…' : b.name) }));
    IdeiasWidget.setNotes(JSON.stringify(notes));
  } catch {
    // o widget só fica com a lista antiga
  }
}

/** Envia ao widget os próximos compromissos (página Agenda) e os dias marcados (página Calendário). */
export async function syncWidgetAgenda(): Promise<void> {
  if (!IdeiasWidget?.setAgenda) return;
  if (!getPerf().bg) return; // teste de desempenho
  perfMark('widget: agenda');
  await waitForIdle(1000);
  try {
    const now = new Date();
    const today = startOfDay(now);
    const todayKey = dayKey(today);
    const tomorrowKey = dayKey(addDays(today, 1));
    const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
    const map = await loadEntries(monthStart, addDays(today, 60), await listCategories());
    const keys = Array.from(map.keys()).sort();

    const upcoming: { day: string; title: string; when: string }[] = [];
    for (const k of keys) {
      if (k < todayKey) continue;
      const [y, m, d] = k.split('-').map(Number);
      const label =
        k === todayKey ? 'hoje' : k === tomorrowKey ? 'amanhã' : `${WEEKDAYS_SHORT[new Date(y, m - 1, d).getDay()]}, ${pad2(d)}/${pad2(m)}`;
      for (const e of map.get(k) ?? []) {
        // Hoje, esconde o que já passou há mais de meia hora.
        if (k === todayKey && !e.allDay && e.startMs < now.getTime() - 30 * 60 * 1000) continue;
        upcoming.push({ day: pad2(d), title: e.title, when: e.allDay ? label : `${label} · ${timeLabel(e.startMs)}` });
        if (upcoming.length >= 3) break;
      }
      if (upcoming.length >= 3) break;
    }
    IdeiasWidget.setAgenda(JSON.stringify({ upcoming, marks: keys }));
  } catch {
    // o widget só fica com os dados antigos
  }
}

// ---------- Gravação (serviço nativo em primeiro plano) ----------

export type RecPhase = 'idle' | 'recording' | 'paused';

export type RecState = {
  state: RecPhase;
  /** Tempo gravado (ms), contado pelo serviço. */
  ms: number;
  /** Volume do microfone, 0 a 1. */
  level: number;
  /** Nota de destino (-1 = nota nova). */
  blockId: number;
  /** Parte atual (gravações longas são divididas a cada 25 min). */
  part: number;
  /** Aviso do serviço (ex.: pausou porque uma chamada começou). */
  notice: string;
  error: string;
  /** Resultado da última gravação: saved | short | discarded | empty | error. */
  last: string;
};

export const IDLE_REC: RecState = { state: 'idle', ms: 0, level: 0, blockId: -1, part: 1, notice: '', error: '', last: '' };

/** O build atual tem o serviço de gravação? (falso em build antigo: precisa reinstalar o app) */
export const recAvailable = (): boolean => !!IdeiasWidget?.startRecording && !!IdeiasWidget?.getRecordingState;

export function getRecState(): RecState {
  try {
    const raw = IdeiasWidget?.getRecordingState?.();
    if (!raw) return IDLE_REC;
    const o = JSON.parse(raw);
    return {
      state: o.state === 'recording' || o.state === 'paused' ? o.state : 'idle',
      ms: Number(o.ms) || 0,
      level: Number(o.level) || 0,
      blockId: Number(o.blockId ?? -1),
      part: Number(o.part) || 1,
      notice: String(o.notice ?? ''),
      error: String(o.error ?? ''),
      last: String(o.last ?? ''),
    };
  } catch {
    return IDLE_REC;
  }
}

export const recStart = (blockId: number): boolean => !!IdeiasWidget?.startRecording?.(blockId);
export const recPause = (): void => IdeiasWidget?.pauseRecording?.();
export const recResume = (): void => IdeiasWidget?.resumeRecording?.();
export const recStop = (): void => IdeiasWidget?.stopRecording?.();
/** Vibração curta ('light' ou 'strong'). */
export const haptic = (kind: 'light' | 'strong'): void => {
  try {
    IdeiasWidget?.haptic?.(kind);
  } catch {}
};
export const recDiscard = (): void => IdeiasWidget?.discardRecording?.();

/** Espera `cond` ficar verdadeira, olhando o estado do serviço a cada 40 ms. */
export async function waitRec(cond: (s: RecState) => boolean, timeoutMs: number): Promise<boolean> {
  const end = Date.now() + timeoutMs;
  while (Date.now() < end) {
    if (cond(getRecState())) return true;
    await new Promise((r) => setTimeout(r, 40));
  }
  return cond(getRecState());
}

type PendingRecording = { file: string; blockId: number; durationMs: number; group?: string; recovered?: boolean };

export type ImportedRecording = {
  audioId: number;
  blockId: number;
  /** A nota foi criada agora para esta gravação. */
  newBlock: boolean;
  fileName: string;
  durationMs: number;
  /** Salva depois de uma interrupção inesperada. */
  recovered: boolean;
};

// Partes de uma gravação longa (mesmo "group") caem na mesma nota, mesmo que cheguem em momentos diferentes.
const groupBlocks = new Map<string, number>();
const importListeners = new Set<(list: ImportedRecording[]) => void>();

/** Avisa quando gravações forem importadas (a tela de Gravação usa para mostrar o "Desfazer"). */
export function subscribeImported(fn: (list: ImportedRecording[]) => void): () => void {
  importListeners.add(fn);
  return () => {
    importListeners.delete(fn);
  };
}

/**
 * Importa as gravações prontas do serviço (feitas pela tela, pelo widget ou recuperadas depois de uma
 * interrupção): cada uma vira um áudio pendente na nota escolhida ou numa nota nova, criada só agora.
 */
export async function importWidgetRecordings(): Promise<ImportedRecording[]> {
  if (!IdeiasWidget) return [];
  if (!getPerf().bg) return [];
  perfMark('widget: gravações');
  await waitForIdle(1000);
  try {
    IdeiasWidget.recoverInterrupted?.();
  } catch {
    // sem recuperação: segue com o que já está pendente
  }
  let list: PendingRecording[] = [];
  try {
    const parsed = JSON.parse(IdeiasWidget.consumePending());
    if (Array.isArray(parsed)) list = parsed;
  } catch {
    return [];
  }
  const done: ImportedRecording[] = [];
  for (const rec of list) {
    try {
      if (!rec.file || !audioFileExists(rec.file)) continue;
      let blockId = -1;
      let newBlock = false;
      const g = rec.group || '';
      if (g && groupBlocks.has(g) && (await getBlock(groupBlocks.get(g) as number))) blockId = groupBlocks.get(g) as number;
      else if (rec.blockId > 0 && (await getBlock(rec.blockId))) blockId = rec.blockId;
      else {
        blockId = await createBlock();
        newBlock = true;
      }
      if (g) groupBlocks.set(g, blockId);
      const audioId = await addAudio(blockId, rec.file, rec.durationMs);
      done.push({
        audioId,
        blockId,
        newBlock,
        fileName: rec.file,
        durationMs: rec.durationMs,
        recovered: !!rec.recovered,
      });
    } catch {
      // mantém o arquivo no disco; não apaga gravação por causa de um erro
    }
  }
  if (done.length > 0) {
    importListeners.forEach((fn) => {
      try {
        fn(done);
      } catch {}
    });
  }
  return done;
}

/** Android 13+: sem essa permissão a notificação "Gravando…" não aparece na barra. */
export async function askNotificationPermission(): Promise<void> {
  if (Platform.OS !== 'android' || Platform.Version < 33) return;
  try {
    await PermissionsAndroid.request('android.permission.POST_NOTIFICATIONS' as any);
  } catch {
    // segue sem notificação visível
  }
}
