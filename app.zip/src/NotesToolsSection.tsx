import React, { useState } from 'react';
import { View } from 'react-native';
import { RestructureDialog } from './RestructureDialog';
import { SettingRow } from './SettingRow';
import { TagsManager } from './TagsManager';

/** Ferramentas que atuam sobre as notas já existentes: reorganizar o texto e gerenciar tags. */
export function NotesToolsSection() {
  const [organizeAll, setOrganizeAll] = useState(false);
  const [tagsOpen, setTagsOpen] = useState(false);

  return (
    <View>
      <SettingRow
        label="Organizar notas existentes (citações, listas e subtítulos). Você escolhe o que aplicar."
        accessibilityLabel="Organizar notas existentes"
        action="Abrir"
        onPress={() => setOrganizeAll(true)}
      />
      <RestructureDialog visible={organizeAll} blockIds="all" onClose={() => setOrganizeAll(false)} />

      <SettingRow
        label="Tags das notas: renomear, mesclar ou apagar."
        accessibilityLabel="Gerenciar tags das notas"
        action="Abrir"
        onPress={() => setTagsOpen(true)}
      />
      <TagsManager visible={tagsOpen} onClose={() => setTagsOpen(false)} />
    </View>
  );
}
