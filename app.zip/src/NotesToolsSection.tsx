import React, { useState } from 'react';
import { View, useWindowDimensions } from 'react-native';
import { RestructureDialog } from './RestructureDialog';
import { SettingRow } from './SettingRow';
import { TagsManager } from './TagsManager';
import { SPACE } from './theme';

/** Ferramentas que atuam sobre as notas já existentes: reorganizar o texto e gerenciar tags. */
export function NotesToolsSection() {
  const { width: sw } = useWindowDimensions();
  const [organizeAll, setOrganizeAll] = useState(false);
  const [tagsOpen, setTagsOpen] = useState(false);

  return (
    <View style={{ gap: sw * SPACE.md }}>
      <SettingRow
        label="Organizar notas existentes"
        hint="Citações, listas e subtítulos. Você escolhe o que aplicar."
        action="Abrir"
        onPress={() => setOrganizeAll(true)}
      />
      <RestructureDialog visible={organizeAll} blockIds="all" onClose={() => setOrganizeAll(false)} />

      <SettingRow
        label="Gerenciar tags"
        hint="Renomear, mesclar ou apagar tags das notas."
        action="Abrir"
        onPress={() => setTagsOpen(true)}
      />
      <TagsManager visible={tagsOpen} onClose={() => setTagsOpen(false)} />
    </View>
  );
}
