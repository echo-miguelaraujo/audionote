import React from 'react';
import { Text, View } from 'react-native';
import type { MoodCollection, MoodItem } from './db';
import { colors, fonts } from './theme';

type Box = { x: number; y: number; w: number; h: number };
type Pt = { x: number; y: number };

/** Ponto em que a reta do centro do retângulo `a` até (bx, by) cruza a borda de `a` (com uma folga `pad`). */
function edge(a: Box, bx: number, by: number, pad: number): Pt {
  const cx = a.x + a.w / 2;
  const cy = a.y + a.h / 2;
  const dx = bx - cx;
  const dy = by - cy;
  if (dx === 0 && dy === 0) return { x: cx, y: cy };
  const hw = a.w / 2 + pad;
  const hh = a.h / 2 + pad;
  const t = Math.min(dx !== 0 ? hw / Math.abs(dx) : Infinity, dy !== 0 ? hh / Math.abs(dy) : Infinity);
  return { x: cx + dx * t, y: cy + dy * t };
}

/**
 * Setas entre as cenas, na ordem dos números (da 1 para a 2, da 2 para a 3...). Com a transição e o gancho
 * da cena de origem escritos no meio da seta. "lines" desenha as setas (por baixo dos cartões) e "labels"
 * desenha os rótulos (por cima). Só desenha; não recebe toque.
 */
export function SceneLinks({
  layer,
  items,
  subs,
  u,
  live,
}: {
  layer: 'lines' | 'labels';
  /** Cenas já na ordem dos números. */
  items: MoodItem[];
  subs: Record<number, MoodCollection | undefined>;
  u: number;
  /** Cartão que está sendo arrastado agora: a seta acompanha. */
  live: { id: number; dx: number; dy: number } | null;
}) {
  const box = (it: MoodItem): Box => ({
    x: it.x * u + (live && live.id === it.id ? live.dx : 0),
    y: it.y * u + (live && live.id === it.id ? live.dy : 0),
    w: it.w * u,
    h: it.h * u,
  });
  const th = Math.max(2, u * 0.006);
  const head = u * 0.03;
  const pad = u * 0.012;
  const out: React.ReactNode[] = [];
  for (let i = 0; i < items.length - 1; i++) {
    const a = box(items[i]);
    const b = box(items[i + 1]);
    const p1 = edge(a, b.x + b.w / 2, b.y + b.h / 2, pad);
    const p2 = edge(b, a.x + a.w / 2, a.y + a.h / 2, pad);
    const dx = p2.x - p1.x;
    const dy = p2.y - p1.y;
    const len = Math.sqrt(dx * dx + dy * dy);
    if (len < head * 1.5) continue; // cartões encostados: não cabe seta
    const ang = Math.atan2(dy, dx);
    const from = subs[Number(items[i].content)];
    const key = `${items[i].id}-${items[i + 1].id}`;
    if (layer === 'lines') {
      out.push(
        <View
          key={key}
          style={{
            position: 'absolute',
            left: p1.x,
            top: p1.y - th / 2,
            width: len - head * 0.8,
            height: th,
            borderRadius: th / 2,
            backgroundColor: colors.red,
            transformOrigin: 'left center',
            transform: [{ rotate: `${ang}rad` }],
          }}
        />,
        <View key={`${key}-h`} style={{ position: 'absolute', left: p2.x, top: p2.y, width: 0, height: 0, transform: [{ rotate: `${ang}rad` }] }}>
          <View
            style={{
              position: 'absolute',
              left: -head,
              top: -head * 0.5,
              width: 0,
              height: 0,
              borderTopWidth: head * 0.5,
              borderBottomWidth: head * 0.5,
              borderLeftWidth: head,
              borderTopColor: 'transparent',
              borderBottomColor: 'transparent',
              borderLeftColor: colors.red,
            }}
          />
        </View>
      );
    } else if (from && (from.sceneTransition || from.sceneHook)) {
      const maxW = u * 0.42;
      out.push(
        <View
          key={`${key}-l`}
          style={{ position: 'absolute', left: (p1.x + p2.x) / 2 - maxW / 2, top: (p1.y + p2.y) / 2, width: maxW, alignItems: 'center', transform: [{ translateY: -u * 0.03 }] }}
        >
          <View
            style={{
              maxWidth: maxW,
              paddingHorizontal: u * 0.03,
              paddingVertical: u * 0.015,
              borderRadius: u * 0.035,
              backgroundColor: colors.paper,
              borderWidth: 1,
              borderColor: colors.line,
            }}
          >
            {!!from.sceneTransition && (
              <Text numberOfLines={1} style={{ fontFamily: fonts.bold, fontSize: u * 0.032, color: colors.onLight }}>
                {from.sceneTransition}
              </Text>
            )}
            {!!from.sceneHook && (
              <Text numberOfLines={2} style={{ fontFamily: fonts.regular, fontSize: u * 0.028, color: colors.subtle }}>
                {from.sceneHook}
              </Text>
            )}
          </View>
        </View>
      );
    }
  }
  return (
    <View pointerEvents="none" style={{ position: 'absolute', left: 0, top: 0 }}>
      {out}
    </View>
  );
}
