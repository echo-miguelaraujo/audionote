import React from 'react';
import { SvgXml } from 'react-native-svg';
import { colors } from './theme';
import { ICON_SET, ICON_VIEWBOX, IconKey } from './iconSet';

export type IconName = Extract<
  IconKey,
  'chevron-left' | 'chevron-right' | 'plus' | 'minus' | 'close' | 'check' | 'expand' | 'more' | 'scenes' | 'canvas' | 'trash'
  | 'chat'
>;

type Props = {
  name: IconName;
  /** Lado do ícone em px. */
  size: number;
  color?: string;
};

/**
 * Ícones do app (telas em React Native). Mesma biblioteca dos editores HTML: `iconSet.ts`
 * (Phosphor Fill). Para um ícone novo, inclua em `iconSet.ts` e em `IconName`.
 */
export function Icon({ name, size, color = colors.onDark }: Props) {
  const xml = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${ICON_VIEWBOX}" fill="${color}">${ICON_SET[name]}</svg>`;
  return <SvgXml xml={xml} width={size} height={size} />;
}
