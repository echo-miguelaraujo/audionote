import React from 'react';
import { View } from 'react-native';
import { colors } from './theme';

export type IconName = 'chevron-left' | 'chevron-right' | 'plus' | 'minus' | 'close' | 'check' | 'expand' | 'more';

type Props = {
  name: IconName;
  /** Lado do ícone em px. */
  size: number;
  color?: string;
};

/**
 * Ícones do app desenhados com Views (sem fonte nem emoji), para ficarem iguais em qualquer aparelho.
 * Todos usam o mesmo traço: 1/10 do tamanho.
 */
export function Icon({ name, size, color = colors.onDark }: Props) {
  const t = Math.max(1.5, size * 0.1);
  const box = { width: size, height: size, alignItems: 'center', justifyContent: 'center' } as const;
  const bar = (w: number, h: number, rotate?: string) => (
    <View
      style={{
        position: 'absolute',
        width: w,
        height: h,
        borderRadius: t / 2,
        backgroundColor: color,
        transform: rotate ? [{ rotate }] : undefined,
      }}
    />
  );

  switch (name) {
    case 'chevron-left':
    case 'chevron-right': {
      const s = size * 0.5;
      return (
        <View style={box}>
          <View
            style={{
              width: s,
              height: s,
              borderLeftWidth: t,
              borderBottomWidth: t,
              borderColor: color,
              transform: [{ rotate: name === 'chevron-left' ? '45deg' : '225deg' }],
              marginLeft: name === 'chevron-left' ? s * 0.25 : -s * 0.25,
            }}
          />
        </View>
      );
    }
    case 'plus':
      return (
        <View style={box}>
          {bar(size * 0.6, t)}
          {bar(t, size * 0.6)}
        </View>
      );
    case 'minus':
      return <View style={box}>{bar(size * 0.6, t)}</View>;
    case 'close':
      return (
        <View style={box}>
          {bar(size * 0.7, t, '45deg')}
          {bar(size * 0.7, t, '-45deg')}
        </View>
      );
    case 'check':
      return (
        <View style={box}>
          <View
            style={{
              width: size * 0.28,
              height: size * 0.5,
              borderRightWidth: t,
              borderBottomWidth: t,
              borderColor: color,
              transform: [{ rotate: '45deg' }, { translateY: -size * 0.05 }],
            }}
          />
        </View>
      );
    case 'expand': {
      // Dois cantos opostos, "ajustar à tela".
      const c = size * 0.34;
      const corner = (pos: object, borders: object) => (
        <View style={[{ position: 'absolute', width: c, height: c, borderColor: color }, pos, borders]} />
      );
      return (
        <View style={box}>
          {corner({ top: size * 0.12, left: size * 0.12 }, { borderTopWidth: t, borderLeftWidth: t })}
          {corner({ bottom: size * 0.12, right: size * 0.12 }, { borderBottomWidth: t, borderRightWidth: t })}
        </View>
      );
    }
    case 'more': {
      // Três pontos na vertical, "mais ações".
      const d = size * 0.16;
      const dot = (top: number) => (
        <View style={{ position: 'absolute', top, width: d, height: d, borderRadius: d / 2, backgroundColor: color }} />
      );
      return (
        <View style={box}>
          {dot(size * 0.2)}
          {dot(size * 0.5 - d / 2)}
          {dot(size * 0.8 - d)}
        </View>
      );
    }
  }
}
