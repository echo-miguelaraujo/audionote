import React from 'react';
import { View } from 'react-native';
import { colors } from './theme';

export type IconName = 'chevron-left' | 'chevron-right' | 'plus' | 'minus' | 'close' | 'check' | 'expand' | 'more' | 'scenes' | 'canvas';

type Props = {
  name: IconName;
  /** Lado do ícone em px. */
  size: number;
  color?: string;
};

/**
 * Ícones do app desenhados com Views (sem fonte nem emoji), para ficarem iguais em qualquer aparelho.
 * Todos usam o mesmo traço: 1/10 do tamanho.
 */
export function Icon({ name, size, color = colors.onDark }: Props) {
  const t = Math.max(1.5, size * 0.1);
  const box = { width: size, height: size, alignItems: 'center', justifyContent: 'center' } as const;
  const bar = (w: number, h: number, rotate?: string) => (
    <View
      style={{
        position: 'absolute',
        width: w,
        height: h,
        borderRadius: t / 2,
        backgroundColor: color,
        transform: rotate ? [{ rotate }] : undefined,
      }}
    />
  );

  switch (name) {
    case 'chevron-left':
    case 'chevron-right': {
      const s = size * 0.5;
      return (
        <View style={box}>
          <View
            style={{
              width: s,
              height: s,
              borderLeftWidth: t,
              borderBottomWidth: t,
              borderColor: color,
              transform: [{ rotate: name === 'chevron-left' ? '45deg' : '225deg' }],
              marginLeft: name === 'chevron-left' ? s * 0.25 : -s * 0.25,
            }}
          />
        </View>
      );
    }
    case 'plus':
      return (
        <View style={box}>
          {bar(size * 0.6, t)}
          {bar(t, size * 0.6)}
        </View>
      );
    case 'minus':
      return <View style={box}>{bar(size * 0.6, t)}</View>;
    case 'close':
      return (
        <View style={box}>
          {bar(size * 0.7, t, '45deg')}
          {bar(size * 0.7, t, '-45deg')}
        </View>
      );
    case 'check':
      return (
        <View style={box}>
          <View
            style={{
              width: size * 0.28,
              height: size * 0.5,
              borderRightWidth: t,
              borderBottomWidth: t,
              borderColor: color,
              transform: [{ rotate: '45deg' }, { translateY: -size * 0.05 }],
            }}
          />
        </View>
      );
    case 'expand': {
      // Dois cantos opostos, "ajustar à tela".
      const c = size * 0.34;
      const corner = (pos: object, borders: object) => (
        <View style={[{ position: 'absolute', width: c, height: c, borderColor: color }, pos, borders]} />
      );
      return (
        <View style={box}>
          {corner({ top: size * 0.12, left: size * 0.12 }, { borderTopWidth: t, borderLeftWidth: t })}
          {corner({ bottom: size * 0.12, right: size * 0.12 }, { borderBottomWidth: t, borderRightWidth: t })}
        </View>
      );
    }
    case 'more': {
      // Três pontos na vertical, "mais ações".
      const d = size * 0.16;
      const dot = (top: number) => (
        <View style={{ position: 'absolute', top, width: d, height: d, borderRadius: d / 2, backgroundColor: color }} />
      );
      return (
        <View style={box}>
          {dot(size * 0.2)}
          {dot(size * 0.5 - d / 2)}
          {dot(size * 0.8 - d)}
        </View>
      );
    }
    case 'scenes': {
      // Claquete: a tampa listrada (inclinada) em cima de um corpo retangular.
      const bodyW = size * 0.72;
      const bodyH = size * 0.4;
      const slateH = size * 0.17;
      return (
        <View style={box}>
          <View
            style={{
              position: 'absolute',
              bottom: size * 0.14,
              width: bodyW,
              height: bodyH,
              borderWidth: t,
              borderColor: color,
              borderRadius: t,
            }}
          />
          <View
            style={{
              position: 'absolute',
              top: size * 0.2,
              width: bodyW,
              height: slateH,
              backgroundColor: color,
              borderRadius: t * 0.6,
              transform: [{ rotate: '-12deg' }],
            }}
          />
        </View>
      );
    }
    case 'canvas': {
      // Quadro livre: moldura com pecinhas soltas em tamanhos e posições diferentes.
      const f = size * 0.78;
      const piece = (left: number, top: number, w: number, h: number) => (
        <View style={{ position: 'absolute', left, top, width: w, height: h, backgroundColor: color, borderRadius: t * 0.6 }} />
      );
      return (
        <View style={box}>
          <View style={{ width: f, height: f, borderWidth: t, borderColor: color, borderRadius: t * 1.5 }}>
            {piece(f * 0.12, f * 0.14, f * 0.34, f * 0.26)}
            {piece(f * 0.56, f * 0.3, f * 0.2, f * 0.34)}
            {piece(f * 0.2, f * 0.56, f * 0.26, f * 0.18)}
          </View>
        </View>
      );
    }
  }
}
