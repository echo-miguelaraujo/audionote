import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Alert,
  Animated,
  BackHandler,
  Easing,
  LayoutChangeEvent,
  Pressable,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
} from 'react-native';
import {
  RecordingPresets,
  requestRecordingPermissionsAsync,
  setAudioModeAsync,
  useAudioRecorder,
  useAudioRecorderState,
} from 'expo-audio';
import { activateKeepAwakeAsync, deactivateKeepAwake } from 'expo-keep-awake';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { addAudio, createBlock } from './db';
import { importRecording } from './storage';
import { formatTimer } from './format';
import { colors, fonts } from './theme';

type Phase = 'idle' | 'recording' | 'paused';

type Props = {
  /** Bloco escolhido em "Selecionar Nota": a gravação começa sozinha. */
  pendingTarget: number | null;
  onConsumePending: () => void;
  onChooseExisting: () => void;
  onSaved: () => void;
  onPopupChange: (open: boolean) => void;
};

export function RecordingScreen({
  pendingTarget,
  onConsumePending,
  onChooseExisting,
  onSaved,
  onPopupChange,
}: Props) {
  const { width: sw } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const recorder = useAudioRecorder(RecordingPresets.HIGH_QUALITY);
  const state = useAudioRecorderState(recorder, 250);
  const [phase, setPhase] = useState<Phase>('idle');
  const [popup, setPopup] = useState(false);
  const [areaH, setAreaH] = useState(0);
  const targetRef = useRef<number | null>(null);
  const busy = useRef(false);
  const pulse = useRef(new Animated.Value(0)).current;

  const circle = sw * 0.62;

  const setPopupOpen = useCallback(
    (open: boolean) => {
      setPopup(open);
      onPopupChange(open);
    },
    [onPopupChange]
  );

  // Mantém a tela acesa durante a gravação (o Android pode cortar o microfone em segundo plano).
  useEffect(() => {
    if (phase === 'recording') {
      activateKeepAwakeAsync('gravacao').catch(() => {});
      return () => {
        deactivateKeepAwake('gravacao').catch(() => {});
      };
    }
  }, [phase]);

  // Pulso suave no botão enquanto grava.
  useEffect(() => {
    if (phase === 'recording') {
      const loop = Animated.loop(
        Animated.sequence([
          Animated.timing(pulse, {
            toValue: 1,
            duration: 1100,
            easing: Easing.inOut(Easing.quad),
            useNativeDriver: true,
          }),
          Animated.timing(pulse, {
            toValue: 0,
            duration: 1100,
            easing: Easing.inOut(Easing.quad),
            useNativeDriver: true,
          }),
        ])
      );
      loop.start();
      return () => {
        loop.stop();
        pulse.setValue(0);
      };
    }
  }, [phase, pulse]);

  // Botão voltar fecha o pop-up.
  useEffect(() => {
    if (!popup) return;
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      setPopupOpen(false);
      return true;
    });
    return () => sub.remove();
  }, [popup, setPopupOpen]);

  const start = useCallback(
    async (getBlockId: () => Promise<number>) => {
      if (busy.current) return;
      busy.current = true;
      try {
        const perm = await requestRecordingPermissionsAsync();
        if (!perm.granted) {
          Alert.alert(
            'Microfone bloqueado',
            'Permita o microfone em Configurações > Apps > Ideias > Permissões.'
          );
          return;
        }
        await setAudioModeAsync({ allowsRecording: true, playsInSilentMode: true });
        const blockId = await getBlockId();
        await recorder.prepareToRecordAsync();
        recorder.record();
        targetRef.current = blockId;
        setPhase('recording');
        onSaved(); // atualiza a Biblioteca (bloco novo)
      } catch (e) {
        Alert.alert('Não foi possível gravar', String(e));
      } finally {
        busy.current = false;
      }
    },
    [recorder, onSaved]
  );

  // Começa sozinho ao voltar de "Selecionar Nota".
  useEffect(() => {
    if (pendingTarget !== null && phase === 'idle') {
      const id = pendingTarget;
      onConsumePending();
      start(async () => id);
    }
  }, [pendingTarget, phase, onConsumePending, start]);

  const stopAndSave = useCallback(async () => {
    if (busy.current) return;
    busy.current = true;
    try {
      const durationMs = recorder.getStatus().durationMillis;
      await recorder.stop();
      const uri = recorder.uri;
      const blockId = targetRef.current;
      setPhase('idle');
      await setAudioModeAsync({ allowsRecording: false, playsInSilentMode: true });
      if (!uri || blockId === null) {
        Alert.alert('Gravação perdida', 'Não foi possível localizar o arquivo gravado.');
        return;
      }
      const fileName = importRecording(uri);
      await addAudio(blockId, fileName, durationMs);
      targetRef.current = null;
      onSaved();
    } catch (e) {
      setPhase('idle');
      Alert.alert('Erro ao salvar o áudio', String(e));
    } finally {
      busy.current = false;
    }
  }, [recorder, onSaved]);

  const togglePause = () => {
    if (phase === 'recording') {
      recorder.pause();
      setPhase('paused');
    } else if (phase === 'paused') {
      recorder.record();
      setPhase('recording');
    }
  };

  const onCirclePress = () => {
    if (phase === 'idle') setPopupOpen(true);
    else stopAndSave();
  };

  const glowScale = pulse.interpolate({ inputRange: [0, 1], outputRange: [1, 1.035] });
  const timerMs = phase === 'idle' ? 0 : state.durationMillis;
  const timerSize = sw * 0.075;
  const pauseSize = sw * 0.15;

  return (
    <View style={styles.flex}>
      <Text
        style={[
          styles.timer,
          {
            top: insets.top + sw * 0.1,
            fontSize: timerSize,
            letterSpacing: -timerSize * 0.03,
            color: phase === 'paused' ? colors.gray : colors.text,
          },
        ]}
      >
        {formatTimer(timerMs)}
      </Text>

      <View style={styles.center} onLayout={(e: LayoutChangeEvent) => setAreaH(e.nativeEvent.layout.height)}>
        <Pressable onPress={onCirclePress} hitSlop={20}>
          <Animated.View
            style={{
              width: circle,
              height: circle,
              alignItems: 'center',
              justifyContent: 'center',
              transform: [{ scale: glowScale }],
            }}
          >
            {/* brilho: anéis concêntricos com opacidade decrescente */}
            {[0.1, 0.07, 0.05, 0.03].map((a, i) => {
              const d = circle + (i + 1) * sw * 0.022;
              return (
                <View
                  key={i}
                  style={{
                    position: 'absolute',
                    width: d,
                    height: d,
                    borderRadius: d / 2,
                    backgroundColor: `rgba(237,242,245,${a})`,
                  }}
                />
              );
            })}
            <View
              style={{
                width: circle,
                height: circle,
                borderRadius: circle / 2,
                backgroundColor: colors.circle,
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <View
                style={{
                  width: circle * 0.93,
                  height: circle * 0.93,
                  borderRadius: (circle * 0.93) / 2,
                  borderWidth: 2,
                  borderColor: '#DDE3EE',
                  backgroundColor: '#EEF2F5',
                }}
              />
            </View>
          </Animated.View>
        </Pressable>
      </View>

      {phase !== 'idle' && areaH > 0 && (
        <Pressable
          onPress={togglePause}
          hitSlop={16}
          style={{
            position: 'absolute',
            alignSelf: 'center',
            top: areaH / 2 + circle / 2 + sw * 0.12,
            width: pauseSize,
            height: pauseSize,
            borderRadius: pauseSize / 2,
            backgroundColor: colors.text,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          {phase === 'recording' ? (
            <View style={{ flexDirection: 'row', gap: pauseSize * 0.12 }}>
              <View style={{ width: pauseSize * 0.12, height: pauseSize * 0.38, backgroundColor: '#000' }} />
              <View style={{ width: pauseSize * 0.12, height: pauseSize * 0.38, backgroundColor: '#000' }} />
            </View>
          ) : (
            <View
              style={{
                marginLeft: pauseSize * 0.07,
                borderTopWidth: pauseSize * 0.2,
                borderBottomWidth: pauseSize * 0.2,
                borderLeftWidth: pauseSize * 0.32,
                borderTopColor: 'transparent',
                borderBottomColor: 'transparent',
                borderLeftColor: '#000',
              }}
            />
          )}
        </Pressable>
      )}

      {popup && (
        <Pressable style={styles.overlay} onPress={() => setPopupOpen(false)}>
          <View
            style={{
              width: sw * 0.78,
              height: sw * 0.37,
              borderRadius: sw * 0.074,
              backgroundColor: '#FFFFFF',
              flexDirection: 'row',
              overflow: 'hidden',
            }}
          >
            {[
              {
                key: 'new',
                text: 'Gravar\nNovo',
                onPress: () => {
                  setPopupOpen(false);
                  start(createBlock);
                },
              },
              {
                key: 'existing',
                text: 'Selecionar\nNota',
                onPress: () => {
                  setPopupOpen(false);
                  onChooseExisting();
                },
              },
            ].map((opt) => (
              <Pressable
                key={opt.key}
                onPress={opt.onPress}
                style={{ flex: 1, justifyContent: 'center', paddingLeft: sw * 0.78 * 0.072 }}
              >
                <Text
                  style={{
                    color: '#000',
                    fontFamily: fonts.black,
                    fontSize: sw * 0.07,
                    lineHeight: sw * 0.07 * 0.9,
                    letterSpacing: -sw * 0.07 * 0.045,
                  }}
                >
                  {opt.text}
                </Text>
              </Pressable>
            ))}
          </View>
        </Pressable>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: colors.bg },
  timer: {
    position: 'absolute',
    alignSelf: 'center',
    fontFamily: fonts.light,
    fontVariant: ['tabular-nums'],
  },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.76)',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
