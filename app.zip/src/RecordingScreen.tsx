import React, { useCallback, useEffect, useRef, useState } from 'react';
import { appAlert } from './dialog';
import {
  Animated,
  Easing,
  LayoutChangeEvent,
  Pressable,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
} from 'react-native';
import { requestRecordingPermissionsAsync } from 'expo-audio';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Aura } from './Aura';
import { BottomSheet, SheetItem } from './BottomSheet';
import { Block, deleteQueueItem, getBlock, listBlocks } from './db';
import {
  getRecState,
  haptic,
  IDLE_REC,
  ImportedRecording,
  recDiscard,
  subscribeImported,
  importWidgetRecordings,
  recAvailable,
  recPause,
  recResume,
  recStart,
  recStop,
  RecState,
  waitRec,
} from './widget';
import { formatTimerMs } from './format';
import { UndoToast } from './UndoToast';
import { colors, fonts, TYPE, HIT, alpha } from './theme';

type Phase = 'idle' | 'recording' | 'paused';

type Props = {
  onSaved: () => void;
  onOpenSettings: () => void;
  pendingCount: number;
  onOpenQueue: () => void;
  /** Abre a nota (toque numa gravação da lista). */
  onOpenNote: (blockId: number) => void;
  /** Muda quando o conteúdo muda (atualiza a lista de gravações). */
  version: number;
};

export function RecordingScreen({
  onSaved,
  onOpenSettings,
  pendingCount,
  onOpenQueue,
  onOpenNote,
  version,
}: Props) {
  const { width: sw } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const [rs, setRs] = useState<RecState>(IDLE_REC);
  const [popup, setPopup] = useState(false);
  const [blocks, setBlocks] = useState<Block[]>([]);
  const [areaH, setAreaH] = useState(0);
  const [destTitle, setDestTitle] = useState('');
  const [toast, setToast] = useState<{ id: number; items: ImportedRecording[] } | null>(null);
  const level = useRef(new Animated.Value(0)).current;
  const busy = useRef(false);
  const prevPhase = useRef<Phase>('idle');
  const pulse = useRef(new Animated.Value(0)).current;

  const phase: Phase = rs.state;
  const circle = sw * 0.62;

  const setPopupOpen = useCallback((open: boolean) => {
    setPopup(open);
    if (open) listBlocks().then(setBlocks).catch(() => {});
  }, []);

  // Acompanha o serviço de gravação: rápido enquanto grava (cronômetro), devagar parado
  // (para perceber uma gravação iniciada pelo widget ou pela notificação).
  useEffect(() => {
    let alive = true;
    let timer: ReturnType<typeof setTimeout>;
    const poll = () => {
      if (!alive) return;
      const s = getRecState();
      setRs((p) =>
        p.state === s.state && p.ms === s.ms && p.notice === s.notice && p.part === s.part ? p : s
      );
      Animated.timing(level, {
        toValue: s.state === 'recording' ? s.level : 0,
        duration: 90,
        useNativeDriver: true,
      }).start();
      timer = setTimeout(poll, s.state === 'idle' ? 400 : 50);
    };
    poll();
    return () => {
      alive = false;
      clearTimeout(timer);
    };
  }, [level]);

  // Nota de destino (mostrada sob o cronômetro).
  useEffect(() => {
    if (phase === 'idle') return;
    if (rs.blockId <= 0) {
      setDestTitle('Nova nota');
      return;
    }
    getBlock(rs.blockId)
      .then((b) => setDestTitle(b ? b.noteTitle || b.name : 'Nova nota'))
      .catch(() => {});
  }, [phase, rs.blockId]);

  // "Desfazer" depois de salvar.
  useEffect(
    () =>
      subscribeImported((list) => {
        if (list.some((r) => r.recovered)) return;
        setToast({ id: Date.now(), items: list });
      }),
    []
  );

  const undo = useCallback(async () => {
    const items = toast?.items ?? [];
    setToast(null);
    for (const it of items) await deleteQueueItem(it.audioId).catch(() => {});
    haptic('light');
    onSaved();
  }, [toast, onSaved]);

  // Gravação terminou (por aqui, pelo widget ou pela notificação): importa o áudio e avisa se algo deu errado.
  useEffect(() => {
    const was = prevPhase.current;
    prevPhase.current = phase;
    if (phase !== 'idle' || was === 'idle') return;
    const st = getRecState();
    importWidgetRecordings()
      .then((list) => {
        if (list.length > 0) onSaved();
        else if (st.last === 'short') {
          appAlert('Gravação muito curta', 'Gravações com menos de 1 segundo são descartadas.');
        } else if (st.last === 'error') {
          appAlert('Erro ao salvar o áudio', st.error || 'Não foi possível salvar a gravação.');
        }
      })
      .catch((e) => appAlert('Erro ao salvar o áudio', String(e)));
  }, [phase, onSaved]);

  // Pulso suave no botão enquanto grava.
  useEffect(() => {
    if (phase === 'recording') {
      const loop = Animated.loop(
        Animated.sequence([
          Animated.timing(pulse, {
            toValue: 1,
            duration: 1100,
            easing: Easing.inOut(Easing.quad),
            useNativeDriver: true,
          }),
          Animated.timing(pulse, {
            toValue: 0,
            duration: 1100,
            easing: Easing.inOut(Easing.quad),
            useNativeDriver: true,
          }),
        ])
      );
      loop.start();
      return () => {
        loop.stop();
        pulse.setValue(0);
      };
    }
  }, [phase, pulse]);

  // blockId: id da nota escolhida, ou -1 para nota nova (ela só é criada ao parar).
  const start = useCallback(async (blockId: number) => {
    if (busy.current) return;
    busy.current = true;
    try {
      if (!recAvailable()) {
        appAlert('Gravação indisponível', 'Este build do app não tem o serviço de gravação. Instale o build novo.');
        return;
      }
      const perm = await requestRecordingPermissionsAsync();
      if (!perm.granted) {
        appAlert(
          'Microfone bloqueado',
          'Permita o microfone em Configurações > Apps > Ideias > Permissões.'
        );
        return;
      }
      if (!recStart(blockId)) {
        appAlert('Não foi possível gravar', getRecState().error || 'O Android não deixou iniciar a gravação.');
        return;
      }
      haptic('strong');
      const ok = await waitRec((s) => s.state !== 'idle', 4000);
      if (!ok) appAlert('Não foi possível gravar', getRecState().error || 'O serviço de gravação não iniciou.');
    } catch (e) {
      appAlert('Não foi possível gravar', String(e));
    } finally {
      busy.current = false;
    }
  }, []);

  const stopAndSave = useCallback(async () => {
    if (busy.current) return;
    busy.current = true;
    try {
      haptic('strong');
      recStop();
      await waitRec((s) => s.state === 'idle', 8000);
    } finally {
      busy.current = false;
    }
  }, []);

  const discard = () => {
    appAlert('Descartar gravação?', 'O áudio gravado será apagado.', [
      { text: 'Continuar gravando', style: 'cancel' },
      {
        text: 'Descartar',
        style: 'destructive',
        onPress: async () => {
          haptic('light');
          recDiscard();
          await waitRec((s) => s.state === 'idle', 8000);
        },
      },
    ]);
  };

  const togglePause = () => {
    haptic('light');
    if (phase === 'recording') recPause();
    else if (phase === 'paused') recResume();
  };

  // Toque: grava em nota nova. Segurar: escolher a nota.
  const onCirclePress = () => {
    if (phase === 'idle') start(-1);
    else stopAndSave();
  };

  const onCircleLongPress = () => {
    if (phase !== 'idle') return;
    haptic('light');
    setPopupOpen(true);
  };

  const sheetItems: SheetItem[] =
    blocks.length === 0
      ? [{ key: 'empty', label: 'Nenhuma nota ainda', muted: true }]
      : blocks.map((b) => ({
          key: String(b.id),
          label: b.noteTitle || b.name,
          onPress: () => {
            setPopupOpen(false);
            start(b.id);
          },
        }));

  const glowScale = pulse.interpolate({ inputRange: [0, 1], outputRange: [1, 1.035] });
  const timerSize = sw * 0.075;
  const pauseSize = sw * 0.15;

  return (
    <View style={styles.flex}>
      <Text
        style={[
          styles.timer,
          {
            top: insets.top + sw * 0.1,
            fontSize: timerSize,
            letterSpacing: -timerSize * 0.03,
            color: phase === 'paused' ? colors.muted : colors.text,
          },
        ]}
      >
        {formatTimerMs(rs.ms)}
      </Text>

      {phase !== 'idle' && destTitle !== '' && (
        <Text
          numberOfLines={1}
          style={{
            position: 'absolute',
            alignSelf: 'center',
            top: insets.top + sw * 0.1 + timerSize * 1.9,
            maxWidth: sw * 0.8,
            color: colors.muted,
            fontFamily: fonts.regular,
            fontSize: sw * TYPE.label,
          }}
        >
          {destTitle}
        </Text>
      )}

      {rs.notice !== '' && phase !== 'idle' && (
        <Text
          style={{
            position: 'absolute',
            alignSelf: 'center',
            textAlign: 'center',
            top: insets.top + sw * 0.1 + timerSize * 3.2,
            paddingHorizontal: sw * 0.1,
            color: colors.red,
            fontFamily: fonts.regular,
            fontSize: sw * TYPE.caption,
          }}
        >
          {rs.notice}
        </Text>
      )}

      {phase === 'idle' && (
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Configurações"
          onPress={onOpenSettings}
          hitSlop={HIT.lg}
          style={{
            position: 'absolute',
            top: insets.top + sw * 0.1 + timerSize * 0.2,
            right: sw * 0.07,
            width: sw * 0.055,
            height: sw * 0.055,
            borderRadius: sw * 0.0275,
            backgroundColor: colors.text,
          }}
        />
      )}

      {phase === 'idle' && pendingCount > 0 && (
        <Pressable
          accessibilityRole="button"
          onPress={onOpenQueue}
          hitSlop={HIT.md}
          style={{
            position: 'absolute',
            alignSelf: 'center',
            top: insets.top + sw * 0.1 + timerSize * 1.9,
          }}
        >
          <Text style={{ color: colors.red, fontFamily: fonts.regular, fontSize: sw * TYPE.label }}>
            {pendingCount} {pendingCount === 1 ? 'pendente' : 'pendentes'} ›
          </Text>
        </Pressable>
      )}

      <View style={styles.center} onLayout={(e: LayoutChangeEvent) => setAreaH(e.nativeEvent.layout.height)}>
        <Pressable accessibilityRole="button" accessibilityLabel={phase === 'idle' ? 'Gravar' : 'Parar e salvar'} accessibilityHint="Segure para escolher onde salvar" onPress={onCirclePress} onLongPress={onCircleLongPress} delayLongPress={400} hitSlop={HIT.lg}>
          <Animated.View
            style={{
              width: circle,
              height: circle,
              alignItems: 'center',
              justifyContent: 'center',
              transform: [{ scale: glowScale }],
            }}
          >
            {/* aura: nasce de dentro do botão enquanto grava e recolhe ao parar */}
            <Aura size={circle} expanded={phase !== 'idle'} moving={phase === 'recording'} level={level} />
            {/* brilho: anéis concêntricos com opacidade decrescente */}
            {[0.1, 0.07, 0.05, 0.03].map((a, i) => {
              const d = circle + (i + 1) * sw * 0.022;
              return (
                <View
                  key={i}
                  style={{
                    position: 'absolute',
                    width: d,
                    height: d,
                    borderRadius: d / 2,
                    backgroundColor: alpha(colors.circle, a),
                  }}
                />
              );
            })}
            <View
              style={{
                width: circle,
                height: circle,
                borderRadius: circle / 2,
                backgroundColor: colors.circle,
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <View
                style={{
                  width: circle * 0.93,
                  height: circle * 0.93,
                  borderRadius: (circle * 0.93) / 2,
                  borderWidth: 2,
                  borderColor: colors.circleRing,
                  backgroundColor: colors.circle,
                }}
              />
            </View>
          </Animated.View>
        </Pressable>
      </View>

      {phase !== 'idle' && areaH > 0 && (
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={phase === 'recording' ? 'Pausar' : 'Retomar'}
          onPress={togglePause}
          hitSlop={HIT.md}
          style={{
            position: 'absolute',
            alignSelf: 'center',
            top: areaH / 2 + circle / 2 + sw * 0.12,
            width: pauseSize,
            height: pauseSize,
            borderRadius: pauseSize / 2,
            backgroundColor: colors.text,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          {phase === 'recording' ? (
            <View style={{ flexDirection: 'row', gap: pauseSize * 0.12 }}>
              <View style={{ width: pauseSize * 0.12, height: pauseSize * 0.38, backgroundColor: colors.bg }} />
              <View style={{ width: pauseSize * 0.12, height: pauseSize * 0.38, backgroundColor: colors.bg }} />
            </View>
          ) : (
            <View
              style={{
                marginLeft: pauseSize * 0.07,
                borderTopWidth: pauseSize * 0.2,
                borderBottomWidth: pauseSize * 0.2,
                borderLeftWidth: pauseSize * 0.32,
                borderTopColor: 'transparent',
                borderBottomColor: 'transparent',
                borderLeftColor: colors.onLight,
              }}
            />
          )}
        </Pressable>
      )}

      {phase !== 'idle' && areaH > 0 && (
        <Pressable
          accessibilityRole="button"
          onPress={discard}
          hitSlop={HIT.md}
          style={{
            position: 'absolute',
            alignSelf: 'center',
            top: areaH / 2 + circle / 2 + sw * 0.12 + pauseSize + sw * 0.06,
          }}
        >
          <Text style={{ color: colors.red, fontFamily: fonts.regular, fontSize: sw * TYPE.label }}>Descartar</Text>
        </Pressable>
      )}

      {toast && (
        <UndoToast
          key={toast.id}
          text="Gravação salva"
          bottom={sw * 0.04}
          onUndo={undo}
          onDismiss={() => setToast(null)}
        />
      )}

      <BottomSheet
        visible={popup}
        onClose={() => setPopupOpen(false)}
        title="Gravar novo"
        onTitlePress={() => {
          setPopupOpen(false);
          start(-1);
        }}
        subtitle="Selecionar nota"
        items={sheetItems}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: 'transparent' },
  timer: {
    position: 'absolute',
    alignSelf: 'center',
    fontFamily: fonts.light,
    fontVariant: ['tabular-nums'],
  },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
});
