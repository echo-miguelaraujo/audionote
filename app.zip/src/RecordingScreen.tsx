import React, { useCallback, useEffect, useRef, useState } from 'react';
import { appAlert } from './dialog';
import {
  Animated,
  Easing,
  LayoutChangeEvent,
  Pressable,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
} from 'react-native';
import {
  RecordingPresets,
  requestRecordingPermissionsAsync,
  setAudioModeAsync,
  useAudioRecorder,
  useAudioRecorderState,
} from 'expo-audio';
import { activateKeepAwakeAsync, deactivateKeepAwake } from 'expo-keep-awake';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Aura } from './Aura';
import { BottomSheet, SheetItem } from './BottomSheet';
import { addAudio, Block, createBlock, listBlocks } from './db';
import { importRecording } from './storage';
import { formatTimerMs } from './format';
import { colors, fonts } from './theme';

type Phase = 'idle' | 'recording' | 'paused';

// Voz em mono e 64 kbps: arquivo ~metade do tamanho, ótimo para fala e cabe melhor no envio à IA.
const RECORDING_OPTIONS = { ...RecordingPresets.HIGH_QUALITY, numberOfChannels: 1, bitRate: 64000 };

type Props = {
  onSaved: () => void;
  onOpenSettings: () => void;
  pendingCount: number;
  onOpenQueue: () => void;
};

/** Cronômetro MM:SS:mmm. O recorder informa o tempo a cada 250 ms; entre uma leitura e outra o valor é interpolado. */
function RecTimer({ phase, baseMs, style }: { phase: Phase; baseMs: number; style: any }) {
  const [ms, setMs] = useState(0);
  const anchor = useRef({ ms: 0, at: Date.now() });
  const startedAt = useRef(0);
  const last = useRef(0);
  const phaseRef = useRef<Phase>('idle');
  const baseRef = useRef(baseMs);
  baseRef.current = baseMs;

  useEffect(() => {
    const prev = phaseRef.current;
    phaseRef.current = phase;
    if (phase === 'idle') {
      last.current = 0;
      setMs(0);
      return;
    }
    if (phase === 'paused') {
      last.current = Math.max(last.current, baseRef.current);
      setMs(last.current);
      return;
    }
    // recording
    const now = Date.now();
    if (prev === 'idle') {
      anchor.current = { ms: 0, at: now };
      startedAt.current = now;
      last.current = 0;
    } else {
      anchor.current = { ms: Math.max(last.current, baseRef.current), at: now };
      startedAt.current = 0;
    }
    const id = setInterval(() => {
      const a = anchor.current;
      let v = a.ms + (Date.now() - a.at);
      v = Math.min(v, a.ms + 600);
      v = Math.max(v, last.current);
      last.current = v;
      setMs(v);
    }, 40);
    return () => clearInterval(id);
  }, [phase]);

  useEffect(() => {
    if (phaseRef.current !== 'recording') return;
    // ignora leituras velhas (da gravação anterior) logo no começo
    if (startedAt.current && Date.now() - startedAt.current < 350) return;
    anchor.current = { ms: baseMs, at: Date.now() };
  }, [baseMs]);

  return <Text style={style}>{formatTimerMs(ms)}</Text>;
}

export function RecordingScreen({
  onSaved,
  onOpenSettings,
  pendingCount,
  onOpenQueue,
}: Props) {
  const { width: sw } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const recorder = useAudioRecorder(RECORDING_OPTIONS);
  const state = useAudioRecorderState(recorder, 250);
  const [phase, setPhase] = useState<Phase>('idle');
  const [popup, setPopup] = useState(false);
  const [blocks, setBlocks] = useState<Block[]>([]);
  const [areaH, setAreaH] = useState(0);
  const targetRef = useRef<number | null>(null);
  const busy = useRef(false);
  const pulse = useRef(new Animated.Value(0)).current;

  const circle = sw * 0.62;

  const setPopupOpen = useCallback((open: boolean) => {
    setPopup(open);
    if (open) listBlocks().then(setBlocks).catch(() => {});
  }, []);

  // Mantém a tela acesa durante a gravação (o Android pode cortar o microfone em segundo plano).
  useEffect(() => {
    if (phase === 'recording') {
      activateKeepAwakeAsync('gravacao').catch(() => {});
      return () => {
        deactivateKeepAwake('gravacao').catch(() => {});
      };
    }
  }, [phase]);

  // Pulso suave no botão enquanto grava.
  useEffect(() => {
    if (phase === 'recording') {
      const loop = Animated.loop(
        Animated.sequence([
          Animated.timing(pulse, {
            toValue: 1,
            duration: 1100,
            easing: Easing.inOut(Easing.quad),
            useNativeDriver: true,
          }),
          Animated.timing(pulse, {
            toValue: 0,
            duration: 1100,
            easing: Easing.inOut(Easing.quad),
            useNativeDriver: true,
          }),
        ])
      );
      loop.start();
      return () => {
        loop.stop();
        pulse.setValue(0);
      };
    }
  }, [phase, pulse]);

  const start = useCallback(
    async (getBlockId: () => Promise<number>) => {
      if (busy.current) return;
      busy.current = true;
      try {
        const perm = await requestRecordingPermissionsAsync();
        if (!perm.granted) {
          appAlert(
            'Microfone bloqueado',
            'Permita o microfone em Configurações > Apps > Ideias > Permissões.'
          );
          return;
        }
        await setAudioModeAsync({ allowsRecording: true, playsInSilentMode: true, allowsBackgroundRecording: true });
        const blockId = await getBlockId();
        await recorder.prepareToRecordAsync();
        recorder.record();
        targetRef.current = blockId;
        setPhase('recording');
        onSaved(); // atualiza a Biblioteca (bloco novo)
      } catch (e) {
        appAlert('Não foi possível gravar', String(e));
      } finally {
        busy.current = false;
      }
    },
    [recorder, onSaved]
  );

  const stopAndSave = useCallback(async () => {
    if (busy.current) return;
    busy.current = true;
    try {
      const durationMs = recorder.getStatus().durationMillis;
      await recorder.stop();
      const uri = recorder.uri;
      const blockId = targetRef.current;
      setPhase('idle');
      await setAudioModeAsync({ allowsRecording: false, playsInSilentMode: true, allowsBackgroundRecording: false });
      if (!uri || blockId === null) {
        appAlert('Gravação perdida', 'Não foi possível localizar o arquivo gravado.');
        return;
      }
      const fileName = importRecording(uri);
      await addAudio(blockId, fileName, durationMs);
      targetRef.current = null;
      onSaved();
    } catch (e) {
      setPhase('idle');
      appAlert('Erro ao salvar o áudio', String(e));
    } finally {
      busy.current = false;
    }
  }, [recorder, onSaved]);

  const togglePause = () => {
    if (phase === 'recording') {
      recorder.pause();
      setPhase('paused');
    } else if (phase === 'paused') {
      recorder.record();
      setPhase('recording');
    }
  };

  const onCirclePress = () => {
    if (phase === 'idle') setPopupOpen(true);
    else stopAndSave();
  };

  const sheetItems: SheetItem[] =
    blocks.length === 0
      ? [{ key: 'empty', label: 'Nenhuma nota ainda', muted: true }]
      : blocks.map((b) => ({
          key: String(b.id),
          label: b.noteTitle || b.name,
          onPress: () => {
            setPopupOpen(false);
            start(async () => b.id);
          },
        }));

  const glowScale = pulse.interpolate({ inputRange: [0, 1], outputRange: [1, 1.035] });
  const timerSize = sw * 0.075;
  const pauseSize = sw * 0.15;

  return (
    <View style={styles.flex}>
      <RecTimer
        phase={phase}
        baseMs={state.durationMillis}
        style={[
          styles.timer,
          {
            top: insets.top + sw * 0.1,
            fontSize: timerSize,
            letterSpacing: -timerSize * 0.03,
            color: phase === 'paused' ? colors.gray : colors.text,
          },
        ]}
      />

      {phase === 'idle' && (
        <Pressable
          onPress={onOpenSettings}
          hitSlop={22}
          style={{
            position: 'absolute',
            top: insets.top + sw * 0.1 + timerSize * 0.2,
            right: sw * 0.07,
            width: sw * 0.055,
            height: sw * 0.055,
            borderRadius: sw * 0.0275,
            backgroundColor: colors.text,
          }}
        />
      )}

      {phase === 'idle' && pendingCount > 0 && (
        <Pressable
          onPress={onOpenQueue}
          hitSlop={16}
          style={{
            position: 'absolute',
            alignSelf: 'center',
            top: insets.top + sw * 0.1 + timerSize * 1.9,
          }}
        >
          <Text style={{ color: colors.red, fontFamily: fonts.regular, fontSize: sw * 0.04 }}>
            {pendingCount} {pendingCount === 1 ? 'pendente' : 'pendentes'} ›
          </Text>
        </Pressable>
      )}

      <View style={styles.center} onLayout={(e: LayoutChangeEvent) => setAreaH(e.nativeEvent.layout.height)}>
        <Pressable onPress={onCirclePress} hitSlop={20}>
          <Animated.View
            style={{
              width: circle,
              height: circle,
              alignItems: 'center',
              justifyContent: 'center',
              transform: [{ scale: glowScale }],
            }}
          >
            {/* aura: nasce de dentro do botão enquanto grava e recolhe ao parar */}
            <Aura size={circle} expanded={phase !== 'idle'} moving={phase === 'recording'} />
            {/* brilho: anéis concêntricos com opacidade decrescente */}
            {[0.1, 0.07, 0.05, 0.03].map((a, i) => {
              const d = circle + (i + 1) * sw * 0.022;
              return (
                <View
                  key={i}
                  style={{
                    position: 'absolute',
                    width: d,
                    height: d,
                    borderRadius: d / 2,
                    backgroundColor: `rgba(237,242,245,${a})`,
                  }}
                />
              );
            })}
            <View
              style={{
                width: circle,
                height: circle,
                borderRadius: circle / 2,
                backgroundColor: colors.circle,
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <View
                style={{
                  width: circle * 0.93,
                  height: circle * 0.93,
                  borderRadius: (circle * 0.93) / 2,
                  borderWidth: 2,
                  borderColor: '#DDE3EE',
                  backgroundColor: '#EEF2F5',
                }}
              />
            </View>
          </Animated.View>
        </Pressable>
      </View>

      {phase !== 'idle' && areaH > 0 && (
        <Pressable
          onPress={togglePause}
          hitSlop={16}
          style={{
            position: 'absolute',
            alignSelf: 'center',
            top: areaH / 2 + circle / 2 + sw * 0.12,
            width: pauseSize,
            height: pauseSize,
            borderRadius: pauseSize / 2,
            backgroundColor: colors.text,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          {phase === 'recording' ? (
            <View style={{ flexDirection: 'row', gap: pauseSize * 0.12 }}>
              <View style={{ width: pauseSize * 0.12, height: pauseSize * 0.38, backgroundColor: '#000' }} />
              <View style={{ width: pauseSize * 0.12, height: pauseSize * 0.38, backgroundColor: '#000' }} />
            </View>
          ) : (
            <View
              style={{
                marginLeft: pauseSize * 0.07,
                borderTopWidth: pauseSize * 0.2,
                borderBottomWidth: pauseSize * 0.2,
                borderLeftWidth: pauseSize * 0.32,
                borderTopColor: 'transparent',
                borderBottomColor: 'transparent',
                borderLeftColor: '#000',
              }}
            />
          )}
        </Pressable>
      )}

      <BottomSheet
        visible={popup}
        onClose={() => setPopupOpen(false)}
        title="Gravar novo"
        onTitlePress={() => {
          setPopupOpen(false);
          start(createBlock);
        }}
        subtitle="Selecionar nota"
        items={sheetItems}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: 'transparent' },
  timer: {
    position: 'absolute',
    alignSelf: 'center',
    fontFamily: fonts.light,
    fontVariant: ['tabular-nums'],
  },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
});
