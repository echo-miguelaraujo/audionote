import React from 'react';
import { Modal, Pressable, StyleSheet, Text, TextInput, View, useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors, fonts, RADIUS, SPACE, TYPE, tracking, HIT } from './theme';
import { useKeyboardInset } from './useKeyboardInset';

type ShellProps = {
  visible: boolean;
  onClose: () => void;
  /** Diálogo com teclado: sobe um pouco mais para o campo não ficar escondido. */
  keyboard?: boolean;
  /** Limita a altura do cartão (para conteúdo rolável). */
  maxHeight?: number;
  children: React.ReactNode;
};

/**
 * Base de todos os diálogos do app: mesmo véu, mesma largura, mesmo raio, mesmo fundo.
 * Tocar fora ou no botão voltar chama `onClose`.
 */
export function DialogShell({ visible, onClose, keyboard, maxHeight, children }: ShellProps) {
  const { width: sw, height: sh } = useWindowDimensions();
  const kb = useKeyboardInset();
  const top = sh * (keyboard ? 0.15 : 0.08);
  // Com o teclado aberto, o cartão cabe no espaço que sobra acima dele.
  const cardMax = kb > 0 ? Math.min(maxHeight ?? Infinity, sh - kb - top - sw * SPACE.md) : maxHeight;
  return (
    <Modal visible={visible} transparent animationType="fade" statusBarTranslucent onRequestClose={onClose}>
      <Pressable
        style={{ flex: 1, backgroundColor: colors.scrim, alignItems: 'center', paddingTop: top, paddingBottom: kb }}
        onPress={onClose}
      >
        <Pressable
          accessible={false}
          onPress={() => {}}
          style={{
            width: sw * 0.84,
            maxHeight: cardMax,
            borderRadius: sw * RADIUS.dialog,
            padding: sw * SPACE.lg,
            backgroundColor: colors.paper,
          }}
        >
          {children}
        </Pressable>
      </Pressable>
    </Modal>
  );
}

export function DialogTitle({ children }: { children: React.ReactNode }) {
  const { width: sw } = useWindowDimensions();
  const size = sw * TYPE.title;
  return (
    <Text style={{ color: colors.onLight, fontFamily: fonts.bold, fontSize: size, letterSpacing: tracking(size, 0.0167) }}>
      {children}
    </Text>
  );
}

export type ActionTone = 'default' | 'danger' | 'cancel';

const TONE: Record<ActionTone, string> = {
  default: colors.onLight,
  danger: colors.red,
  cancel: colors.subtle,
};

/** Ação em texto de um diálogo ("Cancelar", "Salvar"…). */
export function DialogAction({
  label,
  onPress,
  tone = 'default',
  disabled,
}: {
  label: string;
  onPress: () => void;
  tone?: ActionTone;
  disabled?: boolean;
}) {
  const { width: sw } = useWindowDimensions();
  return (
    <Pressable onPress={onPress} disabled={disabled} hitSlop={HIT.md} accessibilityRole="button">
      <Text style={{ color: TONE[tone], opacity: disabled ? 0.4 : 1, fontFamily: fonts.bold, fontSize: sw * TYPE.subtitle }}>
        {label}
      </Text>
    </Pressable>
  );
}

/** Linha de ações do rodapé: "Cancelar" à esquerda do botão de confirmar, sempre com o mesmo estilo. */
export function DialogActions({
  onCancel,
  cancelLabel = 'Cancelar',
  confirmLabel,
  onConfirm,
  confirmTone = 'default',
  confirmDisabled,
  extra,
}: {
  onCancel: () => void;
  cancelLabel?: string;
  confirmLabel: string;
  onConfirm: () => void;
  confirmTone?: ActionTone;
  confirmDisabled?: boolean;
  /** Ação extra alinhada à esquerda (ex.: "Excluir", "Sem cor"). */
  extra?: { label: string; onPress: () => void; tone?: ActionTone };
}) {
  const { width: sw } = useWindowDimensions();
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end', gap: sw * SPACE.xl, marginTop: sw * SPACE.lg }}>
      {extra ? (
        <View style={{ marginRight: 'auto' }}>
          <DialogAction label={extra.label} tone={extra.tone ?? 'danger'} onPress={extra.onPress} />
        </View>
      ) : null}
      <DialogAction label={cancelLabel} tone="cancel" onPress={onCancel} />
      <DialogAction label={confirmLabel} tone={confirmTone} onPress={onConfirm} disabled={confirmDisabled} />
    </View>
  );
}

/** Campo de texto de uma linha com sublinhado, usado nos diálogos de nome/link. */
export function DialogInput(props: React.ComponentProps<typeof TextInput>) {
  const { width: sw } = useWindowDimensions();
  return (
    <TextInput
      placeholderTextColor={colors.subtle}
      accessibilityLabel={props.accessibilityLabel ?? props.placeholder}
      {...props}
      style={[
        {
          color: colors.onLight,
          fontFamily: fonts.regular,
          fontSize: sw * TYPE.subtitle,
          borderBottomWidth: 2,
          borderBottomColor: colors.onLight,
          paddingVertical: sw * SPACE.sm,
          marginTop: sw * SPACE.md,
        },
        props.style,
      ]}
    />
  );
}

/** Quadradinho arredondado que mostra a cor escolhida, no canto do título. */
export function ColorChip({ color, bordered }: { color: string; bordered?: boolean }) {
  const { width: sw } = useWindowDimensions();
  const d = sw * 0.085;
  return (
    <View
      style={{
        width: d,
        height: d,
        borderRadius: d * 0.38,
        backgroundColor: color,
        borderWidth: bordered ? 1 : 0,
        borderColor: colors.line,
      }}
    />
  );
}

/** Base das janelas que sobem de baixo (lista de notas, de coleções…): mesmo véu, margem e raio. */
export function SheetShell({
  visible,
  onClose,
  height,
  maxHeight,
  lift = 0,
  children,
}: {
  visible: boolean;
  onClose: () => void;
  height?: number;
  maxHeight?: number;
  /** Sobe a janela inteira (ex.: altura do teclado) para os campos não ficarem escondidos. */
  lift?: number;
  children: React.ReactNode;
}) {
  const { width: sw } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      statusBarTranslucent
      navigationBarTranslucent
      onRequestClose={onClose}
    >
      <View style={{ flex: 1, justifyContent: 'flex-end', paddingBottom: lift }}>
        <Pressable style={{ ...StyleSheet.absoluteFillObject, backgroundColor: colors.scrim }} onPress={onClose} />
        <Pressable
          accessible={false}
          onPress={() => {}}
          style={{
            marginHorizontal: sw * SPACE.sm,
            marginBottom: insets.bottom + sw * 0.021,
            height,
            maxHeight,
            borderRadius: sw * RADIUS.sheet,
            backgroundColor: colors.paper,
            overflow: 'hidden',
          }}
        >
          {children}
        </Pressable>
      </View>
    </Modal>
  );
}
