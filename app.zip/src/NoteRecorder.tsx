import React, { forwardRef, useCallback, useEffect, useImperativeHandle, useRef, useState } from 'react';
import { Pressable, Text, View, useWindowDimensions } from 'react-native';
import {
  RecordingPresets,
  requestRecordingPermissionsAsync,
  setAudioModeAsync,
  useAudioRecorder,
  useAudioRecorderState,
} from 'expo-audio';
import { activateKeepAwakeAsync, deactivateKeepAwake } from 'expo-keep-awake';
import { addAudio } from './db';
import { appAlert, appError } from './dialog';
import { formatTimer } from './format';
import { importRecording } from './storage';
import { getRecState } from './widget';
import { colors, fonts, SPACE, HIT, tracking } from './theme';

export type NotePhase = 'idle' | 'recording' | 'paused';
export type NoteRecorderHandle = {
  /** Se estiver gravando, para e salva o áudio. Use antes de fechar a nota. */
  finish: () => Promise<void>;
};

// Mesmas opções da tela de Gravação: voz em mono, 64 kbps.
const RECORDING_OPTIONS = { ...RecordingPresets.HIGH_QUALITY, numberOfChannels: 1, bitRate: 64000 };

type Props = {
  blockId: number;
  onPhase: (p: NotePhase) => void;
  /** Chamado depois que o áudio foi salvo na nota (para atualizar o contador e transcrever). */
  onSaved: () => void;
};

/** Gravar direto dentro da nota: aparece no cabeçalho e grava para esta mesma nota. */
export const NoteRecorder = forwardRef<NoteRecorderHandle, Props>(function NoteRecorder(
  { blockId, onPhase, onSaved },
  ref
) {
  const { width: sw } = useWindowDimensions();
  const recorder = useAudioRecorder(RECORDING_OPTIONS);
  const state = useAudioRecorderState(recorder, 250);
  const [phase, setPhase] = useState<NotePhase>('idle');
  const phaseRef = useRef<NotePhase>('idle');
  const busy = useRef(false);

  const change = useCallback(
    (p: NotePhase) => {
      phaseRef.current = p;
      setPhase(p);
      onPhase(p);
    },
    [onPhase]
  );

  useEffect(() => {
    if (phase === 'recording') {
      activateKeepAwakeAsync('gravacao-nota').catch(() => {});
      return () => {
        deactivateKeepAwake('gravacao-nota').catch(() => {});
      };
    }
  }, [phase]);

  const start = async () => {
    if (busy.current) return;
    if (getRecState().state !== 'idle') {
      appAlert('Gravação em andamento', 'Já existe uma gravação em andamento na aba Gravação. Pare-a antes de gravar aqui.');
      return;
    }
    busy.current = true;
    try {
      const perm = await requestRecordingPermissionsAsync();
      if (!perm.granted) {
        appAlert('Microfone bloqueado', 'Permita o microfone em Configurações > Apps > Ideias > Permissões.');
        return;
      }
      await setAudioModeAsync({ allowsRecording: true, playsInSilentMode: true, allowsBackgroundRecording: true });
      await recorder.prepareToRecordAsync();
      recorder.record();
      change('recording');
    } catch (e) {
      appError('Não foi possível gravar', e);
    } finally {
      busy.current = false;
    }
  };

  const stopAndSave = useCallback(async () => {
    if (busy.current || phaseRef.current === 'idle') return;
    busy.current = true;
    try {
      const durationMs = recorder.getStatus().durationMillis;
      await recorder.stop();
      const uri = recorder.uri;
      change('idle');
      await setAudioModeAsync({ allowsRecording: false, playsInSilentMode: true, allowsBackgroundRecording: false });
      if (!uri) {
        appAlert('Gravação perdida', 'Não foi possível localizar o arquivo gravado.');
        return;
      }
      const fileName = importRecording(uri);
      await addAudio(blockId, fileName, durationMs);
      onSaved();
    } catch (e) {
      change('idle');
      appError('Erro ao salvar o áudio', e);
    } finally {
      busy.current = false;
    }
  }, [recorder, blockId, onSaved, change]);

  useImperativeHandle(ref, () => ({ finish: stopAndSave }), [stopAndSave]);

  const togglePause = () => {
    if (phase === 'recording') {
      recorder.pause();
      change('paused');
    } else if (phase === 'paused') {
      recorder.record();
      change('recording');
    }
  };

  const size = sw * 0.047;
  const text = { fontFamily: fonts.bold, fontSize: size, letterSpacing: tracking(size, 0.03) };

  if (phase === 'idle') {
    return (
      <Pressable onPress={() => start().catch(() => {})} hitSlop={HIT.md} accessibilityRole="button" style={{ flexDirection: 'row', alignItems: 'center', gap: sw * SPACE.sm }}>
        <View style={{ width: sw * 0.036, height: sw * 0.036, borderRadius: sw * 0.018, backgroundColor: colors.red }} />
        <Text style={[text, { color: colors.onDark }]}>Gravar</Text>
      </Pressable>
    );
  }

  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: sw * SPACE.lg }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: sw * SPACE.sm }}>
        <View
          style={{
            width: sw * 0.036,
            height: sw * 0.036,
            borderRadius: sw * 0.018,
            backgroundColor: phase === 'recording' ? colors.red : colors.muted,
          }}
        />
        <Text style={[text, { color: phase === 'paused' ? colors.muted : colors.onDark }]}>
          {formatTimer(state.durationMillis).replace(/^00:/, '')}
        </Text>
      </View>
      <Pressable onPress={togglePause} hitSlop={HIT.md} accessibilityRole="button">
        <Text style={[text, { color: colors.onDark }]}>{phase === 'recording' ? 'Pausar' : 'Retomar'}</Text>
      </Pressable>
      <Pressable onPress={() => stopAndSave().catch(() => {})} hitSlop={HIT.md} accessibilityRole="button">
        <Text style={[text, { color: colors.red }]}>Parar</Text>
      </Pressable>
    </View>
  );
});
