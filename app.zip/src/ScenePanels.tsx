import React, { useMemo, useRef, useState } from 'react';
import { Image, PanResponder, Pressable, ScrollView, Text, View } from 'react-native';
import { Icon } from './Icon';
import { mediaUri } from './media';
import { colors, fonts, RADIUS, SPACE, TYPE } from './theme';

export type PanelKind = 'shoot' | 'edit';

/** Uma cena como o painel precisa dela. */
export type PanelScene = {
  subId: number;
  name: string;
  cover: string | null;
  /** Local e plano, em uma linha. */
  detail: string;
  /** Posição guardada neste painel (null = ainda sem posição). */
  order: number | null;
  /** Posição no quadro: desempata cenas sem ordem. */
  board: number;
  done: boolean;
};

const COPY: Record<PanelKind, { title: string; hint: string }> = {
  shoot: { title: 'Gravação', hint: 'Arraste pelo ícone para ordenar como será gravado no dia.' },
  edit: { title: 'Edição', hint: 'A ordem em que as cenas entram no vídeo final.' },
};

type Props = {
  kind: PanelKind;
  /** Largura de referência da tela (mesma unidade `u` do resto do app). */
  u: number;
  /** Altura do cabeçalho, para o painel começar logo abaixo dele. */
  top: number;
  bottom: number;
  scenes: PanelScene[];
  onReorder: (kind: PanelKind, ids: number[]) => void;
  onToggleDone: (subId: number, done: boolean) => void;
};

/** Com ordem guardada vem primeiro, na ordem dela; as demais seguem pela posição no quadro. */
export function sortScenes(list: PanelScene[]): PanelScene[] {
  return [...list].sort((a, b) => {
    if (a.order != null && b.order != null) return a.order - b.order || a.subId - b.subId;
    if (a.order != null) return -1;
    if (b.order != null) return 1;
    return a.board - b.board || a.subId - b.subId;
  });
}

/** Painel de ordem das cenas. Cobre o quadro; o cabeçalho e os botões laterais ficam por cima. */
export function ScenePanel({ kind, u, top, bottom, scenes, onReorder, onToggleDone }: Props) {
  const c = COPY[kind];
  const rows = useMemo(() => sortScenes(scenes), [scenes]);
  const ROW = u * 0.2;
  const [drag, setDrag] = useState<{ from: number; dy: number } | null>(null);
  const fromRef = useRef(-1);
  const n = rows.length;
  const doneCount = rows.filter((r) => r.done).length;

  const target = (from: number, dy: number) => Math.max(0, Math.min(n - 1, Math.round(from + dy / ROW)));
  const finish = (dy: number) => {
    const from = fromRef.current;
    fromRef.current = -1;
    setDrag(null);
    if (from < 0) return;
    const to = target(from, dy);
    if (to === from) return;
    const ids = rows.map((r) => r.subId);
    const [m] = ids.splice(from, 1);
    ids.splice(to, 0, m);
    onReorder(kind, ids);
  };

  const shiftOf = (i: number) => {
    if (!drag) return 0;
    const to = target(drag.from, drag.dy);
    if (i === drag.from) return drag.dy;
    if (drag.from < to && i > drag.from && i <= to) return -ROW;
    if (drag.from > to && i < drag.from && i >= to) return ROW;
    return 0;
  };

  return (
    <View style={{ position: 'absolute', left: 0, right: 0, top: 0, bottom: 0, backgroundColor: colors.paper, paddingTop: top + u * SPACE.lg }}>
      <View style={{ paddingHorizontal: u * SPACE.xl, marginBottom: u * SPACE.md }}>
        <Text style={{ color: colors.onLight, fontFamily: fonts.bold, fontSize: u * TYPE.body }}>
          {c.title}
          {kind === 'shoot' && n > 0 ? `  ·  ${doneCount} de ${n} gravadas` : ''}
        </Text>
        <Text style={{ color: colors.subtle, fontFamily: fonts.regular, fontSize: u * TYPE.caption, marginTop: u * SPACE.sm }}>{c.hint}</Text>
      </View>
      {kind === 'shoot' ? (
        <ScrollView scrollEnabled={!drag} contentContainerStyle={{ paddingHorizontal: u * SPACE.xl, paddingBottom: bottom + u * 0.2 }}>
          {n === 0 ? (
            <Text style={{ color: colors.subtle, fontFamily: fonts.regular, fontSize: u * TYPE.body }}>Ainda não há cenas neste projeto.</Text>
          ) : null}
          {rows.map((r, i) => (
            <SceneRow
              key={r.subId}
              scene={r}
              index={i}
              u={u}
              h={ROW}
              dragging={drag?.from === i}
              shift={shiftOf(i)}
              onStart={() => {
                fromRef.current = i;
                setDrag({ from: i, dy: 0 });
              }}
              onMove={(dy) => setDrag({ from: i, dy })}
              onEnd={finish}
              onToggleDone={onToggleDone}
            />
          ))}
        </ScrollView>
      ) : null}
    </View>
  );
}

type RowProps = {
  scene: PanelScene;
  index: number;
  u: number;
  h: number;
  dragging: boolean;
  shift: number;
  onStart: () => void;
  onMove: (dy: number) => void;
  onEnd: (dy: number) => void;
  onToggleDone: (subId: number, done: boolean) => void;
};

function SceneRow({ scene, index, u, h, dragging, shift, onStart, onMove, onEnd, onToggleDone }: RowProps) {
  const pan = useMemo(
    () =>
      PanResponder.create({
        onStartShouldSetPanResponder: () => true,
        onMoveShouldSetPanResponder: () => true,
        onPanResponderTerminationRequest: () => false,
        onPanResponderGrant: onStart,
        onPanResponderMove: (_, g) => onMove(g.dy),
        onPanResponderRelease: (_, g) => onEnd(g.dy),
        onPanResponderTerminate: (_, g) => onEnd(g.dy),
      }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [index, scene.subId]
  );
  const thumb = h * 0.7;
  return (
    <View
      style={{
        height: h,
        flexDirection: 'row',
        alignItems: 'center',
        gap: u * SPACE.md,
        borderBottomWidth: 1,
        borderBottomColor: colors.hairline,
        backgroundColor: dragging ? colors.paper : 'transparent',
        zIndex: dragging ? 10 : 0,
        elevation: dragging ? 6 : 0,
        shadowOpacity: dragging ? 0.2 : 0,
        shadowRadius: 8,
        transform: [{ translateY: shift }],
      }}
    >
      <View {...pan.panHandlers} accessibilityLabel="Arrastar para reordenar" accessibilityRole="button" style={{ padding: u * 0.02 }}>
        <Icon name="list" size={u * 0.06} color={colors.subtle} />
      </View>
      <Text style={{ width: u * 0.07, color: colors.onLight, fontFamily: fonts.bold, fontSize: u * TYPE.body, textAlign: 'center' }}>{index + 1}</Text>
      <View style={{ width: thumb, height: thumb, borderRadius: u * 0.02, overflow: 'hidden', backgroundColor: colors.hairline }}>
        {scene.cover ? <Image source={{ uri: mediaUri(scene.cover) }} resizeMode="cover" style={{ width: thumb, height: thumb }} /> : null}
      </View>
      <View style={{ flex: 1 }}>
        <Text numberOfLines={1} style={{ color: colors.onLight, fontFamily: fonts.bold, fontSize: u * TYPE.body }}>{scene.name}</Text>
        {scene.detail ? (
          <Text numberOfLines={1} style={{ color: colors.subtle, fontFamily: fonts.regular, fontSize: u * TYPE.caption }}>{scene.detail}</Text>
        ) : null}
      </View>
      <Pressable
        accessibilityRole="checkbox"
        accessibilityState={{ checked: scene.done }}
        accessibilityLabel="Cena gravada"
        hitSlop={10}
        onPress={() => onToggleDone(scene.subId, !scene.done)}
        style={{
          width: u * 0.08,
          height: u * 0.08,
          borderRadius: u * 0.04,
          alignItems: 'center',
          justifyContent: 'center',
          backgroundColor: scene.done ? colors.onLight : 'transparent',
          borderWidth: 2,
          borderColor: colors.onLight,
        }}
      >
        {scene.done ? <Icon name="check" size={u * 0.05} color={colors.paper} /> : null}
      </Pressable>
    </View>
  );
}
