/**
 * Biblioteca do layout livre guardada no aparelho (SQLite): estilos de texto com nome e modelos de página próprios.
 * Não vai para a nota nem para a nuvem.
 */
import { getDb } from './db';

export type LibKind = 'style' | 'tpl';
export type LibItem = { id: number; kind: LibKind; name: string; data: unknown };

async function ready() {
  const db = await getDb();
  await db.execAsync(`CREATE TABLE IF NOT EXISTS free_lib (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kind TEXT NOT NULL,
    name TEXT NOT NULL,
    data TEXT NOT NULL,
    created_at INTEGER NOT NULL
  );`);
  return db;
}

export async function listLib(): Promise<LibItem[]> {
  const db = await ready();
  const rows = await db.getAllAsync<{ id: number; kind: string; name: string; data: string }>(
    'SELECT id, kind, name, data FROM free_lib ORDER BY created_at ASC, id ASC',
  );
  const out: LibItem[] = [];
  for (const r of rows) {
    try {
      out.push({ id: r.id, kind: r.kind === 'tpl' ? 'tpl' : 'style', name: r.name, data: JSON.parse(r.data) });
    } catch {
      /* item corrompido: ignora */
    }
  }
  return out;
}

export async function addLib(kind: LibKind, name: string, data: unknown): Promise<void> {
  const db = await ready();
  await db.runAsync('INSERT INTO free_lib (kind, name, data, created_at) VALUES (?, ?, ?, ?)', [
    kind,
    name.trim().slice(0, 60),
    JSON.stringify(data ?? {}),
    Date.now(),
  ]);
}

export async function deleteLib(id: number): Promise<void> {
  const db = await ready();
  await db.runAsync('DELETE FROM free_lib WHERE id = ?', [id]);
}

/** JavaScript que entrega a biblioteca à página do layout livre. */
export async function libScript(): Promise<string> {
  const items = await listLib();
  const pack = { style: items.filter((i) => i.kind === 'style'), tpl: items.filter((i) => i.kind === 'tpl') };
  const json = JSON.stringify(pack).replace(/</g, '\\u003c').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
  return `window.setLib&&window.setLib(${json});true;`;
}
