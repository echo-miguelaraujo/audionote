import { getSetting, setSetting } from './settings';
import { Ficha, newFichaId } from './ficha';

// Modelos de ficha: guardados neste aparelho (como "Minhas fontes"), não vão para a nuvem.
export type FichaTemplate = {
  id: string;
  name: string;
  title: string;
  mode: Ficha['mode'];
  html: string;
  /** Só os nomes dos campos: o preenchimento é de cada ficha. */
  labels: string[];
};

const KEY = 'ficha_templates';

export async function loadFichaTemplates(): Promise<FichaTemplate[]> {
  try {
    const raw = await getSetting(KEY);
    const j = raw ? JSON.parse(raw) : [];
    return Array.isArray(j)
      ? j
          .filter((t) => t && typeof t.id === 'string' && typeof t.name === 'string')
          .map((t) => ({
            id: t.id,
            name: t.name,
            title: typeof t.title === 'string' ? t.title : '',
            mode: t.mode === 'fields' ? 'fields' : 'text',
            html: typeof t.html === 'string' ? t.html : '',
            labels: Array.isArray(t.labels) ? t.labels.filter((l: unknown) => typeof l === 'string') : [],
          }))
      : [];
  } catch {
    return [];
  }
}

const persist = (list: FichaTemplate[]) => setSetting(KEY, list.length ? JSON.stringify(list) : '');

/** Guarda a ficha como modelo (campos sem valores). Devolve a lista nova. */
export async function saveFichaTemplate(name: string, f: Ficha): Promise<FichaTemplate[]> {
  const list = await loadFichaTemplates();
  const t: FichaTemplate = {
    id: newFichaId(),
    name,
    title: f.title,
    mode: f.mode,
    html: f.html,
    labels: f.fields.map((x) => x.label),
  };
  const next = [...list, t];
  await persist(next);
  return next;
}

export async function removeFichaTemplate(id: string): Promise<FichaTemplate[]> {
  const next = (await loadFichaTemplates()).filter((t) => t.id !== id);
  await persist(next);
  return next;
}

/** Ficha nova a partir do modelo (mantém o vínculo, se houver). */
export const fichaFromTemplate = (t: FichaTemplate, keep: Ficha): Ficha => ({
  title: keep.title.trim() ? keep.title : t.title,
  mode: t.mode,
  html: t.html,
  fields: t.labels.map((label) => ({ id: newFichaId(), label, value: '' })),
  link: keep.link,
});
