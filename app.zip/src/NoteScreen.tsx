import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { appAlert, appToast, appError, appMenu } from './dialog';
import {
  ActivityIndicator,
  Animated,
  BackHandler,
  Keyboard,
  Linking,
  Pressable,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { WebView, WebViewMessageEvent } from 'react-native-webview';
import * as ImagePicker from 'expo-image-picker';
import * as DocumentPicker from 'expo-document-picker';
import * as IntentLauncher from 'expo-intent-launcher';
import * as Sharing from 'expo-sharing';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ActionItem, ActionMenu } from './ActionMenu';
import { BottomSheet, SheetItem } from './BottomSheet';
import { Icon } from './Icon';
import {
  FlatCollection,
  createCollection,
  getBlock,
  getNoteJson,
  isFavorite,
  linkNoteToCollection,
  listAudios,
  createNoteWithTitle,
  createTemplate,
  findBlockIdByUuid,
  listBacklinks,
  listBlocks,
  noteTitlesByUuids,
  searchNotesForLink,
  setBlockParent,
  setPinned,
  listCollectionTree,
  listNoteLinks,
  saveNoteJson,
  setBlockTags,
  setFavorite,
  unlinkNoteFromCollection,
} from './db';
import { EDITOR_HTML } from './editorHtml';
import { TagsDialog } from './TagsDialog';
import { FontsScreen } from './FontsScreen';
import { setFontsScript, useFontsVersion } from './fonts';
import { noteJsonForTemplate } from './noteTemplates';
import { tagStats } from './libraryFilters';
import { exportNotePdf } from './exportPdf';
import { NotePagesInput, buildPagerHtml, exportNotePdf169, savePagesToGallery } from './noteShare';
import { NotePagesCapture } from './NotePagesCapture';
import { mediaFile, mediaUri, mimeFor, nameFromRef, saveMedia, toStoredHtml, toWebHtml } from './media';
import { fetchPreviewText, saveCover } from './linkPreview';
import { askImages, imagesHtml, readPickedImages } from './imageNote';
import { Note, appendSections, emptyNote, htmlToText, parseNote } from './note';
import { FREE_HTML } from './freeHtml';
import { freeTitle, freeToHtml, parseFree, seedFromFlow } from './freeLayout';
import { flowToFree, freeToFlow, makeSync } from './layoutSync';
import { processQueue, setEditingBlock, setOpenBlock, subscribeQueue } from './queue';
import { NotePhase, NoteRecorder, NoteRecorderHandle } from './NoteRecorder';
import { PromptDialog } from './PromptDialog';
import { Proposal, SuggestMode, applyProposals, proposeCustom, proposeForNotes } from './restructure';
import { AskAiDialog } from './AskAiDialog';
import { HeaderAction, ScreenHeader } from './ScreenHeader';
import { CardColorDialog } from './CardColorDialog';
import { getNoteScale, getRecentColors, pushRecentColor, setNoteScale } from './settings';
import { StateMessage } from './StateMessage';
import { colors, fonts, TYPE, SPACE, HIT, MIN_TOUCH, RADIUS, tracking } from './theme';

type Props = {
  blockId: number;
  onClose: () => void;
  /** Abre uma coleção (a tela da nota é fechada antes). */
  onOpenCollection: (collectionId: number) => void;
  /** Abre outra nota (link, subnota, nota-pai ou menção). O voltar retorna a esta. */
  onOpenNote: (blockId: number) => void;
};

/** Fundo claro (true) ou escuro (false), para escolher o estilo da barra de status sobre a página. */
const isLightHex = (hex: string): boolean => {
  const h = /^#[0-9a-f]{6}$/i.test(hex) ? hex.slice(1) : 'FFFFFF';
  const r = parseInt(h.slice(0, 2), 16), g = parseInt(h.slice(2, 4), 16), b = parseInt(h.slice(4, 6), 16);
  return (0.299 * r + 0.587 * g + 0.114 * b) / 255 >= 0.45;
};

/** Texto -> literal JS seguro para injetar na WebView. */
const lit = (v: unknown): string =>
  JSON.stringify(v).replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');

export function NoteScreen({ blockId, onClose, onOpenCollection, onOpenNote }: Props) {
  const { width: sw } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const web = useRef<WebView>(null);
  const [loaded, setLoaded] = useState(false);
  const [editing, setEditing] = useState(false);
  const [fav, setFav] = useState(false);
  const [pendingInfo, setPendingInfo] = useState(0);
  const [exporting, setExporting] = useState(false);
  /** Menu "Compartilhar" (PDF A4, PDF 16:9, imagens 16:9) e, durante a geração de imagens, o HTML paginado. */
  const [shareMenu, setShareMenu] = useState(false);
  const [pager, setPager] = useState<string | null>(null);
  /** Sugestões de estrutura mostradas dentro da própria nota (abaixo do título). */
  const suggestRef = useRef<Proposal[]>([]);
  const suggestRun = useRef(0);
  /** Pedido livre à IA: janela de texto aberta (guarda o trecho selecionado na hora do toque no ✦). */
  const [askAi, setAskAi] = useState<{ sel: string } | null>(null);
  const [reading, setReading] = useState(false);
  const [kbPad, setKbPad] = useState(0);
  const [linkDlg, setLinkDlg] = useState<{ current: string | null } | null>(null);
  /** Cor personalizada pedida pelo editor: 'text' (cor do texto) ou 'hilite' (marca-texto). */
  const [colorFor, setColorFor] = useState<'text' | 'hilite' | 'frame' | 'bg' | null>(null);
  const recentRef = useRef<string[]>([]);
  /** Links entre notas: menções a esta nota (backlinks), nota-pai e se está fixada. */
  const blRef = useRef<{ id: number; title: string }[]>([]);
  const [blCount, setBlCount] = useState(0);
  const [parent, setParent] = useState<{ id: number; title: string } | null>(null);
  const [pinned, setPinnedState] = useState(false);
  const [tplDlg, setTplDlg] = useState(false);
  /** Tags da nota e janela para editá-las. */
  const [tags, setTags] = useState<string[]>([]);
  const [tagsDlg, setTagsDlg] = useState<{ existing: { key: string; name: string; count: number }[] } | null>(null);
  const [noteMenu, setNoteMenu] = useState(false);
  /** Layout da nota: 'flow' = nota corrida (editor de texto); 'free' = layout livre (caixas e imagens posicionáveis). */
  const [layout, setLayout] = useState<'flow' | 'free'>('flow');
  const layoutRef = useRef<'flow' | 'free'>('flow');
  /** Layout livre: a página ocupa a tela toda e a barra de cima flutua sobre ela (leitura em tela cheia). */
  const overlay = layout === 'free';
  const immersive = overlay && !editing;
  const noteMenuItems: ActionItem[] = [
    ...(layout === 'free'
      ? [
          { key: 'edit', label: 'Editar página', onPress: () => run('window.beginEdit()') },
          { key: 'tags', label: tags.length > 0 ? `Tags (${tags.length})` : 'Adicionar tags', onPress: () => openTags().catch(() => {}) },
        ]
      : []),
    layout === 'free'
      ? { key: 'flow', label: 'Voltar para nota corrida', onPress: () => switchLayout('flow').catch(() => {}) }
      : { key: 'free', label: 'Layout livre (diagramação)', onPress: () => switchLayout('free').catch(() => {}) },
    ...(layout === 'flow'
      ? [
          { key: 'find', label: 'Localizar na nota', onPress: () => run('window.openFind()') },
          { key: 'suggest', label: 'Sugestões de ligação', onPress: () => run('window.toggleSuggest()') },
        ]
      : []),
    ...(layout === 'flow' && blCount > 0
      ? [{ key: 'backlinks', label: `Ver menções (${blCount})`, onPress: () => run('window.scrollToBacklinks()') }]
      : []),
    { key: 'share', label: 'Compartilhar…', disabled: exporting, onPress: () => setShareMenu(true) },
    {
      key: 'pin',
      label: pinned ? 'Desafixar do topo' : 'Fixar no topo',
      onPress: async () => {
        await setPinned(blockId, !pinned).catch(() => {});
        setPinnedState(!pinned);
      },
    },
    { key: 'tpl', label: 'Salvar como modelo', onPress: () => setTplDlg(true) },
    ...(parent
      ? [
          {
            key: 'unlink',
            label: 'Desvincular da nota-pai',
            onPress: async () => {
              await setBlockParent(blockId, null).catch(() => {});
              setParent(null);
            },
          },
        ]
      : []),
  ];

  const saveAsTemplate = async (name: string) => {
    setTplDlg(false);
    try {
      await settle();
      const json = await getNoteJson(blockId);
      if (!json) return;
      await createTemplate(name, noteJsonForTemplate(json));
      appToast('Modelo salvo', `"${name}" aparece em Nova nota › A partir de modelo.`);
    } catch (e) {
      appError('Não consegui salvar o modelo', e);
    }
  };

  const openTags = async () => {
    try {
      setTagsDlg({ existing: tagStats(await listBlocks()) });
    } catch (e) {
      appError('Não consegui ler as tags', e);
    }
  };
  /** Barra "Localizar" aberta no editor (o voltar do Android fecha ela primeiro). */
  const findOpenRef = useRef(false);
  const [videoDlg, setVideoDlg] = useState(false);
  /** Janela do Google Fonts aberta pelo botão "Fonte" do editor. */
  const [fontsOpen, setFontsOpen] = useState(false);
  const fontsVer = useFontsVersion();
  const [recPhase, setRecPhase] = useState<NotePhase>('idle');
  // Tela cheia: a barra de cima some ao rolar para baixo e volta ao rolar para cima ou tocar na página.
  const [pageBg, setPageBg] = useState('#FFFFFF');
  const [chrome, setChrome] = useState(true);
  const [headH, setHeadH] = useState(0);
  const chromeAnim = useRef(new Animated.Value(1)).current;
  const chromeOn = !immersive || chrome || recPhase !== 'idle';
  useEffect(() => {
    Animated.timing(chromeAnim, { toValue: chromeOn ? 1 : 0, duration: 180, useNativeDriver: true }).start();
  }, [chromeOn, chromeAnim]);
  useEffect(() => {
    if (!editing) setChrome(true);
  }, [editing]);
  /** Coleções em que esta nota está vinculada. */
  const [links, setLinks] = useState<FlatCollection[]>([]);
  /** null = lista fechada; senão, todas as coleções (para vincular/desvincular). */
  const [colTree, setColTree] = useState<FlatCollection[] | null>(null);
  const [newColDlg, setNewColDlg] = useState(false);
  const recRef = useRef<NoteRecorderHandle>(null);

  const noteRef = useRef<Note>(emptyNote());
  const readyRef = useRef(false);
  const loadedRef = useRef(false);
  const editingRef = useRef(false);
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const dirty = useRef(false);
  const waiters = useRef<(() => void)[]>([]);
  const curH = useRef(0);
  const fullH = useRef(0);
  const scaleRef = useRef(1);

  const run = useCallback((code: string) => {
    web.current?.injectJavaScript(`${code};true;`);
  }, []);

  /** Layout livre: a página começa sob a barra ao editar e ocupa a tela toda ao ler. Valores lidos na hora do envio. */
  const insetsRef = useRef({ top: 0, bottom: 0 });
  const pushInsets = useCallback(() => {
    run(`window.setInsets&&window.setInsets(${Math.round(insetsRef.current.top)},${Math.round(insetsRef.current.bottom)})`);
  }, [run]);

  // ---------- enviar a nota para o editor ----------
  /** Títulos atuais dos links/cartões de nota (e "nota excluída") e a lista de menções. */
  const pushLinkInfo = useCallback(async () => {
    const html = noteRef.current.html;
    const uuids = [...new Set([...html.matchAll(/data-note="([0-9a-fA-F-]{8,40})"/g)].map((x) => x[1]))];
    if (uuids.length > 0) run(`window.refreshNoteLinks(${lit(await noteTitlesByUuids(uuids))})`);
    run(`window.setBacklinks(${lit(blRef.current)})`);
  }, [run]);

  const sendInit = useCallback(() => {
    if (!readyRef.current || !loadedRef.current) return;
    const n = noteRef.current;
    if (layoutRef.current === 'free') {
      // Imagens guardadas como app-media:// viram caminhos reais para a WebView.
      const free = n.free ? JSON.parse(toWebHtml(JSON.stringify(n.free))) : null;
      const seed = n.free ? null : seedFromFlow(n.title, htmlToText(n.html), toWebHtml(n.html));
      pushInsets();
      run(`window.initFree(${lit({ free, seed, editable: editingRef.current })})`);
      return;
    }
    run(
      `window.initNote(${lit({
        title: n.title,
        html: toWebHtml(n.html),
        cover: n.cover ? mediaUri(n.cover) : null,
        editable: editingRef.current,
        scale: scaleRef.current,
        recent: recentRef.current,
      })})`
    );
    pushLinkInfo().catch(() => {});
  }, [run, pushLinkInfo, pushInsets]);

  // Últimas cores personalizadas: carregadas uma vez; o editor recebe junto com a nota.
  useEffect(() => {
    getRecentColors()
      .then((l) => {
        recentRef.current = l;
        run(`window.setRecentColors(${lit(l)})`);
      })
      .catch(() => {});
  }, [run]);

  // Minhas fontes: o editor recebe a lista (e o @font-face) ao ficar pronto e a cada mudança.
  useEffect(() => {
    if (readyRef.current) run(setFontsScript());
  }, [fontsVer, run]);

  useEffect(() => {
    setOpenBlock(blockId);
    return () => setOpenBlock(null);
  }, [blockId]);

  // ---------- carregar / salvar ----------
  const reload = useCallback(async () => {
    const [b, json, audios, favorite, linked] = await Promise.all([
      getBlock(blockId),
      getNoteJson(blockId),
      listAudios(blockId),
      isFavorite(blockId),
      listNoteLinks(blockId),
    ]);
    setTags(b?.tags ?? []);
    setParent(b && b.parentId !== null ? { id: b.parentId, title: b.parentTitle ?? '' } : null);
    setPinnedState(!!b?.pinned);
    blRef.current = b?.uuid ? await listBacklinks(blockId, b.uuid).catch(() => []) : [];
    setBlCount(blRef.current.length);
    setLinks(linked);
    noteRef.current = parseNote(json) ?? emptyNote();
    const lay = noteRef.current.layout === 'free' ? 'free' : 'flow';
    if (lay !== layoutRef.current) readyRef.current = false; // a outra página (WebView) vai ser montada e avisa quando estiver pronta
    layoutRef.current = lay;
    setLayout(lay);
    loadedRef.current = true;
    setLoaded(true);
    setFav(favorite);
    setPendingInfo(audios.filter((a) => a.status === 'pending' || a.status === 'error').length);
    sendInit();
  }, [blockId, sendInit]);

  useEffect(() => {
    getNoteScale()
      .then((v) => {
        scaleRef.current = v;
        run(`window.setScale && window.setScale(${v})`);
      })
      .catch(() => {});
  }, [run]);

  useEffect(() => {
    reload().catch((e) => appError('Erro ao abrir a nota', e));
    return subscribeQueue(() => {
      if (!editingRef.current) reload().catch(() => {});
    });
  }, [reload]);

  const flush = useCallback(async () => {
    if (saveTimer.current) {
      clearTimeout(saveTimer.current);
      saveTimer.current = null;
    }
    if (dirty.current) {
      dirty.current = false;
      await saveNoteJson(blockId, JSON.stringify(noteRef.current));
    }
  }, [blockId]);

  const scheduleSave = useCallback(() => {
    dirty.current = true;
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => {
      flush().catch(() => {});
    }, 500);
  }, [flush]);

  useEffect(
    () => () => {
      flush().catch(() => {});
      setEditingBlock(null);
    },
    [flush]
  );

  /** Pede ao editor o texto atual e espera a resposta (ou 500 ms), para nunca perder o que foi digitado. */
  const syncFromWeb = useCallback(
    () =>
      new Promise<void>((resolve) => {
        if (!readyRef.current) return resolve();
        const t = setTimeout(resolve, 500);
        waiters.current.push(() => {
          clearTimeout(t);
          resolve();
        });
        run('window.flushNow()');
      }),
    [run]
  );

  // ---------- modo de edição ----------
  // O editor liga a edição sozinho no duplo toque (precisa ser dentro do gesto para abrir o teclado).
  const onEditingStarted = () => {
    editingRef.current = true;
    setEditingBlock(blockId);
    setEditing(true);
  };

  const finishEditing = useCallback(async () => {
    Keyboard.dismiss();
    await syncFromWeb();
    run('window.setEditable(false)');
    await flush();
    editingRef.current = false;
    setEditingBlock(null);
    setEditing(false);
    processQueue().catch(() => {}); // libera o que ficou esperando a edição
  }, [flush, run, syncFromWeb]);

  // Depois de gravar dentro da nota: atualiza o aviso de pendentes e já tenta transcrever.
  const afterRecorded = useCallback(() => {
    listAudios(blockId)
      .then((a) => setPendingInfo(a.filter((x) => x.status === 'pending' || x.status === 'error').length))
      .catch(() => {});
    processQueue().catch(() => {});
  }, [blockId]);

  const close = useCallback(async () => {
    await recRef.current?.finish(); // se estiver gravando, salva o áudio antes de sair
    if (editingRef.current) await finishEditing();
    else await syncFromWeb();
    await flush();
    onClose();
  }, [finishEditing, flush, onClose, syncFromWeb]);

  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (findOpenRef.current) {
        run('window.closeFind()');
        return true;
      }
      if (editingRef.current) finishEditing().catch(() => {});
      else close().catch(() => {});
      return true;
    });
    return () => sub.remove();
  }, [finishEditing, close, run]);

  // ---------- teclado: mantém a barra de ferramentas visível ----------
  useEffect(() => {
    let timer: ReturnType<typeof setTimeout> | undefined;
    const show = Keyboard.addListener('keyboardDidShow', (e) => {
      web.current?.injectJavaScript('window.kbHidden&&window.kbHidden(false);true;');
      const h = e.endCoordinates?.height ?? 0;
      if (timer) clearTimeout(timer);
      timer = setTimeout(() => {
        // Se a tela já encolheu sozinha para o teclado, não precisa de folga extra.
        setKbPad(curH.current >= fullH.current - 20 ? h : 0);
      }, 120);
    });
    const hide = Keyboard.addListener('keyboardDidHide', () => {
      // Sem isso, um "mostrar" atrasado podia reaplicar a folga depois de o teclado sumir (o buraco embaixo).
      if (timer) clearTimeout(timer);
      setKbPad(0);
      // Teclado minimizado: usar as funções da barra não deve abri-lo de novo.
      web.current?.injectJavaScript('window.kbHidden&&window.kbHidden(true);true;');
    });
    return () => {
      if (timer) clearTimeout(timer);
      show.remove();
      hide.remove();
    };
  }, []);

  // ---------- favorita e PDF ----------
  const toggleFav = async () => {
    const v = !fav;
    setFav(v);
    await setFavorite(blockId, v);
  };

  const exportPdf = async () => {
    if (exporting) return;
    setExporting(true);
    try {
      await syncFromWeb();
      const n = noteRef.current;
      if (layoutRef.current === 'free' && n.free) await exportNotePdf(n.title, freeToHtml(n.free, toWebHtml), null, true);
      else await exportNotePdf(n.title, toWebHtml(n.html), n.cover ? mediaUri(n.cover) : null);
    } catch (e) {
      appError('Não foi possível gerar o PDF', e);
    } finally {
      setExporting(false);
    }
  };

  /** Nota atual pronta para virar páginas (já com o que está no editor salvo). */
  const pagesInput = async (): Promise<NotePagesInput> => {
    await syncFromWeb();
    const n = noteRef.current;
    if (layoutRef.current === 'free' && n.free) return { kind: 'free', free: n.free, toUri: toWebHtml };
    return { kind: 'flow', title: n.title, body: toWebHtml(n.html), cover: n.cover ? mediaUri(n.cover) : null };
  };

  const exportPdf169 = async () => {
    if (exporting) return;
    setExporting(true);
    try {
      await exportNotePdf169(noteRef.current.title, await pagesInput());
    } catch (e) {
      appError('Não foi possível gerar o PDF 16:9', e);
    } finally {
      setExporting(false);
    }
  };

  /** Imagens 16:9: monta o HTML paginado; a captura página a página é feita por <NotePagesCapture>. */
  const startImages = async () => {
    if (exporting) return;
    setExporting(true);
    try {
      setPager(await buildPagerHtml(await pagesInput()));
    } catch (e) {
      setExporting(false);
      appError('Não foi possível gerar as imagens', e);
    }
  };

  const pagesDone = async (uris: string[]) => {
    setPager(null);
    try {
      await savePagesToGallery(noteRef.current.title, uris);
      appToast(
        uris.length === 1 ? 'Salvo na galeria' : `${uris.length} páginas salvas na galeria`,
        uris.length === 1 ? 'A imagem 16:9 já está nas suas fotos.' : 'As imagens 16:9 estão nas suas fotos, em ordem. Selecione todas por lá para compartilhar.'
      );
    } catch (e) {
      appError('Não consegui salvar as imagens', e);
    } finally {
      setExporting(false);
    }
  };

  /** Troca entre nota corrida e layout livre. Os dois conteúdos ficam guardados; nada é apagado. */
  const switchLayout = async (to: 'flow' | 'free') => {
    if (layoutRef.current === to) return;
    await settle();
    readyRef.current = false;
    layoutRef.current = to;
    // O que mudou de um lado é levado ao outro (texto e imagens), mantendo a diagramação.
    const cur = noteRef.current;
    let next: Note = { ...cur, layout: to };
    if (cur.free) {
      if (to === 'free') next = { ...next, free: flowToFree(cur.free, cur.html, cur.title) };
      else {
        const r = freeToFlow(cur.free, cur.html, cur.title);
        next = { ...next, html: r.html, title: r.title, free: r.free };
      }
    }
    noteRef.current = next;
    scheduleSave();
    await flush();
    setLayout(to);
  };

  const pickFrameImage = async (id: string) => {
    try {
      const r = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: 0.7 });
      if (r.canceled || !r.assets[0]) return;
      const a = r.assets[0];
      const name = saveMedia(a.uri, a.fileName, 'jpg');
      run(`window.setFrameImage(${lit(id)}, ${lit(mediaUri(name))})`);
    } catch (e) {
      appError('Não foi possível adicionar a imagem', e);
    }
  };

  /** Salva o que está no editor (e sai da edição) antes de analisar ou aplicar sugestões. */
  const settle = async () => {
    if (editingRef.current) await finishEditing();
    await syncFromWeb();
    await flush();
  };

  /** Botão ✦ do cabeçalho: a IA analisa e as sugestões aparecem no topo da nota (nada muda sem permissão). */
  const startSuggest = async (mode: SuggestMode, selection: string, request = '') => {
    await settle();
    const id = ++suggestRun.current;
    run('window.suggestState("loading")');
    let payload: { items: { id: string; label: string; preview: string }[]; failed: string | null; empty?: string };
    try {
      const r =
        mode === 'custom'
          ? await proposeCustom(blockId, request, selection)
          : { ...(await proposeForNotes([blockId], undefined, { mode, selection })), empty: undefined as string | undefined };
      suggestRef.current = r.proposals;
      payload = {
        items: r.proposals.map((p) => ({ id: p.id, label: p.label, preview: p.preview, html: p.kind === 'custom' ? p.html : undefined })),
        failed: r.failed,
        empty: r.empty ?? (mode === 'tasks' ? 'Não encontrei tarefas nesse texto.' : undefined),
      };
    } catch (e) {
      suggestRef.current = [];
      payload = { items: [], failed: String(e).slice(0, 160) };
    }
    if (suggestRun.current !== id) return; // fechou ou pediu de novo no meio
    run(`window.showSuggestions(${lit(payload)})`);
  };

  /** Aplica só as sugestões marcadas e recarrega a nota. */
  const applySuggest = async (ids: string[]) => {
    const chosen = suggestRef.current.filter((p) => ids.includes(p.id));
    if (chosen.length === 0) return;
    await settle();
    run('window.suggestState("applying")');
    let text: string;
    try {
      const r = await applyProposals(chosen);
      text =
        `${r.applied} ${r.applied === 1 ? 'mudança aplicada' : 'mudanças aplicadas'}.` +
        (r.skipped > 0 ? ` ${r.skipped} não ${r.skipped === 1 ? 'foi aplicada' : 'foram aplicadas'} porque o texto mudou.` : '');
    } catch (e) {
      text = `Não consegui aplicar: ${String(e).slice(0, 120)}`;
    }
    suggestRef.current = [];
    run(`window.suggestDone(${lit(text)})`);
    reload().catch(() => {});
  };

  // ---------- coleções ----------
  const refreshLinks = useCallback(async () => {
    const [linked, tree] = await Promise.all([listNoteLinks(blockId), listCollectionTree()]);
    setLinks(linked);
    setColTree(tree);
  }, [blockId]);

  const openColSheet = () => {
    refreshLinks().catch((e) => appError('Não consegui ler as coleções', e));
  };

  const toggleLink = async (c: FlatCollection) => {
    try {
      if (links.some((l) => l.id === c.id)) await unlinkNoteFromCollection(blockId, c.id);
      else await linkNoteToCollection(blockId, c.id);
      await refreshLinks();
    } catch (e) {
      appError('Não consegui alterar o vínculo', e);
    }
  };

  const goToCollection = async (id: number) => {
    setColTree(null);
    await close();
    onOpenCollection(id);
  };

  const colItems: SheetItem[] =
    colTree === null
      ? []
      : colTree.length === 0
        ? [{ key: 'none', label: 'Nenhuma coleção ainda', muted: true }]
        : colTree.map((c) => ({
            key: String(c.id),
            // Coleções de dentro aparecem recuadas, logo abaixo da coleção de fora.
            label: `${c.depth > 0 ? `${'   '.repeat(c.depth - 1)}↳ ` : ''}${c.name}`,
            selected: links.some((l) => l.id === c.id),
            onPress: () => {
              toggleLink(c).catch(() => {});
            },
            onLongPress: () => {
              goToCollection(c.id).catch(() => {});
            },
          }));

  // ---------- anexos ----------
  const pickImage = async () => {
    try {
      const r = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: 0.7 });
      if (r.canceled || !r.assets[0]) return;
      const a = r.assets[0];
      const name = saveMedia(a.uri, a.fileName, 'jpg');
      run(`window.insertImage(${lit(mediaUri(name))})`);
    } catch (e) {
      appError('Não foi possível adicionar a imagem', e);
    }
  };

  /** Foto/print de anotação -> texto lido pela IA, inserido onde está o cursor (com a imagem original embaixo). */
  const readImageIntoNote = async () => {
    if (reading) return;
    const imgs = await askImages('Texto de uma imagem');
    if (!imgs) return;
    setReading(true);
    try {
      const res = await readPickedImages(imgs, []);
      if (!res.ok) {
        appAlert('Não consegui ler a imagem', res.message);
        return;
      }
      const tmp = appendSections(emptyNote(), res.read.sections);
      run(`window.insertHtml(${lit(toWebHtml(tmp.html + imagesHtml(res.media)))})`);
    } catch (e) {
      appError('Não consegui ler a imagem', e);
    } finally {
      setReading(false);
    }
  };

  const pickVideo = async () => {
    try {
      const r = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['videos'] });
      if (r.canceled || !r.assets[0]) return;
      const a = r.assets[0];
      const name = saveMedia(a.uri, a.fileName, 'mp4');
      run(`window.insertVideoFile(${lit(mediaUri(name))})`);
    } catch (e) {
      appError('Não foi possível adicionar o vídeo', e);
    }
  };

  const pickFile = async () => {
    try {
      const r = await DocumentPicker.getDocumentAsync({ copyToCacheDirectory: true, multiple: false });
      if (r.canceled || !r.assets[0]) return;
      const a = r.assets[0];
      const name = saveMedia(a.uri, a.name, 'bin');
      run(`window.insertFile(${lit(mediaUri(name))}, ${lit(a.name)})`);
    } catch (e) {
      appError('Não foi possível adicionar o arquivo', e);
    }
  };

  const pickCover = async () => {
    try {
      const r = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ['images'],
        quality: 0.7,
        allowsEditing: true,
        aspect: [16, 9],
      });
      if (r.canceled || !r.assets[0]) return;
      const name = saveMedia(r.assets[0].uri, r.assets[0].fileName, 'jpg');
      noteRef.current = { ...noteRef.current, cover: name };
      scheduleSave();
      run(`window.setCover(${lit(mediaUri(name))})`);
    } catch (e) {
      appError('Não foi possível trocar a capa', e);
    }
  };

  const removeCover = () => {
    noteRef.current = { ...noteRef.current, cover: null };
    scheduleSave();
    run('window.setCover(null)');
  };

  const openFile = async (uri: string, fallbackName?: string) => {
    try {
      const name = nameFromRef(uri) || fallbackName || '';
      const f = mediaFile(name);
      if (!f.exists) {
        appToast('Arquivo não encontrado', 'O arquivo anexado não está mais no celular.');
        return;
      }
      try {
        await IntentLauncher.startActivityAsync('android.intent.action.VIEW', {
          data: f.contentUri,
          flags: 1,
          type: mimeFor(name),
        });
      } catch {
        if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(f.uri);
      }
    } catch (e) {
      appError('Não foi possível abrir o arquivo', e);
    }
  };

  const openLink = (url: string) => {
    const u = /^[a-z][a-z0-9+.-]*:/i.test(url) ? url : `https://${url}`;
    Linking.openURL(u).catch(() => appToast('Não foi possível abrir o link', u));
  };

  /** Cards de link em busca de prévia (evita buscar duas vezes o mesmo). */
  const cardBusy = useRef<Set<string>>(new Set());

  /** Busca título, descrição e capa do link, guarda a capa no app e preenche o card na nota. */
  const loadLinkCard = async (lid: string, url: string) => {
    if (cardBusy.current.has(lid)) return;
    cardBusy.current.add(lid);
    let d: Record<string, unknown> = { ok: false };
    try {
      const p = await fetchPreviewText(url);
      if (p) {
        const cover = await saveCover(p.imageUrl);
        d = { ok: true, title: p.title, desc: p.desc, site: p.site, img: cover ? mediaUri(cover.img) : '', ar: cover?.ar ?? 0 };
      }
    } catch {
      d = { ok: false };
    } finally {
      cardBusy.current.delete(lid);
    }
    run(`window.fillLinkCard(${lit(lid)}, ${lit(d)})`);
  };

  /** Toque num card com a nota em edição. */
  const cardMenu = (lid: string, url: string) => {
    appMenu('Link', url, [
      { text: 'Abrir', onPress: () => openLink(url) },
      { text: 'Tamanho', onPress: () => run(`window.openSizeFor(${lit(lid)})`) },
      { text: 'Atualizar prévia', onPress: () => run(`window.refreshLinkCard(${lit(lid)})`) },
      { text: 'Virar link de texto', onPress: () => run(`window.cardToLink(${lit(lid)})`) },
      { text: 'Remover card', style: 'destructive', onPress: () => run(`window.removeLinkCard(${lit(lid)})`) },
      { text: 'Cancelar', style: 'cancel' },
    ]);
  };

  const askLink = (current: string | null) => {
    if (current === null) return setLinkDlg({ current: null });
    appMenu('Link', current, [
      { text: 'Editar', onPress: () => setLinkDlg({ current }) },
      ...(/^https?:\/\//i.test(current)
        ? [{ text: 'Transformar em card', onPress: () => run('window.linkToCard()') }]
        : []),
      { text: 'Remover link', style: 'destructive', onPress: () => run('window.removeLink()') },
      { text: 'Cancelar', style: 'cancel' },
    ]);
  };

  // ---------- mensagens do editor ----------
  const onMessage = (e: WebViewMessageEvent) => {
    let m: any;
    try {
      m = JSON.parse(e.nativeEvent.data);
    } catch {
      return;
    }
    switch (m.type) {
      case 'editing':
        onEditingStarted();
        break;
      case 'scale': {
        const v = Number(m.value);
        if (Number.isFinite(v)) {
          scaleRef.current = v;
          setNoteScale(v).catch(() => {});
        }
        break;
      }
      case 'ready':
        readyRef.current = true;
        run(setFontsScript());
        if (layoutRef.current === 'free') pushInsets();
        sendInit();
        break;
      case 'change': {
        const html = toStoredHtml(String(m.html ?? ''));
        const title = String(m.title ?? '');
        const cur = noteRef.current;
        if (cur.html !== html || cur.title !== title) {
          noteRef.current = { ...cur, title, html };
          scheduleSave();
        }
        const w = waiters.current;
        waiters.current = [];
        w.forEach((f) => f());
        break;
      }
      case 'fchange': {
        let free;
        try {
          free = parseFree(JSON.parse(toStoredHtml(JSON.stringify(m.free))));
        } catch {
          free = undefined;
        }
        if (free && layoutRef.current === 'free') {
          const cur = noteRef.current;
          // `sync` não viaja pela WebView: continua o da nota (ou nasce agora, a partir do texto semeado).
          const synced = { ...free, sync: cur.free?.sync ?? makeSync(cur.html, cur.title, free) };
          noteRef.current = { ...cur, layout: 'free', free: synced, title: freeTitle(synced) || cur.title };
          scheduleSave();
        }
        const w = waiters.current;
        waiters.current = [];
        w.forEach((f) => f());
        break;
      }
      case 'pickFrameImage':
        pickFrameImage(String(m.id));
        break;
      case 'pickFrameColor':
        setColorFor(m.for === 'bg' ? 'bg' : 'frame');
        break;
      case 'bg':
        if (typeof m.color === 'string') setPageBg(m.color);
        break;
      case 'tapView':
        if (!editingRef.current) setChrome((c) => !c);
        break;
      case 'scrollDir':
        if (!editingRef.current) setChrome(m.dir === 'up');
        break;
      case 'finish':
        finishEditing().catch(() => {});
        break;
      case 'pickImage':
        pickImage();
        break;
      case 'pickOcr':
        readImageIntoNote().catch(() => {});
        break;
      case 'pickVideo':
        pickVideo();
        break;
      case 'pickFile':
        pickFile();
        break;
      case 'pickCover':
        pickCover();
        break;
      case 'removeCover':
        removeCover();
        break;
      case 'askVideoUrl':
        setVideoDlg(true);
        break;
      case 'searchNotes':
        searchNotesForLink(String(m.q ?? ''), blockId)
          .then((list) => run(`window.setNoteResults(${lit(list)})`))
          .catch(() => {});
        break;
      case 'createNoteLink':
        createNoteWithTitle(String(m.title ?? ''))
          .then(async (c) => {
            const t = (await noteTitlesByUuids([c.uuid]))[c.uuid] ?? String(m.title ?? '');
            run(`window.insertNoteLink(${lit(c.uuid)},${lit(t)})`);
          })
          .catch((e) => appError('Não consegui criar a nota', e));
        break;
      case 'newSubnote':
        (async () => {
          const c = await createNoteWithTitle('', blockId);
          const t = (await noteTitlesByUuids([c.uuid]))[c.uuid] ?? 'Subnota';
          run(`window.insertSubnote(${lit(c.uuid)},${lit(t)})`);
          await new Promise((r) => setTimeout(r, 250));
          await settle(); // o cartão precisa estar salvo antes de sair desta nota
          onOpenNote(c.id);
        })().catch((e) => appError('Não consegui criar a subnota', e));
        break;
      case 'openNote':
        (async () => {
          if (m.gone) {
            appToast('Nota excluída', 'Essa nota não existe mais neste aparelho.');
            return;
          }
          const id = typeof m.id === 'number' ? m.id : await findBlockIdByUuid(String(m.uuid ?? ''));
          if (id === null || id === undefined) {
            appToast('Nota não encontrada', 'Essa nota ainda não chegou a este aparelho.');
            return;
          }
          await settle();
          onOpenNote(id);
        })().catch(() => {});
        break;
      case 'findState':
        findOpenRef.current = !!m.open;
        break;
      case 'askDeleteCols':
        appAlert('Excluir colunas?', 'O conteúdo delas será apagado.', [
          { text: 'Cancelar', style: 'cancel' },
          { text: 'Excluir', style: 'destructive', onPress: () => run('window.deleteCols()') },
        ]);
        break;
      case 'openFonts':
        setFontsOpen(true);
        break;
      case 'pickColor':
        setColorFor(m.for === 'hilite' ? 'hilite' : 'text');
        break;
      case 'askLink':
        askLink(typeof m.current === 'string' ? m.current : null);
        break;
      case 'openLink':
        if (m.url) openLink(String(m.url));
        break;
      case 'linkCard':
        if (m.lid && m.url) loadLinkCard(String(m.lid), String(m.url)).catch(() => {});
        break;
      case 'cardMenu':
        if (m.url) cardMenu(String(m.lid ?? ''), String(m.url));
        break;
      case 'openFile':
        if (m.uri) openFile(String(m.uri), m.name ? String(m.name) : undefined);
        break;
      case 'suggest': {
        // O ✦ pergunta o que fazer; com um trecho selecionado, a IA olha só ele.
        const sel = String(m.sel ?? '');
        appMenu('IA na nota', sel.trim() ? 'Trecho selecionado' : 'Nota inteira', [
          { text: 'Organizar texto', onPress: () => startSuggest('organize', sel).catch(() => {}) },
          { text: 'Virar lista de tarefas', onPress: () => startSuggest('tasks', sel).catch(() => {}) },
          { text: 'Fazer meu pedido…', onPress: () => setAskAi({ sel }) },
          { text: 'Cancelar', style: 'cancel' },
        ]);
        break;
      }
      case 'suggestApply':
        if (Array.isArray(m.ids)) applySuggest(m.ids.map(String)).catch(() => {});
        break;
      case 'suggestClose':
        suggestRun.current++;
        suggestRef.current = [];
        break;
      case 'jserror':
        break;
    }
  };

  // ---------- visual ----------
  const head = (label: string, onPress: () => void, extra?: object) => (
    <Pressable onPress={onPress} hitSlop={HIT.md} accessibilityRole="button">
      <Text style={[styles.headText, { fontSize: sw * TYPE.body, letterSpacing: tracking(sw * TYPE.body, 0.03) }, extra]}>{label}</Text>
    </Pressable>
  );

  insetsRef.current = { top: headH, bottom: kbPad > 0 ? 0 : insets.bottom };
  useEffect(() => {
    if (layout === 'free' && readyRef.current) pushInsets();
  }, [layout, editing, headH, kbPad, insets.bottom, pushInsets]);

  const showHint = !editing && loaded && pendingInfo > 0;

  const header = (
    <ScreenHeader
        plate={immersive}
        pointerEvents={immersive ? 'box-none' : 'auto'}
        onBack={() => close().catch(() => {})}
        right={
          <>
          <NoteRecorder ref={recRef} blockId={blockId} onPhase={setRecPhase} onSaved={afterRecorded} />
          {recPhase === 'idle' && (
            <>
              <Pressable onPress={openColSheet} hitSlop={HIT.md} accessibilityRole="button" accessibilityLabel="Coleções desta nota">
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: sw * SPACE.xs }}>
                  <View style={{ width: sw * 0.052, height: sw * 0.052 }}>
                    <View
                      style={{
                        position: 'absolute',
                        left: 0,
                        top: 0,
                        width: sw * 0.036,
                        height: sw * 0.036,
                        borderWidth: 1.6,
                        borderColor: links.length > 0 ? colors.red : colors.onDark,
                        borderRadius: 3,
                      }}
                    />
                    <View
                      style={{
                        position: 'absolute',
                        right: 0,
                        bottom: 0,
                        width: sw * 0.036,
                        height: sw * 0.036,
                        borderWidth: 1.6,
                        borderColor: links.length > 0 ? colors.red : colors.onDark,
                        borderRadius: 3,
                        backgroundColor: colors.bg,
                      }}
                    />
                  </View>
                  {links.length > 0 && (
                    <Text style={{ color: colors.red, fontFamily: fonts.bold, fontSize: sw * TYPE.label }}>
                      {links.length}
                    </Text>
                  )}
                </View>
              </Pressable>
              {head(fav ? '★' : '☆', () => toggleFav().catch(() => {}), { fontSize: sw * TYPE.title })}
              {exporting && <ActivityIndicator color={colors.onDark} />}
              <Pressable onPress={() => setNoteMenu(true)} hitSlop={HIT.md} accessibilityRole="button" accessibilityLabel="Mais ações">
                <Icon name="more" size={sw * 0.06} />
              </Pressable>
              {editing && <HeaderAction label="Concluído" onPress={() => finishEditing().catch(() => {})} />}
            </>
          )}
          </>
        }
    />
  );

  const pill = {
    backgroundColor: colors.overlayButtonStrong,
    borderRadius: sw * 0.04,
    paddingHorizontal: sw * 0.03,
    paddingVertical: sw * 0.012,
  } as const;

  /** Tela cheia: nota-pai e tags aparecem como pílulas sobre a página, junto com a barra. */
  const metaRow = immersive ? (
    <View pointerEvents="box-none" style={{ flexDirection: 'row', flexWrap: 'wrap', gap: sw * SPACE.sm, paddingHorizontal: sw * SPACE.lg, paddingTop: sw * SPACE.sm }}>
      {parent && (
        <Pressable onPress={() => onOpenNote(parent.id)} hitSlop={HIT.sm} accessibilityRole="button" style={pill}>
          <Text numberOfLines={1} style={{ color: colors.mutedLight, fontFamily: fonts.regular, fontSize: sw * TYPE.caption }}>
            {'Dentro de: '}
            <Text style={{ color: colors.red }}>{parent.title}</Text>
          </Text>
        </Pressable>
      )}
      <Pressable onPress={() => openTags().catch(() => {})} hitSlop={HIT.sm} accessibilityRole="button" accessibilityLabel="Tags da nota" style={pill}>
        <Text style={{ color: tags.length > 0 ? colors.red : colors.mutedLight, fontFamily: fonts.regular, fontSize: sw * TYPE.caption }}>
          {tags.length > 0 ? tags.map((t) => `#${t}`).join('  ') : '+ Tag'}
        </Text>
      </Pressable>
    </View>
  ) : null;

  return (
    <View
      style={[styles.root, immersive && { backgroundColor: pageBg }]}
      onLayout={(e) => {
        curH.current = e.nativeEvent.layout.height;
        if (kbPad === 0) fullH.current = Math.max(fullH.current, curH.current);
      }}
    >
      {!overlay && header}

      {!overlay && !editing && parent && (
        <Pressable onPress={() => onOpenNote(parent.id)} hitSlop={HIT.sm} accessibilityRole="button" style={{ paddingHorizontal: sw * 0.06, paddingBottom: sw * 0.015 }}>
          <Text style={{ color: colors.muted, fontFamily: fonts.regular, fontSize: sw * TYPE.caption }}>
            {'Dentro de: '}
            <Text style={{ color: colors.red }}>{parent.title}</Text>
          </Text>
        </Pressable>
      )}

      {!overlay && !editing && (
        <Pressable
          onPress={() => openTags().catch(() => {})}
          hitSlop={HIT.sm}
          accessibilityRole="button"
          accessibilityLabel="Tags da nota"
          style={{ flexDirection: 'row', flexWrap: 'wrap', gap: sw * 0.025, paddingHorizontal: sw * 0.06, paddingBottom: sw * 0.02 }}
        >
          {tags.length === 0 ? (
            <Text style={{ color: colors.muted, fontFamily: fonts.regular, fontSize: sw * TYPE.caption }}>+ Tag</Text>
          ) : (
            tags.map((t) => (
              <Text key={t} style={{ color: colors.red, fontFamily: fonts.regular, fontSize: sw * TYPE.caption }}>{`#${t}`}</Text>
            ))
          )}
        </Pressable>
      )}

      {overlay && <StatusBar style={immersive && isLightHex(pageBg) ? 'dark' : 'light'} />}
      <View style={overlay ? [styles.cardFull, { bottom: kbPad > 0 ? kbPad : 0 }, immersive && { backgroundColor: pageBg }] : styles.card}>
        <WebView
          key={layout}
          ref={web}
          originWhitelist={['*']}
          source={{ html: layout === 'free' ? FREE_HTML : EDITOR_HTML, baseUrl: 'file:///' }}
          onMessage={onMessage}
          javaScriptEnabled
          allowFileAccess
          allowFileAccessFromFileURLs
          allowUniversalAccessFromFileURLs
          mixedContentMode="always"
          setSupportMultipleWindows={false}
          textZoom={100}
          overScrollMode="never"
          hideKeyboardAccessoryView
          automaticallyAdjustContentInsets={false}
          onShouldStartLoadWithRequest={(r) => r.url.startsWith('file:') || r.url.startsWith('about:')}
          style={{ backgroundColor: immersive ? pageBg : colors.bg }}
          containerStyle={{ backgroundColor: immersive ? pageBg : colors.bg }}
        />
        {showHint && (
          <View pointerEvents="none" style={[styles.hint, { left: sw * 0.075, right: sw * 0.075 }, overlay && { bottom: insets.bottom + sw * 0.22 }]}>
            <Text style={{ color: colors.muted, fontFamily: fonts.regular, fontSize: sw * TYPE.caption, lineHeight: sw * 0.05 }}>
              {pendingInfo} {pendingInfo === 1 ? 'áudio espera' : 'áudios esperam'} transcrição (veja a Fila na tela de
              Gravação).
            </Text>
          </View>
        )}
      </View>

      {!overlay && <View style={{ height: kbPad > 0 ? kbPad : insets.bottom }} />}

      {overlay && (
        <Animated.View
          pointerEvents={chromeOn || editing ? 'box-none' : 'none'}
          onLayout={(e) => setHeadH(e.nativeEvent.layout.height)}
          style={[styles.overlayTop, { opacity: editing ? 1 : chromeAnim, backgroundColor: editing ? colors.bg : 'transparent' }]}
        >
          <View pointerEvents="box-none">{header}</View>
          {metaRow}
        </Animated.View>
      )}

      {immersive && (
        <Animated.View pointerEvents={chromeOn ? 'auto' : 'none'} style={{ position: 'absolute', right: sw * SPACE.lg, bottom: insets.bottom + sw * SPACE.lg, opacity: chromeAnim, zIndex: 20 }}>
          <Pressable
            onPress={() => run('window.beginEdit()')}
            accessibilityRole="button"
            accessibilityLabel="Editar página"
            style={{
              minHeight: MIN_TOUCH,
              paddingHorizontal: sw * SPACE.xl,
              borderRadius: sw * RADIUS.pill,
              backgroundColor: colors.paper,
              borderWidth: 1,
              borderColor: colors.glassLine,
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <Text style={{ color: colors.onLight, fontFamily: fonts.bold, fontSize: sw * TYPE.body }}>Editar</Text>
          </Pressable>
        </Animated.View>
      )}

      {reading && (
        <View style={styles.reading}>
          <StateMessage kind="loading" centered>Lendo a imagem…</StateMessage>
        </View>
      )}

      <BottomSheet
        visible={colTree !== null}
        onClose={() => setColTree(null)}
        title="Criar coleção e vincular"
        onTitlePress={() => {
          setColTree(null);
          setNewColDlg(true);
        }}
        subtitle="Toque: vincular ou desvincular · Segure: abrir"
        items={colItems}
        separators
      />
      <ActionMenu visible={noteMenu} onClose={() => setNoteMenu(false)} items={noteMenuItems} />
      <ActionMenu
        visible={shareMenu}
        onClose={() => setShareMenu(false)}
        title="Compartilhar nota"
        items={[
          { key: 'pdfA4', label: 'PDF (documento A4)', onPress: () => exportPdf().catch(() => {}) },
          { key: 'pdf169', label: 'PDF 16:9 (dividido em páginas)', onPress: () => exportPdf169().catch(() => {}) },
          { key: 'img169', label: 'Imagens 16:9 (uma por página)', onPress: () => startImages().catch(() => {}) },
        ]}
      />
      {pager !== null && (
        <NotePagesCapture
          html={pager}
          onDone={(u) => pagesDone(u).catch(() => {})}
          onError={(e) => {
            setPager(null);
            setExporting(false);
            appError('Não foi possível gerar as imagens', e);
          }}
        />
      )}
      <AskAiDialog
        visible={askAi !== null}
        hasSelection={!!askAi?.sel.trim()}
        onCancel={() => setAskAi(null)}
        onSubmit={(req) => {
          const sel = askAi?.sel ?? '';
          setAskAi(null);
          startSuggest('custom', sel, req).catch(() => {});
        }}
      />
      <PromptDialog
        visible={tplDlg}
        title="Salvar como modelo"
        initialValue=""
        placeholder="Nome do modelo"
        onCancel={() => setTplDlg(false)}
        onSubmit={(v) => saveAsTemplate(v)}
      />

      <TagsDialog
        visible={tagsDlg !== null}
        current={tags}
        existing={tagsDlg?.existing ?? []}
        onCancel={() => setTagsDlg(null)}
        onSave={async (t) => {
          setTagsDlg(null);
          setTags(t);
          try {
            await setBlockTags(blockId, t);
          } catch (e) {
            appError('Não consegui salvar as tags', e);
          }
        }}
      />

      <CardColorDialog
        visible={colorFor !== null}
        initial={null}
        title={colorFor === 'hilite' ? 'Cor do marca-texto' : colorFor === 'bg' ? 'Cor do fundo' : colorFor === 'frame' ? 'Cor' : 'Cor do texto'}
        allowClear={false}
        palette={[]}
        onCancel={() => setColorFor(null)}
        onPick={(hex) => {
          const kind = colorFor;
          setColorFor(null);
          if (!hex || !kind) return;
          if (kind === 'frame' || kind === 'bg') {
            run(`window.setFrameColor(${lit(hex)},${lit(kind)})`);
            return;
          }
          run(`window.applyColor(${lit(kind)},${lit(hex)})`);
          pushRecentColor(hex)
            .then((l) => {
              recentRef.current = l;
              run(`window.setRecentColors(${lit(l)})`);
            })
            .catch(() => {});
        }}
      />

      <PromptDialog
        visible={newColDlg}
        title="Nova coleção"
        initialValue=""
        placeholder="Nome da coleção"
        onCancel={() => setNewColDlg(false)}
        onSubmit={async (v) => {
          setNewColDlg(false);
          try {
            const id = await createCollection(v);
            await linkNoteToCollection(blockId, id);
            setLinks(await listNoteLinks(blockId));
          } catch (e) {
            appError('Não consegui criar a coleção', e);
          }
        }}
      />
      <PromptDialog
        visible={linkDlg !== null}
        title={linkDlg?.current ? 'Editar link' : 'Adicionar link'}
        initialValue={linkDlg?.current ?? ''}
        placeholder="https://…"
        maxLength={1000}
        url
        onCancel={() => setLinkDlg(null)}
        onSubmit={(v) => {
          setLinkDlg(null);
          run(`window.applyLink(${lit(v)})`);
        }}
      />
      <PromptDialog
        visible={videoDlg}
        title="Link do vídeo"
        initialValue=""
        placeholder="YouTube, Vimeo ou link do vídeo"
        maxLength={1000}
        url
        onCancel={() => setVideoDlg(false)}
        onSubmit={(v) => {
          setVideoDlg(false);
          run(`window.insertVideoUrl(${lit(v)})`);
        }}
      />
      {fontsOpen && <FontsScreen onClose={() => setFontsOpen(false)} />}
    </View>
  );
}

const styles = StyleSheet.create({
  reading: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: colors.scrimSoft,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 30,
  },
  root: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: colors.bg },
  headText: { color: colors.onDark, fontFamily: fonts.bold },
  card: { flex: 1, backgroundColor: colors.bg, overflow: 'hidden' },
  cardFull: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: colors.bg, overflow: 'hidden' },
  overlayTop: { position: 'absolute', top: 0, left: 0, right: 0, zIndex: 20 },
  hint: { position: 'absolute', bottom: 16 },
});
