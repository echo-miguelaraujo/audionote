import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Alert,
  BackHandler,
  Keyboard,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  useWindowDimensions,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { getBlock, getNoteJson, listAudios, saveNoteJson } from './db';
import { Note, Sentence, Topic, emptyNote, makeSentence, parseNote, uid } from './note';
import { processQueue, setEditingBlock, subscribeQueue } from './queue';
import { Run, Style, applyStyle, colorOfRange, plain, rangeHas, replaceText, styleOfChar } from './richtext';
import { colors, fonts } from './theme';

type Props = { blockId: number; onClose: () => void };

const PALETTE: { name: string; value: string | null }[] = [
  { name: 'Branco', value: null },
  { name: 'Vermelho', value: '#FF3030' },
  { name: 'Amarelo', value: '#FFD60A' },
  { name: 'Verde', value: '#32D74B' },
  { name: 'Azul', value: '#4DA3FF' },
];

function runFont(r: Run | Style): string {
  if (r.b && r.i) return fonts.boldItalic;
  if (r.b) return fonts.bold;
  if (r.i) return fonts.italic;
  return fonts.regular;
}

type Sel = { sid: string | null; start: number; end: number };

type RichProps = {
  sentence: Sentence;
  size: number;
  autoFocus: boolean;
  focused: boolean;
  pendingRef: React.MutableRefObject<Style | null>;
  selOverride: { start: number; end: number } | null;
  onRuns: (runs: Run[]) => void;
  onFocus: () => void;
  onSel: (start: number, end: number) => void;
};

function RichInput({ sentence, size, autoFocus, focused, pendingRef, selOverride, onRuns, onFocus, onSel }: RichProps) {
  const runsRef = useRef(sentence.runs);
  runsRef.current = sentence.runs;
  return (
    <TextInput
      multiline
      scrollEnabled={false}
      autoFocus={autoFocus}
      onFocus={onFocus}
      placeholder="Escreva aqui…"
      placeholderTextColor={colors.gray}
      selectionColor={colors.red}
      cursorColor={colors.red}
      underlineColorAndroid="transparent"
      textAlignVertical="top"
      onChangeText={(text) => {
        const old = plain(runsRef.current);
        if (text === old) return;
        const next = replaceText(runsRef.current, old, text, pendingRef.current);
        pendingRef.current = null;
        runsRef.current = next;
        onRuns(next);
      }}
      onSelectionChange={(e) => onSel(e.nativeEvent.selection.start, e.nativeEvent.selection.end)}
      selection={selOverride ?? undefined}
      style={{
        color: colors.text,
        fontFamily: fonts.regular,
        fontSize: size,
        lineHeight: size * 1.3,
        letterSpacing: -size * 0.03,
        padding: 0,
        paddingVertical: 4,
        opacity: focused ? 1 : 0.92,
      }}
    >
      {sentence.runs.map((r, i) => (
        <Text key={i} style={{ fontFamily: runFont(r), color: r.c ?? colors.text }}>
          {r.t}
        </Text>
      ))}
    </TextInput>
  );
}

export function NoteScreen({ blockId, onClose }: Props) {
  const { width: sw } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const [blockName, setBlockName] = useState('');
  const [note, setNote] = useState<Note | null>(null);
  const [editing, setEditing] = useState(false);
  const [focusId, setFocusId] = useState<string | null>(null);
  const [newFocus, setNewFocus] = useState<string | null>(null);
  const [sel, setSel] = useState<Sel>({ sid: null, start: 0, end: 0 });
  const [selOverride, setSelOverride] = useState<{ sid: string; start: number; end: number } | null>(null);
  const [, setTick] = useState(0);
  const [moveFor, setMoveFor] = useState<{ tid: string; sid: string } | null>(null);
  const [pendingInfo, setPendingInfo] = useState(0);
  const [kbPad, setKbPad] = useState(0);

  const noteRef = useRef<Note>(emptyNote());
  const history = useRef<Note[]>([]);
  const lastKey = useRef<{ key: string; at: number } | null>(null);
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const dirty = useRef(false);
  const editingRef = useRef(false);
  const pendingRef = useRef<Style | null>(null);
  const curH = useRef(0);
  const fullH = useRef(0);

  const titleSize = sw * 0.078;
  const bodySize = sw * 0.05;

  // ---------- carregar / salvar ----------
  const reload = useCallback(async () => {
    const [b, json, audios] = await Promise.all([getBlock(blockId), getNoteJson(blockId), listAudios(blockId)]);
    setBlockName(b?.name ?? '');
    const n = parseNote(json) ?? emptyNote();
    noteRef.current = n;
    setNote(n);
    setPendingInfo(audios.filter((a) => a.status === 'pending' || a.status === 'error').length);
  }, [blockId]);

  useEffect(() => {
    reload().catch((e) => Alert.alert('Erro ao abrir a nota', String(e)));
    return subscribeQueue(() => {
      if (!editingRef.current) reload().catch(() => {});
    });
  }, [reload]);

  const flush = useCallback(async () => {
    if (saveTimer.current) {
      clearTimeout(saveTimer.current);
      saveTimer.current = null;
    }
    if (dirty.current) {
      dirty.current = false;
      await saveNoteJson(blockId, JSON.stringify(noteRef.current));
    }
  }, [blockId]);

  const scheduleSave = useCallback(() => {
    dirty.current = true;
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => {
      flush().catch(() => {});
    }, 600);
  }, [flush]);

  useEffect(
    () => () => {
      flush().catch(() => {});
      setEditingBlock(null);
    },
    [flush]
  );

  // ---------- alterações com histórico (desfazer) ----------
  const commit = useCallback(
    (fn: (n: Note) => Note, key?: string) => {
      const prev = noteRef.current;
      const next = fn(prev);
      if (next === prev) return;
      const now = Date.now();
      const lk = lastKey.current;
      if (!key || !lk || lk.key !== key || now - lk.at > 1200) {
        history.current.push(prev);
        if (history.current.length > 60) history.current.shift();
      }
      lastKey.current = key ? { key, at: now } : null;
      noteRef.current = next;
      setNote(next);
      scheduleSave();
    },
    [scheduleSave]
  );

  const undo = () => {
    const prev = history.current.pop();
    if (!prev) return;
    noteRef.current = prev;
    lastKey.current = null;
    setNote(prev);
    scheduleSave();
  };

  const mapTopic = (n: Note, tid: string, fn: (t: Topic) => Topic): Note => ({
    ...n,
    topics: n.topics.map((t) => (t.id === tid ? fn(t) : t)),
  });

  // ---------- modo de edição ----------
  const startEditing = () => {
    editingRef.current = true;
    setEditingBlock(blockId);
    setEditing(true);
  };

  const finishEditing = useCallback(async () => {
    Keyboard.dismiss();
    commit((n) => ({
      ...n,
      topics: n.topics.map((t) => ({
        ...t,
        sentences: t.sentences.filter((s) => plain(s.runs).trim() !== ''),
      })),
    }));
    setFocusId(null);
    setSel({ sid: null, start: 0, end: 0 });
    pendingRef.current = null;
    await flush();
    editingRef.current = false;
    setEditingBlock(null);
    setEditing(false);
    processQueue().catch(() => {}); // libera o que ficou esperando a edição
  }, [commit, flush]);

  const close = useCallback(async () => {
    if (editingRef.current) await finishEditing();
    await flush();
    onClose();
  }, [finishEditing, flush, onClose]);

  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (editingRef.current) finishEditing().catch(() => {});
      else close().catch(() => {});
      return true;
    });
    return () => sub.remove();
  }, [finishEditing, close]);

  // ---------- teclado: mantém a barra visível ----------
  useEffect(() => {
    const show = Keyboard.addListener('keyboardDidShow', (e) => {
      const h = e.endCoordinates?.height ?? 0;
      setTimeout(() => {
        // Se a tela já encolheu sozinha para o teclado, não precisa de folga extra.
        setKbPad(curH.current >= fullH.current - 20 ? h : 0);
      }, 120);
    });
    const hide = Keyboard.addListener('keyboardDidHide', () => setKbPad(0));
    return () => {
      show.remove();
      hide.remove();
    };
  }, []);

  // ---------- operações na estrutura ----------
  const shift = <T,>(arr: T[], i: number, dir: -1 | 1): T[] => {
    const j = i + dir;
    if (i < 0 || j < 0 || j >= arr.length) return arr;
    const out = [...arr];
    [out[i], out[j]] = [out[j], out[i]];
    return out;
  };

  const shiftTopic = (tid: string, dir: -1 | 1) =>
    commit((n) => ({ ...n, topics: shift(n.topics, n.topics.findIndex((t) => t.id === tid), dir) }));

  const shiftSentence = (tid: string, sid: string, dir: -1 | 1) =>
    commit((n) =>
      mapTopic(n, tid, (t) => ({
        ...t,
        sentences: shift(t.sentences, t.sentences.findIndex((s) => s.id === sid), dir),
      }))
    );

  const deleteSentence = (tid: string, sid: string) => {
    commit((n) => mapTopic(n, tid, (t) => ({ ...t, sentences: t.sentences.filter((s) => s.id !== sid) })));
    setFocusId(null);
  };

  const deleteTopic = (t: Topic) => {
    const run = () => {
      commit((n) => ({ ...n, topics: n.topics.filter((x) => x.id !== t.id) }));
      setFocusId(null);
    };
    if (t.sentences.length === 0) return run();
    Alert.alert('Apagar tópico?', `"${t.title || 'Sem título'}" e as ${t.sentences.length} frases dele serão apagados. Dá para desfazer.`, [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Apagar', style: 'destructive', onPress: run },
    ]);
  };

  const addSentence = (tid: string, afterSid?: string) => {
    const s: Sentence = { id: uid(), runs: [] };
    commit((n) =>
      mapTopic(n, tid, (t) => {
        const arr = [...t.sentences];
        const i = afterSid ? arr.findIndex((x) => x.id === afterSid) : -1;
        arr.splice(i >= 0 ? i + 1 : arr.length, 0, s);
        return { ...t, sentences: arr };
      })
    );
    setNewFocus(s.id);
  };

  const addTopic = () => {
    const t: Topic = { id: uid(), title: '', sentences: [{ id: uid(), runs: [] }] };
    commit((n) => ({ ...n, topics: [...n.topics, t] }));
    setNewFocus(t.sentences[0].id);
  };

  const moveSentence = (from: string, sid: string, to: string | 'new') => {
    commit((n) => {
      const src = n.topics.find((t) => t.id === from);
      const sentence = src?.sentences.find((s) => s.id === sid);
      if (!src || !sentence) return n;
      let topics = n.topics.map((t) =>
        t.id === from ? { ...t, sentences: t.sentences.filter((s) => s.id !== sid) } : t
      );
      if (to === 'new') topics = [...topics, { id: uid(), title: '', sentences: [sentence] }];
      else topics = topics.map((t) => (t.id === to ? { ...t, sentences: [...t.sentences, sentence] } : t));
      return { ...n, topics };
    });
    setMoveFor(null);
  };

  // ---------- formatação ----------
  const activeSentence = (): Sentence | null => {
    if (!sel.sid) return null;
    for (const t of noteRef.current.topics) {
      const s = t.sentences.find((x) => x.id === sel.sid);
      if (s) return s;
    }
    return null;
  };

  const format = (patch: { b?: boolean; i?: boolean; c?: string | null }) => {
    const s = activeSentence();
    if (!s || !sel.sid) return;
    if (sel.start === sel.end) {
      // sem seleção: vale para o que for digitado a seguir
      const base: Style = pendingRef.current ?? styleOfChar(s.runs, sel.start - 1);
      const next: Style = { ...base };
      if (patch.b) next.b = !base.b || undefined;
      if (patch.i) next.i = !base.i || undefined;
      if (patch.c !== undefined) next.c = patch.c ?? undefined;
      pendingRef.current = next;
      setTick((x) => x + 1);
      return;
    }
    const { start, end } = sel;
    const sid = sel.sid;
    commit((n) => ({
      ...n,
      topics: n.topics.map((t) => ({
        ...t,
        sentences: t.sentences.map((x) => (x.id === sid ? { ...x, runs: applyStyle(x.runs, start, end, patch) } : x)),
      })),
    }));
    setSelOverride({ sid, start, end });
    setTimeout(() => setSelOverride(null), 120);
  };

  const info = (): { b: boolean; i: boolean; c: string | null } => {
    const s = activeSentence();
    if (!s) return { b: false, i: false, c: null };
    if (sel.start !== sel.end)
      return {
        b: rangeHas(s.runs, sel.start, sel.end, 'b'),
        i: rangeHas(s.runs, sel.start, sel.end, 'i'),
        c: (() => {
          const c = colorOfRange(s.runs, sel.start, sel.end);
          return c === 'mixed' ? null : c;
        })(),
      };
    const st = pendingRef.current ?? styleOfChar(s.runs, sel.start - 1);
    return { b: !!st.b, i: !!st.i, c: st.c ?? null };
  };

  const onSel = (sid: string, start: number, end: number) =>
    setSel((p) => (p.sid === sid && p.start === start && p.end === end ? p : { sid, start, end }));

  const setSentenceRuns = (tid: string, sid: string, runs: Run[]) =>
    commit(
      (n) => mapTopic(n, tid, (t) => ({ ...t, sentences: t.sentences.map((s) => (s.id === sid ? { ...s, runs } : s)) })),
      `s:${sid}`
    );

  // ---------- visual ----------
  const n = note ?? emptyNote();
  const small = sw * 0.04;
  const ctl = (label: string, onPress: () => void, danger = false) => (
    <Pressable onPress={onPress} hitSlop={8}>
      <Text style={{ color: danger ? colors.red : colors.gray, fontFamily: fonts.bold, fontSize: small }}>{label}</Text>
    </Pressable>
  );

  const fmt = info();
  const tbBtn = (label: React.ReactNode, active: boolean, onPress: () => void) => (
    <Pressable
      onPress={onPress}
      hitSlop={6}
      style={{
        minWidth: sw * 0.11,
        height: sw * 0.11,
        borderRadius: sw * 0.055,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: active ? colors.text : '#1C1C1E',
      }}
    >
      {label}
    </Pressable>
  );

  const isEmpty = n.topics.length === 0 && !n.title.trim();

  return (
    <View
      style={styles.root}
      onLayout={(e) => {
        curH.current = e.nativeEvent.layout.height;
        if (kbPad === 0) fullH.current = Math.max(fullH.current, curH.current);
      }}
    >
      <View style={[styles.header, { paddingTop: insets.top + sw * 0.03, paddingHorizontal: sw * 0.06 }]}>
        <Pressable onPress={() => close().catch(() => {})} hitSlop={16}>
          <Text style={[styles.headText, { fontSize: sw * 0.05 }]}>← Voltar</Text>
        </Pressable>
        <View style={{ flexDirection: 'row', gap: sw * 0.06 }}>
          {editing && (
            <Pressable onPress={undo} hitSlop={16}>
              <Text style={[styles.headText, { fontSize: sw * 0.05 }]}>Desfazer</Text>
            </Pressable>
          )}
          <Pressable onPress={() => (editing ? finishEditing() : startEditing())} hitSlop={16}>
            <Text style={[styles.headText, { fontSize: sw * 0.05 }]}>{editing ? 'Concluído' : 'Editar'}</Text>
          </Pressable>
        </View>
      </View>

      <View style={[styles.card, { marginHorizontal: sw * 0.025, marginTop: sw * 0.025, borderRadius: sw * 0.1 }]}>
        <ScrollView
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={{
            paddingHorizontal: sw * 0.075,
            paddingTop: sw * 0.09,
            paddingBottom: sw * 0.4,
          }}
        >
          {/* Título */}
          {editing ? (
            <TextInput
              multiline
              value={n.title}
              onChangeText={(v) => commit((x) => ({ ...x, title: v }), 'title')}
              onFocus={() => setFocusId('title')}
              placeholder={blockName || 'Título'}
              placeholderTextColor={colors.gray}
              selectionColor={colors.red}
              cursorColor={colors.red}
              underlineColorAndroid="transparent"
              style={{
                color: colors.text,
                fontFamily: fonts.black,
                fontSize: titleSize,
                letterSpacing: -titleSize * 0.04,
                lineHeight: titleSize * 1.12,
                padding: 0,
              }}
            />
          ) : (
            <Text
              style={{
                color: n.title.trim() ? colors.text : colors.gray,
                fontFamily: fonts.black,
                fontSize: titleSize,
                letterSpacing: -titleSize * 0.04,
                lineHeight: titleSize * 1.12,
              }}
            >
              {n.title.trim() || blockName || 'Nota'}
            </Text>
          )}

          {!editing && isEmpty && (
            <Text style={{ color: colors.gray, fontFamily: fonts.regular, fontSize: bodySize * 0.9, lineHeight: bodySize * 1.3, marginTop: sw * 0.05 }}>
              {pendingInfo > 0
                ? `Ainda sem texto. ${pendingInfo} ${pendingInfo === 1 ? 'áudio espera' : 'áudios esperam'} transcrição (veja a Fila na tela de Gravação).`
                : 'Ainda sem texto. Grave um áudio ou toque em Editar para escrever.'}
            </Text>
          )}

          {/* Tópicos */}
          {n.topics.map((t) => (
            <View key={t.id} style={{ marginTop: sw * 0.07 }}>
              {editing ? (
                <TextInput
                  multiline
                  value={t.title}
                  onChangeText={(v) => commit((x) => mapTopic(x, t.id, (tt) => ({ ...tt, title: v })), `t:${t.id}`)}
                  onFocus={() => setFocusId(t.id)}
                  placeholder="Subtítulo"
                  placeholderTextColor={colors.gray}
                  selectionColor={colors.red}
                  cursorColor={colors.red}
                  underlineColorAndroid="transparent"
                  style={{
                    color: colors.text,
                    fontFamily: fonts.black,
                    fontSize: titleSize,
                    letterSpacing: -titleSize * 0.04,
                    lineHeight: titleSize * 1.12,
                    padding: 0,
                  }}
                />
              ) : (
                !!t.title.trim() && (
                  <Text
                    style={{
                      color: colors.text,
                      fontFamily: fonts.black,
                      fontSize: titleSize,
                      letterSpacing: -titleSize * 0.04,
                      lineHeight: titleSize * 1.12,
                    }}
                  >
                    {t.title}
                  </Text>
                )
              )}

              {editing && focusId === t.id && (
                <View style={styles.ctlRow}>
                  {ctl('↑', () => shiftTopic(t.id, -1))}
                  {ctl('↓', () => shiftTopic(t.id, 1))}
                  {ctl('+ frase', () => addSentence(t.id))}
                  {ctl('Apagar tópico', () => deleteTopic(t), true)}
                </View>
              )}

              {!editing ? (
                <Text
                  style={{
                    color: colors.text,
                    fontFamily: fonts.regular,
                    fontSize: bodySize,
                    lineHeight: bodySize * 1.3,
                    letterSpacing: -bodySize * 0.03,
                    marginTop: sw * 0.015,
                  }}
                >
                  {t.sentences.map((s, si) => (
                    <Text key={s.id}>
                      {s.runs.map((r, ri) => (
                        <Text key={ri} style={{ fontFamily: runFont(r), color: r.c ?? colors.text }}>
                          {r.t}
                        </Text>
                      ))}
                      {si < t.sentences.length - 1 ? ' ' : ''}
                    </Text>
                  ))}
                </Text>
              ) : (
                t.sentences.map((s) => (
                  <View
                    key={s.id}
                    style={{
                      marginTop: sw * 0.025,
                      paddingLeft: 12,
                      borderLeftWidth: 2,
                      borderLeftColor: focusId === s.id ? colors.red : '#2A2A2A',
                    }}
                  >
                    <RichInput
                      sentence={s}
                      size={bodySize}
                      autoFocus={newFocus === s.id}
                      focused={focusId === s.id}
                      pendingRef={pendingRef}
                      selOverride={selOverride && selOverride.sid === s.id ? selOverride : null}
                      onRuns={(runs) => setSentenceRuns(t.id, s.id, runs)}
                      onFocus={() => {
                        if (focusId !== s.id) pendingRef.current = null;
                        setFocusId(s.id);
                        setNewFocus(null);
                        setSel((p) => (p.sid === s.id ? p : { sid: s.id, start: 0, end: 0 }));
                      }}
                      onSel={(a, b) => onSel(s.id, a, b)}
                    />
                    {focusId === s.id && (
                      <View style={styles.ctlRow}>
                        {ctl('↑', () => shiftSentence(t.id, s.id, -1))}
                        {ctl('↓', () => shiftSentence(t.id, s.id, 1))}
                        {ctl('Mover', () => setMoveFor({ tid: t.id, sid: s.id }))}
                        {ctl('+ frase', () => addSentence(t.id, s.id))}
                        {ctl('Apagar', () => deleteSentence(t.id, s.id), true)}
                      </View>
                    )}
                  </View>
                ))
              )}
              {editing && t.sentences.length === 0 && (
                <Text style={{ color: colors.gray, fontFamily: fonts.regular, fontSize: small, marginTop: 6 }}>
                  Tópico vazio. Toque no subtítulo e em “+ frase”.
                </Text>
              )}
            </View>
          ))}

          {editing && (
            <Pressable onPress={addTopic} hitSlop={10} style={{ marginTop: sw * 0.08 }}>
              <Text style={{ color: colors.text, fontFamily: fonts.bold, fontSize: sw * 0.05 }}>+ Novo tópico</Text>
            </Pressable>
          )}
        </ScrollView>
      </View>

      {editing ? (
        <View
          style={{
            paddingTop: sw * 0.025,
            paddingHorizontal: sw * 0.04,
            paddingBottom: (kbPad > 0 ? kbPad : insets.bottom) + sw * 0.025,
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}
        >
          {tbBtn(<Text style={{ fontFamily: fonts.black, fontSize: sw * 0.052, color: fmt.b ? '#000' : colors.text }}>B</Text>, fmt.b, () => format({ b: true }))}
          {tbBtn(<Text style={{ fontFamily: fonts.italic, fontSize: sw * 0.052, color: fmt.i ? '#000' : colors.text }}>I</Text>, fmt.i, () => format({ i: true }))}
          {PALETTE.map((p) =>
            tbBtn(
              <View
                style={{
                  width: sw * 0.058,
                  height: sw * 0.058,
                  borderRadius: sw * 0.029,
                  backgroundColor: p.value ?? '#FFFFFF',
                  borderWidth: 2,
                  borderColor: fmt.c === p.value ? colors.red : 'transparent',
                }}
              />,
              fmt.c === p.value,
              () => format({ c: p.value })
            )
          )}
        </View>
      ) : (
        <View style={{ height: insets.bottom + sw * 0.03 }} />
      )}

      <Modal visible={moveFor !== null} transparent animationType="fade" statusBarTranslucent onRequestClose={() => setMoveFor(null)}>
        <Pressable style={styles.overlay} onPress={() => setMoveFor(null)}>
          <Pressable
            onPress={() => {}}
            style={{ width: sw * 0.84, maxHeight: '70%', borderRadius: sw * 0.074, backgroundColor: '#FFFFFF', padding: sw * 0.06 }}
          >
            <Text style={{ color: '#000', fontFamily: fonts.bold, fontSize: sw * 0.06, letterSpacing: -1, marginBottom: 12 }}>
              Mover para…
            </Text>
            <ScrollView>
              {n.topics
                .filter((t) => t.id !== moveFor?.tid)
                .map((t) => (
                  <Pressable key={t.id} onPress={() => moveFor && moveSentence(moveFor.tid, moveFor.sid, t.id)} style={{ paddingVertical: 10 }}>
                    <Text style={{ color: '#000', fontFamily: fonts.regular, fontSize: sw * 0.05 }}>{t.title || 'Sem título'}</Text>
                  </Pressable>
                ))}
              <Pressable onPress={() => moveFor && moveSentence(moveFor.tid, moveFor.sid, 'new')} style={{ paddingVertical: 10 }}>
                <Text style={{ color: colors.red, fontFamily: fonts.bold, fontSize: sw * 0.05 }}>+ Novo tópico</Text>
              </Pressable>
            </ScrollView>
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: colors.red },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  headText: { color: '#FFFFFF', fontFamily: fonts.bold, letterSpacing: -0.5 },
  card: { flex: 1, backgroundColor: colors.bg, overflow: 'hidden' },
  ctlRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 18, marginTop: 6, marginBottom: 4 },
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.78)', alignItems: 'center', justifyContent: 'center' },
});
