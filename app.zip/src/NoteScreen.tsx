import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { appAlert } from './dialog';
import {
  ActivityIndicator,
  BackHandler,
  Keyboard,
  Linking,
  Pressable,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
} from 'react-native';
import { WebView, WebViewMessageEvent } from 'react-native-webview';
import * as ImagePicker from 'expo-image-picker';
import * as DocumentPicker from 'expo-document-picker';
import * as IntentLauncher from 'expo-intent-launcher';
import * as Sharing from 'expo-sharing';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { BottomSheet, SheetItem } from './BottomSheet';
import {
  FlatCollection,
  createCollection,
  getBlock,
  getNoteJson,
  isFavorite,
  linkNoteToCollection,
  listAudios,
  listCollectionTree,
  listNoteLinks,
  saveNoteJson,
  setFavorite,
  unlinkNoteFromCollection,
} from './db';
import { EDITOR_HTML } from './editorHtml';
import { exportNotePdf } from './exportPdf';
import { mediaFile, mediaUri, mimeFor, nameFromRef, saveMedia, toStoredHtml, toWebHtml } from './media';
import { askImages, imagesHtml, readPickedImages } from './imageNote';
import { Note, appendSections, emptyNote, parseNote } from './note';
import { processQueue, setEditingBlock, setOpenBlock, subscribeQueue } from './queue';
import { NotePhase, NoteRecorder, NoteRecorderHandle } from './NoteRecorder';
import { PromptDialog } from './PromptDialog';
import { RestructureDialog } from './RestructureDialog';
import { CardColorDialog } from './CardColorDialog';
import { getNoteScale, getRecentColors, pushRecentColor, setNoteScale } from './settings';
import { colors, fonts } from './theme';

type Props = {
  blockId: number;
  onClose: () => void;
  /** Abre uma coleção (a tela da nota é fechada antes). */
  onOpenCollection: (collectionId: number) => void;
};

/** Texto -> literal JS seguro para injetar na WebView. */
const lit = (v: unknown): string =>
  JSON.stringify(v).replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');

export function NoteScreen({ blockId, onClose, onOpenCollection }: Props) {
  const { width: sw } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const web = useRef<WebView>(null);
  const [loaded, setLoaded] = useState(false);
  const [editing, setEditing] = useState(false);
  const [fav, setFav] = useState(false);
  const [pendingInfo, setPendingInfo] = useState(0);
  const [exporting, setExporting] = useState(false);
  const [organizing, setOrganizing] = useState(false);
  const organizeIds = useMemo(() => [blockId], [blockId]);
  const [reading, setReading] = useState(false);
  const [kbPad, setKbPad] = useState(0);
  const [linkDlg, setLinkDlg] = useState<{ current: string | null } | null>(null);
  /** Cor personalizada pedida pelo editor: 'text' (cor do texto) ou 'hilite' (marca-texto). */
  const [colorFor, setColorFor] = useState<'text' | 'hilite' | null>(null);
  const recentRef = useRef<string[]>([]);
  const [videoDlg, setVideoDlg] = useState(false);
  const [recPhase, setRecPhase] = useState<NotePhase>('idle');
  /** Coleções em que esta nota está vinculada. */
  const [links, setLinks] = useState<FlatCollection[]>([]);
  /** null = lista fechada; senão, todas as coleções (para vincular/desvincular). */
  const [colTree, setColTree] = useState<FlatCollection[] | null>(null);
  const [newColDlg, setNewColDlg] = useState(false);
  const recRef = useRef<NoteRecorderHandle>(null);

  const noteRef = useRef<Note>(emptyNote());
  const readyRef = useRef(false);
  const loadedRef = useRef(false);
  const editingRef = useRef(false);
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const dirty = useRef(false);
  const waiters = useRef<(() => void)[]>([]);
  const curH = useRef(0);
  const fullH = useRef(0);
  const scaleRef = useRef(1);

  const run = useCallback((code: string) => {
    web.current?.injectJavaScript(`${code};true;`);
  }, []);

  // ---------- enviar a nota para o editor ----------
  const sendInit = useCallback(() => {
    if (!readyRef.current || !loadedRef.current) return;
    const n = noteRef.current;
    run(
      `window.initNote(${lit({
        title: n.title,
        html: toWebHtml(n.html),
        cover: n.cover ? mediaUri(n.cover) : null,
        editable: editingRef.current,
        scale: scaleRef.current,
        recent: recentRef.current,
      })})`
    );
  }, [run]);

  // Últimas cores personalizadas: carregadas uma vez; o editor recebe junto com a nota.
  useEffect(() => {
    getRecentColors()
      .then((l) => {
        recentRef.current = l;
        run(`window.setRecentColors(${lit(l)})`);
      })
      .catch(() => {});
  }, [run]);

  useEffect(() => {
    setOpenBlock(blockId);
    return () => setOpenBlock(null);
  }, [blockId]);

  // ---------- carregar / salvar ----------
  const reload = useCallback(async () => {
    const [b, json, audios, favorite, linked] = await Promise.all([
      getBlock(blockId),
      getNoteJson(blockId),
      listAudios(blockId),
      isFavorite(blockId),
      listNoteLinks(blockId),
    ]);
    void b;
    setLinks(linked);
    noteRef.current = parseNote(json) ?? emptyNote();
    loadedRef.current = true;
    setLoaded(true);
    setFav(favorite);
    setPendingInfo(audios.filter((a) => a.status === 'pending' || a.status === 'error').length);
    sendInit();
  }, [blockId, sendInit]);

  useEffect(() => {
    getNoteScale()
      .then((v) => {
        scaleRef.current = v;
        run(`window.setScale && window.setScale(${v})`);
      })
      .catch(() => {});
  }, [run]);

  useEffect(() => {
    reload().catch((e) => appAlert('Erro ao abrir a nota', String(e)));
    return subscribeQueue(() => {
      if (!editingRef.current) reload().catch(() => {});
    });
  }, [reload]);

  const flush = useCallback(async () => {
    if (saveTimer.current) {
      clearTimeout(saveTimer.current);
      saveTimer.current = null;
    }
    if (dirty.current) {
      dirty.current = false;
      await saveNoteJson(blockId, JSON.stringify(noteRef.current));
    }
  }, [blockId]);

  const scheduleSave = useCallback(() => {
    dirty.current = true;
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => {
      flush().catch(() => {});
    }, 500);
  }, [flush]);

  useEffect(
    () => () => {
      flush().catch(() => {});
      setEditingBlock(null);
    },
    [flush]
  );

  /** Pede ao editor o texto atual e espera a resposta (ou 500 ms), para nunca perder o que foi digitado. */
  const syncFromWeb = useCallback(
    () =>
      new Promise<void>((resolve) => {
        if (!readyRef.current) return resolve();
        const t = setTimeout(resolve, 500);
        waiters.current.push(() => {
          clearTimeout(t);
          resolve();
        });
        run('window.flushNow()');
      }),
    [run]
  );

  // ---------- modo de edição ----------
  // O editor liga a edição sozinho no duplo toque (precisa ser dentro do gesto para abrir o teclado).
  const onEditingStarted = () => {
    editingRef.current = true;
    setEditingBlock(blockId);
    setEditing(true);
  };

  const finishEditing = useCallback(async () => {
    Keyboard.dismiss();
    await syncFromWeb();
    run('window.setEditable(false)');
    await flush();
    editingRef.current = false;
    setEditingBlock(null);
    setEditing(false);
    processQueue().catch(() => {}); // libera o que ficou esperando a edição
  }, [flush, run, syncFromWeb]);

  // Depois de gravar dentro da nota: atualiza o aviso de pendentes e já tenta transcrever.
  const afterRecorded = useCallback(() => {
    listAudios(blockId)
      .then((a) => setPendingInfo(a.filter((x) => x.status === 'pending' || x.status === 'error').length))
      .catch(() => {});
    processQueue().catch(() => {});
  }, [blockId]);

  const close = useCallback(async () => {
    await recRef.current?.finish(); // se estiver gravando, salva o áudio antes de sair
    if (editingRef.current) await finishEditing();
    else await syncFromWeb();
    await flush();
    onClose();
  }, [finishEditing, flush, onClose, syncFromWeb]);

  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (editingRef.current) finishEditing().catch(() => {});
      else close().catch(() => {});
      return true;
    });
    return () => sub.remove();
  }, [finishEditing, close]);

  // ---------- teclado: mantém a barra de ferramentas visível ----------
  useEffect(() => {
    const show = Keyboard.addListener('keyboardDidShow', (e) => {
      const h = e.endCoordinates?.height ?? 0;
      setTimeout(() => {
        // Se a tela já encolheu sozinha para o teclado, não precisa de folga extra.
        setKbPad(curH.current >= fullH.current - 20 ? h : 0);
      }, 120);
    });
    const hide = Keyboard.addListener('keyboardDidHide', () => setKbPad(0));
    return () => {
      show.remove();
      hide.remove();
    };
  }, []);

  // ---------- favorita e PDF ----------
  const toggleFav = async () => {
    const v = !fav;
    setFav(v);
    await setFavorite(blockId, v);
  };

  const exportPdf = async () => {
    if (exporting) return;
    setExporting(true);
    try {
      await syncFromWeb();
      const n = noteRef.current;
      await exportNotePdf(n.title, toWebHtml(n.html), n.cover ? mediaUri(n.cover) : null);
    } catch (e) {
      appAlert('Não foi possível gerar o PDF', String(e));
    } finally {
      setExporting(false);
    }
  };

  /** Organizar: salva o que está no editor e abre a tela com as sugestões (nada muda sem permissão). */
  const openOrganize = async () => {
    if (editingRef.current) await finishEditing();
    await syncFromWeb();
    await flush();
    setOrganizing(true);
  };

  // ---------- coleções ----------
  const refreshLinks = useCallback(async () => {
    const [linked, tree] = await Promise.all([listNoteLinks(blockId), listCollectionTree()]);
    setLinks(linked);
    setColTree(tree);
  }, [blockId]);

  const openColSheet = () => {
    refreshLinks().catch((e) => appAlert('Não consegui ler as coleções', String(e)));
  };

  const toggleLink = async (c: FlatCollection) => {
    try {
      if (links.some((l) => l.id === c.id)) await unlinkNoteFromCollection(blockId, c.id);
      else await linkNoteToCollection(blockId, c.id);
      await refreshLinks();
    } catch (e) {
      appAlert('Não consegui alterar o vínculo', String(e));
    }
  };

  const goToCollection = async (id: number) => {
    setColTree(null);
    await close();
    onOpenCollection(id);
  };

  const colItems: SheetItem[] =
    colTree === null
      ? []
      : colTree.length === 0
        ? [{ key: 'none', label: 'Nenhuma coleção ainda', muted: true }]
        : colTree.map((c) => ({
            key: String(c.id),
            // Coleções de dentro aparecem recuadas, logo abaixo da coleção de fora.
            label: `${c.depth > 0 ? `${'   '.repeat(c.depth - 1)}↳ ` : ''}${c.name}`,
            selected: links.some((l) => l.id === c.id),
            onPress: () => {
              toggleLink(c).catch(() => {});
            },
            onLongPress: () => {
              goToCollection(c.id).catch(() => {});
            },
          }));

  // ---------- anexos ----------
  const pickImage = async () => {
    try {
      const r = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: 0.7 });
      if (r.canceled || !r.assets[0]) return;
      const a = r.assets[0];
      const name = saveMedia(a.uri, a.fileName, 'jpg');
      run(`window.insertImage(${lit(mediaUri(name))})`);
    } catch (e) {
      appAlert('Não foi possível adicionar a imagem', String(e));
    }
  };

  /** Foto/print de anotação -> texto lido pela IA, inserido onde está o cursor (com a imagem original embaixo). */
  const readImageIntoNote = async () => {
    if (reading) return;
    const imgs = await askImages('Texto de uma imagem');
    if (!imgs) return;
    setReading(true);
    try {
      const res = await readPickedImages(imgs, []);
      if (!res.ok) {
        appAlert('Não consegui ler a imagem', res.message);
        return;
      }
      const tmp = appendSections(emptyNote(), res.read.sections);
      run(`window.insertHtml(${lit(toWebHtml(tmp.html + imagesHtml(res.media)))})`);
    } catch (e) {
      appAlert('Não consegui ler a imagem', String(e));
    } finally {
      setReading(false);
    }
  };

  const pickVideo = async () => {
    try {
      const r = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['videos'] });
      if (r.canceled || !r.assets[0]) return;
      const a = r.assets[0];
      const name = saveMedia(a.uri, a.fileName, 'mp4');
      run(`window.insertVideoFile(${lit(mediaUri(name))})`);
    } catch (e) {
      appAlert('Não foi possível adicionar o vídeo', String(e));
    }
  };

  const pickFile = async () => {
    try {
      const r = await DocumentPicker.getDocumentAsync({ copyToCacheDirectory: true, multiple: false });
      if (r.canceled || !r.assets[0]) return;
      const a = r.assets[0];
      const name = saveMedia(a.uri, a.name, 'bin');
      run(`window.insertFile(${lit(mediaUri(name))}, ${lit(a.name)})`);
    } catch (e) {
      appAlert('Não foi possível adicionar o arquivo', String(e));
    }
  };

  const pickCover = async () => {
    try {
      const r = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ['images'],
        quality: 0.7,
        allowsEditing: true,
        aspect: [16, 9],
      });
      if (r.canceled || !r.assets[0]) return;
      const name = saveMedia(r.assets[0].uri, r.assets[0].fileName, 'jpg');
      noteRef.current = { ...noteRef.current, cover: name };
      scheduleSave();
      run(`window.setCover(${lit(mediaUri(name))})`);
    } catch (e) {
      appAlert('Não foi possível trocar a capa', String(e));
    }
  };

  const removeCover = () => {
    noteRef.current = { ...noteRef.current, cover: null };
    scheduleSave();
    run('window.setCover(null)');
  };

  const openFile = async (uri: string, fallbackName?: string) => {
    try {
      const name = nameFromRef(uri) || fallbackName || '';
      const f = mediaFile(name);
      if (!f.exists) {
        appAlert('Arquivo não encontrado', 'O arquivo anexado não está mais no celular.');
        return;
      }
      try {
        await IntentLauncher.startActivityAsync('android.intent.action.VIEW', {
          data: f.contentUri,
          flags: 1,
          type: mimeFor(name),
        });
      } catch {
        if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(f.uri);
      }
    } catch (e) {
      appAlert('Não foi possível abrir o arquivo', String(e));
    }
  };

  const openLink = (url: string) => {
    const u = /^[a-z][a-z0-9+.-]*:/i.test(url) ? url : `https://${url}`;
    Linking.openURL(u).catch(() => appAlert('Não foi possível abrir o link', u));
  };

  const askLink = (current: string | null) => {
    if (current === null) return setLinkDlg({ current: null });
    appAlert('Link', current, [
      { text: 'Editar', onPress: () => setLinkDlg({ current }) },
      { text: 'Remover link', style: 'destructive', onPress: () => run('window.removeLink()') },
      { text: 'Cancelar', style: 'cancel' },
    ]);
  };

  // ---------- mensagens do editor ----------
  const onMessage = (e: WebViewMessageEvent) => {
    let m: any;
    try {
      m = JSON.parse(e.nativeEvent.data);
    } catch {
      return;
    }
    switch (m.type) {
      case 'editing':
        onEditingStarted();
        break;
      case 'scale': {
        const v = Number(m.value);
        if (Number.isFinite(v)) {
          scaleRef.current = v;
          setNoteScale(v).catch(() => {});
        }
        break;
      }
      case 'ready':
        readyRef.current = true;
        sendInit();
        break;
      case 'change': {
        const html = toStoredHtml(String(m.html ?? ''));
        const title = String(m.title ?? '');
        const cur = noteRef.current;
        if (cur.html !== html || cur.title !== title) {
          noteRef.current = { ...cur, title, html };
          scheduleSave();
        }
        const w = waiters.current;
        waiters.current = [];
        w.forEach((f) => f());
        break;
      }
      case 'pickImage':
        pickImage();
        break;
      case 'pickOcr':
        readImageIntoNote().catch(() => {});
        break;
      case 'pickVideo':
        pickVideo();
        break;
      case 'pickFile':
        pickFile();
        break;
      case 'pickCover':
        pickCover();
        break;
      case 'removeCover':
        removeCover();
        break;
      case 'askVideoUrl':
        setVideoDlg(true);
        break;
      case 'askDeleteCols':
        appAlert('Excluir as colunas?', 'O conteúdo delas será apagado.', [
          { text: 'Cancelar', style: 'cancel' },
          { text: 'Excluir', style: 'destructive', onPress: () => run('window.deleteCols()') },
        ]);
        break;
      case 'pickColor':
        setColorFor(m.for === 'hilite' ? 'hilite' : 'text');
        break;
      case 'askLink':
        askLink(typeof m.current === 'string' ? m.current : null);
        break;
      case 'openLink':
        if (m.url) openLink(String(m.url));
        break;
      case 'openFile':
        if (m.uri) openFile(String(m.uri), m.name ? String(m.name) : undefined);
        break;
      case 'jserror':
        break;
    }
  };

  // ---------- visual ----------
  const head = (label: string, onPress: () => void, extra?: object) => (
    <Pressable onPress={onPress} hitSlop={14}>
      <Text style={[styles.headText, { fontSize: sw * 0.047 }, extra]}>{label}</Text>
    </Pressable>
  );

  const showHint = !editing && loaded && pendingInfo > 0;

  return (
    <View
      style={styles.root}
      onLayout={(e) => {
        curH.current = e.nativeEvent.layout.height;
        if (kbPad === 0) fullH.current = Math.max(fullH.current, curH.current);
      }}
    >
      <View style={[styles.header, { paddingTop: insets.top + sw * 0.03, paddingHorizontal: sw * 0.06 }]}>
        {head('← Voltar', () => close().catch(() => {}))}
        <View style={{ flexDirection: 'row', gap: sw * 0.055, alignItems: 'center' }}>
          <NoteRecorder ref={recRef} blockId={blockId} onPhase={setRecPhase} onSaved={afterRecorded} />
          {recPhase === 'idle' && (
            <>
              <Pressable onPress={openColSheet} hitSlop={14} accessibilityLabel="Coleções desta nota">
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: sw * 0.012 }}>
                  <View style={{ width: sw * 0.052, height: sw * 0.052 }}>
                    <View
                      style={{
                        position: 'absolute',
                        left: 0,
                        top: 0,
                        width: sw * 0.036,
                        height: sw * 0.036,
                        borderWidth: 1.6,
                        borderColor: links.length > 0 ? colors.red : '#FFFFFF',
                        borderRadius: 3,
                      }}
                    />
                    <View
                      style={{
                        position: 'absolute',
                        right: 0,
                        bottom: 0,
                        width: sw * 0.036,
                        height: sw * 0.036,
                        borderWidth: 1.6,
                        borderColor: links.length > 0 ? colors.red : '#FFFFFF',
                        borderRadius: 3,
                        backgroundColor: colors.bg,
                      }}
                    />
                  </View>
                  {links.length > 0 && (
                    <Text style={{ color: colors.red, fontFamily: fonts.bold, fontSize: sw * 0.04 }}>
                      {links.length}
                    </Text>
                  )}
                </View>
              </Pressable>
              {head('✦', () => openOrganize().catch(() => {}), { fontSize: sw * 0.052 })}
              {head(fav ? '★' : '☆', () => toggleFav().catch(() => {}), { fontSize: sw * 0.06 })}
              {exporting ? (
                <ActivityIndicator color="#FFFFFF" />
              ) : (
                head('PDF', () => exportPdf().catch(() => {}))
              )}
              {editing && head('Concluído', () => finishEditing().catch(() => {}))}
            </>
          )}
        </View>
      </View>

      <View style={styles.card}>
        <WebView
          ref={web}
          originWhitelist={['*']}
          source={{ html: EDITOR_HTML, baseUrl: 'file:///' }}
          onMessage={onMessage}
          javaScriptEnabled
          allowFileAccess
          allowFileAccessFromFileURLs
          allowUniversalAccessFromFileURLs
          mixedContentMode="always"
          setSupportMultipleWindows={false}
          textZoom={100}
          overScrollMode="never"
          hideKeyboardAccessoryView
          automaticallyAdjustContentInsets={false}
          onShouldStartLoadWithRequest={(r) => r.url.startsWith('file:') || r.url.startsWith('about:')}
          style={{ backgroundColor: '#000000' }}
          containerStyle={{ backgroundColor: '#000000' }}
        />
        {showHint && (
          <View pointerEvents="none" style={[styles.hint, { left: sw * 0.075, right: sw * 0.075 }]}>
            <Text style={{ color: colors.gray, fontFamily: fonts.regular, fontSize: sw * 0.037, lineHeight: sw * 0.05 }}>
              {pendingInfo} {pendingInfo === 1 ? 'áudio espera' : 'áudios esperam'} transcrição (veja a Fila na tela de
              Gravação).
            </Text>
          </View>
        )}
      </View>

      <View style={{ height: kbPad > 0 ? kbPad : insets.bottom }} />

      {reading && (
        <View style={styles.reading}>
          <ActivityIndicator color="#FFFFFF" size="large" />
          <Text style={{ color: '#FFFFFF', fontFamily: fonts.regular, fontSize: sw * 0.045, marginTop: sw * 0.04 }}>
            Lendo a imagem…
          </Text>
        </View>
      )}

      <RestructureDialog visible={organizing} blockIds={organizeIds} onClose={() => setOrganizing(false)} />

      <BottomSheet
        visible={colTree !== null}
        onClose={() => setColTree(null)}
        title="Criar coleção e vincular"
        onTitlePress={() => {
          setColTree(null);
          setNewColDlg(true);
        }}
        subtitle="Toque: vincular ou desvincular · Segure: abrir"
        items={colItems}
        separators
      />
      <CardColorDialog
        visible={colorFor !== null}
        initial={null}
        title={colorFor === 'hilite' ? 'Cor do marca-texto' : 'Cor do texto'}
        allowClear={false}
        palette={[]}
        onCancel={() => setColorFor(null)}
        onPick={(hex) => {
          const kind = colorFor;
          setColorFor(null);
          if (!hex || !kind) return;
          run(`window.applyColor(${lit(kind)},${lit(hex)})`);
          pushRecentColor(hex)
            .then((l) => {
              recentRef.current = l;
              run(`window.setRecentColors(${lit(l)})`);
            })
            .catch(() => {});
        }}
      />

      <PromptDialog
        visible={newColDlg}
        title="Nova coleção"
        initialValue=""
        placeholder="Nome da coleção"
        onCancel={() => setNewColDlg(false)}
        onSubmit={async (v) => {
          setNewColDlg(false);
          try {
            const id = await createCollection(v);
            await linkNoteToCollection(blockId, id);
            setLinks(await listNoteLinks(blockId));
          } catch (e) {
            appAlert('Não consegui criar a coleção', String(e));
          }
        }}
      />
      <PromptDialog
        visible={linkDlg !== null}
        title={linkDlg?.current ? 'Editar link' : 'Adicionar link'}
        initialValue={linkDlg?.current ?? ''}
        placeholder="https://…"
        maxLength={1000}
        url
        onCancel={() => setLinkDlg(null)}
        onSubmit={(v) => {
          setLinkDlg(null);
          run(`window.applyLink(${lit(v)})`);
        }}
      />
      <PromptDialog
        visible={videoDlg}
        title="Link do vídeo"
        initialValue=""
        placeholder="YouTube, Vimeo ou link do vídeo"
        maxLength={1000}
        url
        onCancel={() => setVideoDlg(false)}
        onSubmit={(v) => {
          setVideoDlg(false);
          run(`window.insertVideoUrl(${lit(v)})`);
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  reading: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.6)',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 30,
  },
  root: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: colors.bg },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingBottom: 6 },
  headText: { color: '#FFFFFF', fontFamily: fonts.bold, letterSpacing: -0.5 },
  card: { flex: 1, backgroundColor: colors.bg, overflow: 'hidden' },
  hint: { position: 'absolute', bottom: 16 },
});
