import React, { useCallback, useEffect, useRef, useState } from 'react';
import { appAlert } from './dialog';
import {
  ActivityIndicator,
  BackHandler,
  Keyboard,
  Linking,
  Pressable,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
} from 'react-native';
import { WebView, WebViewMessageEvent } from 'react-native-webview';
import * as ImagePicker from 'expo-image-picker';
import * as DocumentPicker from 'expo-document-picker';
import * as IntentLauncher from 'expo-intent-launcher';
import * as Sharing from 'expo-sharing';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { getBlock, getNoteJson, isFavorite, listAudios, saveNoteJson, setFavorite } from './db';
import { EDITOR_HTML } from './editorHtml';
import { exportNotePdf } from './exportPdf';
import { mediaFile, mediaUri, mimeFor, nameFromRef, saveMedia, toStoredHtml, toWebHtml } from './media';
import { Note, emptyNote, parseNote } from './note';
import { processQueue, setEditingBlock, subscribeQueue } from './queue';
import { NotePhase, NoteRecorder, NoteRecorderHandle } from './NoteRecorder';
import { PromptDialog } from './PromptDialog';
import { getNoteScale, setNoteScale } from './settings';
import { colors, fonts } from './theme';

type Props = { blockId: number; onClose: () => void };

/** Texto -> literal JS seguro para injetar na WebView. */
const lit = (v: unknown): string =>
  JSON.stringify(v).replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');

export function NoteScreen({ blockId, onClose }: Props) {
  const { width: sw } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const web = useRef<WebView>(null);
  const [loaded, setLoaded] = useState(false);
  const [editing, setEditing] = useState(false);
  const [fav, setFav] = useState(false);
  const [pendingInfo, setPendingInfo] = useState(0);
  const [exporting, setExporting] = useState(false);
  const [kbPad, setKbPad] = useState(0);
  const [linkDlg, setLinkDlg] = useState<{ current: string | null } | null>(null);
  const [videoDlg, setVideoDlg] = useState(false);
  const [recPhase, setRecPhase] = useState<NotePhase>('idle');
  const recRef = useRef<NoteRecorderHandle>(null);

  const noteRef = useRef<Note>(emptyNote());
  const readyRef = useRef(false);
  const loadedRef = useRef(false);
  const editingRef = useRef(false);
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const dirty = useRef(false);
  const waiters = useRef<(() => void)[]>([]);
  const curH = useRef(0);
  const fullH = useRef(0);
  const scaleRef = useRef(1);

  const run = useCallback((code: string) => {
    web.current?.injectJavaScript(`${code};true;`);
  }, []);

  // ---------- enviar a nota para o editor ----------
  const sendInit = useCallback(() => {
    if (!readyRef.current || !loadedRef.current) return;
    const n = noteRef.current;
    run(
      `window.initNote(${lit({
        title: n.title,
        html: toWebHtml(n.html),
        cover: n.cover ? mediaUri(n.cover) : null,
        editable: editingRef.current,
        scale: scaleRef.current,
      })})`
    );
  }, [run]);

  // ---------- carregar / salvar ----------
  const reload = useCallback(async () => {
    const [b, json, audios, favorite] = await Promise.all([
      getBlock(blockId),
      getNoteJson(blockId),
      listAudios(blockId),
      isFavorite(blockId),
    ]);
    void b;
    noteRef.current = parseNote(json) ?? emptyNote();
    loadedRef.current = true;
    setLoaded(true);
    setFav(favorite);
    setPendingInfo(audios.filter((a) => a.status === 'pending' || a.status === 'error').length);
    sendInit();
  }, [blockId, sendInit]);

  useEffect(() => {
    getNoteScale()
      .then((v) => {
        scaleRef.current = v;
        run(`window.setScale && window.setScale(${v})`);
      })
      .catch(() => {});
  }, [run]);

  useEffect(() => {
    reload().catch((e) => appAlert('Erro ao abrir a nota', String(e)));
    return subscribeQueue(() => {
      if (!editingRef.current) reload().catch(() => {});
    });
  }, [reload]);

  const flush = useCallback(async () => {
    if (saveTimer.current) {
      clearTimeout(saveTimer.current);
      saveTimer.current = null;
    }
    if (dirty.current) {
      dirty.current = false;
      await saveNoteJson(blockId, JSON.stringify(noteRef.current));
    }
  }, [blockId]);

  const scheduleSave = useCallback(() => {
    dirty.current = true;
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => {
      flush().catch(() => {});
    }, 500);
  }, [flush]);

  useEffect(
    () => () => {
      flush().catch(() => {});
      setEditingBlock(null);
    },
    [flush]
  );

  /** Pede ao editor o texto atual e espera a resposta (ou 500 ms), para nunca perder o que foi digitado. */
  const syncFromWeb = useCallback(
    () =>
      new Promise<void>((resolve) => {
        if (!readyRef.current) return resolve();
        const t = setTimeout(resolve, 500);
        waiters.current.push(() => {
          clearTimeout(t);
          resolve();
        });
        run('window.flushNow()');
      }),
    [run]
  );

  // ---------- modo de edição ----------
  // O editor liga a edição sozinho no duplo toque (precisa ser dentro do gesto para abrir o teclado).
  const onEditingStarted = () => {
    editingRef.current = true;
    setEditingBlock(blockId);
    setEditing(true);
  };

  const finishEditing = useCallback(async () => {
    Keyboard.dismiss();
    await syncFromWeb();
    run('window.setEditable(false)');
    await flush();
    editingRef.current = false;
    setEditingBlock(null);
    setEditing(false);
    processQueue().catch(() => {}); // libera o que ficou esperando a edição
  }, [flush, run, syncFromWeb]);

  // Depois de gravar dentro da nota: atualiza o aviso de pendentes e já tenta transcrever.
  const afterRecorded = useCallback(() => {
    listAudios(blockId)
      .then((a) => setPendingInfo(a.filter((x) => x.status === 'pending' || x.status === 'error').length))
      .catch(() => {});
    processQueue().catch(() => {});
  }, [blockId]);

  const close = useCallback(async () => {
    await recRef.current?.finish(); // se estiver gravando, salva o áudio antes de sair
    if (editingRef.current) await finishEditing();
    else await syncFromWeb();
    await flush();
    onClose();
  }, [finishEditing, flush, onClose, syncFromWeb]);

  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (editingRef.current) finishEditing().catch(() => {});
      else close().catch(() => {});
      return true;
    });
    return () => sub.remove();
  }, [finishEditing, close]);

  // ---------- teclado: mantém a barra de ferramentas visível ----------
  useEffect(() => {
    const show = Keyboard.addListener('keyboardDidShow', (e) => {
      const h = e.endCoordinates?.height ?? 0;
      setTimeout(() => {
        // Se a tela já encolheu sozinha para o teclado, não precisa de folga extra.
        setKbPad(curH.current >= fullH.current - 20 ? h : 0);
      }, 120);
    });
    const hide = Keyboard.addListener('keyboardDidHide', () => setKbPad(0));
    return () => {
      show.remove();
      hide.remove();
    };
  }, []);

  // ---------- favorita e PDF ----------
  const toggleFav = async () => {
    const v = !fav;
    setFav(v);
    await setFavorite(blockId, v);
  };

  const exportPdf = async () => {
    if (exporting) return;
    setExporting(true);
    try {
      await syncFromWeb();
      const n = noteRef.current;
      await exportNotePdf(n.title, toWebHtml(n.html), n.cover ? mediaUri(n.cover) : null);
    } catch (e) {
      appAlert('Não foi possível gerar o PDF', String(e));
    } finally {
      setExporting(false);
    }
  };

  // ---------- anexos ----------
  const pickImage = async () => {
    try {
      const r = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: 0.7 });
      if (r.canceled || !r.assets[0]) return;
      const a = r.assets[0];
      const name = saveMedia(a.uri, a.fileName, 'jpg');
      run(`window.insertImage(${lit(mediaUri(name))})`);
    } catch (e) {
      appAlert('Não foi possível adicionar a imagem', String(e));
    }
  };

  const pickVideo = async () => {
    try {
      const r = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['videos'] });
      if (r.canceled || !r.assets[0]) return;
      const a = r.assets[0];
      const name = saveMedia(a.uri, a.fileName, 'mp4');
      run(`window.insertVideoFile(${lit(mediaUri(name))})`);
    } catch (e) {
      appAlert('Não foi possível adicionar o vídeo', String(e));
    }
  };

  const pickFile = async () => {
    try {
      const r = await DocumentPicker.getDocumentAsync({ copyToCacheDirectory: true, multiple: false });
      if (r.canceled || !r.assets[0]) return;
      const a = r.assets[0];
      const name = saveMedia(a.uri, a.name, 'bin');
      run(`window.insertFile(${lit(mediaUri(name))}, ${lit(a.name)})`);
    } catch (e) {
      appAlert('Não foi possível adicionar o arquivo', String(e));
    }
  };

  const pickCover = async () => {
    try {
      const r = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ['images'],
        quality: 0.7,
        allowsEditing: true,
        aspect: [16, 9],
      });
      if (r.canceled || !r.assets[0]) return;
      const name = saveMedia(r.assets[0].uri, r.assets[0].fileName, 'jpg');
      noteRef.current = { ...noteRef.current, cover: name };
      scheduleSave();
      run(`window.setCover(${lit(mediaUri(name))})`);
    } catch (e) {
      appAlert('Não foi possível trocar a capa', String(e));
    }
  };

  const removeCover = () => {
    noteRef.current = { ...noteRef.current, cover: null };
    scheduleSave();
    run('window.setCover(null)');
  };

  const openFile = async (uri: string, fallbackName?: string) => {
    try {
      const name = nameFromRef(uri) || fallbackName || '';
      const f = mediaFile(name);
      if (!f.exists) {
        appAlert('Arquivo não encontrado', 'O arquivo anexado não está mais no celular.');
        return;
      }
      try {
        await IntentLauncher.startActivityAsync('android.intent.action.VIEW', {
          data: f.contentUri,
          flags: 1,
          type: mimeFor(name),
        });
      } catch {
        if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(f.uri);
      }
    } catch (e) {
      appAlert('Não foi possível abrir o arquivo', String(e));
    }
  };

  const openLink = (url: string) => {
    const u = /^[a-z][a-z0-9+.-]*:/i.test(url) ? url : `https://${url}`;
    Linking.openURL(u).catch(() => appAlert('Não foi possível abrir o link', u));
  };

  const askLink = (current: string | null) => {
    if (current === null) return setLinkDlg({ current: null });
    appAlert('Link', current, [
      { text: 'Editar', onPress: () => setLinkDlg({ current }) },
      { text: 'Remover link', style: 'destructive', onPress: () => run('window.removeLink()') },
      { text: 'Cancelar', style: 'cancel' },
    ]);
  };

  // ---------- mensagens do editor ----------
  const onMessage = (e: WebViewMessageEvent) => {
    let m: any;
    try {
      m = JSON.parse(e.nativeEvent.data);
    } catch {
      return;
    }
    switch (m.type) {
      case 'editing':
        onEditingStarted();
        break;
      case 'scale': {
        const v = Number(m.value);
        if (Number.isFinite(v)) {
          scaleRef.current = v;
          setNoteScale(v).catch(() => {});
        }
        break;
      }
      case 'ready':
        readyRef.current = true;
        sendInit();
        break;
      case 'change': {
        const html = toStoredHtml(String(m.html ?? ''));
        const title = String(m.title ?? '');
        const cur = noteRef.current;
        if (cur.html !== html || cur.title !== title) {
          noteRef.current = { ...cur, title, html };
          scheduleSave();
        }
        const w = waiters.current;
        waiters.current = [];
        w.forEach((f) => f());
        break;
      }
      case 'pickImage':
        pickImage();
        break;
      case 'pickVideo':
        pickVideo();
        break;
      case 'pickFile':
        pickFile();
        break;
      case 'pickCover':
        pickCover();
        break;
      case 'removeCover':
        removeCover();
        break;
      case 'askVideoUrl':
        setVideoDlg(true);
        break;
      case 'askLink':
        askLink(typeof m.current === 'string' ? m.current : null);
        break;
      case 'openLink':
        if (m.url) openLink(String(m.url));
        break;
      case 'openFile':
        if (m.uri) openFile(String(m.uri), m.name ? String(m.name) : undefined);
        break;
      case 'jserror':
        break;
    }
  };

  // ---------- visual ----------
  const head = (label: string, onPress: () => void, extra?: object) => (
    <Pressable onPress={onPress} hitSlop={14}>
      <Text style={[styles.headText, { fontSize: sw * 0.047 }, extra]}>{label}</Text>
    </Pressable>
  );

  const showHint = !editing && loaded && pendingInfo > 0;

  return (
    <View
      style={styles.root}
      onLayout={(e) => {
        curH.current = e.nativeEvent.layout.height;
        if (kbPad === 0) fullH.current = Math.max(fullH.current, curH.current);
      }}
    >
      <View style={[styles.header, { paddingTop: insets.top + sw * 0.03, paddingHorizontal: sw * 0.06 }]}>
        {head('← Voltar', () => close().catch(() => {}))}
        <View style={{ flexDirection: 'row', gap: sw * 0.055, alignItems: 'center' }}>
          <NoteRecorder ref={recRef} blockId={blockId} onPhase={setRecPhase} onSaved={afterRecorded} />
          {recPhase === 'idle' && (
            <>
              {head(fav ? '★' : '☆', () => toggleFav().catch(() => {}), { fontSize: sw * 0.06 })}
              {exporting ? (
                <ActivityIndicator color="#FFFFFF" />
              ) : (
                head('PDF', () => exportPdf().catch(() => {}))
              )}
              {editing && head('Concluído', () => finishEditing().catch(() => {}))}
            </>
          )}
        </View>
      </View>

      <View style={styles.card}>
        <WebView
          ref={web}
          originWhitelist={['*']}
          source={{ html: EDITOR_HTML, baseUrl: 'file:///' }}
          onMessage={onMessage}
          javaScriptEnabled
          allowFileAccess
          allowFileAccessFromFileURLs
          allowUniversalAccessFromFileURLs
          mixedContentMode="always"
          setSupportMultipleWindows={false}
          textZoom={100}
          overScrollMode="never"
          hideKeyboardAccessoryView
          automaticallyAdjustContentInsets={false}
          onShouldStartLoadWithRequest={(r) => r.url.startsWith('file:') || r.url.startsWith('about:')}
          style={{ backgroundColor: '#000000' }}
          containerStyle={{ backgroundColor: '#000000' }}
        />
        {showHint && (
          <View pointerEvents="none" style={[styles.hint, { left: sw * 0.075, right: sw * 0.075 }]}>
            <Text style={{ color: colors.gray, fontFamily: fonts.regular, fontSize: sw * 0.037, lineHeight: sw * 0.05 }}>
              {pendingInfo} {pendingInfo === 1 ? 'áudio espera' : 'áudios esperam'} transcrição (veja a Fila na tela de
              Gravação).
            </Text>
          </View>
        )}
      </View>

      <View style={{ height: kbPad > 0 ? kbPad : insets.bottom }} />

      <PromptDialog
        visible={linkDlg !== null}
        title={linkDlg?.current ? 'Editar link' : 'Adicionar link'}
        initialValue={linkDlg?.current ?? ''}
        placeholder="https://…"
        maxLength={1000}
        url
        onCancel={() => setLinkDlg(null)}
        onSubmit={(v) => {
          setLinkDlg(null);
          run(`window.applyLink(${lit(v)})`);
        }}
      />
      <PromptDialog
        visible={videoDlg}
        title="Link do vídeo"
        initialValue=""
        placeholder="YouTube, Vimeo ou link do vídeo"
        maxLength={1000}
        url
        onCancel={() => setVideoDlg(false)}
        onSubmit={(v) => {
          setVideoDlg(false);
          run(`window.insertVideoUrl(${lit(v)})`);
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: colors.bg },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingBottom: 6 },
  headText: { color: '#FFFFFF', fontFamily: fonts.bold, letterSpacing: -0.5 },
  card: { flex: 1, backgroundColor: colors.bg, overflow: 'hidden' },
  hint: { position: 'absolute', bottom: 16 },
});
