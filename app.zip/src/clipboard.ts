/**
 * Área de transferência interna do app para o editor de notas: uma caixa do layout livre (texto, imagem,
 * forma ou link) e um "pincel" de formatação. Vale entre notas enquanto o app estiver aberto.
 */
type Clip = { frame: unknown | null; style: unknown | null };
const clip: Clip = { frame: null, style: null };

export function setClip(what: 'frame' | 'style', data: unknown): void {
  if (what === 'frame') clip.frame = data ?? null;
  else clip.style = data ?? null;
}

/** JavaScript que entrega o conteúdo atual à página do editor (nota corrida ou layout livre). */
export const clipScript = (): string => `window.setClip&&window.setClip(${JSON.stringify(clip).replace(/</g, '\\u003c').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029')});true;`;
