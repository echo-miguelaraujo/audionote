import React, { memo, useCallback, useEffect, useRef, useState } from 'react';
import { Button, IconButton } from './Button';
import { Icon } from './Icon';
import { HeaderAction, ScreenHeader } from './ScreenHeader';
import {
  Animated,
  BackHandler,
  Easing,
  Image,
  Linking,
  PanResponder,
  Pressable,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { activateKeepAwakeAsync, deactivateKeepAwake } from 'expo-keep-awake';
import * as Clipboard from 'expo-clipboard';
import * as ImagePicker from 'expo-image-picker';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ActionItem, ActionMenu } from './ActionMenu';
import { StockPickerScreen } from './StockPickerScreen';
import { BottomSheet, SheetItem } from './BottomSheet';
import { Collage } from './Collage';
import { DotGrid } from './DotGrid';
import { appAlert, appToast, appError } from './dialog';
import {
  Block,
  MoodCollection,
  LINK_CARD,
  MoodItem,
  NOTE_CARD,
  SUBCOL_CARD,
  SWATCH_CARD,
  addMoodItem,
  addSubCollection,
  bringMoodItemToFront,
  collectionPath,
  createBlock,
  deleteCollection,
  deleteMoodItem,
  getCollectionName,
  linkNoteToCollection,
  listBlocks,
  listCollectionsByIds,
  listMoodItems,
  renameCollection,
  updateMoodItem,
} from './db';
import { deleteMedia, isRemote, mediaFile, mediaUri, saveMedia } from './media';
import { Image as RNImage } from 'react-native';
import { StockPhoto, labelOf, reportStockUse } from './stockImages';
import { PromptDialog } from './PromptDialog';
import { RichText, asHtml, plainOf } from './RichText';
import { TextEditorOverlay } from './TextEditorOverlay';
import { colors, fonts, HIT, TYPE, tracking } from './theme';
import { Rect, boxOf, frameToRatio, itemBounds, readableOn, unionBounds } from './boardGeometry';
import { ExportLayer } from './ExportLayer';
import { WebPickScreen } from './WebPickScreen';
import { FRAME_HD_PX, captureLayer, captureLayerSized, sharePdf, sharePng } from './exportBoard';
import { safeFileName } from './exportPdf';
import { ItemView, Live } from './ItemView';
import { CaptionDialog } from './CaptionDialog';
import { PresentationOverlay } from './PresentationOverlay';
import { focusStop, fitStop } from './boardTour';
import { CardColorDialog } from './CardColorDialog';
import { boardPaletteColors, extractPalette, parseSwatch } from './palette';
import { createLinkCard, linkHeight, refreshLinkCard } from './linkCards';
import { createVideoCard, dataFromWeb, downloadVideoCard, importLocalVideo, setVideoPoster } from './videoCards';
import { WebVideo, parseVideo, videoFiles } from './videoData';
import { domainOf, extractUrl, normalizeUrl, parseLink, stringifyLink } from './linkPreview';

/** Último link copiado que já foi usado ou recusado (vale para o app todo, para não repetir a sugestão). */
let lastClipUrl: string | null = null;

type Props = {
  collectionId: number;
  /** Muda quando algo fora desta tela mudou (nota editada, coleção de dentro alterada...): recarrega o quadro. */
  version: number;
  /** Volta um nível (para a coleção de fora, ou para a lista de coleções). */
  onClose: () => void;
  onOpenCollection: (id: number) => void;
  onOpenNote: (blockId: number) => void;
  /** Apresentação ligada (vale para todas as coleções abertas ao mesmo tempo). */
  presenting: boolean;
  /** Esta é a coleção que está na tela (a de cima da pilha). */
  isTop: boolean;
  onPresent: (on: boolean) => void;
};

/** Tamanho do quadro, em "larguras de tela" (1 = largura do celular). */
const WORLD_W = 5;
const WORLD_H = 8;
const MAX_ZOOM = 3;

type View2 = { tx: number; ty: number; z: number };
type Patch = Partial<Pick<MoodItem, 'x' | 'y' | 'w' | 'h' | 'rot'>>;
type ViewRef = React.MutableRefObject<View2>;

const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));


type LiveItem = Live & { id: number };

type ExportFmt = 'png' | 'pdf' | 'h169' | 'v916';
type ExportArea = 'all' | 'screen' | 'selected' | 'card';

/** Botões do quadro: usam os componentes padrão. Ficam fora do componente da tela (ver Button). */
function Btn({ label, onPress, red, u }: { label: string; onPress: () => void; red?: boolean; u: number }) {
  return <Button size="compact" variant={red ? 'destructive' : 'dark'} label={label} onPress={onPress} u={u} />;
}

export function CollectionScreen({
  collectionId,
  version,
  onClose,
  onOpenCollection,
  onOpenNote,
  presenting,
  isTop,
  onPresent,
}: Props) {
  const { width: sw, height: sh } = useWindowDimensions();
  // Unidade do quadro = lado menor da tela (a largura em pé). Assim nada muda de tamanho ao girar.
  const u = Math.min(sw, sh);
  const insets = useSafeAreaInsets();
  const [name, setName] = useState('');
  /** Nomes das coleções de fora, para o topo da tela ("Viagens › Japão"). */
  const [crumb, setCrumb] = useState('');
  const [items, setItems] = useState<MoodItem[]>([]);
  /** Dados das coleções de dentro e das notas vinculadas, por id (para desenhar os cartões). */
  const [subs, setSubs] = useState<Record<number, MoodCollection>>({});
  const [notes, setNotes] = useState<Record<number, Block>>({});
  const [subDlg, setSubDlg] = useState(false);
  const [noteSheet, setNoteSheet] = useState<Block[] | null>(null);
  const [selected, setSelected] = useState<number | null>(null);
  const [renaming, setRenaming] = useState(false);
  /** null = fechado; id 0 = novo texto; outro = editando esse item. */
  const [editor, setEditor] = useState<{ id: number; html: string } | null>(null);
  /** false = só visualizar (e arrastar); true = pode selecionar, editar, remover e adicionar. */
  const [editMode, setEditMode] = useState(false);
  const editModeRef = useRef(false);
  editModeRef.current = editMode;
  const selectedRef = useRef<number | null>(null);
  selectedRef.current = selected;
  /** "Selecionar vários": toques alternam a seleção de cada item; o quadro só arrasta/dá zoom. */
  const [multiMode, setMultiMode] = useState(false);
  const [multiSel, setMultiSel] = useState<number[]>([]);
  const multiModeRef = useRef(false);
  multiModeRef.current = multiMode;
  const exitMulti = useCallback(() => {
    setMultiMode(false);
    setMultiSel([]);
  }, []);
  const [colorDlg, setColorDlg] = useState(false);
  const lastTap = useRef(0);
  /** Dois toques seguidos em qualquer lugar do quadro entram no modo de edição (e já selecionam o item tocado). */
  const handleTap = useCallback((hitId: number | null) => {
    const now = Date.now();
    const dbl = now - lastTap.current < 400;
    lastTap.current = dbl ? 0 : now;
    if (dbl && !editModeRef.current) {
      setEditMode(true);
      if (hitId !== null) setSelected(hitId);
    }
  }, []);
  /** Tamanho real (em px do quadro) de cada item, medido na tela. */
  const sizes = useRef<Record<number, { w: number; h: number }>>({});
  const onSize = useCallback((id: number, w: number, h: number) => {
    sizes.current[id] = { w, h };
  }, []);
  const [live, setLive] = useState<LiveItem | null>(null);
  const liveRef = useRef<LiveItem | null>(null);

  // ---------- zoom e posição do quadro ----------
  const worldW = WORLD_W * u;
  const worldH = WORLD_H * u;
  const minZoom = Math.max(sw / worldW, sh / worldH);
  const view = useRef<View2>({ tx: 0, ty: 0, z: 1 });
  const atx = useRef(new Animated.Value(0)).current;
  const aty = useRef(new Animated.Value(0)).current;
  const az = useRef(new Animated.Value(1)).current;
  /** Animação de câmera em andamento (apresentação) e a posição real dela a cada instante. */
  const flying = useRef<Animated.CompositeAnimation | null>(null);
  const curCam = useRef<View2>({ tx: 0, ty: 0, z: 1 });
  useEffect(() => {
    const a = atx.addListener(({ value }) => (curCam.current.tx = value));
    const b = aty.addListener(({ value }) => (curCam.current.ty = value));
    const c = az.addListener(({ value }) => (curCam.current.z = value));
    return () => {
      atx.removeListener(a);
      aty.removeListener(b);
      az.removeListener(c);
    };
  }, [atx, aty, az]);
  const rootRef = useRef<View>(null);
  const origin = useRef({ x: 0, y: 0 });

  const clampView = useCallback(
    (v: View2): View2 => {
      const z = clamp(v.z, minZoom, MAX_ZOOM);
      return {
        z,
        tx: clamp(v.tx, sw - worldW * z, 0),
        ty: clamp(v.ty, sh - worldH * z, 0),
      };
    },
    [minZoom, sw, sh, worldW, worldH]
  );

  const setView = useCallback(
    (v: View2) => {
      const c = clampView(v);
      if (flying.current) {
        flying.current.stop();
        flying.current = null;
      }
      view.current = c;
      atx.setValue(c.tx);
      aty.setValue(c.ty);
      az.setValue(c.z);
    },
    [clampView, atx, aty, az]
  );

  const fitAll = useCallback(
    (list: MoodItem[]) => {
      if (list.length === 0) {
        // Coleção nova: começa no meio do quadro.
        setView({ z: 1, tx: sw / 2 - worldW / 2, ty: sh / 2 - worldH / 2 });
        return;
      }
      const t = fitStop(list, sizes.current, u, sw, sh, minZoom, 1);
      if (t) setView(t);
    },
    [setView, sw, sh, u, worldW, worldH, minZoom]
  );

  /** Lê o quadro do banco: itens, coleções de dentro e notas vinculadas. */
  const loadAll = async (fit: boolean) => {
    const list = await listMoodItems(collectionId);
    const subIds = list.filter((i) => i.kind === 'collection').map((i) => Number(i.content));
    const noteIds = list.filter((i) => i.kind === 'note').map((i) => Number(i.content));
    const [subList, noteList] = await Promise.all([listCollectionsByIds(subIds), listBlocks(noteIds)]);
    const subMap: Record<number, MoodCollection> = {};
    subList.forEach((c) => (subMap[c.id] = c));
    const noteMap: Record<number, Block> = {};
    noteList.forEach((b) => (noteMap[b.id] = b));
    // Cartão cujo destino não existe mais (não deveria acontecer) simplesmente não aparece.
    const visible = list.filter((i) =>
      i.kind === 'collection' ? !!subMap[Number(i.content)] : i.kind === 'note' ? !!noteMap[Number(i.content)] : true
    );
    setSubs(subMap);
    setNotes(noteMap);
    setItems(visible);
    if (fit) fitAll(visible);
  };

  const fitted = useRef(false);
  useEffect(() => {
    getCollectionName(collectionId).then(setName).catch(() => {});
    collectionPath(collectionId)
      .then((p) =>
        setCrumb(
          p
            .slice(0, -1)
            .map((x) => x.name)
            .join(' › ')
        )
      )
      .catch(() => {});
    loadAll(!fitted.current)
      .then(() => {
        fitted.current = true;
        // Aberta no meio de uma apresentação (mergulho): começa na visão geral, depois do quadro medir.
        if (presentingRef.current && dived.current) setTimeout(() => goOverview(false), 400);
      })
      .catch((e) => appError('Erro ao abrir a coleção', e));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [collectionId, version]);

  // Girou a tela: mantém o quadro dentro dos limites.
  useEffect(() => {
    setView(view.current);
    if (presentingRef.current) {
      // Na apresentação, girar a tela reenquadra o foco atual (ou a visão geral).
      const f = focusRef.current !== null ? itemsRef.current.find((i) => i.id === focusRef.current) : undefined;
      if (f) goFocus(f, false);
      else goOverview(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sw, sh, setView]);

  // Um único gesto para o quadro inteiro. Os itens não recebem toque: o quadro calcula qual item está sob o dedo.
  const handlers = useRef<{
    grant: (e: any) => void;
    move: (e: any) => void;
    release: () => void;
    terminate: () => void;
  }>({ grant() {}, move() {}, release() {}, terminate() {} });
  const bgPan = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderTerminationRequest: () => false,
      onPanResponderGrant: (e) => handlers.current.grant(e),
      onPanResponderMove: (e) => handlers.current.move(e),
      onPanResponderRelease: () => handlers.current.release(),
      onPanResponderTerminate: () => handlers.current.terminate(),
    })
  ).current;

  useEffect(() => {
    if (!isTop) return; // só a coleção que está na tela trata o botão voltar
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (presenting) {
        // Aberta por mergulho: sobe um nível; senão, sai da apresentação.
        if (dived.current) onClose();
        else onPresent(false);
      } else if (multiMode) exitMulti();
      else if (selected !== null) setSelected(null);
      else if (editMode) setEditMode(false);
      else onClose();
      return true;
    });
    return () => sub.remove();
  }, [selected, editMode, multiMode, exitMulti, onClose, presenting, isTop, onPresent]);

  const itemsRef = useRef(items);
  itemsRef.current = items;
  const sel = items.find((i) => i.id === selected) ?? null;

  const commit = useCallback((id: number, patch: Patch) => {
    setItems((prev) => prev.map((i) => (i.id === id ? { ...i, ...patch } : i)));
    updateMoodItem(id, patch).catch((e) => appError('Não consegui salvar a alteração', e));
  }, []);

  /** Ponto do quadro que está no centro da tela, em unidades de largura. */
  const viewCenter = () => {
    const v = view.current;
    return { x: (sw / 2 - v.tx) / v.z / u, y: (sh / 2 - v.ty) / v.z / u };
  };

  const addPhotos = async () => {
    try {
      const r = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ['images', 'videos'],
        allowsMultipleSelection: true,
        quality: 0.85,
      });
      if (r.canceled) return;
      const c = viewCenter();
      const z = view.current.z;
      const added: MoodItem[] = [];
      let vfailed = 0;
      for (const a of r.assets) {
        if (a.type === 'video') {
          // Vídeo escolhido junto com as fotos: vira cartão de vídeo (capa travada até o play).
          try {
            setBusy('Importando vídeo…');
            const d = await importLocalVideo(a.uri, a.fileName, { width: a.width, height: a.height, durationMs: a.duration });
            added.push(await createVideoCard(collectionId, d, c, clamp(1 / z, 0.4, 2.5), added.length));
          } catch {
            vfailed++;
          } finally {
            setBusy(null);
          }
          continue;
        }
        const stored = saveMedia(a.uri, a.fileName, 'jpg');
        const w = clamp(0.42 / z, 0.2, 1.4);
        const ratio = a.width && a.height ? a.height / a.width : 1.3;
        const h = clamp(w * ratio, w * 0.4, w * 2.5);
        const n = added.length;
        added.push(
          await addMoodItem({
            collectionId,
            kind: 'image',
            content: stored,
            x: clamp(c.x - w / 2 + n * 0.05 / z, 0, WORLD_W - w),
            y: clamp(c.y - h / 2 + n * 0.05 / z, 0, WORLD_H - h),
            w,
            h,
            rot: ((n % 5) - 2) * 4,
            bold: false,
          })
        );
      }
      setItems((prev) => [...prev, ...added]);
      if (added.length > 0) setSelected(added[added.length - 1].id);
      if (vfailed > 0) appToast(vfailed === 1 ? 'Um vídeo não foi importado' : `${vfailed} vídeos não foram importados`, 'Confira se há espaço no aparelho.');
    } catch (e) {
      appError('Não consegui adicionar a foto', e);
    }
  };

  /** Foto da web: vira um cartão de imagem que guarda só o endereço (nada é baixado). */
  const addWebPhotos = async (list: StockPhoto[]) => {
    setStockOpen(false);
    try {
      const c = viewCenter();
      const z = view.current.z;
      const added: MoodItem[] = [];
      for (const p of list) {
        RNImage.prefetch(p.fullUrl).catch(() => {}); // deixa a imagem no cache do celular
        if (!p.caption) reportStockUse(p).catch(() => {});
        let pw = p.width;
        let ph = p.height;
        if (p.sizeUnknown) {
          // O banco não diz o tamanho: mede a imagem para o card não cortar a foto.
          const sz = await new Promise<{ w: number; h: number } | null>((res) => {
            const t = setTimeout(() => res(null), 6000);
            RNImage.getSize(p.fullUrl, (w0, h0) => { clearTimeout(t); res({ w: w0, h: h0 }); }, () => { clearTimeout(t); res(null); });
          });
          if (sz) { pw = sz.w; ph = sz.h; }
        }
        const w = clamp(0.42 / z, 0.2, 1.4);
        const ratio = pw && ph ? ph / pw : 1.3;
        const h = clamp(w * ratio, w * 0.4, w * 2.5);
        const n = added.length;
        added.push(
          await addMoodItem({
            collectionId,
            kind: 'image',
            content: p.fullUrl,
            x: clamp(c.x - w / 2 + (n * 0.05) / z, 0, WORLD_W - w),
            y: clamp(c.y - h / 2 + (n * 0.05) / z, 0, WORLD_H - h),
            w,
            h,
            rot: ((n % 5) - 2) * 4,
            bold: false,
            caption: p.caption ?? `Foto: ${p.author} · ${labelOf(p.source)}${p.license ? ' · ' + p.license : ''}`,
          })
        );
      }
      setItems((prev) => [...prev, ...added]);
      if (added.length > 0) setSelected(added[added.length - 1].id);
    } catch (e) {
      appError('Não consegui adicionar a foto', e);
    }
  };

  /** Vídeo da galeria: o arquivo é copiado para o app e a capa é tirada do vídeo. */
  const addVideos = async () => {
    try {
      const r = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['videos'], allowsMultipleSelection: true });
      if (r.canceled) return;
      setBusy('Importando vídeo…');
      await new Promise((res) => setTimeout(res, 60)); // deixa o aviso aparecer antes da cópia
      const c = viewCenter();
      const k = clamp(1 / view.current.z, 0.4, 2.5);
      const added: MoodItem[] = [];
      let failed = 0;
      for (const a of r.assets) {
        try {
          const d = await importLocalVideo(a.uri, a.fileName, { width: a.width, height: a.height, durationMs: a.duration });
          added.push(await createVideoCard(collectionId, d, c, k, added.length));
        } catch {
          failed++;
        }
      }
      if (added.length > 0) {
        setItems((prev) => [...prev, ...added]);
        setSelected(added[added.length - 1].id);
      }
      if (failed > 0) appToast(failed === 1 ? 'Um vídeo não foi importado' : `${failed} vídeos não foram importados`, 'Confira se há espaço no aparelho.');
    } catch (e) {
      appError('Não consegui adicionar o vídeo', e);
    } finally {
      setBusy(null);
    }
  };

  /** Vídeo da web ou de um banco: guarda só o endereço (e a capa). Dá para baixar depois, pelo menu do cartão. */
  const addWebVideos = async (list: WebVideo[]) => {
    setVideoStockOpen(false);
    if (list.length === 0) return;
    setBusy('Adicionando vídeo…');
    try {
      const c = viewCenter();
      const k = clamp(1 / view.current.z, 0.4, 2.5);
      const added: MoodItem[] = [];
      let failed = 0;
      for (const v of list) {
        try {
          const src = v.src || (await v.resolve?.()) || '';
          if (!src) {
            failed++;
            continue;
          }
          const d = await dataFromWeb({ ...v, src });
          added.push(await createVideoCard(collectionId, d, c, k, added.length, v.caption));
        } catch {
          failed++;
        }
      }
      if (added.length > 0) {
        setItems((prev) => [...prev, ...added]);
        setSelected(added[added.length - 1].id);
      }
      if (failed > 0) appToast(failed === 1 ? 'Um vídeo não foi adicionado' : `${failed} vídeos não foram adicionados`, 'Não achei o arquivo do vídeo.');
    } catch (e) {
      appError('Não consegui adicionar o vídeo', e);
    } finally {
      setBusy(null);
    }
  };

  /** Vídeo tocando dentro do cartão (capa travada até o play). Tocar de novo volta para a capa. */
  const [inlineId, setInlineId] = useState<number | null>(null);
  const playVideo = (it: MoodItem) => {
    const d = parseVideo(it.content);
    if (!d.src) {
      appToast('Vídeo indisponível');
      return;
    }
    setInlineId((cur) => (cur === it.id ? null : it.id));
  };
  const onPlayFail = useCallback((id: number) => {
    setInlineId((cur) => (cur === id ? null : cur));
    appToast('Não consegui tocar este vídeo', 'Se for da web, o endereço pode ter expirado.');
  }, []);

  const downloadSel = async (it: MoodItem) => {
    setBusy('Baixando vídeo…');
    try {
      const r = await downloadVideoCard(it.id, it.content);
      if (r.ok) {
        patchItem(it.id, { content: r.content });
        appToast('Vídeo salvo no aparelho');
      } else if (r.reason === 'stream') appAlert('Não dá para baixar', 'Este vídeo é uma transmissão (m3u8), não um arquivo. Ele toca, mas só com internet.');
      else if (r.reason === 'big') appAlert('Arquivo grande demais', 'O limite para baixar é 150 MB. O vídeo continua tocando pela internet.');
      else appAlert('Não consegui baixar', 'O site pode ter bloqueado o download ou o endereço expirou.');
    } catch (e) {
      appError('Não consegui baixar o vídeo', e);
    } finally {
      setBusy(null);
    }
  };

  const pickPoster = async (it: MoodItem) => {
    try {
      const r = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: 0.85 });
      if (r.canceled || !r.assets[0]) return;
      const a = r.assets[0];
      patchItem(it.id, { content: await setVideoPoster(it.id, it.content, a.uri, a.fileName) });
    } catch (e) {
      appError('Não consegui trocar a capa', e);
    }
  };

  /** Abre o que o cartão aponta: a coleção de dentro ou a nota. */
  const openCard = (it: MoodItem) => {
    if (it.kind === 'link') {
      const url = parseLink(it.content).url;
      if (url) Linking.openURL(url).catch(() => appToast('Não consegui abrir o link', url));
      return;
    }
    if (it.kind === 'video') {
      playVideo(it);
      return;
    }
    const id = Number(it.content);
    if (!Number.isFinite(id)) return;
    if (it.kind === 'collection') onOpenCollection(id);
    else if (it.kind === 'note') onOpenNote(id);
  };

  // ---------- apresentação (exploração por toque + mergulho + legendas) ----------
  const presentingRef = useRef(presenting);
  presentingRef.current = presenting;
  const [focusId, setFocusId] = useState<number | null>(null);
  const focusRef = useRef<number | null>(null);
  focusRef.current = focusId;
  /** Câmera e modo de edição de antes da apresentação, para restaurar ao sair. */
  const savedPres = useRef<{ view: View2; editMode: boolean } | null>(null);
  /** Esta tela já nasceu em apresentação (mergulho): "voltar" sobe um nível em vez de sair da apresentação. */
  const dived = useRef(presenting);

  /** Anima a câmera até `t` (ease in-out). Um novo pedido interrompe o anterior; view.current já aponta o destino. */
  const flyTo = (t: View2, ms = 500) => {
    flying.current?.stop();
    const c = clampView(t);
    view.current = c;
    const step = (v: Animated.Value, to: number) =>
      Animated.timing(v, { toValue: to, duration: ms, easing: Easing.inOut(Easing.ease), useNativeDriver: false });
    const anim = Animated.parallel([step(atx, c.tx), step(aty, c.ty), step(az, c.z)]);
    flying.current = anim;
    anim.start(() => {
      if (flying.current === anim) flying.current = null;
    });
  };

  /** Dedo na tela no meio da animação: para onde ela estava e segue dali. */
  const stopFly = () => {
    if (!flying.current) return;
    flying.current.stop();
    flying.current = null;
    view.current = clampView({ ...curCam.current });
  };

  const goOverview = (animate = true) => {
    setFocusId(null);
    const t = fitStop(itemsRef.current, sizes.current, u, sw, sh, minZoom, 1);
    if (!t) return;
    if (animate) flyTo(t);
    else setView(t);
  };

  const goFocus = (it: MoodItem, animate = true) => {
    setFocusId(it.id);
    const t = focusStop(it, sizes.current, u, sw, sh, minZoom, MAX_ZOOM, !!it.caption);
    if (animate) flyTo(t);
    else setView(t);
  };

  /** Ordem da apresentação: leitura (de cima para baixo, da esquerda para a direita; itens na mesma faixa de ~0.3 u contam como uma linha). */
  const presentOrder = (): MoodItem[] => {
    const cy = (i: MoodItem) => {
      const b = itemBounds(i, sizes.current, u);
      return { x: b.x + b.w / 2, y: b.y + b.h / 2 };
    };
    const arr = itemsRef.current.map((i) => ({ i, c: cy(i) })).sort((a, b) => a.c.y - b.c.y);
    const rows: { i: MoodItem; c: { x: number; y: number } }[][] = [];
    for (const e of arr) {
      const row = rows[rows.length - 1];
      if (row && e.c.y - row[0].c.y < 0.3) row.push(e);
      else rows.push([e]);
    }
    return rows.flatMap((r) => r.sort((a, b) => a.c.x - b.c.x).map((e) => e.i));
  };

  /** Índice do foco na ordem (-1 = visão geral). */
  const presentIndex = (order: MoodItem[]) => (focusRef.current === null ? -1 : order.findIndex((i) => i.id === focusRef.current));

  /** Avançar (+1) ou voltar (-1): visão geral → 1º item → … → último; voltando do 1º item, vai à visão geral. */
  const presentStep = (dir: 1 | -1) => {
    const order = presentOrder();
    if (order.length === 0) return;
    const next = presentIndex(order) + dir;
    if (next < 0) goOverview(true);
    else if (next < order.length) goFocus(order[next], true);
  };

  const enterCollection = (it: MoodItem) => {
    const id = Number(it.content);
    if (Number.isFinite(id)) onOpenCollection(id);
  };

  /** Toque curto na apresentação: enquadra o item; toque de novo numa coleção entra nela; no vazio, volta à visão geral. */
  const presentTap = (hitId: number | null) => {
    const it = hitId !== null ? itemsRef.current.find((i) => i.id === hitId) : undefined;
    if (!it) {
      if (focusRef.current !== null) goOverview(true);
      return;
    }
    if (it.id === focusRef.current && it.kind === 'collection') {
      enterCollection(it);
      return;
    }
    if (it.id === focusRef.current && it.kind === 'video') {
      playVideo(it);
      return;
    }
    goFocus(it, true); // nota e link: só foco, sem abrir
  };

  const prevPresenting = useRef(false);
  useEffect(() => {
    if (presenting && !prevPresenting.current) {
      if (isTop || dived.current) {
        savedPres.current = { view: { ...view.current }, editMode };
        setEditMode(false);
        setSelected(null);
        exitMulti();
        setColorDlg(false);
        if (itemsRef.current.length > 0) goOverview(true);
      }
    } else if (!presenting && prevPresenting.current) {
      setFocusId(null);
      const s0 = savedPres.current;
      savedPres.current = null;
      if (s0) {
        setView(s0.view);
        setEditMode(s0.editMode);
      }
    }
    prevPresenting.current = presenting;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [presenting]);

  // Tela acesa só durante a apresentação.
  useEffect(() => {
    if (!presenting) return;
    const tag = `presentation-${collectionId}`;
    activateKeepAwakeAsync(tag).catch(() => {});
    return () => {
      deactivateKeepAwake(tag).catch(() => {});
    };
  }, [presenting, collectionId]);

  const [captionDlg, setCaptionDlg] = useState(false);
  const saveCaption = (text: string) => {
    setCaptionDlg(false);
    if (!sel) return;
    const caption = text ? text : null;
    patchItem(sel.id, { caption });
    updateMoodItem(sel.id, { caption }).catch((e) => appError('Não consegui salvar a legenda', e));
  };
  useEffect(() => {
    if (inlineId !== null && selected !== inlineId && focusId !== inlineId) setInlineId(null);
  }, [selected, focusId, inlineId]);
  const focusItem = focusId !== null ? items.find((i) => i.id === focusId) : undefined;

  // ---------- exportar (PNG / PDF / cartão) ----------
  const [exporting, setExporting] = useState<{ items: MoodItem[]; rect: Rect; background: boolean } | null>(null);
  const layerRef = useRef<View>(null);
  const layerReady = useRef<(() => void) | null>(null);

  /**
   * Exporta uma área do quadro. 'card' = só o item `only`, endireitado (sem giro).
   * Formatos: 'png' (recorte, fundo transparente), 'pdf', 'h169' (imagem 16:9 HD com fundo pontilhado)
   * e 'v916' (9:16 HD, para stories).
   */
  const runExport = async (fmt: ExportFmt, area: ExportArea, only?: MoodItem) => {
    const list = itemsRef.current;
    const frame = fmt === 'h169' || fmt === 'v916';
    let chosen: MoodItem[] = [];
    let rect: Rect | null = null;
    if (area === 'card' && only) {
      chosen = [{ ...only, rot: 0 }];
      rect = unionBounds(chosen, sizes.current, u, 0.02);
    } else if (area === 'all') {
      chosen = list;
      rect = unionBounds(list, sizes.current, u, frame ? 0.14 : 0.08);
    } else if (area === 'screen') {
      const v = view.current;
      const r: Rect = { x: -v.tx / v.z / u, y: -v.ty / v.z / u, w: sw / v.z / u, h: sh / v.z / u };
      chosen = list.filter((i) => {
        const b = itemBounds(i, sizes.current, u);
        return b.x < r.x + r.w && b.x + b.w > r.x && b.y < r.y + r.h && b.y + b.h > r.y;
      });
      rect = chosen.length > 0 ? r : null; // recorta na própria tela, não no item
    } else {
      const ids = multiMode ? multiSel : selected !== null ? [selected] : [];
      chosen = list.filter((i) => ids.includes(i.id));
      rect = unionBounds(chosen, sizes.current, u, frame ? 0.14 : 0.04);
    }
    if (!rect || chosen.length === 0) {
      appAlert(area === 'screen' ? 'Nada na tela' : 'Quadro vazio', 'Não há itens para exportar nessa área.');
      return;
    }
    let outW = 0;
    let outH = 0;
    if (frame) {
      const ratio = fmt === 'h169' ? 16 / 9 : 9 / 16;
      rect = frameToRatio(rect, ratio);
      outW = fmt === 'h169' ? FRAME_HD_PX : Math.round(FRAME_HD_PX * ratio);
      outH = fmt === 'h169' ? Math.round(FRAME_HD_PX / ratio) : FRAME_HD_PX;
      if (area === 'all' || area === 'screen') {
        // Com o quadro mais largo/alto que a área, entram também os itens que ficaram dentro dele.
        const f = rect;
        chosen = list.filter((i) => {
          const b = itemBounds(i, sizes.current, u);
          return b.x < f.x + f.w && b.x + b.w > f.x && b.y < f.y + f.h && b.y + b.h > f.y;
        });
      }
    }
    const wPx = Math.max(1, Math.round(rect.w * u));
    const hPx = Math.max(1, Math.round(rect.h * u));
    const r0 = rect;
    setExporting({ items: chosen.map((i) => ({ ...i, x: i.x - r0.x, y: i.y - r0.y })), rect: r0, background: frame });
    try {
      await new Promise<void>((resolve) => {
        layerReady.current = resolve;
      });
      const base = area === 'card' ? `${safeFileName(name, 'Quadro')}_cartao` : safeFileName(name, 'Quadro');
      if (frame) {
        const img = await captureLayerSized(layerRef, outW, outH);
        await sharePng(`${base}_${fmt === 'h169' ? '16x9' : '9x16'}`, img.uri);
      } else {
        const png = await captureLayer(layerRef, wPx, hPx);
        if (fmt === 'png') await sharePng(base, png.uri);
        else await sharePdf(base, png.uri, png.w, png.h);
      }
    } catch (e) {
      appError('Não consegui exportar', e);
    } finally {
      layerReady.current = null;
      setExporting(null);
    }
  };

  /** Menus de baixo (mesmo layout de "+ Adicionar" e "Mais"). */
  const [shareMenu, setShareMenu] = useState(false);
  /** Formato escolhido, esperando a escolha da área. */
  const [areaMenu, setAreaMenu] = useState<ExportFmt | null>(null);
  /** Atalho dos selecionados (modo "Selecionar vários"): escolhe só o formato. */
  const [selFmtMenu, setSelFmtMenu] = useState(false);

  const hasExportSel = editMode && (multiMode ? multiSel.length > 0 : selected !== null);

  const FORMATS: { key: ExportFmt; label: string }[] = [
    { key: 'h169', label: 'Imagem 16:9 (HD)' },
    { key: 'v916', label: 'Imagem 9:16 (HD, stories)' },
    { key: 'png', label: 'PNG recortado (sem fundo)' },
    { key: 'pdf', label: 'PDF' },
  ];

  const askExport = () => {
    if (itemsRef.current.length === 0) {
      appToast('Quadro vazio', 'Adicione itens ao quadro antes de exportar.');
      return;
    }
    setShareMenu(true);
  };

  const shareItems: ActionItem[] = [
    ...FORMATS.map((f) => ({ key: f.key, label: f.label, onPress: () => setAreaMenu(f.key) })),
    { key: 'present', label: 'Apresentar', onPress: () => onPresent(true) },
  ];
  const areaItems: ActionItem[] = areaMenu
    ? [
        { key: 'screen', label: 'O que está na tela agora', onPress: () => runExport(areaMenu, 'screen') },
        { key: 'all', label: 'Quadro todo', onPress: () => runExport(areaMenu, 'all') },
        { key: 'selected', label: 'Itens selecionados', disabled: !hasExportSel, onPress: () => runExport(areaMenu, 'selected') },
      ]
    : [];
  const selFmtItems: ActionItem[] = FORMATS.map((f) => ({
    key: f.key,
    label: f.label,
    onPress: () => runExport(f.key, 'selected'),
  }));

  // ---------- paleta de cores ----------
  const [busy, setBusy] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const showToast = (t: string) => {
    setToast(t);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 1800);
  };
  useEffect(
    () => () => {
      if (toastTimer.current) clearTimeout(toastTimer.current);
    },
    []
  );

  const copyText = async (text: string, msg: string) => {
    try {
      await Clipboard.setStringAsync(text);
      showToast(msg);
    } catch (e) {
      appError('Não consegui copiar', e);
    }
  };

  /** Toque numa faixa de um cartão de paleta já selecionado: copia aquele hex. */
  const copyStripe = (it: MoodItem, px: number, py: number) => {
    const sd = parseSwatch(it.content);
    if (!sd) return;
    const v = view.current;
    const wx = (px - v.tx) / v.z;
    const wy = (py - v.ty) / v.z;
    const sz = sizes.current[it.id] ?? { w: it.w * u, h: it.h * u };
    const a = (-(it.rot || 0) * Math.PI) / 180;
    const dx = wx - (it.x * u + sz.w / 2);
    const dy = wy - (it.y * u + sz.h / 2);
    const lx = dx * Math.cos(a) - dy * Math.sin(a);
    const pad = u * 0.02 * (it.w / SWATCH_CARD.w);
    const f = clamp((lx + sz.w / 2 - pad) / Math.max(1, sz.w - pad * 2), 0, 0.999);
    const hex = sd.colors[Math.floor(f * sd.colors.length)];
    copyText(hex, `${hex} copiado`);
  };

  /** Imagens do quadro (maiores primeiro, até 30) para a paleta do quadro inteiro. */
  const boardImageNames = (): string[] =>
    itemsRef.current
      .filter((i) => i.kind === 'image')
      .sort((a, b) => b.w * b.h - a.w * a.h)
      .slice(0, 30)
      .map((i) => i.content);

  const runExtract = async (names: string[]): Promise<string[] | null> => {
    setBusy('Extraindo cores…');
    try {
      return await extractPalette(names, 5);
    } catch (e) {
      appAlert('Não consegui extrair as cores', e instanceof Error ? e.message : String(e));
      return null;
    } finally {
      setBusy(null);
    }
  };

  /** Cria o cartão de paleta. `near` = imagem ao lado da qual ele nasce; sem ela, no centro da visão. */
  const makePalette = async (names: string[], whole: boolean, near?: MoodItem) => {
    if (names.length === 0) return;
    const colors = await runExtract(names);
    if (!colors) return;
    try {
      const w = SWATCH_CARD.w;
      const h = SWATCH_CARD.h;
      let x: number;
      let y: number;
      if (near) {
        const b = itemBounds(near, sizes.current, u);
        x = b.x + b.w + 0.05;
        y = b.y;
        if (x + w > WORLD_W) {
          x = near.x;
          y = b.y + b.h + 0.05;
        }
      } else {
        const c = viewCenter();
        x = c.x - w / 2;
        y = c.y - h / 2;
      }
      const it = await addMoodItem({
        collectionId,
        kind: 'swatch',
        content: JSON.stringify({ v: 1, colors, src: whole ? [] : names }),
        x: clamp(x, 0, WORLD_W - w),
        y: clamp(y, 0, WORLD_H - h),
        w,
        h,
        rot: 0,
        bold: false,
      });
      exitMulti();
      setItems((prev) => [...prev, it]);
      setSelected(it.id);
    } catch (e) {
      appError('Não consegui criar a paleta', e);
    }
  };

  /** Recalcula as cores de um cartão a partir de `src` (ou das imagens do quadro, se o cartão era do quadro todo). */
  const refreshSwatch = async (it: MoodItem) => {
    const sd = parseSwatch(it.content);
    const src = sd?.src ?? [];
    const names = src.length > 0 ? src.filter((n) => isRemote(n) || mediaFile(n).exists) : boardImageNames();
    if (names.length === 0) {
      appAlert('Não consegui atualizar', 'As imagens de origem não estão mais aqui.');
      return;
    }
    const colors = await runExtract(names);
    if (!colors) return;
    const content = JSON.stringify({ v: 1, colors, src });
    patchItem(it.id, { content });
    updateMoodItem(it.id, { content }).catch((e) => appError('Não consegui salvar a paleta', e));
  };

  // ---------- cartões de link ----------
  const [linkDlg, setLinkDlg] = useState<{ initial: string } | null>(null);
  const [editLinkId, setEditLinkId] = useState<number | null>(null);
  /** Link copiado que ainda não foi aceito nem recusado (faixa "Criar cartão do link copiado?"). */
  const [clipUrl, setClipUrl] = useState<string | null>(null);

  const patchItem = (id: number, p: Partial<MoodItem>) =>
    setItems((prev) => prev.map((i) => (i.id === id ? { ...i, ...p } : i)));

  /** Busca a prévia em segundo plano e atualiza o cartão sem travar a tela. */
  const refreshLink = async (id: number, content: string, quiet = true) => {
    try {
      const r = await refreshLinkCard(id, content);
      patchItem(id, { content: r.content, h: r.h });
      if (!quiet && !r.ok) appToast('Sem prévia', 'Não consegui buscar a prévia agora. Tente de novo mais tarde.');
    } catch {
      /* o cartão continua com o que já tem */
    }
  };

  const addLink = async (url: string) => {
    try {
      const c = viewCenter();
      const it = await createLinkCard(collectionId, url, c);
      lastClipUrl = url;
      setClipUrl(null);
      setItems((prev) => [...prev, it]);
      setSelected(it.id);
      refreshLink(it.id, it.content);
    } catch (e) {
      appError('Não consegui criar o cartão do link', e);
    }
  };

  const openLinkDialog = async () => {
    let initial = '';
    try {
      const t = await Clipboard.getStringAsync();
      initial = extractUrl(t) ?? '';
    } catch {
      /* sem acesso à área de transferência */
    }
    setLinkDlg({ initial });
  };

  // Só ao entrar no modo de edição: oferece criar o cartão do link copiado (uma vez por link).
  useEffect(() => {
    if (!editMode) {
      setClipUrl(null);
      return;
    }
    let alive = true;
    Clipboard.getStringAsync()
      .then((t) => {
        const url = extractUrl(t);
        if (alive && url && url !== lastClipUrl) setClipUrl(url);
      })
      .catch(() => {});
    return () => {
      alive = false;
    };
  }, [editMode]);

  const pickThumb = async (it: MoodItem) => {
    try {
      const r = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: 0.85 });
      if (r.canceled || !r.assets[0]) return;
      const a = r.assets[0];
      const d = parseLink(it.content);
      const next = { ...d, img: saveMedia(a.uri, a.fileName, 'jpg'), custom: true };
      const h = linkHeight(next);
      await updateMoodItem(it.id, { content: stringifyLink(next), h });
      if (d.img) deleteMedia(d.img);
      patchItem(it.id, { content: stringifyLink(next), h });
    } catch (e) {
      appError('Não consegui trocar a miniatura', e);
    }
  };

  const dropThumb = async (it: MoodItem) => {
    try {
      const d = parseLink(it.content);
      const next = { ...d, img: null, custom: true };
      const h = linkHeight(next);
      await updateMoodItem(it.id, { content: stringifyLink(next), h });
      if (d.img) deleteMedia(d.img);
      patchItem(it.id, { content: stringifyLink(next), h });
    } catch (e) {
      appError('Não consegui remover a miniatura', e);
    }
  };

  const changeLinkUrl = async (it: MoodItem, raw: string) => {
    const url = normalizeUrl(raw);
    if (!url) {
      appAlert('Link inválido', 'Use um endereço que comece com http:// ou https://.');
      return;
    }
    const d = parseLink(it.content);
    const next = { ...d, url, title: domainOf(url), desc: '', site: domainOf(url), fetchedAt: null };
    await updateMoodItem(it.id, { content: stringifyLink(next) });
    patchItem(it.id, { content: stringifyLink(next) });
    refreshLink(it.id, stringifyLink(next), false);
  };

  const addSub = async (nameText: string) => {
    const c = viewCenter();
    const k = clamp(1 / view.current.z, 0.55, 2.6);
    const w = SUBCOL_CARD.w * k;
    const h = SUBCOL_CARD.h * k;
    const it = await addSubCollection(
      collectionId,
      nameText,
      clamp(c.x - w / 2, 0, WORLD_W - w),
      clamp(c.y - h / 2, 0, WORLD_H - h),
      k
    );
    const subId = Number(it.content);
    setSubs((prev) => ({
      ...prev,
      [subId]: { id: subId, name: nameText, parentId: collectionId, count: 0, covers: [], x: null, y: null },
    }));
    setItems((prev) => [...prev, it]);
    setSelected(it.id);
  };

  /** Abre a lista de notas que ainda não estão neste quadro. */
  const openNoteSheet = async () => {
    try {
      const all = await listBlocks();
      const have = new Set(itemsRef.current.filter((i) => i.kind === 'note').map((i) => Number(i.content)));
      setNoteSheet(all.filter((b) => !have.has(b.id)));
    } catch (e) {
      appError('Não consegui ler as notas', e);
    }
  };

  /** Põe o cartão da nota no centro do que está sendo visto. */
  const linkNote = async (blockId: number): Promise<boolean> => {
    const c = viewCenter();
    const k = clamp(1 / view.current.z, 0.55, 2.6);
    const w = NOTE_CARD.w * k;
    const h = NOTE_CARD.h * k;
    const it = await linkNoteToCollection(blockId, collectionId, {
      x: clamp(c.x - w / 2, 0, WORLD_W - w),
      y: clamp(c.y - h / 2, 0, WORLD_H - h),
    });
    if (!it) return false;
    await updateMoodItem(it.id, { w, h });
    await loadAll(false);
    setSelected(it.id);
    return true;
  };

  const noteSheetItems: SheetItem[] =
    noteSheet === null
      ? []
      : noteSheet.length === 0
        ? [{ key: 'none', label: 'Nenhuma outra nota para vincular', muted: true }]
        : noteSheet.map((b) => ({
            key: String(b.id),
            label: b.noteTitle || b.name,
            onPress: () => {
              setNoteSheet(null);
              linkNote(b.id).catch((e) => appError('Não consegui vincular a nota', e));
            },
          }));

  const finishEditor = async (html: string) => {
    const ed = editor;
    setEditor(null);
    if (!ed) return;
    const empty = plainOf(html) === '';
    if (ed.id === 0) {
      if (empty) return;
      const c = viewCenter();
      const z = view.current.z;
      const w = clamp(0.06 / z, 0.03, 0.5); // tamanho da letra
      const box = clamp(0.6 / z, 0.3, 2.5); // largura da caixa
      const it = await addMoodItem({
        collectionId,
        kind: 'text',
        content: html,
        x: clamp(c.x - box / 2, 0, WORLD_W - box),
        y: clamp(c.y - 0.1, 0, WORLD_H - 0.2),
        w,
        h: box,
        rot: 0,
        bold: false,
      });
      setItems((prev) => [...prev, it]);
      setSelected(it.id);
    } else if (empty) {
      await removeItem(ed.id);
    } else {
      setItems((prev) => prev.map((i) => (i.id === ed.id ? { ...i, content: html } : i)));
      updateMoodItem(ed.id, { content: html }).catch((e) => appError('Não consegui salvar o texto', e));
    }
  };

  const openEditor = useCallback((id: number) => {
    const it = itemsRef.current.find((i) => i.id === id);
    // Espera o toque terminar de vez antes de montar o editor por cima (evita o toque 'vazar' para ele).
    if (it && it.kind === 'text') setTimeout(() => setEditor({ id, html: asHtml(it.content) }), 120);
  }, []);

  // ---------- gestos do quadro ----------
  type Pt = { x: number; y: number };
  const getPts = (e: any): Pt[] =>
    ((e.nativeEvent.touches ?? []) as any[]).map((p) => ({ x: p.pageX - origin.current.x, y: p.pageY - origin.current.y }));
  const centroid = (pts: Pt[]): Pt =>
    pts.length >= 2
      ? { x: (pts[0].x + pts[1].x) / 2, y: (pts[0].y + pts[1].y) / 2 }
      : { x: pts[0].x, y: pts[0].y };
  const pinchOf = (pts: Pt[]) => ({
    dist: Math.hypot(pts[1].x - pts[0].x, pts[1].y - pts[0].y),
    ang: (Math.atan2(pts[1].y - pts[0].y, pts[1].x - pts[0].x) * 180) / Math.PI,
  });

  const gs = useRef({
    n: 0,
    moved: false,
    multi: false,
    hit: null as number | null,
    wasSelected: false,
    mode: 'none' as 'none' | 'board' | 'item' | 'pinchBoard' | 'pinchItem',
    target: null as number | null,
    sx: 0,
    sy: 0,
    cx: 0,
    cy: 0,
    dist: 0,
    ang: 0,
    bv: { tx: 0, ty: 0, z: 1 } as View2,
  });

  /** Qual item está sob o ponto (px, py) da tela? O de cima primeiro. Conta feita aqui, com giro e uma folga para o dedo. */
  const hitTest = (px: number, py: number): MoodItem | null => {
    const v = view.current;
    const wx = (px - v.tx) / v.z;
    const wy = (py - v.ty) / v.z;
    const slop = 14 / v.z;
    const list = itemsRef.current;
    for (let i = list.length - 1; i >= 0; i--) {
      const it = list[i];
      const box = boxOf(it);
      const sz = sizes.current[it.id] ?? { w: box.w * u, h: box.h * u };
      const cx = it.x * u + sz.w / 2;
      const cy = it.y * u + sz.h / 2;
      const a = (-(it.rot || 0) * Math.PI) / 180;
      const dx = wx - cx;
      const dy = wy - cy;
      const lx = dx * Math.cos(a) - dy * Math.sin(a);
      const ly = dx * Math.sin(a) + dy * Math.cos(a);
      if (Math.abs(lx) <= sz.w / 2 + slop && Math.abs(ly) <= sz.h / 2 + slop) return it;
    }
    return null;
  };

  const setLiveBoth = (l: LiveItem | null) => {
    liveRef.current = l;
    setLive(l);
  };

  /** Grava no item o que o dedo fez até agora (arrasto, tamanho, giro). */
  const commitLive = () => {
    const L = liveRef.current;
    if (!L) return;
    setLiveBoth(null);
    const it = itemsRef.current.find((i) => i.id === L.id);
    if (!it) return;
    const sz = sizes.current[it.id] ?? { w: 0, h: 0 };
    const bw = sz.w / u;
    const bh = sz.h / u;
    const sc = clamp(L.s, 0.1, 8);
    commit(it.id, {
      // A escala é em volta do centro; ao gravar, o canto superior esquerdo acompanha.
      x: clamp(it.x + L.dx / u + (bw * (1 - sc)) / 2, -0.3, WORLD_W - 0.1),
      y: clamp(it.y + L.dy / u + (bh * (1 - sc)) / 2, -0.3, WORLD_H - 0.1),
      rot: it.rot + L.r,
      w: it.w * sc,
      h: it.h * sc,
    });
  };

  const rebase = (pts: Pt[]) => {
    const g = gs.current;
    const n = Math.min(2, pts.length);
    const c = centroid(pts);
    g.n = n;
    g.cx = c.x;
    g.cy = c.y;
    if (n === 2) {
      const p = pinchOf(pts);
      g.dist = p.dist;
      g.ang = p.ang;
    }
    g.bv = { ...view.current };
  };

  /** Chegou o segundo dedo: no modo de edição com item selecionado/tocado, é pinça e giro do item; senão, zoom do quadro. */
  const enterMulti = () => {
    const g = gs.current;
    g.multi = true;
    g.moved = true;
    const tgt = editModeRef.current && !multiModeRef.current && !presentingRef.current ? g.hit ?? selectedRef.current : null;
    if (tgt !== null) {
      g.mode = 'pinchItem';
      g.target = tgt;
      if (selectedRef.current !== tgt) setSelected(tgt);
    } else {
      g.mode = 'pinchBoard';
    }
  };

  handlers.current = {
    grant: (e) => {
      const g = gs.current;
      const pts = getPts(e);
      if (pts.length === 0) return;
      stopFly();
      const hit = hitTest(pts[0].x, pts[0].y);
      g.moved = false;
      g.multi = false;
      g.target = null;
      g.hit = hit ? hit.id : null;
      g.wasSelected = hit !== null && selectedRef.current === hit.id;
      g.sx = pts[0].x;
      g.sy = pts[0].y;
      setLiveBoth(null);
      rebase(pts);
      g.mode = hit && !multiModeRef.current && !presentingRef.current ? 'item' : 'board';
      if (g.n === 2) enterMulti();
      if (editModeRef.current && !multiModeRef.current && hit && selectedRef.current !== hit.id) setSelected(hit.id);
    },
    move: (e) => {
      const g = gs.current;
      const pts = getPts(e);
      if (pts.length === 0) return;
      const n = Math.min(2, pts.length);
      if (n !== g.n) {
        // Mudou o número de dedos: grava o que já foi feito e recomeça dali.
        commitLive();
        rebase(pts);
        if (n === 2) enterMulti();
        else g.mode = 'none';
        return;
      }
      const c = centroid(pts);
      if (!g.moved && n === 1 && Math.hypot(c.x - g.sx, c.y - g.sy) > 10) g.moved = true;
      const z = view.current.z || 1;
      if (g.mode === 'board') {
        setView({ z: g.bv.z, tx: g.bv.tx + (c.x - g.cx), ty: g.bv.ty + (c.y - g.cy) });
      } else if (g.mode === 'item' && g.moved && g.hit !== null) {
        setLiveBoth({ id: g.hit, dx: (c.x - g.cx) / z, dy: (c.y - g.cy) / z, s: 1, r: 0 });
      } else if (g.mode === 'pinchBoard') {
        const p = pinchOf(pts);
        const nz = clamp(g.bv.z * (p.dist / (g.dist || 1)), minZoom, MAX_ZOOM);
        const wx = (g.cx - g.bv.tx) / g.bv.z;
        const wy = (g.cy - g.bv.ty) / g.bv.z;
        setView({ z: nz, tx: c.x - wx * nz, ty: c.y - wy * nz });
      } else if (g.mode === 'pinchItem' && g.target !== null) {
        const p = pinchOf(pts);
        let d = p.ang - g.ang;
        while (d > 180) d -= 360;
        while (d < -180) d += 360;
        setLiveBoth({
          id: g.target,
          dx: (c.x - g.cx) / z,
          dy: (c.y - g.cy) / z,
          s: clamp(p.dist / (g.dist || 1), 0.2, 5),
          r: d,
        });
      }
    },
    release: () => {
      const g = gs.current;
      commitLive();
      if (presentingRef.current) {
        // Apresentação: o toque curto enquadra; arrastar e pinçar movem só a câmera. Nada é editado.
        if (!g.moved && !g.multi) presentTap(g.hit);
      } else if (!g.moved && !g.multi && multiModeRef.current) {
        // Selecionar vários: o toque liga/desliga o item tocado; toque no vazio não faz nada.
        if (g.hit !== null) {
          const id = g.hit;
          setMultiSel((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
        }
      } else if (!g.moved && !g.multi) {
        const wasEdit = editModeRef.current;
        const hitItem = g.hit !== null ? itemsRef.current.find((i) => i.id === g.hit) : undefined;
        const isCard = hitItem?.kind === 'collection' || hitItem?.kind === 'note' || hitItem?.kind === 'link' || hitItem?.kind === 'video';
        if (!wasEdit && hitItem && isCard) {
          // Fora do modo de edição, um toque num cartão abre a coleção ou a nota.
          lastTap.current = 0;
          openCard(hitItem);
        } else {
          handleTap(g.hit);
          if (wasEdit) {
            if (g.hit !== null) {
              // Toque num texto que já estava selecionado abre o editor; num cartão, abre o destino.
              if (g.wasSelected && hitItem?.kind === 'text') openEditor(hitItem.id);
              else if (g.wasSelected && hitItem && isCard) openCard(hitItem);
              else if (g.wasSelected && hitItem?.kind === 'swatch') copyStripe(hitItem, g.sx, g.sy);
            } else {
              setSelected(null);
            }
          }
        }
      }
      g.mode = 'none';
      g.n = 0;
    },
    terminate: () => {
      commitLive();
      gs.current.mode = 'none';
      gs.current.n = 0;
    },
  };

  const toFront = async () => {
    if (!sel) return;
    const z = await bringMoodItemToFront(sel.id, collectionId);
    setItems((prev) => prev.map((i) => (i.id === sel.id ? { ...i, z } : i)).sort((a, b) => a.z - b.z));
  };

  const removeItem = async (id: number) => {
    try {
      const it = itemsRef.current.find((i) => i.id === id);
      const files: string[] = [];
      if (it?.kind === 'collection') {
        // Apaga a coleção de dentro (e o cartão dela) com tudo que ela contém.
        files.push(...(await deleteCollection(Number(it.content))));
      } else {
        await deleteMoodItem(id);
        if (it?.kind === 'image') files.push(it.content);
        if (it?.kind === 'video') files.push(...videoFiles(it.content));
        if (it?.kind === 'link') {
          const img = parseLink(it.content).img;
          if (img) files.push(img);
        }
      }
      files.forEach((name) => {
        try {
          const f = mediaFile(name);
          if (f.exists) f.delete();
        } catch {
          // arquivo já não existe
        }
      });
      setItems((prev) => prev.filter((i) => i.id !== id));
      setSelected(null);
    } catch (e) {
      appError('Não consegui remover', e);
    }
  };

  const remove = () => {
    if (!sel) return;
    const isCol = sel.kind === 'collection';
    const isNote = sel.kind === 'note';
    appAlert(
      isCol ? 'Excluir coleção?' : isNote ? 'Desvincular nota?' : 'Remover do moodboard?',
      isCol
        ? `"${subs[Number(sel.content)]?.name ?? ''}", as coleções de dentro dela e as imagens serão apagadas. As notas vinculadas não são apagadas.`
        : isNote
          ? 'A nota continua na Biblioteca; só sai desta coleção.'
          : undefined,
      [
        { text: 'Cancelar', style: 'cancel' },
        { text: isCol ? 'Excluir' : isNote ? 'Desvincular' : 'Remover', style: 'destructive', onPress: () => removeItem(sel.id) },
      ]
    );
  };

  /** Item selecionado: uma ação principal por tipo na barra, o resto no menu "Mais". */
  const [selMenu, setSelMenu] = useState(false);
  let selPrimary: { label: string; onPress: () => void } | null = null;
  const selItems: ActionItem[] = [];
  if (sel) selItems.push({ key: 'color', label: 'Cor', onPress: () => setColorDlg(true) });
  if (sel) {
    if (sel.kind === 'text') selPrimary = { label: 'Editar texto', onPress: () => openEditor(sel.id) };
    else if (sel.kind === 'image') selPrimary = { label: 'Paleta', onPress: () => makePalette([sel.content], false, sel) };
    else if (sel.kind === 'swatch') {
      selPrimary = {
        label: 'Copiar todas',
        onPress: () => {
          const sd = parseSwatch(sel.content);
          if (sd) copyText(sd.colors.join(', '), 'Cores copiadas');
        },
      };
      selItems.push({ key: 'refresh', label: 'Atualizar', onPress: () => refreshSwatch(sel) });
    } else selPrimary = { label: sel.kind === 'video' ? 'Assistir' : 'Abrir', onPress: () => openCard(sel) };
    if (sel.kind === 'video') {
      if (isRemote(parseVideo(sel.content).src)) selItems.push({ key: 'download', label: 'Baixar para o aparelho', onPress: () => downloadSel(sel) });
      selItems.push({ key: 'poster', label: 'Trocar capa', onPress: () => pickPoster(sel) });
    }
    if (sel.kind === 'link') {
      selItems.push({ key: 'thumb', label: 'Trocar miniatura', onPress: () => pickThumb(sel) });
      if (parseLink(sel.content).img) selItems.push({ key: 'dropThumb', label: 'Remover miniatura', onPress: () => dropThumb(sel) });
      selItems.push(
        { key: 'preview', label: 'Atualizar prévia', onPress: () => refreshLink(sel.id, sel.content, false) },
        { key: 'editLink', label: 'Editar link', onPress: () => setEditLinkId(sel.id) }
      );
    }
    selItems.push(
      { key: 'caption', label: 'Legenda', onPress: () => setCaptionDlg(true) },
      { key: 'png', label: 'Exportar PNG', onPress: () => runExport('png', 'card', sel) },
      { key: 'front', label: 'Trazer para frente', onPress: toFront }
    );
  }

  /** Menus da barra de edição: o que é raro fica aqui em vez de virar botão. */
  const [addMenu, setAddMenu] = useState(false);
  const [stockOpen, setStockOpen] = useState(false);
  const [videoStockOpen, setVideoStockOpen] = useState(false);
  const [webOpen, setWebOpen] = useState(false);
  const [moreMenu, setMoreMenu] = useState(false);
  const addItems: ActionItem[] = [
    { key: 'photo', label: 'Foto ou vídeo da galeria', onPress: addPhotos },
    { key: 'video', label: 'Vídeo da galeria', onPress: addVideos },
    { key: 'web-photo', label: 'Foto da web', onPress: () => setStockOpen(true) },
    { key: 'web-video', label: 'Vídeo da web', onPress: () => setVideoStockOpen(true) },
    { key: 'web-browse', label: 'Navegar na web', onPress: () => setWebOpen(true) },
    { key: 'text', label: 'Texto', onPress: () => setEditor({ id: 0, html: '' }) },
    { key: 'link', label: 'Link', onPress: () => openLinkDialog() },
    { key: 'collection', label: 'Coleção', onPress: () => setSubDlg(true) },
    { key: 'note', label: 'Nota', onPress: () => openNoteSheet().catch(() => {}) },
  ];
  const moreItems: ActionItem[] = [
    ...(items.some((i) => i.kind === 'image')
      ? [{ key: 'palette', label: 'Paleta do quadro', onPress: () => makePalette(boardImageNames(), true) }]
      : []),
    ...(items.length > 1
      ? [
          {
            key: 'multi',
            label: 'Selecionar vários',
            onPress: () => {
              setSelected(null);
              setMultiSel([]);
              setMultiMode(true);
            },
          },
        ]
      : []),
  ];

  return (
    <View
      ref={rootRef}
      style={styles.root}
      onLayout={() => {
        rootRef.current?.measure((_x, _y, _w, _h, px, py) => {
          origin.current = { x: px ?? 0, y: py ?? 0 };
        });
      }}
    >
      <StatusBar style="dark" hidden={presenting} />

      {/* Quadro: grade, fotos e textos andam e dão zoom juntos. */}
      <View style={StyleSheet.absoluteFill} {...bgPan.panHandlers}>
        <Animated.View
          style={{
            position: 'absolute',
            left: 0,
            top: 0,
            width: worldW,
            height: worldH,
            transformOrigin: 'top left',
            transform: [{ translateX: atx }, { translateY: aty }, { scale: az }],
          }}
        >
          <DotGrid width={worldW} height={worldH} />
          {items.map((it) => (
            <ItemView
              key={it.id}
              item={it}
              sw={u}
              selected={editMode && (multiMode ? multiSel.includes(it.id) : it.id === selected)}
              live={live && live.id === it.id ? live : null}
              col={it.kind === 'collection' ? subs[Number(it.content)] : undefined}
              note={it.kind === 'note' ? notes[Number(it.content)] : undefined}
              onSize={onSize}
              captionMark={editMode}
              playing={inlineId === it.id}
              onPlayFail={onPlayFail}
            />
          ))}
        </Animated.View>
      </View>

      {!presenting && (
        <>
      <ScreenHeader
        u={u}
        surface="light"
        style={styles.header}
        pointerEvents="box-none"
        onBack={onClose}
        crumb={crumb || undefined}
        title={name}
        onTitlePress={() => setRenaming(true)}
        right={<HeaderAction u={u} surface="light" tone="accent" label="Compartilhar" onPress={askExport} />}
      />

      {/* Só "ajustar à tela"; o zoom é pela pinça com dois dedos no fundo. */}
      <View
        style={{ position: 'absolute', right: u * 0.04, bottom: insets.bottom + u * 0.2, gap: u * 0.025 }}
        pointerEvents="box-none"
      >
        <IconButton u={u} icon="expand" label="Ajustar à tela" onPress={() => fitAll(items)} />
      </View>

      <View style={[styles.bar, { paddingBottom: insets.bottom + u * 0.04 }]} pointerEvents="box-none">
        <View style={styles.row}>
          {!editMode ? (
            <Btn u={u} label="Editar" onPress={() => setEditMode(true)} />
          ) : (
            <>
              {multiMode ? (
                <>
                  <View
                    style={{
                      backgroundColor: colors.paper,
                      paddingHorizontal: u * 0.04,
                      paddingVertical: u * 0.026,
                      borderRadius: u * 0.08,
                    }}
                  >
                    <Text style={{ color: colors.onLight, fontFamily: fonts.regular, fontSize: u * 0.04 }}>
                      {multiSel.length === 0
                        ? 'Toque nos itens'
                        : multiSel.length === 1
                          ? '1 selecionado'
                          : `${multiSel.length} selecionados`}
                    </Text>
                  </View>
                  {itemsRef.current.some((i) => multiSel.includes(i.id) && i.kind === 'image') && (
                    <Btn
                      u={u}
                      red
                      label="Paleta das imagens"
                      onPress={() =>
                        makePalette(
                          itemsRef.current.filter((i) => multiSel.includes(i.id) && i.kind === 'image').map((i) => i.content),
                          false
                        )
                      }
                    />
                  )}
                  {multiSel.length > 0 && (
                    <Btn u={u} label="Exportar" onPress={() => setSelFmtMenu(true)} />
                  )}
                  <Btn u={u} label="Cancelar" onPress={exitMulti} />
                </>
              ) : sel ? (
                <>
                  {selPrimary && <Btn u={u} label={selPrimary.label} onPress={selPrimary.onPress} />}
                  <Btn u={u} label="Mais" onPress={() => setSelMenu(true)} />
                  <Btn u={u} label="Remover" onPress={remove} red />
                </>
              ) : (
                <>
                  <Btn u={u} label="+ Adicionar" onPress={() => setAddMenu(true)} />
                  {moreItems.length > 0 && <Btn u={u} label="Mais" onPress={() => setMoreMenu(true)} />}
                </>
              )}
              <Btn
                u={u}
                label="Pronto"
                onPress={() => {
                  exitMulti();
                  setSelected(null);
                  setEditMode(false);
                }}
              />
            </>
          )}
        </View>
      </View>

        </>
      )}

      {exporting && (
        <>
          <ExportLayer
            items={exporting.items}
            rect={exporting.rect}
            u={u}
            subs={subs}
            notes={notes}
            layerRef={layerRef}
            background={exporting.background}
            onReady={() => layerReady.current?.()}
          />
          <View
            pointerEvents="auto"
            style={{
              ...StyleSheet.absoluteFillObject,
              backgroundColor: colors.paper,
              zIndex: 100,
              elevation: 100,
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <Text style={{ color: colors.onLight, fontFamily: fonts.bold, fontSize: u * TYPE.title, letterSpacing: tracking(u * TYPE.title) }}>Gerando imagem…</Text>
          </View>
        </>
      )}

      {presenting && isTop && (
        <PresentationOverlay
          u={u}
          insetsTop={insets.top}
          insetsBottom={insets.bottom}
          caption={focusItem?.caption ?? null}
          canGoBack={dived.current}
          canEnter={focusItem?.kind === 'collection'}
          canPlay={focusItem?.kind === 'video'}
          onPlay={() => focusItem && playVideo(focusItem)}
          canPrev={focusId !== null}
          canNext={items.length > 0 && (focusId === null || presentIndex(presentOrder()) < items.length - 1)}
          onPrev={() => presentStep(-1)}
          onNext={() => presentStep(1)}
          onExit={() => onPresent(false)}
          onBack={onClose}
          onEnter={() => focusItem && enterCollection(focusItem)}
        />
      )}

      <WebPickScreen
        visible={webOpen}
        onClose={() => setWebOpen(false)}
        onPick={(l) => { setWebOpen(false); addWebPhotos(l).catch(() => {}); }}
        onPickVideos={(l) => { setWebOpen(false); addWebVideos(l).catch(() => {}); }}
      />
      <StockPickerScreen visible={stockOpen} onClose={() => setStockOpen(false)} onPick={addWebPhotos} />
      <StockPickerScreen mode="video" visible={videoStockOpen} onClose={() => setVideoStockOpen(false)} onPick={() => {}} onPickVideos={(l) => { addWebVideos(l).catch(() => {}); }} />
      <ActionMenu visible={addMenu} onClose={() => setAddMenu(false)} title="Adicionar ao quadro" items={addItems} />
      <ActionMenu visible={moreMenu} onClose={() => setMoreMenu(false)} items={moreItems} />
      <ActionMenu visible={selMenu} onClose={() => setSelMenu(false)} items={selItems} />
      <ActionMenu visible={shareMenu} onClose={() => setShareMenu(false)} title="Compartilhar" items={shareItems} />
      <ActionMenu visible={areaMenu !== null} onClose={() => setAreaMenu(null)} title="O que exportar?" items={areaItems} />
      <ActionMenu visible={selFmtMenu} onClose={() => setSelFmtMenu(false)} title="Exportar selecionados" items={selFmtItems} />
      <CaptionDialog
        visible={captionDlg && !!sel}
        initialValue={sel?.caption ?? ''}
        onCancel={() => setCaptionDlg(false)}
        onSubmit={saveCaption}
      />

      {!presenting && (busy || toast) && (
        <View
          pointerEvents="none"
          style={{
            position: 'absolute',
            alignSelf: 'center',
            top: insets.top + u * 0.2,
            backgroundColor: colors.scrimStrong,
            borderRadius: u * 0.06,
            paddingHorizontal: u * 0.05,
            paddingVertical: u * 0.025,
          }}
        >
          <Text style={{ color: colors.onDark, fontFamily: fonts.regular, fontSize: u * 0.038 }}>{busy ?? toast}</Text>
        </View>
      )}

      {editMode && !sel && clipUrl && (
        <View
          style={{
            position: 'absolute',
            left: u * 0.04,
            right: u * 0.2,
            bottom: insets.bottom + u * 0.17,
            backgroundColor: colors.scrimStrong,
            borderRadius: u * 0.04,
            paddingVertical: u * 0.025,
            paddingHorizontal: u * 0.035,
            flexDirection: 'row',
            alignItems: 'center',
            gap: u * 0.025,
          }}
        >
          <Text numberOfLines={2} style={{ flex: 1, color: colors.onDark, fontFamily: fonts.regular, fontSize: u * 0.032 }}>
            Criar cartão do link copiado? {domainOf(clipUrl)}
          </Text>
          <Btn u={u} red label="Criar" onPress={() => addLink(clipUrl)} />
          <Pressable
            accessibilityRole="button"
            hitSlop={HIT.md}
            onPress={() => {
              lastClipUrl = clipUrl;
              setClipUrl(null);
            }}
          >
            <Icon name="close" size={u * 0.05} />
          </Pressable>
        </View>
      )}

      <CardColorDialog
        visible={colorDlg && !!sel}
        initial={sel?.color ?? null}
        palette={boardPaletteColors(items)}
        onCancel={() => setColorDlg(false)}
        onPick={(hex) => {
          setColorDlg(false);
          if (!sel) return;
          patchItem(sel.id, { color: hex });
          updateMoodItem(sel.id, { color: hex }).catch((e) => appError('Não consegui salvar a cor', e));
        }}
      />

      <PromptDialog
        visible={linkDlg !== null}
        title="Colar link"
        initialValue={linkDlg?.initial ?? ''}
        placeholder="https://…"
        maxLength={500}
        url
        onCancel={() => setLinkDlg(null)}
        onSubmit={(v) => {
          setLinkDlg(null);
          const url = normalizeUrl(v);
          if (!url) appAlert('Link inválido', 'Use um endereço que comece com http:// ou https://.');
          else addLink(url);
        }}
      />

      <PromptDialog
        visible={editLinkId !== null}
        title="Editar link"
        initialValue={items.find((i) => i.id === editLinkId) ? parseLink(items.find((i) => i.id === editLinkId)!.content).url : ''}
        maxLength={500}
        url
        onCancel={() => setEditLinkId(null)}
        onSubmit={(v) => {
          const it = items.find((i) => i.id === editLinkId);
          setEditLinkId(null);
          if (it) changeLinkUrl(it, v).catch((e) => appError('Não consegui salvar o link', e));
        }}
      />

      <PromptDialog
        visible={renaming}
        title="Renomear coleção"
        initialValue={name}
        onCancel={() => setRenaming(false)}
        onSubmit={async (v) => {
          setRenaming(false);
          setName(v);
          await renameCollection(collectionId, v);
        }}
      />

      <PromptDialog
        visible={subDlg}
        title="Nova coleção aqui dentro"
        initialValue=""
        placeholder="Nome da coleção"
        onCancel={() => setSubDlg(false)}
        onSubmit={(v) => {
          setSubDlg(false);
          addSub(v).catch((e) => appError('Não consegui criar a coleção', e));
        }}
      />

      <BottomSheet
        visible={noteSheet !== null}
        onClose={() => setNoteSheet(null)}
        title="Criar nota nova aqui"
        onTitlePress={async () => {
          setNoteSheet(null);
          try {
            const id = await createBlock();
            await linkNote(id);
            onOpenNote(id);
          } catch (e) {
            appError('Não consegui criar a nota', e);
          }
        }}
        subtitle="Vincular nota existente"
        items={noteSheetItems}
        separators
      />

      {editor && (
        <TextEditorOverlay
          title={editor.id === 0 ? 'Novo texto' : 'Editar texto'}
          initialHtml={editor.html}
          palette={boardPaletteColors(items)}
          onCancel={() => setEditor(null)}
          onDone={(h) => finishEditor(h).catch((e) => appError('Não consegui salvar o texto', e))}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { ...StyleSheet.absoluteFillObject, backgroundColor: colors.paper, overflow: 'hidden' },
  header: { position: 'absolute', top: 0, left: 0, right: 0 },
  bar: { position: 'absolute', left: 0, right: 0, bottom: 0, alignItems: 'center' },
  row: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: 10, paddingHorizontal: 12 },
});
