import React, { memo, useCallback, useEffect, useRef, useState } from 'react';
import {
  Animated,
  BackHandler,
  Image,
  PanResponder,
  Pressable,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import * as ImagePicker from 'expo-image-picker';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { BottomSheet, SheetItem } from './BottomSheet';
import { Collage } from './Collage';
import { DotGrid } from './DotGrid';
import { appAlert } from './dialog';
import {
  Block,
  MoodCollection,
  MoodItem,
  NOTE_CARD,
  SUBCOL_CARD,
  addMoodItem,
  addSubCollection,
  bringMoodItemToFront,
  collectionPath,
  createBlock,
  deleteCollection,
  deleteMoodItem,
  getCollectionName,
  linkNoteToCollection,
  listBlocks,
  listCollectionsByIds,
  listMoodItems,
  renameCollection,
  updateMoodItem,
} from './db';
import { mediaFile, mediaUri, saveMedia } from './media';
import { PromptDialog } from './PromptDialog';
import { RichText, asHtml, plainOf } from './RichText';
import { TextEditorOverlay } from './TextEditorOverlay';
import { fonts } from './theme';

type Props = {
  collectionId: number;
  /** Muda quando algo fora desta tela mudou (nota editada, coleção de dentro alterada...): recarrega o quadro. */
  version: number;
  /** Volta um nível (para a coleção de fora, ou para a lista de coleções). */
  onClose: () => void;
  onOpenCollection: (id: number) => void;
  onOpenNote: (blockId: number) => void;
};

/** Tamanho do quadro, em "larguras de tela" (1 = largura do celular). */
const WORLD_W = 5;
const WORLD_H = 8;
const MAX_ZOOM = 3;

type View2 = { tx: number; ty: number; z: number };
type Live = { dx: number; dy: number; s: number; r: number };
type Patch = Partial<Pick<MoodItem, 'x' | 'y' | 'w' | 'h' | 'rot'>>;
type ViewRef = React.MutableRefObject<View2>;

const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));

/** Tamanho aproximado do item no quadro, em unidades (usado antes de ele ser medido na tela). */
const boxOf = (it: MoodItem): { w: number; h: number } =>
  it.kind === 'text' ? { w: it.h || 0.6, h: 0.25 } : { w: it.w, h: it.h };

type LiveItem = Live & { id: number };

/** Item do quadro. Só desenha: todos os toques são tratados pelo quadro (que descobre qual item foi tocado pela conta, não pelo Android). */
const ItemView = memo(function ItemView({
  item,
  sw,
  selected,
  live,
  col,
  note,
  onSize,
}: {
  item: MoodItem;
  sw: number;
  selected: boolean;
  live: Live | null;
  col?: MoodCollection;
  note?: Block;
  onSize: (id: number, w: number, h: number) => void;
}) {
  const L = live ?? { dx: 0, dy: 0, s: 1, r: 0 };
  const transform = [
    { translateX: L.dx },
    { translateY: L.dy },
    { rotate: `${item.rot + L.r}deg` },
    { scale: L.s },
  ];

  let body: React.ReactNode;
  if (item.kind === 'image') {
    body = (
      <Image
        source={{ uri: mediaUri(item.content) }}
        resizeMode="cover"
        style={{ width: item.w * sw, height: item.h * sw }}
      />
    );
  } else if (item.kind === 'collection') {
    // Mesmo desenho da aba Coleções (nome + colagem), na escala do cartão.
    const k = item.w / SUBCOL_CARD.w;
    const fs = sw * 0.058 * k;
    body = (
      <View style={{ width: item.w * sw, alignItems: 'center' }}>
        <Text
          numberOfLines={1}
          style={{
            fontFamily: fonts.regular,
            fontSize: fs,
            letterSpacing: -fs * 0.04,
            color: '#000',
            marginBottom: sw * 0.02 * k,
            maxWidth: '100%',
          }}
        >
          {col?.name ?? ''}
        </Text>
        <Collage covers={col?.covers ?? []} sw={sw * k} />
      </View>
    );
  } else if (item.kind === 'note') {
    // Cartão preto, como as notas do app: título e começo do texto.
    const k = item.w / NOTE_CARD.w;
    const title = note ? note.noteTitle || note.name : 'Nota';
    const tf = sw * 0.04 * k;
    body = (
      <View
        style={{
          width: item.w * sw,
          height: item.h * sw,
          backgroundColor: '#000',
          borderRadius: sw * 0.02 * k,
          padding: sw * 0.03 * k,
          overflow: 'hidden',
        }}
      >
        <Text
          numberOfLines={2}
          style={{ color: '#fff', fontFamily: fonts.bold, fontSize: tf, letterSpacing: -tf * 0.04 }}
        >
          {title}
        </Text>
        {!!note?.preview && (
          <Text
            numberOfLines={3}
            style={{ color: '#B0B0B0', fontFamily: fonts.light, fontSize: sw * 0.03 * k, marginTop: sw * 0.01 * k }}
          >
            {note.preview}
          </Text>
        )}
      </View>
    );
  } else {
    body = <RichText html={item.content} base={item.w * sw} width={(item.h || 0.6) * sw} />;
  }

  return (
    <View
      pointerEvents="none"
      onLayout={(e) => onSize(item.id, e.nativeEvent.layout.width, e.nativeEvent.layout.height)}
      style={{ position: 'absolute', left: item.x * sw, top: item.y * sw, transform }}
    >
      {body}
      {selected && (
        <View
          pointerEvents="none"
          style={{ ...StyleSheet.absoluteFillObject, borderWidth: 2, borderColor: '#FF3030' }}
        />
      )}
    </View>
  );
});

/** Botões fora do componente da tela: se fossem criados dentro dele, cada re-render os recriaria e o toque se perderia. */
function Btn({ label, onPress, red, u }: { label: string; onPress: () => void; red?: boolean; u: number }) {
  return (
    <Pressable
      onPress={onPress}
      hitSlop={10}
      style={{
        backgroundColor: red ? '#FF3030' : '#000',
        paddingHorizontal: u * 0.04,
        paddingVertical: u * 0.026,
        borderRadius: u * 0.08,
      }}
    >
      <Text style={{ color: '#fff', fontFamily: fonts.regular, fontSize: u * 0.04 }}>{label}</Text>
    </Pressable>
  );
}

function Round({ label, onPress, u }: { label: string; onPress: () => void; u: number }) {
  return (
    <Pressable
      onPress={onPress}
      hitSlop={6}
      style={{
        width: u * 0.11,
        height: u * 0.11,
        borderRadius: u * 0.055,
        backgroundColor: 'rgba(255,255,255,0.92)',
        borderWidth: 1,
        borderColor: 'rgba(0,0,0,0.15)',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <Text style={{ color: '#000', fontFamily: fonts.regular, fontSize: u * 0.055, lineHeight: u * 0.065 }}>{label}</Text>
    </Pressable>
  );
}

export function CollectionScreen({ collectionId, version, onClose, onOpenCollection, onOpenNote }: Props) {
  const { width: sw, height: sh } = useWindowDimensions();
  // Unidade do quadro = lado menor da tela (a largura em pé). Assim nada muda de tamanho ao girar.
  const u = Math.min(sw, sh);
  const insets = useSafeAreaInsets();
  const [name, setName] = useState('');
  /** Nomes das coleções de fora, para o topo da tela ("Viagens › Japão"). */
  const [crumb, setCrumb] = useState('');
  const [items, setItems] = useState<MoodItem[]>([]);
  /** Dados das coleções de dentro e das notas vinculadas, por id (para desenhar os cartões). */
  const [subs, setSubs] = useState<Record<number, MoodCollection>>({});
  const [notes, setNotes] = useState<Record<number, Block>>({});
  const [subDlg, setSubDlg] = useState(false);
  const [noteSheet, setNoteSheet] = useState<Block[] | null>(null);
  const [selected, setSelected] = useState<number | null>(null);
  const [renaming, setRenaming] = useState(false);
  /** null = fechado; id 0 = novo texto; outro = editando esse item. */
  const [editor, setEditor] = useState<{ id: number; html: string } | null>(null);
  /** false = só visualizar (e arrastar); true = pode selecionar, editar, remover e adicionar. */
  const [editMode, setEditMode] = useState(false);
  const editModeRef = useRef(false);
  editModeRef.current = editMode;
  const selectedRef = useRef<number | null>(null);
  selectedRef.current = selected;
  const lastTap = useRef(0);
  /** Dois toques seguidos em qualquer lugar do quadro entram no modo de edição (e já selecionam o item tocado). */
  const handleTap = useCallback((hitId: number | null) => {
    const now = Date.now();
    const dbl = now - lastTap.current < 400;
    lastTap.current = dbl ? 0 : now;
    if (dbl && !editModeRef.current) {
      setEditMode(true);
      if (hitId !== null) setSelected(hitId);
    }
  }, []);
  /** Tamanho real (em px do quadro) de cada item, medido na tela. */
  const sizes = useRef<Record<number, { w: number; h: number }>>({});
  const onSize = useCallback((id: number, w: number, h: number) => {
    sizes.current[id] = { w, h };
  }, []);
  const [live, setLive] = useState<LiveItem | null>(null);
  const liveRef = useRef<LiveItem | null>(null);

  // ---------- zoom e posição do quadro ----------
  const worldW = WORLD_W * u;
  const worldH = WORLD_H * u;
  const minZoom = Math.max(sw / worldW, sh / worldH);
  const view = useRef<View2>({ tx: 0, ty: 0, z: 1 });
  const atx = useRef(new Animated.Value(0)).current;
  const aty = useRef(new Animated.Value(0)).current;
  const az = useRef(new Animated.Value(1)).current;
  const rootRef = useRef<View>(null);
  const origin = useRef({ x: 0, y: 0 });

  const clampView = useCallback(
    (v: View2): View2 => {
      const z = clamp(v.z, minZoom, MAX_ZOOM);
      return {
        z,
        tx: clamp(v.tx, sw - worldW * z, 0),
        ty: clamp(v.ty, sh - worldH * z, 0),
      };
    },
    [minZoom, sw, sh, worldW, worldH]
  );

  const setView = useCallback(
    (v: View2) => {
      const c = clampView(v);
      view.current = c;
      atx.setValue(c.tx);
      aty.setValue(c.ty);
      az.setValue(c.z);
    },
    [clampView, atx, aty, az]
  );

  /** Mantém o ponto (px, py) da tela parado enquanto o zoom muda. */
  const zoomAt = useCallback(
    (px: number, py: number, z: number) => {
      const v = view.current;
      const nz = clamp(z, minZoom, MAX_ZOOM);
      const wx = (px - v.tx) / v.z;
      const wy = (py - v.ty) / v.z;
      setView({ z: nz, tx: px - wx * nz, ty: py - wy * nz });
    },
    [minZoom, setView]
  );

  const fitAll = useCallback(
    (list: MoodItem[]) => {
      if (list.length === 0) {
        // Coleção nova: começa no meio do quadro.
        setView({ z: 1, tx: sw / 2 - (worldW / 2), ty: sh / 2 - worldH / 2 });
        return;
      }
      let x0 = Infinity,
        y0 = Infinity,
        x1 = -Infinity,
        y1 = -Infinity;
      for (const it of list) {
        const { w, h } = boxOf(it);
        x0 = Math.min(x0, it.x);
        y0 = Math.min(y0, it.y);
        x1 = Math.max(x1, it.x + w);
        y1 = Math.max(y1, it.y + h);
      }
      const pad = 0.08;
      const bw = (x1 - x0 + pad * 2) * u;
      const bh = (y1 - y0 + pad * 2) * u;
      const z = clamp(Math.min(sw / bw, (sh * 0.85) / bh, 1), minZoom, 1);
      const cx = ((x0 + x1) / 2) * u;
      const cy = ((y0 + y1) / 2) * u;
      setView({ z, tx: sw / 2 - cx * z, ty: sh / 2 - cy * z });
    },
    [setView, sw, sh, u, worldW, worldH, minZoom]
  );

  /** Lê o quadro do banco: itens, coleções de dentro e notas vinculadas. */
  const loadAll = async (fit: boolean) => {
    const list = await listMoodItems(collectionId);
    const subIds = list.filter((i) => i.kind === 'collection').map((i) => Number(i.content));
    const noteIds = list.filter((i) => i.kind === 'note').map((i) => Number(i.content));
    const [subList, noteList] = await Promise.all([listCollectionsByIds(subIds), listBlocks(noteIds)]);
    const subMap: Record<number, MoodCollection> = {};
    subList.forEach((c) => (subMap[c.id] = c));
    const noteMap: Record<number, Block> = {};
    noteList.forEach((b) => (noteMap[b.id] = b));
    // Cartão cujo destino não existe mais (não deveria acontecer) simplesmente não aparece.
    const visible = list.filter((i) =>
      i.kind === 'collection' ? !!subMap[Number(i.content)] : i.kind === 'note' ? !!noteMap[Number(i.content)] : true
    );
    setSubs(subMap);
    setNotes(noteMap);
    setItems(visible);
    if (fit) fitAll(visible);
  };

  const fitted = useRef(false);
  useEffect(() => {
    getCollectionName(collectionId).then(setName).catch(() => {});
    collectionPath(collectionId)
      .then((p) =>
        setCrumb(
          p
            .slice(0, -1)
            .map((x) => x.name)
            .join(' › ')
        )
      )
      .catch(() => {});
    loadAll(!fitted.current)
      .then(() => {
        fitted.current = true;
      })
      .catch((e) => appAlert('Erro ao abrir a coleção', String(e)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [collectionId, version]);

  // Girou a tela: mantém o quadro dentro dos limites.
  useEffect(() => {
    setView(view.current);
  }, [sw, sh, setView]);

  // Um único gesto para o quadro inteiro. Os itens não recebem toque: o quadro calcula qual item está sob o dedo.
  const handlers = useRef<{
    grant: (e: any) => void;
    move: (e: any) => void;
    release: () => void;
    terminate: () => void;
  }>({ grant() {}, move() {}, release() {}, terminate() {} });
  const bgPan = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderTerminationRequest: () => false,
      onPanResponderGrant: (e) => handlers.current.grant(e),
      onPanResponderMove: (e) => handlers.current.move(e),
      onPanResponderRelease: () => handlers.current.release(),
      onPanResponderTerminate: () => handlers.current.terminate(),
    })
  ).current;

  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (selected !== null) setSelected(null);
      else if (editMode) setEditMode(false);
      else onClose();
      return true;
    });
    return () => sub.remove();
  }, [selected, editMode, onClose]);

  const itemsRef = useRef(items);
  itemsRef.current = items;
  const sel = items.find((i) => i.id === selected) ?? null;

  const commit = useCallback((id: number, patch: Patch) => {
    setItems((prev) => prev.map((i) => (i.id === id ? { ...i, ...patch } : i)));
    updateMoodItem(id, patch).catch((e) => appAlert('Não consegui salvar a alteração', String(e)));
  }, []);

  /** Ponto do quadro que está no centro da tela, em unidades de largura. */
  const viewCenter = () => {
    const v = view.current;
    return { x: (sw / 2 - v.tx) / v.z / u, y: (sh / 2 - v.ty) / v.z / u };
  };

  const addPhotos = async () => {
    try {
      const r = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ['images'],
        allowsMultipleSelection: true,
        quality: 0.85,
      });
      if (r.canceled) return;
      const c = viewCenter();
      const z = view.current.z;
      const added: MoodItem[] = [];
      for (const a of r.assets) {
        const stored = saveMedia(a.uri, a.fileName, 'jpg');
        const w = clamp(0.42 / z, 0.2, 1.4);
        const ratio = a.width && a.height ? a.height / a.width : 1.3;
        const h = clamp(w * ratio, w * 0.4, w * 2.5);
        const n = added.length;
        added.push(
          await addMoodItem({
            collectionId,
            kind: 'image',
            content: stored,
            x: clamp(c.x - w / 2 + n * 0.05 / z, 0, WORLD_W - w),
            y: clamp(c.y - h / 2 + n * 0.05 / z, 0, WORLD_H - h),
            w,
            h,
            rot: ((n % 5) - 2) * 4,
            bold: false,
          })
        );
      }
      setItems((prev) => [...prev, ...added]);
      if (added.length > 0) setSelected(added[added.length - 1].id);
    } catch (e) {
      appAlert('Não consegui adicionar a foto', String(e));
    }
  };

  /** Abre o que o cartão aponta: a coleção de dentro ou a nota. */
  const openCard = (it: MoodItem) => {
    const id = Number(it.content);
    if (!Number.isFinite(id)) return;
    if (it.kind === 'collection') onOpenCollection(id);
    else if (it.kind === 'note') onOpenNote(id);
  };

  const addSub = async (nameText: string) => {
    const c = viewCenter();
    const k = clamp(1 / view.current.z, 0.55, 2.6);
    const w = SUBCOL_CARD.w * k;
    const h = SUBCOL_CARD.h * k;
    const it = await addSubCollection(
      collectionId,
      nameText,
      clamp(c.x - w / 2, 0, WORLD_W - w),
      clamp(c.y - h / 2, 0, WORLD_H - h),
      k
    );
    const subId = Number(it.content);
    setSubs((prev) => ({
      ...prev,
      [subId]: { id: subId, name: nameText, parentId: collectionId, count: 0, covers: [], x: null, y: null },
    }));
    setItems((prev) => [...prev, it]);
    setSelected(it.id);
  };

  /** Abre a lista de notas que ainda não estão neste quadro. */
  const openNoteSheet = async () => {
    try {
      const all = await listBlocks();
      const have = new Set(itemsRef.current.filter((i) => i.kind === 'note').map((i) => Number(i.content)));
      setNoteSheet(all.filter((b) => !have.has(b.id)));
    } catch (e) {
      appAlert('Não consegui ler as notas', String(e));
    }
  };

  /** Põe o cartão da nota no centro do que está sendo visto. */
  const linkNote = async (blockId: number): Promise<boolean> => {
    const c = viewCenter();
    const k = clamp(1 / view.current.z, 0.55, 2.6);
    const w = NOTE_CARD.w * k;
    const h = NOTE_CARD.h * k;
    const it = await linkNoteToCollection(blockId, collectionId, {
      x: clamp(c.x - w / 2, 0, WORLD_W - w),
      y: clamp(c.y - h / 2, 0, WORLD_H - h),
    });
    if (!it) return false;
    await updateMoodItem(it.id, { w, h });
    await loadAll(false);
    setSelected(it.id);
    return true;
  };

  const noteSheetItems: SheetItem[] =
    noteSheet === null
      ? []
      : noteSheet.length === 0
        ? [{ key: 'none', label: 'Nenhuma outra nota para vincular', muted: true }]
        : noteSheet.map((b) => ({
            key: String(b.id),
            label: b.noteTitle || b.name,
            onPress: () => {
              setNoteSheet(null);
              linkNote(b.id).catch((e) => appAlert('Não consegui vincular a nota', String(e)));
            },
          }));

  const finishEditor = async (html: string) => {
    const ed = editor;
    setEditor(null);
    if (!ed) return;
    const empty = plainOf(html) === '';
    if (ed.id === 0) {
      if (empty) return;
      const c = viewCenter();
      const z = view.current.z;
      const w = clamp(0.06 / z, 0.03, 0.5); // tamanho da letra
      const box = clamp(0.6 / z, 0.3, 2.5); // largura da caixa
      const it = await addMoodItem({
        collectionId,
        kind: 'text',
        content: html,
        x: clamp(c.x - box / 2, 0, WORLD_W - box),
        y: clamp(c.y - 0.1, 0, WORLD_H - 0.2),
        w,
        h: box,
        rot: 0,
        bold: false,
      });
      setItems((prev) => [...prev, it]);
      setSelected(it.id);
    } else if (empty) {
      await removeItem(ed.id);
    } else {
      setItems((prev) => prev.map((i) => (i.id === ed.id ? { ...i, content: html } : i)));
      updateMoodItem(ed.id, { content: html }).catch((e) => appAlert('Não consegui salvar o texto', String(e)));
    }
  };

  const openEditor = useCallback((id: number) => {
    const it = itemsRef.current.find((i) => i.id === id);
    // Espera o toque terminar de vez antes de montar o editor por cima (evita o toque 'vazar' para ele).
    if (it && it.kind === 'text') setTimeout(() => setEditor({ id, html: asHtml(it.content) }), 120);
  }, []);

  // ---------- gestos do quadro ----------
  type Pt = { x: number; y: number };
  const getPts = (e: any): Pt[] =>
    ((e.nativeEvent.touches ?? []) as any[]).map((p) => ({ x: p.pageX - origin.current.x, y: p.pageY - origin.current.y }));
  const centroid = (pts: Pt[]): Pt =>
    pts.length >= 2
      ? { x: (pts[0].x + pts[1].x) / 2, y: (pts[0].y + pts[1].y) / 2 }
      : { x: pts[0].x, y: pts[0].y };
  const pinchOf = (pts: Pt[]) => ({
    dist: Math.hypot(pts[1].x - pts[0].x, pts[1].y - pts[0].y),
    ang: (Math.atan2(pts[1].y - pts[0].y, pts[1].x - pts[0].x) * 180) / Math.PI,
  });

  const gs = useRef({
    n: 0,
    moved: false,
    multi: false,
    hit: null as number | null,
    wasSelected: false,
    mode: 'none' as 'none' | 'board' | 'item' | 'pinchBoard' | 'pinchItem',
    target: null as number | null,
    sx: 0,
    sy: 0,
    cx: 0,
    cy: 0,
    dist: 0,
    ang: 0,
    bv: { tx: 0, ty: 0, z: 1 } as View2,
  });

  /** Qual item está sob o ponto (px, py) da tela? O de cima primeiro. Conta feita aqui, com giro e uma folga para o dedo. */
  const hitTest = (px: number, py: number): MoodItem | null => {
    const v = view.current;
    const wx = (px - v.tx) / v.z;
    const wy = (py - v.ty) / v.z;
    const slop = 14 / v.z;
    const list = itemsRef.current;
    for (let i = list.length - 1; i >= 0; i--) {
      const it = list[i];
      const box = boxOf(it);
      const sz = sizes.current[it.id] ?? { w: box.w * u, h: box.h * u };
      const cx = it.x * u + sz.w / 2;
      const cy = it.y * u + sz.h / 2;
      const a = (-(it.rot || 0) * Math.PI) / 180;
      const dx = wx - cx;
      const dy = wy - cy;
      const lx = dx * Math.cos(a) - dy * Math.sin(a);
      const ly = dx * Math.sin(a) + dy * Math.cos(a);
      if (Math.abs(lx) <= sz.w / 2 + slop && Math.abs(ly) <= sz.h / 2 + slop) return it;
    }
    return null;
  };

  const setLiveBoth = (l: LiveItem | null) => {
    liveRef.current = l;
    setLive(l);
  };

  /** Grava no item o que o dedo fez até agora (arrasto, tamanho, giro). */
  const commitLive = () => {
    const L = liveRef.current;
    if (!L) return;
    setLiveBoth(null);
    const it = itemsRef.current.find((i) => i.id === L.id);
    if (!it) return;
    const sz = sizes.current[it.id] ?? { w: 0, h: 0 };
    const bw = sz.w / u;
    const bh = sz.h / u;
    const sc = clamp(L.s, 0.1, 8);
    commit(it.id, {
      // A escala é em volta do centro; ao gravar, o canto superior esquerdo acompanha.
      x: clamp(it.x + L.dx / u + (bw * (1 - sc)) / 2, -0.3, WORLD_W - 0.1),
      y: clamp(it.y + L.dy / u + (bh * (1 - sc)) / 2, -0.3, WORLD_H - 0.1),
      rot: it.rot + L.r,
      w: it.w * sc,
      h: it.h * sc,
    });
  };

  const rebase = (pts: Pt[]) => {
    const g = gs.current;
    const n = Math.min(2, pts.length);
    const c = centroid(pts);
    g.n = n;
    g.cx = c.x;
    g.cy = c.y;
    if (n === 2) {
      const p = pinchOf(pts);
      g.dist = p.dist;
      g.ang = p.ang;
    }
    g.bv = { ...view.current };
  };

  /** Chegou o segundo dedo: no modo de edição com item selecionado/tocado, é pinça e giro do item; senão, zoom do quadro. */
  const enterMulti = () => {
    const g = gs.current;
    g.multi = true;
    g.moved = true;
    const tgt = editModeRef.current ? g.hit ?? selectedRef.current : null;
    if (tgt !== null) {
      g.mode = 'pinchItem';
      g.target = tgt;
      if (selectedRef.current !== tgt) setSelected(tgt);
    } else {
      g.mode = 'pinchBoard';
    }
  };

  handlers.current = {
    grant: (e) => {
      const g = gs.current;
      const pts = getPts(e);
      if (pts.length === 0) return;
      const hit = hitTest(pts[0].x, pts[0].y);
      g.moved = false;
      g.multi = false;
      g.target = null;
      g.hit = hit ? hit.id : null;
      g.wasSelected = hit !== null && selectedRef.current === hit.id;
      g.sx = pts[0].x;
      g.sy = pts[0].y;
      setLiveBoth(null);
      rebase(pts);
      g.mode = hit ? 'item' : 'board';
      if (g.n === 2) enterMulti();
      if (editModeRef.current && hit && selectedRef.current !== hit.id) setSelected(hit.id);
    },
    move: (e) => {
      const g = gs.current;
      const pts = getPts(e);
      if (pts.length === 0) return;
      const n = Math.min(2, pts.length);
      if (n !== g.n) {
        // Mudou o número de dedos: grava o que já foi feito e recomeça dali.
        commitLive();
        rebase(pts);
        if (n === 2) enterMulti();
        else g.mode = 'none';
        return;
      }
      const c = centroid(pts);
      if (!g.moved && n === 1 && Math.hypot(c.x - g.sx, c.y - g.sy) > 10) g.moved = true;
      const z = view.current.z || 1;
      if (g.mode === 'board') {
        setView({ z: g.bv.z, tx: g.bv.tx + (c.x - g.cx), ty: g.bv.ty + (c.y - g.cy) });
      } else if (g.mode === 'item' && g.moved && g.hit !== null) {
        setLiveBoth({ id: g.hit, dx: (c.x - g.cx) / z, dy: (c.y - g.cy) / z, s: 1, r: 0 });
      } else if (g.mode === 'pinchBoard') {
        const p = pinchOf(pts);
        const nz = clamp(g.bv.z * (p.dist / (g.dist || 1)), minZoom, MAX_ZOOM);
        const wx = (g.cx - g.bv.tx) / g.bv.z;
        const wy = (g.cy - g.bv.ty) / g.bv.z;
        setView({ z: nz, tx: c.x - wx * nz, ty: c.y - wy * nz });
      } else if (g.mode === 'pinchItem' && g.target !== null) {
        const p = pinchOf(pts);
        let d = p.ang - g.ang;
        while (d > 180) d -= 360;
        while (d < -180) d += 360;
        setLiveBoth({
          id: g.target,
          dx: (c.x - g.cx) / z,
          dy: (c.y - g.cy) / z,
          s: clamp(p.dist / (g.dist || 1), 0.2, 5),
          r: d,
        });
      }
    },
    release: () => {
      const g = gs.current;
      commitLive();
      if (!g.moved && !g.multi) {
        const wasEdit = editModeRef.current;
        const hitItem = g.hit !== null ? itemsRef.current.find((i) => i.id === g.hit) : undefined;
        const isCard = hitItem?.kind === 'collection' || hitItem?.kind === 'note';
        if (!wasEdit && hitItem && isCard) {
          // Fora do modo de edição, um toque num cartão abre a coleção ou a nota.
          lastTap.current = 0;
          openCard(hitItem);
        } else {
          handleTap(g.hit);
          if (wasEdit) {
            if (g.hit !== null) {
              // Toque num texto que já estava selecionado abre o editor; num cartão, abre o destino.
              if (g.wasSelected && hitItem?.kind === 'text') openEditor(hitItem.id);
              else if (g.wasSelected && hitItem && isCard) openCard(hitItem);
            } else {
              setSelected(null);
            }
          }
        }
      }
      g.mode = 'none';
      g.n = 0;
    },
    terminate: () => {
      commitLive();
      gs.current.mode = 'none';
      gs.current.n = 0;
    },
  };

  const toFront = async () => {
    if (!sel) return;
    const z = await bringMoodItemToFront(sel.id, collectionId);
    setItems((prev) => prev.map((i) => (i.id === sel.id ? { ...i, z } : i)).sort((a, b) => a.z - b.z));
  };

  const removeItem = async (id: number) => {
    try {
      const it = itemsRef.current.find((i) => i.id === id);
      const files: string[] = [];
      if (it?.kind === 'collection') {
        // Apaga a coleção de dentro (e o cartão dela) com tudo que ela contém.
        files.push(...(await deleteCollection(Number(it.content))));
      } else {
        await deleteMoodItem(id);
        if (it?.kind === 'image') files.push(it.content);
      }
      files.forEach((name) => {
        try {
          const f = mediaFile(name);
          if (f.exists) f.delete();
        } catch {
          // arquivo já não existe
        }
      });
      setItems((prev) => prev.filter((i) => i.id !== id));
      setSelected(null);
    } catch (e) {
      appAlert('Não consegui remover', String(e));
    }
  };

  const remove = () => {
    if (!sel) return;
    const isCol = sel.kind === 'collection';
    const isNote = sel.kind === 'note';
    appAlert(
      isCol ? 'Excluir coleção?' : isNote ? 'Desvincular nota?' : 'Remover do moodboard?',
      isCol
        ? `"${subs[Number(sel.content)]?.name ?? ''}", as coleções de dentro dela e as imagens serão apagadas. As notas vinculadas não são apagadas.`
        : isNote
          ? 'A nota continua na Biblioteca; só sai desta coleção.'
          : undefined,
      [
        { text: 'Cancelar', style: 'cancel' },
        { text: isCol ? 'Excluir' : isNote ? 'Desvincular' : 'Remover', style: 'destructive', onPress: () => removeItem(sel.id) },
      ]
    );
  };

  return (
    <View
      ref={rootRef}
      style={styles.root}
      onLayout={() => {
        rootRef.current?.measure((_x, _y, _w, _h, px, py) => {
          origin.current = { x: px ?? 0, y: py ?? 0 };
        });
      }}
    >
      <StatusBar style="dark" />

      {/* Quadro: grade, fotos e textos andam e dão zoom juntos. */}
      <View style={StyleSheet.absoluteFill} {...bgPan.panHandlers}>
        <Animated.View
          style={{
            position: 'absolute',
            left: 0,
            top: 0,
            width: worldW,
            height: worldH,
            transformOrigin: 'top left',
            transform: [{ translateX: atx }, { translateY: aty }, { scale: az }],
          }}
        >
          <DotGrid width={worldW} height={worldH} />
          {items.map((it) => (
            <ItemView
              key={it.id}
              item={it}
              sw={u}
              selected={editMode && it.id === selected}
              live={live && live.id === it.id ? live : null}
              col={it.kind === 'collection' ? subs[Number(it.content)] : undefined}
              note={it.kind === 'note' ? notes[Number(it.content)] : undefined}
              onSize={onSize}
            />
          ))}
        </Animated.View>
      </View>

      <View style={[styles.header, { paddingTop: insets.top + u * 0.03, paddingHorizontal: u * 0.05 }]} pointerEvents="box-none">
        <Pressable onPress={onClose} hitSlop={18} style={{ width: u * 0.12, height: u * 0.1, justifyContent: 'center' }}>
          <View
            style={{
              width: u * 0.05,
              height: u * 0.05,
              borderLeftWidth: u * 0.012,
              borderBottomWidth: u * 0.012,
              borderColor: '#FF3030',
              transform: [{ rotate: '45deg' }],
              marginLeft: u * 0.015,
            }}
          />
        </Pressable>
        <Pressable onPress={() => setRenaming(true)} hitSlop={10} style={{ flex: 1 }}>
          {!!crumb && (
            <Text numberOfLines={1} style={{ fontFamily: fonts.regular, fontSize: u * 0.032, color: '#808080' }}>
              {crumb}
            </Text>
          )}
          <Text
            numberOfLines={1}
            style={{
              fontFamily: fonts.bold,
              fontSize: u * 0.075,
              letterSpacing: -u * 0.075 * 0.04,
              color: '#000',
            }}
          >
            {name}
          </Text>
        </Pressable>
      </View>

      {/* Zoom pelos botões (além da pinça com dois dedos no fundo). */}
      <View
        style={{ position: 'absolute', right: u * 0.04, bottom: insets.bottom + u * 0.2, gap: u * 0.025 }}
        pointerEvents="box-none"
      >
        <Round u={u} label="+" onPress={() => zoomAt(sw / 2, sh / 2, view.current.z * 1.4)} />
        <Round u={u} label="−" onPress={() => zoomAt(sw / 2, sh / 2, view.current.z / 1.4)} />
        <Round u={u} label="⤢" onPress={() => fitAll(items)} />
      </View>

      <View style={[styles.bar, { paddingBottom: insets.bottom + u * 0.04 }]} pointerEvents="box-none">
        <View style={styles.row}>
          {!editMode ? (
            <Btn u={u} label="Editar" onPress={() => setEditMode(true)} />
          ) : (
            <>
              {sel ? (
                <>
                  {sel.kind === 'text' && <Btn u={u} label="Editar texto" onPress={() => openEditor(sel.id)} />}
                  {(sel.kind === 'collection' || sel.kind === 'note') && (
                    <Btn u={u} label="Abrir" onPress={() => openCard(sel)} />
                  )}
                  <Btn u={u} label="Frente" onPress={toFront} />
                  <Btn u={u} label="Remover" onPress={remove} red />
                </>
              ) : (
                <>
                  <Btn u={u} label="+ Foto" onPress={addPhotos} />
                  <Btn u={u} label="+ Texto" onPress={() => setEditor({ id: 0, html: '' })} />
                  <Btn u={u} label="+ Coleção" onPress={() => setSubDlg(true)} />
                  <Btn u={u} label="+ Nota" onPress={() => openNoteSheet().catch(() => {})} />
                </>
              )}
              <Btn
                u={u}
                label="Pronto"
                onPress={() => {
                  setSelected(null);
                  setEditMode(false);
                }}
              />
            </>
          )}
        </View>
      </View>

      <PromptDialog
        visible={renaming}
        title="Renomear coleção"
        initialValue={name}
        onCancel={() => setRenaming(false)}
        onSubmit={async (v) => {
          setRenaming(false);
          setName(v);
          await renameCollection(collectionId, v);
        }}
      />

      <PromptDialog
        visible={subDlg}
        title="Nova coleção aqui dentro"
        initialValue=""
        placeholder="Nome da coleção"
        onCancel={() => setSubDlg(false)}
        onSubmit={(v) => {
          setSubDlg(false);
          addSub(v).catch((e) => appAlert('Não consegui criar a coleção', String(e)));
        }}
      />

      <BottomSheet
        visible={noteSheet !== null}
        onClose={() => setNoteSheet(null)}
        title="Criar nota nova aqui"
        onTitlePress={async () => {
          setNoteSheet(null);
          try {
            const id = await createBlock();
            await linkNote(id);
            onOpenNote(id);
          } catch (e) {
            appAlert('Não consegui criar a nota', String(e));
          }
        }}
        subtitle="Vincular nota existente"
        items={noteSheetItems}
        separators
      />

      {editor && (
        <TextEditorOverlay
          title={editor.id === 0 ? 'Novo texto' : 'Editar texto'}
          initialHtml={editor.html}
          onCancel={() => setEditor(null)}
          onDone={(h) => finishEditor(h).catch((e) => appAlert('Não consegui salvar o texto', String(e)))}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { ...StyleSheet.absoluteFillObject, backgroundColor: '#FFFFFF', overflow: 'hidden' },
  header: { position: 'absolute', top: 0, left: 0, right: 0, flexDirection: 'row', alignItems: 'center' },
  bar: { position: 'absolute', left: 0, right: 0, bottom: 0, alignItems: 'center' },
  row: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: 10, paddingHorizontal: 12 },
});
