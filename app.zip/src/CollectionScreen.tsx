import React, { memo, useCallback, useEffect, useRef, useState } from 'react';
import {
  Animated,
  BackHandler,
  Image,
  PanResponder,
  Pressable,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import * as ImagePicker from 'expo-image-picker';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { DotGrid } from './DotGrid';
import { appAlert } from './dialog';
import {
  MoodItem,
  addMoodItem,
  bringMoodItemToFront,
  deleteMoodItem,
  getCollectionName,
  listMoodItems,
  renameCollection,
  updateMoodItem,
} from './db';
import { mediaFile, mediaUri, saveMedia } from './media';
import { PromptDialog } from './PromptDialog';
import { RichText, asHtml, plainOf } from './RichText';
import { TextEditorOverlay } from './TextEditorOverlay';
import { fonts } from './theme';

type Props = { collectionId: number; onClose: () => void };

/** Tamanho do quadro, em "larguras de tela" (1 = largura do celular). */
const WORLD_W = 5;
const WORLD_H = 8;
const MAX_ZOOM = 3;

type View2 = { tx: number; ty: number; z: number };
type Live = { dx: number; dy: number; s: number; r: number };
type Patch = Partial<Pick<MoodItem, 'x' | 'y' | 'w' | 'h' | 'rot'>>;
type ViewRef = React.MutableRefObject<View2>;

const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));

/** Item do quadro. Arrastar com 1 dedo; pinça e giro com 2 dedos. O gesto é feito em cima do item. */
const ItemView = memo(function ItemView({
  item,
  sw,
  selected,
  viewRef,
  onSelect,
  onCommit,
  onTapSelectedText,
}: {
  item: MoodItem;
  sw: number;
  selected: boolean;
  viewRef: ViewRef;
  onSelect: (id: number) => void;
  onCommit: (id: number, patch: Patch) => void;
  onTapSelectedText: (id: number) => void;
}) {
  const [live, setLive] = useState<Live | null>(null);
  const size = useRef({ w: 0, h: 0 });
  const latest = useRef({ item, selected, onSelect, onCommit, onTapSelectedText });
  latest.current = { item, selected, onSelect, onCommit, onTapSelectedText };
  const base = useRef<{ dist: number; ang: number } | null>(null);
  const cur = useRef<Live>({ dx: 0, dy: 0, s: 1, r: 0 });
  const wasSelected = useRef(false);
  const pinched = useRef(false);

  const finish = useCallback((cancelled?: boolean) => {
    const { item: it, onCommit: commit } = latest.current;
    const g = cur.current;
    base.current = null;
    cur.current = { dx: 0, dy: 0, s: 1, r: 0 };
    // Dedo sempre treme um pouco: só vale como arrasto se andou mais que ~10 px na TELA (não no quadro).
    const z = viewRef.current.z || 1;
    const movedPx = Math.hypot(g.dx, g.dy) * z;
    const moved = movedPx > 10 || Math.abs(g.s - 1) > 0.03 || Math.abs(g.r) > 2 || pinched.current;
    pinched.current = false;
    if (!moved) {
      setLive(null);
      if (!cancelled && it.kind === 'text' && wasSelected.current) latest.current.onTapSelectedText(it.id);
      return;
    }
    const { w: bw, h: bh } = size.current;
    const s = clamp(g.s, 0.1, 8);
    const patch: Patch = {
      // A escala é aplicada em volta do centro; ao gravar, o canto superior esquerdo acompanha.
      x: clamp(it.x + g.dx / sw + (bw * (1 - s)) / 2, -0.3, WORLD_W - 0.1),
      y: clamp(it.y + g.dy / sw + (bh * (1 - s)) / 2, -0.3, WORLD_H - 0.1),
      rot: it.rot + g.r,
      w: it.w * s,
    };
    // Imagem: altura acompanha. Texto: h é a largura da caixa de texto.
    patch.h = it.h * s;
    commit(it.id, patch);
    setLive(null);
  }, [sw, viewRef]);

  const pan = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderTerminationRequest: () => false,
      onPanResponderGrant: () => {
        wasSelected.current = latest.current.selected;
        latest.current.onSelect(latest.current.item.id);
        cur.current = { dx: 0, dy: 0, s: 1, r: 0 };
        base.current = null;
        pinched.current = false;
      },
      onPanResponderMove: (e, g) => {
        const t = e.nativeEvent.touches;
        if (t.length >= 2) pinched.current = true;
        let s = cur.current.s;
        let r = cur.current.r;
        if (t.length >= 2) {
          const ddx = t[1].pageX - t[0].pageX;
          const ddy = t[1].pageY - t[0].pageY;
          const dist = Math.hypot(ddx, ddy);
          const ang = (Math.atan2(ddy, ddx) * 180) / Math.PI;
          if (!base.current) base.current = { dist: dist / (s || 1), ang: ang - r };
          s = dist / base.current.dist;
          let d = ang - base.current.ang;
          while (d > 180) d -= 360;
          while (d < -180) d += 360;
          r = d;
        } else {
          base.current = null;
        }
        const z = viewRef.current.z || 1;
        cur.current = { dx: g.dx / z, dy: g.dy / z, s, r };
        if (Math.hypot(g.dx, g.dy) < 4 && t.length < 2) return; // ainda é um toque
        setLive({ ...cur.current });
      },
      onPanResponderRelease: () => finish(),
      onPanResponderTerminate: () => finish(true),
    })
  ).current;

  const L = live ?? { dx: 0, dy: 0, s: 1, r: 0 };
  const transform = [
    { translateX: L.dx },
    { translateY: L.dy },
    { rotate: `${item.rot + L.r}deg` },
    { scale: L.s },
  ];

  return (
    <View
      {...pan.panHandlers}
      onLayout={(e) => {
        size.current = { w: e.nativeEvent.layout.width / sw, h: e.nativeEvent.layout.height / sw };
      }}
      style={{ position: 'absolute', left: item.x * sw, top: item.y * sw, transform }}
    >
      {item.kind === 'image' ? (
        <Image
          source={{ uri: mediaUri(item.content) }}
          resizeMode="cover"
          style={{ width: item.w * sw, height: item.h * sw }}
        />
      ) : (
        <RichText html={item.content} base={item.w * sw} width={(item.h || 0.6) * sw} />
      )}
      {selected && (
        <View
          pointerEvents="none"
          style={{ ...StyleSheet.absoluteFillObject, borderWidth: 2, borderColor: '#FF3030' }}
        />
      )}
    </View>
  );
});

export function CollectionScreen({ collectionId, onClose }: Props) {
  const { width: sw, height: sh } = useWindowDimensions();
  // Unidade do quadro = lado menor da tela (a largura em pé). Assim nada muda de tamanho ao girar.
  const u = Math.min(sw, sh);
  const insets = useSafeAreaInsets();
  const [name, setName] = useState('');
  const [items, setItems] = useState<MoodItem[]>([]);
  const [selected, setSelected] = useState<number | null>(null);
  const [renaming, setRenaming] = useState(false);
  /** null = fechado; id 0 = novo texto; outro = editando esse item. */
  const [editor, setEditor] = useState<{ id: number; html: string } | null>(null);

  // ---------- zoom e posição do quadro ----------
  const worldW = WORLD_W * u;
  const worldH = WORLD_H * u;
  const minZoom = Math.max(sw / worldW, sh / worldH);
  const view = useRef<View2>({ tx: 0, ty: 0, z: 1 });
  const atx = useRef(new Animated.Value(0)).current;
  const aty = useRef(new Animated.Value(0)).current;
  const az = useRef(new Animated.Value(1)).current;
  const rootRef = useRef<View>(null);
  const origin = useRef({ x: 0, y: 0 });

  const clampView = useCallback(
    (v: View2): View2 => {
      const z = clamp(v.z, minZoom, MAX_ZOOM);
      return {
        z,
        tx: clamp(v.tx, sw - worldW * z, 0),
        ty: clamp(v.ty, sh - worldH * z, 0),
      };
    },
    [minZoom, sw, sh, worldW, worldH]
  );

  const setView = useCallback(
    (v: View2) => {
      const c = clampView(v);
      view.current = c;
      atx.setValue(c.tx);
      aty.setValue(c.ty);
      az.setValue(c.z);
    },
    [clampView, atx, aty, az]
  );

  /** Mantém o ponto (px, py) da tela parado enquanto o zoom muda. */
  const zoomAt = useCallback(
    (px: number, py: number, z: number) => {
      const v = view.current;
      const nz = clamp(z, minZoom, MAX_ZOOM);
      const wx = (px - v.tx) / v.z;
      const wy = (py - v.ty) / v.z;
      setView({ z: nz, tx: px - wx * nz, ty: py - wy * nz });
    },
    [minZoom, setView]
  );

  const fitAll = useCallback(
    (list: MoodItem[]) => {
      if (list.length === 0) {
        // Coleção nova: começa no meio do quadro.
        setView({ z: 1, tx: sw / 2 - (worldW / 2), ty: sh / 2 - worldH / 2 });
        return;
      }
      let x0 = Infinity,
        y0 = Infinity,
        x1 = -Infinity,
        y1 = -Infinity;
      for (const it of list) {
        const w = it.kind === 'image' ? it.w : it.h || 0.6;
        const h = it.kind === 'image' ? it.h : 0.25;
        x0 = Math.min(x0, it.x);
        y0 = Math.min(y0, it.y);
        x1 = Math.max(x1, it.x + w);
        y1 = Math.max(y1, it.y + h);
      }
      const pad = 0.08;
      const bw = (x1 - x0 + pad * 2) * u;
      const bh = (y1 - y0 + pad * 2) * u;
      const z = clamp(Math.min(sw / bw, (sh * 0.85) / bh, 1), minZoom, 1);
      const cx = ((x0 + x1) / 2) * u;
      const cy = ((y0 + y1) / 2) * u;
      setView({ z, tx: sw / 2 - cx * z, ty: sh / 2 - cy * z });
    },
    [setView, sw, sh, u, worldW, worldH, minZoom]
  );

  useEffect(() => {
    getCollectionName(collectionId).then(setName).catch(() => {});
    listMoodItems(collectionId)
      .then((list) => {
        setItems(list);
        fitAll(list);
      })
      .catch((e) => appAlert('Erro ao abrir a coleção', String(e)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [collectionId]);

  // Girou a tela: mantém o quadro dentro dos limites.
  useEffect(() => {
    setView(view.current);
  }, [sw, sh, setView]);

  // O PanResponder é criado uma vez; estas referências mantêm os valores atuais.
  const minZoomRef = useRef(minZoom);
  minZoomRef.current = minZoom;
  const setViewRef = useRef(setView);
  setViewRef.current = setView;

  // Gesto no fundo: 1 dedo arrasta o quadro; 2 dedos dão zoom (e arrastam junto).
  const bg = useRef<{ n: number; v: View2; cx: number; cy: number; dist: number; px: number; py: number } | null>(null);
  const bgPan = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderTerminationRequest: () => false,
      onPanResponderGrant: () => {
        setSelected(null);
        bg.current = null;
      },
      onPanResponderMove: (e) => {
        const t = e.nativeEvent.touches;
        const n = Math.min(2, t.length);
        const ox = origin.current.x;
        const oy = origin.current.y;
        const cx = (n === 2 ? (t[0].pageX + t[1].pageX) / 2 : t[0].pageX) - ox;
        const cy = (n === 2 ? (t[0].pageY + t[1].pageY) / 2 : t[0].pageY) - oy;
        const dist = n === 2 ? Math.hypot(t[1].pageX - t[0].pageX, t[1].pageY - t[0].pageY) : 0;
        if (!bg.current || bg.current.n !== n) {
          // Mudou o número de dedos: recomeça a partir da posição atual.
          bg.current = { n, v: { ...view.current }, cx, cy, dist, px: cx, py: cy };
          return;
        }
        const b = bg.current;
        if (n === 1) {
          setViewRef.current({ z: b.v.z, tx: b.v.tx + (cx - b.cx), ty: b.v.ty + (cy - b.cy) });
        } else {
          const z = clamp(b.v.z * (dist / (b.dist || 1)), minZoomRef.current, MAX_ZOOM);
          const wx = (b.cx - b.v.tx) / b.v.z;
          const wy = (b.cy - b.v.ty) / b.v.z;
          setViewRef.current({ z, tx: cx - wx * z, ty: cy - wy * z });
        }
      },
      onPanResponderRelease: () => {
        bg.current = null;
      },
      onPanResponderTerminate: () => {
        bg.current = null;
      },
    })
  ).current;

  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (selected !== null) setSelected(null);
      else onClose();
      return true;
    });
    return () => sub.remove();
  }, [selected, onClose]);

  const itemsRef = useRef(items);
  itemsRef.current = items;
  const sel = items.find((i) => i.id === selected) ?? null;

  const commit = useCallback((id: number, patch: Patch) => {
    setItems((prev) => prev.map((i) => (i.id === id ? { ...i, ...patch } : i)));
    updateMoodItem(id, patch).catch(() => {});
  }, []);

  /** Ponto do quadro que está no centro da tela, em unidades de largura. */
  const viewCenter = () => {
    const v = view.current;
    return { x: (sw / 2 - v.tx) / v.z / u, y: (sh / 2 - v.ty) / v.z / u };
  };

  const addPhotos = async () => {
    try {
      const r = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ['images'],
        allowsMultipleSelection: true,
        quality: 0.85,
      });
      if (r.canceled) return;
      const c = viewCenter();
      const z = view.current.z;
      const added: MoodItem[] = [];
      for (const a of r.assets) {
        const stored = saveMedia(a.uri, a.fileName, 'jpg');
        const w = clamp(0.42 / z, 0.2, 1.4);
        const ratio = a.width && a.height ? a.height / a.width : 1.3;
        const h = clamp(w * ratio, w * 0.4, w * 2.5);
        const n = added.length;
        added.push(
          await addMoodItem({
            collectionId,
            kind: 'image',
            content: stored,
            x: clamp(c.x - w / 2 + n * 0.05 / z, 0, WORLD_W - w),
            y: clamp(c.y - h / 2 + n * 0.05 / z, 0, WORLD_H - h),
            w,
            h,
            rot: ((n % 5) - 2) * 4,
            bold: false,
          })
        );
      }
      setItems((prev) => [...prev, ...added]);
      if (added.length > 0) setSelected(added[added.length - 1].id);
    } catch (e) {
      appAlert('Não consegui adicionar a foto', String(e));
    }
  };

  const finishEditor = async (html: string) => {
    const ed = editor;
    setEditor(null);
    if (!ed) return;
    const empty = plainOf(html) === '';
    if (ed.id === 0) {
      if (empty) return;
      const c = viewCenter();
      const z = view.current.z;
      const w = clamp(0.06 / z, 0.03, 0.5); // tamanho da letra
      const box = clamp(0.6 / z, 0.3, 2.5); // largura da caixa
      const it = await addMoodItem({
        collectionId,
        kind: 'text',
        content: html,
        x: clamp(c.x - box / 2, 0, WORLD_W - box),
        y: clamp(c.y - 0.1, 0, WORLD_H - 0.2),
        w,
        h: box,
        rot: 0,
        bold: false,
      });
      setItems((prev) => [...prev, it]);
      setSelected(it.id);
    } else if (empty) {
      await removeItem(ed.id);
    } else {
      setItems((prev) => prev.map((i) => (i.id === ed.id ? { ...i, content: html } : i)));
      updateMoodItem(ed.id, { content: html }).catch(() => {});
    }
  };

  const openEditor = useCallback((id: number) => {
    const it = itemsRef.current.find((i) => i.id === id);
    if (it && it.kind === 'text') setEditor({ id, html: asHtml(it.content) });
  }, []);

  const toFront = async () => {
    if (!sel) return;
    const z = await bringMoodItemToFront(sel.id, collectionId);
    setItems((prev) => prev.map((i) => (i.id === sel.id ? { ...i, z } : i)).sort((a, b) => a.z - b.z));
  };

  const removeItem = async (id: number) => {
    const it = items.find((i) => i.id === id);
    await deleteMoodItem(id);
    if (it?.kind === 'image') {
      try {
        const f = mediaFile(it.content);
        if (f.exists) f.delete();
      } catch {
        // arquivo já não existe
      }
    }
    setItems((prev) => prev.filter((i) => i.id !== id));
    setSelected(null);
  };

  const remove = () => {
    if (!sel) return;
    appAlert('Remover do moodboard?', undefined, [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Remover', style: 'destructive', onPress: () => removeItem(sel.id) },
    ]);
  };

  const btn = u * 0.04;
  const Btn = ({ label, onPress, red }: { label: string; onPress: () => void; red?: boolean }) => (
    <Pressable
      onPress={onPress}
      hitSlop={6}
      style={{
        backgroundColor: red ? '#FF3030' : '#000',
        paddingHorizontal: u * 0.04,
        paddingVertical: u * 0.026,
        borderRadius: u * 0.08,
      }}
    >
      <Text style={{ color: '#fff', fontFamily: fonts.regular, fontSize: btn }}>{label}</Text>
    </Pressable>
  );
  const Round = ({ label, onPress }: { label: string; onPress: () => void }) => (
    <Pressable
      onPress={onPress}
      hitSlop={6}
      style={{
        width: u * 0.11,
        height: u * 0.11,
        borderRadius: u * 0.055,
        backgroundColor: 'rgba(255,255,255,0.92)',
        borderWidth: 1,
        borderColor: 'rgba(0,0,0,0.15)',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <Text style={{ color: '#000', fontFamily: fonts.regular, fontSize: u * 0.055, lineHeight: u * 0.065 }}>{label}</Text>
    </Pressable>
  );

  return (
    <View
      ref={rootRef}
      style={styles.root}
      onLayout={() => {
        rootRef.current?.measure((_x, _y, _w, _h, px, py) => {
          origin.current = { x: px ?? 0, y: py ?? 0 };
        });
      }}
    >
      <StatusBar style="dark" />

      {/* Quadro: grade, fotos e textos andam e dão zoom juntos. */}
      <View style={StyleSheet.absoluteFill} {...bgPan.panHandlers}>
        <Animated.View
          style={{
            position: 'absolute',
            left: 0,
            top: 0,
            width: worldW,
            height: worldH,
            transformOrigin: 'top left',
            transform: [{ translateX: atx }, { translateY: aty }, { scale: az }],
          }}
        >
          <DotGrid width={worldW} height={worldH} />
          {items.map((it) => (
            <ItemView
              key={it.id}
              item={it}
              sw={u}
              selected={it.id === selected}
              viewRef={view}
              onSelect={setSelected}
              onCommit={commit}
              onTapSelectedText={openEditor}
            />
          ))}
        </Animated.View>
      </View>

      <View style={[styles.header, { paddingTop: insets.top + u * 0.03, paddingHorizontal: u * 0.05 }]} pointerEvents="box-none">
        <Pressable onPress={onClose} hitSlop={18} style={{ width: u * 0.12, height: u * 0.1, justifyContent: 'center' }}>
          <View
            style={{
              width: u * 0.05,
              height: u * 0.05,
              borderLeftWidth: u * 0.012,
              borderBottomWidth: u * 0.012,
              borderColor: '#FF3030',
              transform: [{ rotate: '45deg' }],
              marginLeft: u * 0.015,
            }}
          />
        </Pressable>
        <Pressable onPress={() => setRenaming(true)} hitSlop={10} style={{ flex: 1 }}>
          <Text
            numberOfLines={1}
            style={{
              fontFamily: fonts.bold,
              fontSize: u * 0.075,
              letterSpacing: -u * 0.075 * 0.04,
              color: '#000',
            }}
          >
            {name}
          </Text>
        </Pressable>
      </View>

      {/* Zoom pelos botões (além da pinça com dois dedos no fundo). */}
      <View
        style={{ position: 'absolute', right: u * 0.04, bottom: insets.bottom + u * 0.2, gap: u * 0.025 }}
        pointerEvents="box-none"
      >
        <Round label="+" onPress={() => zoomAt(sw / 2, sh / 2, view.current.z * 1.4)} />
        <Round label="−" onPress={() => zoomAt(sw / 2, sh / 2, view.current.z / 1.4)} />
        <Round label="⤢" onPress={() => fitAll(items)} />
      </View>

      <View style={[styles.bar, { paddingBottom: insets.bottom + u * 0.04 }]} pointerEvents="box-none">
        <View style={styles.row}>
          {sel ? (
            <>
              {sel.kind === 'text' && <Btn label="Editar texto" onPress={() => openEditor(sel.id)} />}
              <Btn label="Frente" onPress={toFront} />
              <Btn label="Remover" onPress={remove} red />
            </>
          ) : (
            <>
              <Btn label="+ Foto" onPress={addPhotos} />
              <Btn label="+ Texto" onPress={() => setEditor({ id: 0, html: '' })} />
            </>
          )}
        </View>
      </View>

      <PromptDialog
        visible={renaming}
        title="Renomear coleção"
        initialValue={name}
        onCancel={() => setRenaming(false)}
        onSubmit={async (v) => {
          setRenaming(false);
          setName(v);
          await renameCollection(collectionId, v);
        }}
      />

      {editor && (
        <TextEditorOverlay
          title={editor.id === 0 ? 'Novo texto' : 'Editar texto'}
          initialHtml={editor.html}
          onCancel={() => setEditor(null)}
          onDone={(h) => finishEditor(h).catch(() => {})}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { ...StyleSheet.absoluteFillObject, backgroundColor: '#FFFFFF', overflow: 'hidden' },
  header: { position: 'absolute', top: 0, left: 0, right: 0, flexDirection: 'row', alignItems: 'center' },
  bar: { position: 'absolute', left: 0, right: 0, bottom: 0, alignItems: 'center' },
  row: { flexDirection: 'row', gap: 10 },
});
