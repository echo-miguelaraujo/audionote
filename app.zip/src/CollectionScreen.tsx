import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  BackHandler,
  Image,
  PanResponder,
  Pressable,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import * as ImagePicker from 'expo-image-picker';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { DotGrid } from './DotGrid';
import { appAlert } from './dialog';
import {
  MoodItem,
  addMoodItem,
  bringMoodItemToFront,
  deleteMoodItem,
  getCollectionName,
  listMoodItems,
  renameCollection,
  updateMoodItem,
} from './db';
import { mediaFile, mediaUri, saveMedia } from './media';
import { PromptDialog } from './PromptDialog';
import { fonts } from './theme';

type Props = { collectionId: number; onClose: () => void };

type Live = { dx: number; dy: number; s: number; r: number };
type Patch = Partial<Pick<MoodItem, 'x' | 'y' | 'w' | 'h' | 'rot'>>;

/** Arrastar com 1 dedo; pinça e giro com 2 dedos. Só o item mexido é redesenhado durante o gesto. */
function ItemView({
  item,
  sw,
  selected,
  onSelect,
  onCommit,
}: {
  item: MoodItem;
  sw: number;
  selected: boolean;
  onSelect: (id: number) => void;
  onCommit: (id: number, patch: Patch) => void;
}) {
  const [live, setLive] = useState<Live | null>(null);
  const size = useRef({ w: 0, h: 0 });
  const latest = useRef({ item, onSelect, onCommit });
  latest.current = { item, onSelect, onCommit };
  const base = useRef<{ dist: number; ang: number } | null>(null);
  const cur = useRef<Live>({ dx: 0, dy: 0, s: 1, r: 0 });

  const finish = useCallback(() => {
    const { item: it, onCommit: commit } = latest.current;
    const g = cur.current;
    base.current = null;
    cur.current = { dx: 0, dy: 0, s: 1, r: 0 };
    const moved = Math.abs(g.dx) + Math.abs(g.dy) > 0.5 || Math.abs(g.s - 1) > 0.002 || Math.abs(g.r) > 0.2;
    if (!moved) {
      setLive(null);
      return;
    }
    const { w: bw, h: bh } = size.current;
    const s = Math.min(6, Math.max(0.15, g.s));
    const patch: Patch = {
      // A escala é aplicada em volta do centro; ao gravar, o canto superior esquerdo acompanha.
      x: it.x + g.dx / sw + (bw * (1 - s)) / 2,
      y: it.y + g.dy / sw + (bh * (1 - s)) / 2,
      rot: it.rot + g.r,
    };
    if (it.kind === 'image') {
      patch.w = it.w * s;
      patch.h = it.h * s;
    } else {
      patch.w = it.w * s;
    }
    commit(it.id, patch);
    setLive(null);
  }, [sw]);

  const pan = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderTerminationRequest: () => false,
      onPanResponderGrant: () => {
        latest.current.onSelect(latest.current.item.id);
        cur.current = { dx: 0, dy: 0, s: 1, r: 0 };
        base.current = null;
      },
      onPanResponderMove: (e, g) => {
        const t = e.nativeEvent.touches;
        let s = cur.current.s;
        let r = cur.current.r;
        if (t.length >= 2) {
          const ddx = t[1].pageX - t[0].pageX;
          const ddy = t[1].pageY - t[0].pageY;
          const dist = Math.hypot(ddx, ddy);
          const ang = (Math.atan2(ddy, ddx) * 180) / Math.PI;
          if (!base.current) {
            // Segundo dedo acabou de encostar: guarda o ponto de partida (s e r atuais continuam).
            base.current = { dist: dist / (s || 1), ang: ang - r };
          }
          s = dist / base.current.dist;
          let d = ang - base.current.ang;
          while (d > 180) d -= 360;
          while (d < -180) d += 360;
          r = d;
        } else {
          base.current = null;
        }
        cur.current = { dx: g.dx, dy: g.dy, s, r };
        setLive({ ...cur.current });
      },
      onPanResponderRelease: finish,
      onPanResponderTerminate: finish,
    })
  ).current;

  const L = live ?? { dx: 0, dy: 0, s: 1, r: 0 };
  const transform = [
    { translateX: L.dx },
    { translateY: L.dy },
    { rotate: `${item.rot + L.r}deg` },
    { scale: L.s },
  ];

  return (
    <View
      {...pan.panHandlers}
      onLayout={(e) => {
        size.current = { w: e.nativeEvent.layout.width / sw, h: e.nativeEvent.layout.height / sw };
      }}
      style={{ position: 'absolute', left: item.x * sw, top: item.y * sw, transform }}
    >
      {item.kind === 'image' ? (
        <Image
          source={{ uri: mediaUri(item.content) }}
          resizeMode="cover"
          style={{ width: item.w * sw, height: item.h * sw }}
        />
      ) : (
        <Text
          style={{
            fontFamily: item.bold ? fonts.bold : fonts.regular,
            fontSize: item.w * sw,
            letterSpacing: -item.w * sw * 0.04,
            color: '#000',
          }}
        >
          {item.content}
        </Text>
      )}
      {selected && (
        <View
          pointerEvents="none"
          style={{ ...StyleSheet.absoluteFillObject, borderWidth: 1.5, borderColor: '#FF3030' }}
        />
      )}
    </View>
  );
}

export function CollectionScreen({ collectionId, onClose }: Props) {
  const { width: sw } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const [name, setName] = useState('');
  const [items, setItems] = useState<MoodItem[]>([]);
  const [selected, setSelected] = useState<number | null>(null);
  const [renaming, setRenaming] = useState(false);
  const [newText, setNewText] = useState(false);
  const [editText, setEditText] = useState(false);

  useEffect(() => {
    getCollectionName(collectionId).then(setName).catch(() => {});
    listMoodItems(collectionId)
      .then(setItems)
      .catch((e) => appAlert('Erro ao abrir a coleção', String(e)));
  }, [collectionId]);

  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (selected !== null) setSelected(null);
      else onClose();
      return true;
    });
    return () => sub.remove();
  }, [selected, onClose]);

  const sel = items.find((i) => i.id === selected) ?? null;

  const commit = useCallback((id: number, patch: Patch) => {
    setItems((prev) => prev.map((i) => (i.id === id ? { ...i, ...patch } : i)));
    updateMoodItem(id, patch).catch(() => {});
  }, []);

  const addPhotos = async () => {
    try {
      const r = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ['images'],
        allowsMultipleSelection: true,
        quality: 0.85,
      });
      if (r.canceled) return;
      const added: MoodItem[] = [];
      for (const a of r.assets) {
        const stored = saveMedia(a.uri, a.fileName, 'jpg');
        const w = 0.42;
        const ratio = a.width && a.height ? a.height / a.width : 1.3;
        const h = Math.min(0.9, Math.max(0.2, w * ratio));
        const n = added.length + items.length;
        added.push(
          await addMoodItem({
            collectionId,
            kind: 'image',
            content: stored,
            x: 0.08 + ((n * 0.13) % 0.45),
            y: 0.2 + ((n * 0.11) % 0.4),
            w,
            h,
            rot: ((n % 5) - 2) * 4,
            bold: false,
          })
        );
      }
      setItems((prev) => [...prev, ...added]);
      if (added.length > 0) setSelected(added[added.length - 1].id);
    } catch (e) {
      appAlert('Não consegui adicionar a foto', String(e));
    }
  };

  const addText = async (text: string) => {
    const it = await addMoodItem({
      collectionId,
      kind: 'text',
      content: text,
      x: 0.12,
      y: 0.3 + ((items.length * 0.06) % 0.3),
      w: 0.075,
      h: 0,
      rot: 0,
      bold: false,
    });
    setItems((prev) => [...prev, it]);
    setSelected(it.id);
  };

  const toFront = async () => {
    if (!sel) return;
    const z = await bringMoodItemToFront(sel.id, collectionId);
    setItems((prev) => {
      const next = prev.map((i) => (i.id === sel.id ? { ...i, z } : i));
      return next.sort((a, b) => a.z - b.z);
    });
  };

  const remove = () => {
    if (!sel) return;
    appAlert('Remover do moodboard?', undefined, [
      { text: 'Cancelar', style: 'cancel' },
      {
        text: 'Remover',
        style: 'destructive',
        onPress: async () => {
          await deleteMoodItem(sel.id);
          if (sel.kind === 'image') {
            try {
              const f = mediaFile(sel.content);
              if (f.exists) f.delete();
            } catch {
              // arquivo já não existe
            }
          }
          setItems((prev) => prev.filter((i) => i.id !== sel.id));
          setSelected(null);
        },
      },
    ]);
  };

  const toggleBold = () => {
    if (!sel || sel.kind !== 'text') return;
    const bold = !sel.bold;
    setItems((prev) => prev.map((i) => (i.id === sel.id ? { ...i, bold } : i)));
    updateMoodItem(sel.id, { bold }).catch(() => {});
  };

  const btn = sw * 0.04;
  const Btn = ({ label, onPress, red }: { label: string; onPress: () => void; red?: boolean }) => (
    <Pressable
      onPress={onPress}
      hitSlop={6}
      style={{
        backgroundColor: red ? '#FF3030' : '#000',
        paddingHorizontal: sw * 0.04,
        paddingVertical: sw * 0.026,
        borderRadius: sw * 0.08,
      }}
    >
      <Text style={{ color: '#fff', fontFamily: fonts.regular, fontSize: btn }}>{label}</Text>
    </Pressable>
  );

  return (
    <View style={styles.root}>
      <StatusBar style="dark" />
      <DotGrid />

      {/* Toque no fundo: tira a seleção. */}
      <Pressable style={StyleSheet.absoluteFill} onPress={() => setSelected(null)} />

      {items.map((it) => (
        <ItemView
          key={it.id}
          item={it}
          sw={sw}
          selected={it.id === selected}
          onSelect={setSelected}
          onCommit={commit}
        />
      ))}

      <View style={[styles.header, { paddingTop: insets.top + sw * 0.03, paddingHorizontal: sw * 0.05 }]} pointerEvents="box-none">
        <Pressable onPress={onClose} hitSlop={18} style={{ width: sw * 0.12, height: sw * 0.1, justifyContent: 'center' }}>
          <View
            style={{
              width: sw * 0.05,
              height: sw * 0.05,
              borderLeftWidth: sw * 0.012,
              borderBottomWidth: sw * 0.012,
              borderColor: '#FF3030',
              transform: [{ rotate: '45deg' }],
              marginLeft: sw * 0.015,
            }}
          />
        </Pressable>
        <Pressable onPress={() => setRenaming(true)} hitSlop={10} style={{ flex: 1 }}>
          <Text
            numberOfLines={1}
            style={{
              fontFamily: fonts.bold,
              fontSize: sw * 0.075,
              letterSpacing: -sw * 0.075 * 0.04,
              color: '#000',
            }}
          >
            {name}
          </Text>
        </Pressable>
      </View>

      <View style={[styles.bar, { paddingBottom: insets.bottom + sw * 0.04 }]} pointerEvents="box-none">
        <View style={styles.row}>
          {sel ? (
            <>
              {sel.kind === 'text' && <Btn label="Editar" onPress={() => setEditText(true)} />}
              {sel.kind === 'text' && <Btn label={sel.bold ? 'Normal' : 'Negrito'} onPress={toggleBold} />}
              <Btn label="Frente" onPress={toFront} />
              <Btn label="Remover" onPress={remove} red />
            </>
          ) : (
            <>
              <Btn label="+ Foto" onPress={addPhotos} />
              <Btn label="+ Texto" onPress={() => setNewText(true)} />
            </>
          )}
        </View>
      </View>

      <PromptDialog
        visible={renaming}
        title="Renomear coleção"
        initialValue={name}
        onCancel={() => setRenaming(false)}
        onSubmit={async (v) => {
          setRenaming(false);
          setName(v);
          await renameCollection(collectionId, v);
        }}
      />
      <PromptDialog
        visible={newText}
        title="Novo texto"
        initialValue=""
        maxLength={120}
        onCancel={() => setNewText(false)}
        onSubmit={(v) => {
          setNewText(false);
          addText(v).catch(() => {});
        }}
      />
      <PromptDialog
        visible={editText}
        title="Editar texto"
        initialValue={sel?.kind === 'text' ? sel.content : ''}
        maxLength={120}
        onCancel={() => setEditText(false)}
        onSubmit={(v) => {
          setEditText(false);
          if (!sel) return;
          setItems((prev) => prev.map((i) => (i.id === sel.id ? { ...i, content: v } : i)));
          updateMoodItem(sel.id, { content: v }).catch(() => {});
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { ...StyleSheet.absoluteFillObject, backgroundColor: '#FFFFFF', overflow: 'hidden' },
  header: { position: 'absolute', top: 0, left: 0, right: 0, flexDirection: 'row', alignItems: 'center' },
  bar: { position: 'absolute', left: 0, right: 0, bottom: 0, alignItems: 'center' },
  row: { flexDirection: 'row', gap: 10 },
});
