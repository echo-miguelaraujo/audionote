import type * as SQLite from 'expo-sqlite';

/**
 * Prepara o SQLite para sincronizar com o Supabase SEM mudar o resto do app:
 * os ids inteiros continuam sendo os ids locais; cada linha ganha também um UUID (o id na nuvem).
 *
 * Colunas novas em cada tabela sincronizada:
 *   uuid        id global (o mesmo da tabela correspondente no Supabase)
 *   updated_at  última alteração, em ms (hora do aparelho; nas linhas vindas da nuvem, a hora do servidor)
 *   dirty       1 = tem alteração ainda não enviada
 *   sync_rev    contador interno; a sincronização o incrementa para os gatilhos saberem que a
 *               escrita veio dela (e não de uma edição do usuário)
 *
 * Gatilhos (por isso nenhuma função do db.ts precisou mudar):
 *   INSERT  -> gera o uuid e marca como pendente
 *   UPDATE  -> marca como pendente e carimba updated_at (a menos que a escrita seja da sincronização)
 *   DELETE  -> registra uma "lápide" em sync_tombstones (inclusive nas exclusões em cascata)
 */

export const SYNC_TABLES = ['categories', 'blocks', 'mood_collections', 'mood_items', 'agenda_items'] as const;
export type SyncTable = (typeof SYNC_TABLES)[number];

/** UUID v4 gerado dentro do SQLite. */
export const UUID_SQL = `(lower(hex(randomblob(4))) || '-' || lower(hex(randomblob(2))) || '-4' ||
  substr(lower(hex(randomblob(2))), 2) || '-' || substr('89ab', abs(random()) % 4 + 1, 1) ||
  substr(lower(hex(randomblob(2))), 2) || '-' || lower(hex(randomblob(6))))`;

/** Agora, em milissegundos. */
export const NOW_MS_SQL = `(CAST(strftime('%s', 'now') AS INTEGER) * 1000 + CAST(substr(strftime('%f', 'now'), 4, 3) AS INTEGER))`;

export function triggerSql(t: SyncTable): string {
  return `
    CREATE TRIGGER IF NOT EXISTS trg_sync_ins_${t} AFTER INSERT ON ${t}
    WHEN NEW.uuid IS NULL
    BEGIN
      UPDATE ${t} SET uuid = ${UUID_SQL}, updated_at = ${NOW_MS_SQL}, dirty = 1, sync_rev = sync_rev + 1
      WHERE id = NEW.id;
    END;

    CREATE TRIGGER IF NOT EXISTS trg_sync_upd_${t} AFTER UPDATE ON ${t}
    WHEN NEW.sync_rev = OLD.sync_rev AND NEW.uuid IS NOT NULL
    BEGIN
      UPDATE ${t} SET dirty = 1, updated_at = ${NOW_MS_SQL}, sync_rev = sync_rev + 1
      WHERE id = NEW.id;
    END;

    CREATE TRIGGER IF NOT EXISTS trg_sync_del_${t} AFTER DELETE ON ${t}
    WHEN OLD.uuid IS NOT NULL
    BEGIN
      INSERT OR REPLACE INTO sync_tombstones (tbl, uuid, deleted_at)
      VALUES ('${t}', OLD.uuid, ${NOW_MS_SQL});
    END;
  `;
}

export async function migrateSyncSchema(db: SQLite.SQLiteDatabase): Promise<void> {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS sync_tombstones (
      tbl TEXT NOT NULL,
      uuid TEXT NOT NULL,
      deleted_at INTEGER NOT NULL,
      PRIMARY KEY (tbl, uuid)
    );
  `);

  for (const t of SYNC_TABLES) {
    const cols = new Set(
      (await db.getAllAsync<{ name: string }>(`PRAGMA table_info(${t})`)).map((c) => c.name)
    );
    if (!cols.has('uuid')) await db.execAsync(`ALTER TABLE ${t} ADD COLUMN uuid TEXT`);
    if (!cols.has('updated_at')) await db.execAsync(`ALTER TABLE ${t} ADD COLUMN updated_at INTEGER NOT NULL DEFAULT 0`);
    // DEFAULT 1: toda linha que já existia entra como "pendente" e vai na primeira sincronização.
    if (!cols.has('dirty')) await db.execAsync(`ALTER TABLE ${t} ADD COLUMN dirty INTEGER NOT NULL DEFAULT 1`);
    if (!cols.has('sync_rev')) await db.execAsync(`ALTER TABLE ${t} ADD COLUMN sync_rev INTEGER NOT NULL DEFAULT 0`);

    // Migra as linhas existentes (antes de criar os gatilhos, para não disparar nenhum).
    await db.execAsync(`
      UPDATE ${t} SET uuid = ${UUID_SQL} WHERE uuid IS NULL;
      UPDATE ${t} SET updated_at = CASE WHEN created_at > 0 THEN created_at ELSE ${NOW_MS_SQL} END
        WHERE updated_at = 0;
      CREATE UNIQUE INDEX IF NOT EXISTS idx_${t}_uuid ON ${t}(uuid);
    `);
    await db.execAsync(triggerSql(t));
  }
}
