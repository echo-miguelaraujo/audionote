/** Importação de pastas (boards) do Pinterest: reconhecimento do link e distribuição das imagens no quadro. */

/** Máximo de imagens por importação (o quadro tem espaço finito e cada imagem é baixada). */
export const MAX_PINS = 300;

export type PinImage = { url: string; w: number; h: number };

const RESERVED = new Set([
  'pin', 'search', 'ideas', 'today', 'topics', 'business', 'login', 'settings', 'explore', 'news_hub', 'videos', 'shop', 'about',
]);

const hostOf = (url: string): string => {
  const m = /^https?:\/\/([^/?#:]+)/i.exec(url.trim());
  return m ? m[1].toLowerCase().replace(/^www\./, '') : '';
};

/** Qualquer endereço do Pinterest (inclui os links curtos pin.it). */
export function isPinterestUrl(url: string): boolean {
  const h = hostOf(url);
  return h === 'pin.it' || /(^|\.)pinterest\.[a-z.]+$/.test(h);
}

/** Link de pasta: pinterest.com/<usuário>/<pasta>/ (e subpasta). Pins soltos, buscas e perfis não contam. */
export function isPinterestBoard(url: string): boolean {
  const h = hostOf(url);
  if (!/(^|\.)pinterest\.[a-z.]+$/.test(h)) return false;
  let path = '';
  try {
    path = new URL(url).pathname;
  } catch {
    return false;
  }
  const seg = path.split('/').filter(Boolean);
  if (seg.length < 2 || seg.length > 3) return false;
  return !RESERVED.has(seg[0].toLowerCase());
}

export type Slot = { x: number; y: number; w: number; h: number };

/**
 * Distribui as imagens em colunas (mosaico): cada uma vai para a coluna mais baixa. Escolhe o menor número de colunas
 * em que tudo cabe no quadro (imagens o maior possível, até `maxW`). Se nem com muitas colunas couber, devolve só as que couberam.
 * `ratios` = altura / largura de cada imagem.
 */
export function masonryLayout(
  ratios: number[],
  opts: { world: { w: number; h: number }; startY: number; maxW?: number; gap?: number; margin?: number }
): Slot[] {
  const gap = opts.gap ?? 0.04;
  const margin = opts.margin ?? 0.1;
  const maxW = opts.maxW ?? 0.6;
  const innerW = opts.world.w - 2 * margin;
  const limitY = opts.world.h - margin;
  const minCols = Math.max(1, Math.ceil((innerW + gap) / (maxW + gap)));
  const MAX_COLS = 16;

  const run = (cols: number): { slots: Slot[]; all: boolean } => {
    const w = (innerW - gap * (cols - 1)) / cols;
    const used = Math.min(cols, ratios.length);
    const bottoms = new Array(used).fill(opts.startY);
    const slots: Slot[] = [];
    const totalW = used * w + (used - 1) * gap;
    const x0 = (opts.world.w - totalW) / 2;
    for (const r of ratios) {
      const h = Math.min(w * 2.5, Math.max(w * 0.4, w * r));
      let c = 0;
      for (let i = 1; i < used; i++) if (bottoms[i] < bottoms[c]) c = i;
      if (bottoms[c] + h > limitY) return { slots, all: false };
      slots.push({ x: x0 + c * (w + gap), y: bottoms[c], w, h });
      bottoms[c] += h + gap;
    }
    return { slots, all: true };
  };

  let best: Slot[] = [];
  for (let cols = minCols; cols <= MAX_COLS; cols++) {
    const r = run(cols);
    if (r.all) return r.slots;
    if (r.slots.length >= best.length) best = r.slots;
  }
  return best;
}
