import React, { useEffect, useState } from 'react';
import { Pressable, StyleSheet, Text, TextInput, View, useWindowDimensions } from 'react-native';
import { Button } from './Button';
import { StateMessage } from './StateMessage';
import { listModels, testConnection } from './gemini';
import { DEFAULT_MODEL, loadGeminiSettings, saveGeminiSettings } from './settings';
import { colors, fonts, HIT, LEADING, MIN_TOUCH, SPACE, TYPE } from './theme';

type Busy = 'test' | 'models' | null;
type Status = { ok: boolean; text: string };

/** Chave e modelo do Gemini, com os botões de salvar/testar e o resultado logo abaixo deles. */
export function GeminiSection() {
  const { width: sw } = useWindowDimensions();
  const [apiKey, setApiKey] = useState('');
  const [model, setModel] = useState(DEFAULT_MODEL);
  const [showKey, setShowKey] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [busy, setBusy] = useState<Busy>(null);
  const [status, setStatus] = useState<Status | null>(null);
  const [models, setModels] = useState<string[]>([]);

  useEffect(() => {
    loadGeminiSettings()
      .then((s) => {
        setApiKey(s.apiKey);
        setModel(s.model);
      })
      .finally(() => setLoaded(true));
  }, []);

  const save = async () => {
    await saveGeminiSettings({ apiKey, model });
    setStatus({ ok: true, text: 'Salvo no celular.' });
  };

  const test = async () => {
    setBusy('test');
    setStatus(null);
    const r = await testConnection(apiKey, model);
    setStatus({ ok: r.ok, text: r.message });
    if (r.ok) await saveGeminiSettings({ apiKey, model });
    setBusy(null);
  };

  const fetchModels = async () => {
    setBusy('models');
    setStatus(null);
    const r = await listModels(apiKey);
    if (r.ok) {
      setModels(r.models);
      if (r.models.length === 0) setStatus({ ok: false, text: 'Nenhum modelo disponível para esta chave.' });
    } else {
      setStatus({ ok: false, text: r.message });
    }
    setBusy(null);
  };

  const label = sw * TYPE.label;
  const input = sw * TYPE.subtitle;
  const inputSpacing = { paddingVertical: sw * SPACE.sm, marginTop: sw * SPACE.sm };
  const off = busy !== null;

  return (
    <View>
      <Text style={[styles.label, { fontSize: label }]}>Chave da API do Gemini</Text>
      <View style={[styles.row, { gap: sw * SPACE.md }]}>
        <TextInput
          value={apiKey}
          onChangeText={setApiKey}
          editable={loaded}
          secureTextEntry={!showKey}
          autoCapitalize="none"
          autoCorrect={false}
          autoComplete="off"
          spellCheck={false}
          accessibilityLabel="Chave da API do Gemini"
          placeholder="Cole a chave aqui"
          placeholderTextColor={colors.muted}
          style={[styles.input, inputSpacing, { fontSize: input, flex: 1 }]}
        />
        <Pressable
          onPress={() => setShowKey((v) => !v)}
          hitSlop={HIT.md}
          accessibilityRole="button"
          accessibilityLabel={showKey ? 'Ocultar chave' : 'Mostrar chave'}
        >
          <Text style={{ color: colors.muted, fontFamily: fonts.regular, fontSize: label }}>{showKey ? 'Ocultar' : 'Mostrar'}</Text>
        </Pressable>
      </View>

      <Text style={[styles.label, { fontSize: label, marginTop: sw * SPACE.xl }]}>Modelo</Text>
      <TextInput
        value={model}
        onChangeText={setModel}
        accessibilityLabel="Modelo"
        editable={loaded}
        autoCapitalize="none"
        autoCorrect={false}
        autoComplete="off"
        spellCheck={false}
        style={[styles.input, inputSpacing, { fontSize: input }]}
      />

      {models.length > 0 && (
        <View style={{ marginTop: sw * SPACE.md }}>
          {models.map((m) => (
            <Pressable
              key={m}
              accessibilityRole="button"
              accessibilityState={{ selected: m === model }}
              onPress={() => {
                setModel(m);
                setModels([]);
              }}
              style={{ paddingVertical: sw * SPACE.sm, minHeight: MIN_TOUCH, justifyContent: 'center' }}
            >
              <Text style={{ color: m === model ? colors.red : colors.text, fontFamily: fonts.regular, fontSize: sw * TYPE.body }}>{m}</Text>
            </Pressable>
          ))}
        </View>
      )}

      <View style={{ marginTop: sw * SPACE.xl, gap: sw * SPACE.sm }}>
        <Button label="Salvar" onPress={save} disabled={off} />
        <Button label="Testar conexão" variant="secondary" onPress={test} loading={busy === 'test'} disabled={off && busy !== 'test'} />
        <Button label="Ver modelos" variant="secondary" onPress={fetchModels} loading={busy === 'models'} disabled={off && busy !== 'models'} />
      </View>

      {status && (
        <StateMessage kind={status.ok ? 'info' : 'error'} style={{ marginTop: sw * SPACE.lg }}>
          {status.text}
        </StateMessage>
      )}

      <Text
        style={{
          marginTop: sw * SPACE.lg,
          color: colors.muted,
          fontFamily: fonts.regular,
          fontSize: sw * TYPE.caption,
          lineHeight: sw * TYPE.caption * LEADING,
        }}
      >
        A chave fica guardada só neste celular. Gere uma em aistudio.google.com/apikey.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  label: { color: colors.muted, fontFamily: fonts.regular },
  row: { flexDirection: 'row', alignItems: 'center' },
  input: {
    color: colors.text,
    fontFamily: fonts.regular,
    borderBottomWidth: 2,
    borderBottomColor: colors.text,
  },
});
