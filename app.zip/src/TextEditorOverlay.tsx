import React, { useCallback, useEffect, useRef, useState } from 'react';
import { BackHandler, Keyboard, Pressable, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { WebView, WebViewMessageEvent } from 'react-native-webview';
import { MOOD_EDITOR_HTML } from './moodEditorHtml';
import { fonts } from './theme';

type Props = {
  initialHtml: string;
  title: string;
  /** Recebe o HTML final (vazio se o texto ficou em branco). */
  onDone: (html: string) => void;
  onCancel: () => void;
};

const lit = (v: unknown): string =>
  JSON.stringify(v).replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');

/** Tela cheia com o editor de texto do moodboard (WebView) e os botões Cancelar / Pronto. */
export function TextEditorOverlay({ initialHtml, title, onDone, onCancel }: Props) {
  const { width: sw } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const web = useRef<WebView>(null);
  const htmlRef = useRef(initialHtml);
  const [kbPad, setKbPad] = useState(0);
  const curH = useRef(0);
  const fullH = useRef(0);

  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      onCancel();
      return true;
    });
    return () => sub.remove();
  }, [onCancel]);

  // Teclado: se a janela não encolheu sozinha, deixa uma folga para a barra de ferramentas ficar visível.
  useEffect(() => {
    const show = Keyboard.addListener('keyboardDidShow', (e) => {
      const h = e.endCoordinates?.height ?? 0;
      setTimeout(() => setKbPad(curH.current >= fullH.current - 20 ? h : 0), 150);
    });
    const hide = Keyboard.addListener('keyboardDidHide', () => setKbPad(0));
    return () => {
      show.remove();
      hide.remove();
    };
  }, []);

  const onMessage = useCallback(
    (e: WebViewMessageEvent) => {
      let m: any;
      try {
        m = JSON.parse(e.nativeEvent.data);
      } catch {
        return;
      }
      if (m.type === 'ready') {
        web.current?.injectJavaScript(`window.initText(${lit({ html: initialHtml })});true;`);
      } else if (m.type === 'change' && typeof m.html === 'string') {
        htmlRef.current = m.html;
      }
    },
    [initialHtml]
  );

  const done = () => {
    web.current?.injectJavaScript('window.flushNow();true;');
    setTimeout(() => onDone(htmlRef.current), 150);
  };

  const head = sw * 0.048;
  return (
    <View
      style={styles.root}
      onLayout={(e) => {
        curH.current = e.nativeEvent.layout.height;
        if (kbPad === 0) fullH.current = Math.max(fullH.current, curH.current);
      }}
    >
      <View style={[styles.header, { paddingTop: insets.top + sw * 0.03, paddingHorizontal: sw * 0.05 }]}>
        <Pressable onPress={onCancel} hitSlop={14}>
          <Text style={{ color: '#808080', fontFamily: fonts.regular, fontSize: head }}>Cancelar</Text>
        </Pressable>
        <Text style={{ color: '#000', fontFamily: fonts.bold, fontSize: head }}>{title}</Text>
        <Pressable onPress={done} hitSlop={14}>
          <Text style={{ color: '#FF3030', fontFamily: fonts.bold, fontSize: head }}>Pronto</Text>
        </Pressable>
      </View>
      <View style={styles.card}>
        <WebView
          ref={web}
          originWhitelist={['*']}
          source={{ html: MOOD_EDITOR_HTML, baseUrl: 'file:///' }}
          onMessage={onMessage}
          javaScriptEnabled
          setSupportMultipleWindows={false}
          textZoom={100}
          overScrollMode="never"
          hideKeyboardAccessoryView
          keyboardDisplayRequiresUserAction={false}
          automaticallyAdjustContentInsets={false}
          onShouldStartLoadWithRequest={(r) => r.url.startsWith('file:') || r.url.startsWith('about:')}
          style={{ backgroundColor: '#FFFFFF' }}
          containerStyle={{ backgroundColor: '#FFFFFF' }}
        />
      </View>
      <View style={{ height: kbPad > 0 ? kbPad : insets.bottom }} />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { ...StyleSheet.absoluteFillObject, backgroundColor: '#FFFFFF', zIndex: 50 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingBottom: 8 },
  card: { flex: 1, backgroundColor: '#FFFFFF', overflow: 'hidden' },
});
