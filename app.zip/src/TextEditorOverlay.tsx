import React, { useCallback, useEffect, useRef, useState } from 'react';
import { BackHandler, Keyboard, Pressable, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { WebView, WebViewMessageEvent } from 'react-native-webview';
import { MOOD_EDITOR_HTML } from './moodEditorHtml';
import { colors, fonts, SPACE, HIT } from './theme';
import { FontsScreen } from './FontsScreen';
import { setFontsScript, useFontsVersion } from './fonts';

type Props = {
  initialHtml: string;
  /** Cores dos cartões de paleta do quadro, oferecidas no painel de cor do texto. */
  palette?: string[];
  title: string;
  /** Onde o cartão está na tela (px). Com isso o texto é editado no próprio cartão, sobre o quadro, sem tela cheia. */
  anchor?: { x: number; y: number; w: number };
  /** Se existir, a barra mostra o botão "Box do texto": salva o texto e chama isto. */
  onBox?: () => void;
  /** Recebe o HTML final (vazio se o texto ficou em branco). */
  onDone: (html: string) => void;
  onCancel: () => void;
};

const lit = (v: unknown): string =>
  JSON.stringify(v).replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');

/** Tela cheia com o editor de texto do moodboard (WebView) e os botões Cancelar / Pronto. */
export function TextEditorOverlay({ initialHtml, palette, title, anchor, onBox, onDone, onCancel }: Props) {
  const { width: sw } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const web = useRef<WebView>(null);
  const htmlRef = useRef(initialHtml);
  const boxNext = useRef(false);
  const [kbPad, setKbPad] = useState(0);
  const readyRef = useRef(false);
  const [fontsOpen, setFontsOpen] = useState(false);
  const fontsVer = useFontsVersion();
  const curH = useRef(0);
  const fullH = useRef(0);

  // Nos primeiros instantes, cancelar/voltar/pronto são ignorados: um toque ou evento de teclado
  // que sobra da abertura não pode fechar o editor na mesma hora.
  const openedAt = useRef(Date.now());
  const guarded = () => Date.now() - openedAt.current < 700;
  const cancelRef = useRef(onCancel);
  cancelRef.current = onCancel;

  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (!guarded()) cancelRef.current();
      return true;
    });
    return () => sub.remove();
  }, []);

  // Teclado: se a janela não encolheu sozinha, deixa uma folga para a barra de ferramentas ficar visível.
  useEffect(() => {
    const show = Keyboard.addListener('keyboardDidShow', (e) => {
      const h = e.endCoordinates?.height ?? 0;
      setTimeout(() => setKbPad(curH.current >= fullH.current - 20 ? h : 0), 150);
    });
    const hide = Keyboard.addListener('keyboardDidHide', () => setKbPad(0));
    return () => {
      show.remove();
      hide.remove();
    };
  }, []);

  // Minhas fontes: o editor recebe a lista (e o @font-face) ao ficar pronto e a cada mudança.
  useEffect(() => {
    if (readyRef.current) web.current?.injectJavaScript(setFontsScript());
  }, [fontsVer]);

  const onMessage = useCallback(
    (e: WebViewMessageEvent) => {
      let m: any;
      try {
        m = JSON.parse(e.nativeEvent.data);
      } catch {
        return;
      }
      if (m.type === 'ready') {
        readyRef.current = true;
        web.current?.injectJavaScript(setFontsScript());
        web.current?.injectJavaScript(`window.initText(${lit({ html: initialHtml, palette: palette ?? [], anchor, canBox: !!onBox })});true;`);
      } else if (m.type === 'openBox') {
        boxNext.current = true;
        done();
      } else if (m.type === 'outside') {
        done();
      } else if (m.type === 'openFonts') {
        setFontsOpen(true);
      } else if (m.type === 'change' && typeof m.html === 'string') {
        htmlRef.current = m.html;
      }
    },
    [initialHtml, palette, anchor]
  );

  const done = () => {
    if (guarded()) return;
    web.current?.injectJavaScript('window.flushNow();true;');
    setTimeout(() => {
      onDone(htmlRef.current);
      if (boxNext.current) {
        boxNext.current = false;
        setTimeout(() => onBox?.(), 80);
      }
    }, 150);
  };

  const head = sw * 0.048;
  return (
    <View
      style={[styles.root, anchor && styles.scrim]}
      onLayout={(e) => {
        curH.current = e.nativeEvent.layout.height;
        if (kbPad === 0) fullH.current = Math.max(fullH.current, curH.current);
      }}
    >
      {!anchor && <View style={[styles.header, { paddingTop: insets.top + sw * 0.03, paddingHorizontal: sw * SPACE.lg }]}>
        <Pressable onPress={() => !guarded() && onCancel()} hitSlop={HIT.md} accessibilityRole="button">
          <Text style={{ color: colors.subtle, fontFamily: fonts.regular, fontSize: head }}>Cancelar</Text>
        </Pressable>
        <Text style={{ color: colors.onLight, fontFamily: fonts.bold, fontSize: head }}>{title}</Text>
        <Pressable onPress={done} hitSlop={HIT.md} accessibilityRole="button">
          <Text style={{ color: colors.red, fontFamily: fonts.bold, fontSize: head }}>Pronto</Text>
        </Pressable>
      </View>}
      <View style={[styles.card, anchor && { backgroundColor: 'transparent' }]}>
        <WebView
          ref={web}
          originWhitelist={['*']}
          source={{ html: MOOD_EDITOR_HTML, baseUrl: 'file:///' }}
          onMessage={onMessage}
          javaScriptEnabled
          allowFileAccess
          allowFileAccessFromFileURLs
          allowUniversalAccessFromFileURLs
          mixedContentMode="always"
          setSupportMultipleWindows={false}
          textZoom={100}
          overScrollMode="never"
          hideKeyboardAccessoryView
          keyboardDisplayRequiresUserAction={false}
          automaticallyAdjustContentInsets={false}
          onShouldStartLoadWithRequest={(r) => r.url.startsWith('file:') || r.url.startsWith('about:')}
          style={{ backgroundColor: anchor ? 'transparent' : colors.paper }}
          containerStyle={{ backgroundColor: anchor ? 'transparent' : colors.paper }}
        />
      </View>
      <View style={{ height: kbPad > 0 ? kbPad : insets.bottom }} />
      {fontsOpen && <FontsScreen onClose={() => setFontsOpen(false)} />}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { ...StyleSheet.absoluteFillObject, backgroundColor: colors.paper, zIndex: 50 },
  scrim: { backgroundColor: 'rgba(0,0,0,0.35)' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingBottom: 8 },
  card: { flex: 1, backgroundColor: colors.paper, overflow: 'hidden' },
});
