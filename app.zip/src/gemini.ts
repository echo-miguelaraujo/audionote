import { Note, OrganizerResult, sentenceText } from './note';

const BASE = 'https://generativelanguage.googleapis.com/v1beta';

export type GemErrorKind = 'network' | 'quota' | 'auth' | 'model' | 'server' | 'bad' | 'parse';
export type GemError = { kind: GemErrorKind; message: string; retryAfterMs?: number };
export type GemResult<T> = { ok: true; data: T } | { ok: false; error: GemError };
export type TestResult = { ok: boolean; message: string };

async function request(
  apiKey: string,
  path: string,
  body?: unknown,
  timeoutMs = 30000
): Promise<{ status: number; json: any }> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(`${BASE}${path}`, {
      method: body === undefined ? 'GET' : 'POST',
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': apiKey },
      body: body === undefined ? undefined : JSON.stringify(body),
      signal: ctrl.signal,
    });
    let json: any = null;
    try {
      json = await res.json();
    } catch {
      json = null;
    }
    return { status: res.status, json };
  } finally {
    clearTimeout(timer);
  }
}

function retryDelayMs(json: any): number | undefined {
  const details = json?.error?.details;
  if (!Array.isArray(details)) return undefined;
  for (const d of details) {
    const v = d?.retryDelay;
    if (typeof v === 'string') {
      const n = parseFloat(v);
      if (!isNaN(n)) return Math.round(n * 1000);
    }
  }
  return undefined;
}

export function classify(status: number, json: any): GemError {
  const msg: string = json?.error?.message ?? '';
  if (status === 400 && /api key/i.test(msg))
    return { kind: 'auth', message: 'Chave inválida. Confira em Configurações.' };
  if (status === 400) return { kind: 'bad', message: `Pedido recusado pelo Google: ${msg || 'erro 400'}` };
  if (status === 401 || status === 403)
    return { kind: 'auth', message: 'A chave não tem permissão para este modelo (ou foi desativada).' };
  if (status === 404)
    return { kind: 'model', message: 'Modelo não encontrado. Escolha outro em Configurações > Ver modelos.' };
  if (status === 429) {
    const daily = /per ?day|daily/i.test(msg) || /PerDay/.test(JSON.stringify(json?.error?.details ?? ''));
    const wait = retryDelayMs(json) ?? (daily ? 60 * 60 * 1000 : 10 * 60 * 1000);
    return {
      kind: 'quota',
      message: 'Limite de uso (cota) do Gemini atingido. Vou tentar de novo mais tarde.',
      retryAfterMs: Math.max(30000, wait),
    };
  }
  if (status >= 500)
    return { kind: 'server', message: 'Servidor do Google indisponível. Vou tentar de novo.', retryAfterMs: 2 * 60 * 1000 };
  return { kind: 'bad', message: `Erro ${status}${msg ? `: ${msg}` : ''}` };
}

function networkError(e: unknown): GemError {
  const name = (e as { name?: string } | null)?.name;
  return {
    kind: 'network',
    message: name === 'AbortError' ? 'O Google não respondeu a tempo.' : 'Sem conexão com a internet.',
    retryAfterMs: 60 * 1000,
  };
}

function modelPath(model: string): string {
  return `/models/${encodeURIComponent(model.trim())}:generateContent`;
}

async function generateJson<T>(
  apiKey: string,
  model: string,
  parts: unknown[],
  schema: unknown,
  timeoutMs: number
): Promise<GemResult<T>> {
  let status: number;
  let json: any;
  try {
    ({ status, json } = await request(
      apiKey.trim(),
      modelPath(model),
      {
        contents: [{ role: 'user', parts }],
        generationConfig: { responseMimeType: 'application/json', responseSchema: schema, temperature: 0.2 },
      },
      timeoutMs
    ));
  } catch (e) {
    return { ok: false, error: networkError(e) };
  }
  if (status !== 200) return { ok: false, error: classify(status, json) };
  const text: string = (json?.candidates?.[0]?.content?.parts ?? []).map((p: any) => p?.text ?? '').join('');
  if (!text.trim()) {
    const why = json?.promptFeedback?.blockReason || json?.candidates?.[0]?.finishReason || 'resposta vazia';
    return { ok: false, error: { kind: 'parse', message: `O Gemini não devolveu texto (${why}).`, retryAfterMs: 5 * 60 * 1000 } };
  }
  try {
    const clean = text.replace(/^\s*```(?:json)?/i, '').replace(/```\s*$/, '').trim();
    return { ok: true, data: JSON.parse(clean) as T };
  } catch {
    return { ok: false, error: { kind: 'parse', message: 'Resposta do Gemini em formato inesperado.', retryAfterMs: 5 * 60 * 1000 } };
  }
}

/** Áudio -> texto. Tenta tipos MIME alternativos se o Google recusar o formato. */
export async function transcribeAudio(
  apiKey: string,
  model: string,
  base64: string,
  mimes: string[] = ['audio/mp4', 'audio/aac']
): Promise<GemResult<string>> {
  const schema = {
    type: 'OBJECT',
    properties: { transcript: { type: 'STRING' } },
    required: ['transcript'],
  };
  const prompt =
    'Transcreva fielmente o áudio a seguir, no idioma em que foi falado (normalmente português do Brasil). ' +
    'Não resuma, não comente e não invente nada. Se não houver fala, devolva transcript vazio.';
  let last: GemResult<string> | null = null;
  for (const mime of mimes) {
    const r = await generateJson<{ transcript?: string }>(
      apiKey,
      model,
      [{ text: prompt }, { inline_data: { mime_type: mime, data: base64 } }],
      schema,
      180000
    );
    if (r.ok) return { ok: true, data: String(r.data?.transcript ?? '').trim() };
    last = r;
    const mimeProblem = r.error.kind === 'bad' && /mime|unsupported|format|audio/i.test(r.error.message);
    if (!mimeProblem) return r;
  }
  return last as GemResult<string>;
}

/** Texto -> posições na nota (tópico existente ou novo). A nota nunca é reescrita pela IA. */
export async function organizeIdeas(
  apiKey: string,
  model: string,
  note: Note,
  transcript: string
): Promise<GemResult<OrganizerResult>> {
  const schema = {
    type: 'OBJECT',
    properties: {
      note_title: { type: 'STRING' },
      placements: {
        type: 'ARRAY',
        items: {
          type: 'OBJECT',
          properties: {
            topic_id: { type: 'STRING', nullable: true },
            new_topic_title: { type: 'STRING', nullable: true },
            sentences: { type: 'ARRAY', items: { type: 'STRING' } },
          },
          required: ['sentences'],
        },
      },
    },
    required: ['note_title', 'placements'],
  };
  const current = note.topics.map((t) => ({
    id: t.id,
    title: t.title,
    sentences: t.sentences.slice(-30).map((s) => sentenceText(s).slice(0, 200)),
  }));
  const prompt =
    'Você organiza ideias faladas em notas. Recebe (1) a nota atual dividida em tópicos e (2) a transcrição de um novo áudio.\n' +
    'Divida a transcrição em frases curtas e completas, corrigindo pontuação e erros óbvios da fala, sem inventar nada e sem resumir demais. ' +
    'Agrupe ideias relacionadas. Para cada grupo, encaixe no tópico existente mais adequado (topic_id) ou, se nenhum servir, ' +
    'crie um novo (topic_id null e new_topic_title curto, de 2 a 5 palavras). Mantenha o idioma original.\n' +
    'Se a nota atual NÃO tem título, sugira note_title curto; caso contrário devolva note_title vazio.\n\n' +
    `NOTA ATUAL (título: "${note.title}"):\n${JSON.stringify(current)}\n\nTRANSCRIÇÃO:\n${transcript}`;
  return generateJson<OrganizerResult>(apiKey, model, [{ text: prompt }], schema, 90000);
}

export async function testConnection(apiKey: string, model: string): Promise<TestResult> {
  if (!apiKey.trim()) return { ok: false, message: 'Cole a chave da API primeiro.' };
  try {
    const { status, json } = await request(
      apiKey.trim(),
      modelPath(model),
      {
        contents: [{ parts: [{ text: 'Responda somente com a palavra: ok' }] }],
        generationConfig: { maxOutputTokens: 32 },
      },
      20000
    );
    if (status === 200) return { ok: true, message: `Conexão funcionando com "${model.trim()}".` };
    return { ok: false, message: classify(status, json).message };
  } catch (e) {
    return { ok: false, message: networkError(e).message };
  }
}

/** Lista os modelos Gemini que aceitam generateContent (os nomes mudam com o tempo). */
export async function listModels(
  apiKey: string
): Promise<{ ok: boolean; message: string; models: string[] }> {
  if (!apiKey.trim()) return { ok: false, message: 'Cole a chave da API primeiro.', models: [] };
  try {
    const { status, json } = await request(apiKey.trim(), '/models?pageSize=200', undefined, 20000);
    if (status !== 200) return { ok: false, message: classify(status, json).message, models: [] };
    const models: string[] = (json?.models ?? [])
      .filter(
        (m: any) =>
          typeof m?.name === 'string' &&
          m.name.startsWith('models/gemini') &&
          Array.isArray(m.supportedGenerationMethods) &&
          m.supportedGenerationMethods.includes('generateContent')
      )
      .map((m: any) => String(m.name).replace('models/', ''))
      .sort();
    return { ok: true, message: '', models };
  } catch (e) {
    return { ok: false, message: networkError(e).message, models: [] };
  }
}
