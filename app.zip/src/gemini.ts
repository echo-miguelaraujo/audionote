import { DetectedEvent } from './db';

const BASE = 'https://generativelanguage.googleapis.com/v1beta';

export type GemErrorKind = 'network' | 'quota' | 'auth' | 'model' | 'server' | 'bad' | 'parse';
export type GemError = { kind: GemErrorKind; message: string; retryAfterMs?: number };
export type GemResult<T> = { ok: true; data: T } | { ok: false; error: GemError };
export type TestResult = { ok: boolean; message: string };

async function request(
  apiKey: string,
  path: string,
  body?: unknown,
  timeoutMs = 30000
): Promise<{ status: number; json: any }> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(`${BASE}${path}`, {
      method: body === undefined ? 'GET' : 'POST',
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': apiKey },
      body: body === undefined ? undefined : JSON.stringify(body),
      signal: ctrl.signal,
    });
    let json: any = null;
    try {
      json = await res.json();
    } catch {
      json = null;
    }
    return { status: res.status, json };
  } finally {
    clearTimeout(timer);
  }
}

function retryDelayMs(json: any): number | undefined {
  const details = json?.error?.details;
  if (!Array.isArray(details)) return undefined;
  for (const d of details) {
    const v = d?.retryDelay;
    if (typeof v === 'string') {
      const n = parseFloat(v);
      if (!isNaN(n)) return Math.round(n * 1000);
    }
  }
  return undefined;
}

export function classify(status: number, json: any): GemError {
  const msg: string = json?.error?.message ?? '';
  if (status === 400 && /api key/i.test(msg))
    return { kind: 'auth', message: 'Chave inválida. Confira em Configurações.' };
  if (status === 400) return { kind: 'bad', message: `Pedido recusado pelo Google: ${msg || 'erro 400'}` };
  if (status === 401 || status === 403)
    return { kind: 'auth', message: 'A chave não tem permissão para este modelo (ou foi desativada).' };
  if (status === 404)
    return { kind: 'model', message: 'Modelo não encontrado. Escolha outro em Configurações > Ver modelos.' };
  if (status === 429) {
    const daily = /per ?day|daily/i.test(msg) || /PerDay/.test(JSON.stringify(json?.error?.details ?? ''));
    const wait = retryDelayMs(json) ?? (daily ? 60 * 60 * 1000 : 10 * 60 * 1000);
    return {
      kind: 'quota',
      message: 'Limite de uso (cota) do Gemini atingido. Vou tentar de novo mais tarde.',
      retryAfterMs: Math.max(30000, wait),
    };
  }
  if (status >= 500)
    return { kind: 'server', message: 'Servidor do Google indisponível. Vou tentar de novo.', retryAfterMs: 2 * 60 * 1000 };
  return { kind: 'bad', message: `Erro ${status}${msg ? `: ${msg}` : ''}` };
}

function networkError(e: unknown): GemError {
  const name = (e as { name?: string } | null)?.name;
  return {
    kind: 'network',
    message: name === 'AbortError' ? 'O Google não respondeu a tempo.' : 'Sem conexão com a internet.',
    retryAfterMs: 60 * 1000,
  };
}

function modelPath(model: string): string {
  return `/models/${encodeURIComponent(model.trim())}:generateContent`;
}

async function generateJson<T>(
  apiKey: string,
  model: string,
  parts: unknown[],
  schema: unknown,
  timeoutMs: number
): Promise<GemResult<T>> {
  let status: number;
  let json: any;
  try {
    ({ status, json } = await request(
      apiKey.trim(),
      modelPath(model),
      {
        contents: [{ role: 'user', parts }],
        generationConfig: { responseMimeType: 'application/json', responseSchema: schema, temperature: 0.1 },
      },
      timeoutMs
    ));
  } catch (e) {
    return { ok: false, error: networkError(e) };
  }
  if (status !== 200) return { ok: false, error: classify(status, json) };
  const text: string = (json?.candidates?.[0]?.content?.parts ?? []).map((p: any) => p?.text ?? '').join('');
  if (!text.trim()) {
    const why = json?.promptFeedback?.blockReason || json?.candidates?.[0]?.finishReason || 'resposta vazia';
    return { ok: false, error: { kind: 'parse', message: `O Gemini não devolveu texto (${why}).`, retryAfterMs: 5 * 60 * 1000 } };
  }
  try {
    const clean = text.replace(/^\s*```(?:json)?/i, '').replace(/```\s*$/, '').trim();
    return { ok: true, data: JSON.parse(clean) as T };
  } catch {
    return { ok: false, error: { kind: 'parse', message: 'Resposta do Gemini em formato inesperado.', retryAfterMs: 5 * 60 * 1000 } };
  }
}

export type Section = { heading: string; text: string };
export type Transcription = { text: string; sections: Section[]; events: DetectedEvent[]; title?: string };

const pad = (n: number) => String(n).padStart(2, '0');
const WEEKDAYS = ['domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado'];

/** "sexta-feira, 2026-10-16, 14:05" — referência para o Gemini entender "amanhã", "dia 20", "segunda"… */
function referenceNow(ms: number): string {
  const d = new Date(ms);
  return `${WEEKDAYS[d.getDay()]}, ${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}, ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

const TRANSCRIBE_PROMPT = (recordedAt: number, headings: string[]) =>
  'Você transcreve áudios em português do Brasil para um app de notas pessoais.\n\n' +
  'REGRAS DO TEXTO (campo "sections"):\n' +
  '1. Seja FIEL ao que foi falado. Mantenha as palavras, a ordem, o vocabulário, as gírias, os regionalismos e o jeito de falar da pessoa.\n' +
  '2. Remova SOMENTE vícios de linguagem e termos desnecessários: hesitações (ééé, hmm, ahn, hã), muletas vazias (tipo, né, então, assim, sabe, entendeu, "tá?", "cara" quando só preenche), palavras repetidas por gagueira ou recomeço de frase ("eu eu quero" → "eu quero") e falsos começos abandonados.\n' +
  '3. NÃO resuma, NÃO reescreva, NÃO troque palavras por sinônimos, NÃO "melhore" o estilo, NÃO corrija a gramática da fala e NÃO acrescente nada que não foi dito. ' +
  'Nunca crie texto novo a partir do contexto ou da sua interpretação.\n' +
  '4. Pontue de forma natural. Separe o áudio em SEÇÕES, uma para cada assunto tratado (se for um assunto só, uma seção). Em cada seção, "text" é a fala fiel desse assunto (parágrafos separados por linha em branco) e "heading" é um subtítulo curto (2 a 5 palavras, sem ponto final) que nomeia o assunto. ' +
  'O subtítulo é o ÚNICO texto que você pode criar; o corpo continua 100% fiel à fala.\n' +
  '5. LISTAS: quando a pessoa enumerar itens ou ditar uma lista, escreva cada item em uma linha própria com um marcador no começo, em vez de um parágrafo corrido. Tipos:\n' +
  '   - Tarefas, coisas a fazer, afazeres, "preciso", "não esquecer de", "lembrar de", lista de compras ou de pendências: comece cada linha com "[ ] ".\n' +
  '   - Itens soltos sem ordem (ingredientes, materiais, ideias, opções, "lista de..."): comece cada linha com "- ".\n' +
  '   - Passos em sequência ou ranking ("primeiro..., segundo...", "passo um", modo de preparo, etapas): comece cada linha com "1. ", "2. ", "3. "...\n' +
  '   Cada item continua com as palavras da própria pessoa (sem os marcadores falados como "primeiro" ou "item dois"). Só monte lista quando a pessoa realmente listou; fala corrida comum continua em parágrafos. Uma linha de introdução (ex.: "Ingredientes:") fica como parágrafo antes da lista.\n' +
  (headings.length ? `6. A nota já tem estes subtítulos: ${JSON.stringify(headings)}. Se um assunto do áudio for o mesmo de algum deles, use EXATAMENTE aquele subtítulo; senão crie um novo.\n` : '6. A nota ainda não tem subtítulos.\n') +
  '7. Se não houver fala, devolva sections vazio.\n\n' +
  'TÍTULO (campo "title", separado da transcrição e sem alterá-la): sugira um título curto (2 a 6 palavras, sem ponto final) que resuma o assunto principal do áudio, baseado no contexto. Se não houver fala, devolva vazio.\n\n' +
  'COMPROMISSOS (campo "events", separado da transcrição e sem alterá-la):\n' +
  `Contexto: o áudio foi gravado em ${referenceNow(recordedAt)} (fuso do usuário).\n` +
  'Se a pessoa mencionar um compromisso, tarefa, prazo ou lembrete COM uma data (ex.: "amanhã", "dia 20", "segunda que vem", "15 de novembro", "daqui a 3 dias"), ' +
  'adicione um item em events: title = nome curto da tarefa usando as palavras da própria pessoa (sem inventar detalhes); ' +
  'start = data e hora local no formato YYYY-MM-DDTHH:mm; all_day = true se NÃO houver horário dito (use T00:00), false se houver; ' +
  'excerpt = o trecho falado que originou o item. Resolva datas relativas a partir do momento da gravação; ' +
  'dia do mês sem mês = próxima ocorrência futura. Se só houver horário sem nenhuma data, não crie item. ' +
  'Se não houver nenhum compromisso com data, devolva events vazio. Nunca invente datas.';

const TRANSCRIBE_SCHEMA = {
  type: 'OBJECT',
  properties: {
    sections: {
      type: 'ARRAY',
      items: {
        type: 'OBJECT',
        properties: { heading: { type: 'STRING' }, text: { type: 'STRING' } },
        required: ['heading', 'text'],
      },
    },
    title: { type: 'STRING' },
    events: {
      type: 'ARRAY',
      items: {
        type: 'OBJECT',
        properties: {
          title: { type: 'STRING' },
          start: { type: 'STRING' },
          all_day: { type: 'BOOLEAN' },
          excerpt: { type: 'STRING' },
        },
        required: ['title', 'start', 'all_day'],
      },
    },
  },
  required: ['sections', 'title', 'events'],
};

function cleanSections(raw: any): { text: string; sections: Section[] } {
  const sections: Section[] = [];
  for (const x of Array.isArray(raw) ? raw : []) {
    const text = typeof x?.text === 'string' ? x.text.trim() : '';
    if (!text) continue;
    sections.push({ heading: typeof x?.heading === 'string' ? x.heading.trim().replace(/[.\s]+$/, '') : '', text });
  }
  return { sections, text: sections.map((x) => x.text).join('\n\n') };
}

function cleanEvents(raw: any): DetectedEvent[] {
  if (!Array.isArray(raw)) return [];
  const out: DetectedEvent[] = [];
  for (const e of raw) {
    const title = typeof e?.title === 'string' ? e.title.trim() : '';
    const start = typeof e?.start === 'string' ? e.start.trim() : '';
    if (!title || !/^\d{4}-\d{2}-\d{2}(T\d{2}:\d{2})?/.test(start)) continue;
    out.push({
      title,
      start: start.length === 10 ? `${start}T00:00` : start.slice(0, 16),
      allDay: !!e?.all_day,
      excerpt: typeof e?.excerpt === 'string' ? e.excerpt.trim() : undefined,
    });
  }
  return out;
}

/**
 * Áudio -> texto fiel (sem vícios de linguagem) + compromissos com data encontrados na fala.
 * Tenta tipos MIME alternativos se o Google recusar o formato.
 */
export async function transcribeAudio(
  apiKey: string,
  model: string,
  base64: string,
  recordedAt: number,
  headings: string[] = [],
  mimes: string[] = ['audio/mp4', 'audio/aac']
): Promise<GemResult<Transcription>> {
  let last: GemResult<Transcription> | null = null;
  for (const mime of mimes) {
    const r = await generateJson<{ sections?: unknown; title?: string; events?: unknown }>(
      apiKey,
      model,
      [{ text: TRANSCRIBE_PROMPT(recordedAt, headings) }, { inline_data: { mime_type: mime, data: base64 } }],
      TRANSCRIBE_SCHEMA,
      180000
    );
    if (r.ok) {
      return { ok: true, data: {
          ...cleanSections(r.data?.sections),
          title: String(r.data?.title ?? '').trim().replace(/[.\s]+$/, ''),
          events: cleanEvents(r.data?.events),
        },
      };
    }
    last = r;
    const mimeProblem = r.error.kind === 'bad' && /mime|unsupported|format|audio/i.test(r.error.message);
    if (!mimeProblem) return r;
  }
  return last as GemResult<Transcription>;
}

// ---------- Imagem -> texto (caderno, print, foto de anotação) ----------

export type ImageRead = { title: string; sections: Section[] };

const IMAGE_PROMPT = (headings: string[]) =>
  'Você lê imagens (fotos de caderno e de anotações à mão, prints, fotos de papel ou quadro) para um app de notas pessoais, em português do Brasil.\n\n' +
  'REGRAS DO TEXTO (campo "sections"):\n' +
  '1. Transcreva o texto que está na imagem de forma FIEL: mesmas palavras, mesma ordem, mesmo vocabulário. Não resuma, não reescreva, não troque por sinônimos e não acrescente nada que não está escrito.\n' +
  '2. Mantenha a estrutura da página: cada linha ou item vira uma linha separada, e parágrafos corridos ficam como um parágrafo. Títulos e palavras sublinhadas ficam como linhas próprias.\n' +
  '3. LISTAS: identifique o tipo de cada lista e comece cada item com o marcador certo (um item por linha):\n' +
  '   - Lista de tarefas (quadradinhos/checkbox desenhados, "to do", afazeres, lista de compras com caixinha): "[ ] " para pendente e "[x] " para item riscado, marcado ou com check.\n' +
  '   - Lista com marcadores (bolinhas, traços, setas, estrelas; ingredientes; itens soltos sem ordem): "- ".\n' +
  '   - Lista numerada ou em sequência (1, 2, 3 / a, b, c; passos; modo de preparo; ranking): "1. ", "2. ", "3. "... na ordem em que aparecem.\n' +
  '   Não copie o símbolo desenhado, só use o marcador acima. Uma receita costuma ter ingredientes com "- " e modo de preparo numerado com "1. ". Uma linha de introdução (ex.: "Ingredientes:") fica como parágrafo antes da lista. Sem lista na página, não invente lista.\n' +
  '4. Corrija apenas erros de leitura óbvios de letra. Palavra que você não consegue ler com segurança: escreva [ilegível]. Texto riscado pela pessoa: ignore.\n' +
  '5. Se houver várias imagens, siga a ordem em que foram enviadas, como se fossem páginas seguidas.\n' +
  '6. Separe em SEÇÕES, uma por assunto (se for um assunto só, uma seção). "text" é a transcrição fiel dessa parte e "heading" é um subtítulo curto (2 a 5 palavras, sem ponto final). ' +
  'Se a própria página já tem um título para a parte, use-o como subtítulo. O subtítulo é o ÚNICO texto que você pode criar.\n' +
  (headings.length
    ? `7. A nota já tem estes subtítulos: ${JSON.stringify(headings)}. Se um assunto da imagem for o mesmo de algum deles, use EXATAMENTE aquele subtítulo; senão crie um novo.\n`
    : '7. A nota ainda não tem subtítulos.\n') +
  '8. Se a imagem não tiver nenhum texto legível (só foto de objeto, pessoa, paisagem), devolva sections vazio.\n\n' +
  'TÍTULO (campo "title"): título curto (2 a 6 palavras, sem ponto final) para o assunto principal da imagem. Se não houver texto, devolva vazio.';

const IMAGE_SCHEMA = {
  type: 'OBJECT',
  properties: {
    sections: {
      type: 'ARRAY',
      items: {
        type: 'OBJECT',
        properties: { heading: { type: 'STRING' }, text: { type: 'STRING' } },
        required: ['heading', 'text'],
      },
    },
    title: { type: 'STRING' },
  },
  required: ['sections', 'title'],
};

/** Lê o texto de uma ou mais imagens (base64, na ordem das páginas). */
export async function readImages(
  apiKey: string,
  model: string,
  images: { base64: string; mime: string }[],
  headings: string[] = []
): Promise<GemResult<ImageRead>> {
  const parts: unknown[] = [{ text: IMAGE_PROMPT(headings) }];
  for (const im of images) parts.push({ inline_data: { mime_type: im.mime, data: im.base64 } });
  const r = await generateJson<{ sections?: unknown; title?: string }>(apiKey, model, parts, IMAGE_SCHEMA, 120000);
  if (!r.ok) return r;
  return {
    ok: true,
    data: {
      sections: cleanSections(r.data?.sections).sections,
      title: String(r.data?.title ?? '').trim().replace(/[.\s]+$/, ''),
    },
  };
}

export async function testConnection(apiKey: string, model: string): Promise<TestResult> {
  if (!apiKey.trim()) return { ok: false, message: 'Cole a chave da API primeiro.' };
  try {
    const { status, json } = await request(
      apiKey.trim(),
      modelPath(model),
      {
        contents: [{ parts: [{ text: 'Responda somente com a palavra: ok' }] }],
        generationConfig: { maxOutputTokens: 32 },
      },
      20000
    );
    if (status === 200) return { ok: true, message: `Conexão funcionando com "${model.trim()}".` };
    return { ok: false, message: classify(status, json).message };
  } catch (e) {
    return { ok: false, message: networkError(e).message };
  }
}

/** Lista os modelos Gemini que aceitam generateContent (os nomes mudam com o tempo). */
export async function listModels(
  apiKey: string
): Promise<{ ok: boolean; message: string; models: string[] }> {
  if (!apiKey.trim()) return { ok: false, message: 'Cole a chave da API primeiro.', models: [] };
  try {
    const { status, json } = await request(apiKey.trim(), '/models?pageSize=200', undefined, 20000);
    if (status !== 200) return { ok: false, message: classify(status, json).message, models: [] };
    const models: string[] = (json?.models ?? [])
      .filter(
        (m: any) =>
          typeof m?.name === 'string' &&
          m.name.startsWith('models/gemini') &&
          Array.isArray(m.supportedGenerationMethods) &&
          m.supportedGenerationMethods.includes('generateContent')
      )
      .map((m: any) => String(m.name).replace('models/', ''))
      .sort();
    return { ok: true, message: '', models };
  } catch (e) {
    return { ok: false, message: networkError(e).message, models: [] };
  }
}
