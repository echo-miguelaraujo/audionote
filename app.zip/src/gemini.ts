import { DetectedEvent } from './db';
import { UsageKind, recordUsage } from './usage';

const BASE = 'https://generativelanguage.googleapis.com/v1beta';

export type GemErrorKind = 'network' | 'quota' | 'auth' | 'model' | 'server' | 'bad' | 'parse';
export type GemError = { kind: GemErrorKind; message: string; retryAfterMs?: number };
export type GemResult<T> = { ok: true; data: T } | { ok: false; error: GemError };
export type TestResult = { ok: boolean; message: string };

async function request(
  apiKey: string,
  path: string,
  body?: unknown,
  timeoutMs = 30000
): Promise<{ status: number; json: any }> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(`${BASE}${path}`, {
      method: body === undefined ? 'GET' : 'POST',
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': apiKey },
      body: body === undefined ? undefined : JSON.stringify(body),
      signal: ctrl.signal,
    });
    let json: any = null;
    try {
      json = await res.json();
    } catch {
      json = null;
    }
    return { status: res.status, json };
  } finally {
    clearTimeout(timer);
  }
}

function retryDelayMs(json: any): number | undefined {
  const details = json?.error?.details;
  if (!Array.isArray(details)) return undefined;
  for (const d of details) {
    const v = d?.retryDelay;
    if (typeof v === 'string') {
      const n = parseFloat(v);
      if (!isNaN(n)) return Math.round(n * 1000);
    }
  }
  return undefined;
}

export function classify(status: number, json: any): GemError {
  const msg: string = json?.error?.message ?? '';
  if (status === 400 && /api key/i.test(msg))
    return { kind: 'auth', message: 'Chave inválida. Confira em Configurações.' };
  if (status === 400) return { kind: 'bad', message: `Pedido recusado pelo Google: ${msg || 'erro 400'}` };
  if (status === 401 || status === 403)
    return { kind: 'auth', message: 'A chave não tem permissão para este modelo (ou foi desativada).' };
  if (status === 404)
    return { kind: 'model', message: 'Modelo não encontrado. Escolha outro em Configurações > Ver modelos.' };
  if (status === 429) {
    const daily = /per ?day|daily/i.test(msg) || /PerDay/.test(JSON.stringify(json?.error?.details ?? ''));
    const wait = retryDelayMs(json) ?? (daily ? 60 * 60 * 1000 : 10 * 60 * 1000);
    return {
      kind: 'quota',
      message: 'Limite de uso (cota) do Gemini atingido. Vou tentar de novo mais tarde.',
      retryAfterMs: Math.max(30000, wait),
    };
  }
  if (status >= 500)
    return { kind: 'server', message: 'Servidor do Google indisponível. Vou tentar de novo.', retryAfterMs: 2 * 60 * 1000 };
  return { kind: 'bad', message: `Erro ${status}${msg ? `: ${msg}` : ''}` };
}

function networkError(e: unknown): GemError {
  const name = (e as { name?: string } | null)?.name;
  return {
    kind: 'network',
    message: name === 'AbortError' ? 'O Google não respondeu a tempo.' : 'Sem conexão com a internet.',
    retryAfterMs: 60 * 1000,
  };
}

function modelPath(model: string): string {
  return `/models/${encodeURIComponent(model.trim())}:generateContent`;
}

export type GenOpts = {
  kind: UsageKind;
  /** Teto de tokens de saída: evita resposta descontrolada. */
  maxOutputTokens?: number;
  /** Menos tokens por imagem. */
  mediaResolution?: 'MEDIA_RESOLUTION_LOW' | 'MEDIA_RESOLUTION_MEDIUM';
};

/** Raciocínio interno mínimo: transcrição e extração não precisam, e ele é cobrado como saída. */
function thinkingConfig(model: string): Record<string, unknown> | null {
  const name = model.toLowerCase();
  if (/gemini-2\.5-(flash|flash-lite)/.test(name)) return { thinkingBudget: 0 };
  if (/gemini-3/.test(name)) return { thinkingLevel: 'minimal' };
  return null;
}

/** Parâmetros só de economia. Se o modelo recusar algum, a chamada repete sem eles. */
function savingParams(model: string, opts: GenOpts): Record<string, unknown> {
  const params: Record<string, unknown> = {};
  const thinking = thinkingConfig(model);
  if (thinking) params.thinkingConfig = thinking;
  if (opts.maxOutputTokens) params.maxOutputTokens = opts.maxOutputTokens;
  if (opts.mediaResolution) params.mediaResolution = opts.mediaResolution;
  return params;
}

const UNSUPPORTED_PARAM = /thinking|media.?resolution|max.?output|unknown name|invalid json payload|not supported/i;

async function sendWithFallback(
  apiKey: string,
  model: string,
  parts: unknown[],
  baseConfig: Record<string, unknown>,
  saving: Record<string, unknown>,
  timeoutMs: number
): Promise<{ status: number; json: any }> {
  const send = (generationConfig: Record<string, unknown>) =>
    request(apiKey, modelPath(model), { contents: [{ role: 'user', parts }], generationConfig }, timeoutMs);
  const first = await send({ ...baseConfig, ...saving });
  const refused = first.status === 400 && UNSUPPORTED_PARAM.test(first.json?.error?.message ?? '');
  return refused && Object.keys(saving).length > 0 ? send(baseConfig) : first;
}

function answerText(json: any): string {
  const parts: any[] = json?.candidates?.[0]?.content?.parts ?? [];
  return parts.map((p) => (p?.thought ? '' : p?.text ?? '')).join('');
}

const parseFailure = (message: string): GemResult<never> => ({
  ok: false,
  error: { kind: 'parse', message, retryAfterMs: 5 * 60 * 1000 },
});

export async function generateJson<T>(
  apiKey: string,
  model: string,
  parts: unknown[],
  schema: unknown,
  timeoutMs: number,
  opts: GenOpts = { kind: 'other' }
): Promise<GemResult<T>> {
  const baseConfig = { responseMimeType: 'application/json', responseSchema: schema, temperature: 0.1 };
  let reply: { status: number; json: any };
  try {
    reply = await sendWithFallback(apiKey.trim(), model, parts, baseConfig, savingParams(model, opts), timeoutMs);
  } catch (e) {
    return { ok: false, error: networkError(e) };
  }
  if (reply.status !== 200) return { ok: false, error: classify(reply.status, reply.json) };

  recordUsage(opts.kind, reply.json?.usageMetadata);
  const text = answerText(reply.json);
  if (!text.trim()) {
    const why = reply.json?.promptFeedback?.blockReason || reply.json?.candidates?.[0]?.finishReason || 'resposta vazia';
    return parseFailure(`O Gemini não devolveu texto (${why}).`);
  }
  try {
    const unfenced = text.replace(/^\s*```(?:json)?/i, '').replace(/```\s*$/, '').trim();
    return { ok: true, data: JSON.parse(unfenced) as T };
  } catch {
    return parseFailure('Resposta do Gemini em formato inesperado.');
  }
}

export type Section = { heading: string; text: string };
export type Transcription = { text: string; sections: Section[]; events: DetectedEvent[]; title?: string };

const pad = (n: number) => String(n).padStart(2, '0');
const WEEKDAYS = ['domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado'];

/** "sexta-feira, 2026-10-16, 14:05" — referência para o Gemini entender "amanhã", "dia 20", "segunda"… */
function referenceNow(ms: number): string {
  const d = new Date(ms);
  return `${WEEKDAYS[d.getDay()]}, ${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}, ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

// ---------- Regras compartilhadas entre áudio e imagem ----------
// Texto fixo primeiro e o que varia (data, subtítulos) por último: ajuda o cache de prompt do Gemini.

const LIST_MARKERS =
  'Um item por linha, com marcador por tipo: "[ ] " tarefas, afazeres, compras, pendências; ' +
  '"- " itens soltos sem ordem (ingredientes, ideias, opções); "1. ", "2. "... passos, etapas, ranking. ' +
  'Pontos claramente separados (de uma mensagem, motivos, características, lições) também viram itens: numerados se estiverem em ordem, senão "- ". ';

const LIST_GUARD =
  'Só monte lista se a pessoa realmente listou; na dúvida, parágrafo. Linha de introdução ("Ingredientes:") fica como parágrafo antes da lista.\n';

const quoteRule = (source: string) =>
  `CITAÇÕES: ${source} vai em linha própria começando com "> ", só com o texto citado; a frase que o introduz fica como parágrafo antes. ` +
  'Linhas "> " seguidas formam uma citação. Mencionar um texto sem trazer as palavras dele não é citação.\n';

const SECTION_RULES =
  'SEÇÕES: uma por assunto ou subtópico. "text" é o trecho fiel (parágrafos separados por linha em branco); ' +
  '"heading" é um subtítulo curto e ESPECÍFICO (2 a 5 palavras, sem ponto final), nunca genérico como "Introdução". ' +
  'Em textos longos use no mínimo 3 a 4 subtítulos e nunca deixe mais de 3 ou 4 parágrafos seguidos sem um. O subtítulo é o ÚNICO texto que você pode criar.';

const knownHeadingsContext = (headings: string[]) =>
  headings.length
    ? `Subtítulos já na nota: ${JSON.stringify(headings)}. Se um assunto for o mesmo de algum, use EXATAMENTE aquele; senão crie um novo.`
    : 'A nota ainda não tem subtítulos.';

// ---------- Áudio ----------

const TRANSCRIBE_PROMPT = (recordedAt: number, headings: string[]) =>
  'Você transcreve áudios em português do Brasil para um app de notas pessoais.\n\n' +
  'TEXTO (campo "sections"):\n' +
  '1. Seja FIEL: mantenha palavras, ordem, vocabulário, gírias e regionalismos da pessoa.\n' +
  '2. Remova SOMENTE vícios e termos desnecessários: hesitações (ééé, hmm, ahn), muletas vazias (tipo, né, então, assim, sabe, "tá?", "cara" só de enchimento), ' +
  'repetições por gagueira ("eu eu quero" → "eu quero") e falsos começos abandonados.\n' +
  '3. NÃO resuma, reescreva, troque por sinônimos, melhore o estilo, corrija a gramática da fala nem acrescente nada que não foi dito.\n' +
  '4. Pontue de forma natural. ' + SECTION_RULES + '\n' +
  '5. LISTAS: ' + LIST_MARKERS + 'Cada item mantém as palavras da pessoa, sem marcadores falados como "primeiro". ' + LIST_GUARD +
  '6. ' + quoteRule('texto lido em voz alta ou citado literalmente (versículo, trecho de livro, frase de alguém)') +
  '7. Sem fala: sections vazio.\n\n' +
  'TÍTULO (campo "title"): 2 a 6 palavras, sem ponto final, resumindo o assunto principal. Sem fala: vazio.\n\n' +
  'COMPROMISSOS (campo "events", separado da transcrição): se a pessoa mencionar compromisso, tarefa, prazo ou lembrete COM data ' +
  '("amanhã", "dia 20", "segunda que vem", "daqui a 3 dias"), crie um item: title = nome curto com as palavras dela; ' +
  'start = YYYY-MM-DDTHH:mm local; all_day = true se NÃO houver horário dito (use T00:00), senão false; excerpt = trecho falado. ' +
  'Resolva datas relativas pelo momento da gravação; dia do mês sem mês = próxima ocorrência futura. ' +
  'Só horário sem data: não crie. Nunca invente datas. Nenhum: events vazio.\n\n' +
  `CONTEXTO: gravado em ${referenceNow(recordedAt)} (fuso do usuário). ` + knownHeadingsContext(headings);

const TRANSCRIBE_SCHEMA = {
  type: 'OBJECT',
  properties: {
    sections: {
      type: 'ARRAY',
      items: {
        type: 'OBJECT',
        properties: { heading: { type: 'STRING' }, text: { type: 'STRING' } },
        required: ['heading', 'text'],
      },
    },
    title: { type: 'STRING' },
    events: {
      type: 'ARRAY',
      items: {
        type: 'OBJECT',
        properties: {
          title: { type: 'STRING' },
          start: { type: 'STRING' },
          all_day: { type: 'BOOLEAN' },
          excerpt: { type: 'STRING' },
        },
        required: ['title', 'start', 'all_day'],
      },
    },
  },
  required: ['sections', 'title', 'events'],
};

function cleanSections(raw: any): { text: string; sections: Section[] } {
  const sections: Section[] = [];
  for (const x of Array.isArray(raw) ? raw : []) {
    const text = typeof x?.text === 'string' ? x.text.trim() : '';
    if (!text) continue;
    sections.push({ heading: typeof x?.heading === 'string' ? x.heading.trim().replace(/[.\s]+$/, '') : '', text });
  }
  return { sections, text: sections.map((x) => x.text).join('\n\n') };
}

function cleanEvents(raw: any): DetectedEvent[] {
  if (!Array.isArray(raw)) return [];
  const out: DetectedEvent[] = [];
  for (const e of raw) {
    const title = typeof e?.title === 'string' ? e.title.trim() : '';
    const start = typeof e?.start === 'string' ? e.start.trim() : '';
    if (!title || !/^\d{4}-\d{2}-\d{2}(T\d{2}:\d{2})?/.test(start)) continue;
    out.push({
      title,
      start: start.length === 10 ? `${start}T00:00` : start.slice(0, 16),
      allDay: !!e?.all_day,
      excerpt: typeof e?.excerpt === 'string' ? e.excerpt.trim() : undefined,
    });
  }
  return out;
}

const AUDIO_BYTES_PER_SECOND = 8000; // gravação a 64 kbps
const TOKENS_PER_AUDIO_SECOND = 15; // fala rende ~5; folga de 3x para JSON, título e eventos
const IMAGE_OUTPUT_BUDGET = 16000;

function audioOutputBudget(base64: string): number {
  const seconds = (base64.length * 0.75) / AUDIO_BYTES_PER_SECOND;
  return Math.min(60000, Math.max(2048, Math.round(seconds * TOKENS_PER_AUDIO_SECOND) + 1500));
}

/**
 * Áudio -> texto fiel (sem vícios de linguagem) + compromissos com data encontrados na fala.
 * Tenta tipos MIME alternativos se o Google recusar o formato.
 */
export async function transcribeAudio(
  apiKey: string,
  model: string,
  base64: string,
  recordedAt: number,
  headings: string[] = [],
  mimes: string[] = ['audio/mp4', 'audio/aac']
): Promise<GemResult<Transcription>> {
  let last: GemResult<Transcription> | null = null;
  const maxOutputTokens = audioOutputBudget(base64);
  for (const mime of mimes) {
    const r = await generateJson<{ sections?: unknown; title?: string; events?: unknown }>(
      apiKey,
      model,
      [{ text: TRANSCRIBE_PROMPT(recordedAt, headings) }, { inline_data: { mime_type: mime, data: base64 } }],
      TRANSCRIBE_SCHEMA,
      180000,
      { kind: 'audio', maxOutputTokens }
    );
    if (r.ok) {
      return { ok: true, data: {
          ...cleanSections(r.data?.sections),
          title: String(r.data?.title ?? '').trim().replace(/[.\s]+$/, ''),
          events: cleanEvents(r.data?.events),
        },
      };
    }
    last = r;
    const mimeProblem = r.error.kind === 'bad' && /mime|unsupported|format|audio/i.test(r.error.message);
    if (!mimeProblem) return r;
  }
  return last as GemResult<Transcription>;
}

// ---------- Imagem -> texto (caderno, print, foto de anotação) ----------

export type ImageRead = { title: string; sections: Section[] };

// ---------- Imagem ----------

const IMAGE_PROMPT = (headings: string[]) =>
  'Você lê imagens (fotos de caderno e anotações à mão, prints, papel, quadro) para um app de notas pessoais, em português do Brasil.\n\n' +
  'TEXTO (campo "sections"):\n' +
  '1. Transcreva FIELMENTE: mesmas palavras e ordem. Não resuma, reescreva, troque por sinônimos nem acrescente nada.\n' +
  '2. Mantenha a estrutura: cada linha ou item numa linha separada, parágrafo corrido como um parágrafo, títulos e palavras sublinhadas em linhas próprias.\n' +
  '3. LISTAS: ' + LIST_MARKERS + 'Tarefas com caixinha desenhada: "[ ] " pendente, "[x] " riscado ou marcado. ' +
  'Não copie o símbolo desenhado, só o marcador. Receita: ingredientes com "- " e preparo com "1. ". Sem lista na página, não invente. ' + LIST_GUARD +
  '4. ' + quoteRule('texto copiado de outra fonte (versículo, trecho de livro, frase entre aspas, passagem destacada)') +
  '5. Corrija só erros de leitura óbvios. Palavra ilegível: [ilegível]. Texto riscado: ignore.\n' +
  '6. Várias imagens: siga a ordem enviada, como páginas seguidas.\n' +
  '7. ' + SECTION_RULES + ' Se a página já tem título para a parte, use-o como subtítulo.\n' +
  '8. Imagem sem texto legível (objeto, pessoa, paisagem): sections vazio.\n\n' +
  'TÍTULO (campo "title"): 2 a 6 palavras, sem ponto final, para o assunto principal. Sem texto: vazio.\n\n' +
  'CONTEXTO: ' + knownHeadingsContext(headings);

const IMAGE_SCHEMA = {
  type: 'OBJECT',
  properties: {
    sections: {
      type: 'ARRAY',
      items: {
        type: 'OBJECT',
        properties: { heading: { type: 'STRING' }, text: { type: 'STRING' } },
        required: ['heading', 'text'],
      },
    },
    title: { type: 'STRING' },
  },
  required: ['sections', 'title'],
};

/** Lê o texto de uma ou mais imagens (base64, na ordem das páginas). */
export async function readImages(
  apiKey: string,
  model: string,
  images: { base64: string; mime: string }[],
  headings: string[] = []
): Promise<GemResult<ImageRead>> {
  const parts: unknown[] = [{ text: IMAGE_PROMPT(headings) }];
  for (const im of images) parts.push({ inline_data: { mime_type: im.mime, data: im.base64 } });
  const r = await generateJson<{ sections?: unknown; title?: string }>(apiKey, model, parts, IMAGE_SCHEMA, 120000, {
    kind: 'image',
    maxOutputTokens: IMAGE_OUTPUT_BUDGET,
    mediaResolution: 'MEDIA_RESOLUTION_MEDIUM',
  });
  if (!r.ok) return r;
  return {
    ok: true,
    data: {
      sections: cleanSections(r.data?.sections).sections,
      title: String(r.data?.title ?? '').trim().replace(/[.\s]+$/, ''),
    },
  };
}

export async function testConnection(apiKey: string, model: string): Promise<TestResult> {
  if (!apiKey.trim()) return { ok: false, message: 'Cole a chave da API primeiro.' };
  try {
    const { status, json } = await request(
      apiKey.trim(),
      modelPath(model),
      {
        contents: [{ parts: [{ text: 'Responda somente com a palavra: ok' }] }],
        generationConfig: { maxOutputTokens: 32 },
      },
      20000
    );
    if (status === 200) return { ok: true, message: `Conexão funcionando com "${model.trim()}".` };
    return { ok: false, message: classify(status, json).message };
  } catch (e) {
    return { ok: false, message: networkError(e).message };
  }
}

/** Lista os modelos Gemini que aceitam generateContent (os nomes mudam com o tempo). */
export async function listModels(
  apiKey: string
): Promise<{ ok: boolean; message: string; models: string[] }> {
  if (!apiKey.trim()) return { ok: false, message: 'Cole a chave da API primeiro.', models: [] };
  try {
    const { status, json } = await request(apiKey.trim(), '/models?pageSize=200', undefined, 20000);
    if (status !== 200) return { ok: false, message: classify(status, json).message, models: [] };
    const models: string[] = (json?.models ?? [])
      .filter(
        (m: any) =>
          typeof m?.name === 'string' &&
          m.name.startsWith('models/gemini') &&
          Array.isArray(m.supportedGenerationMethods) &&
          m.supportedGenerationMethods.includes('generateContent')
      )
      .map((m: any) => String(m.name).replace('models/', ''))
      .sort();
    return { ok: true, message: '', models };
  } catch (e) {
    return { ok: false, message: networkError(e).message, models: [] };
  }
}
