/** Conteúdo (JSON) de um item kind='video'. Sem dependências: o banco de dados também o usa. */
export type VideoData = {
  v: 1;
  /** Arquivo em media (vídeo guardado no aparelho) ou endereço http(s) (vídeo da web, não baixado). */
  src: string;
  /** Capa: nome do arquivo em media ou endereço http(s). null = sem capa. */
  poster: string | null;
  /** Duração em segundos. null = não sei. */
  dur: number | null;
  /** Tamanho do vídeo em pixels (para a proporção do cartão). 0 = não sei. */
  vw: number;
  vh: number;
};

const isHttp = (s: string) => /^https?:\/\//i.test(s);

/** Leitura segura do JSON do cartão. Inválido → vídeo vazio (o cartão mostra "vídeo indisponível"). */
export function parseVideo(content: string): VideoData {
  try {
    const j = JSON.parse(content);
    if (j && typeof j.src === 'string') {
      return {
        v: 1,
        src: j.src,
        poster: typeof j.poster === 'string' && j.poster ? j.poster : null,
        dur: typeof j.dur === 'number' && j.dur > 0 ? j.dur : null,
        vw: typeof j.vw === 'number' ? j.vw : 0,
        vh: typeof j.vh === 'number' ? j.vh : 0,
      };
    }
  } catch {
    // cai no padrão
  }
  return { v: 1, src: '', poster: null, dur: null, vw: 0, vh: 0 };
}

export const stringifyVideo = (d: VideoData): string => JSON.stringify(d);

/** Arquivos do app usados pelo cartão (vídeo e capa), para apagar junto com ele. Endereços da web não contam. */
export function videoFiles(content: string): string[] {
  const d = parseVideo(content);
  return [d.src, d.poster ?? ''].filter((n) => !!n && !isHttp(n));
}

/** "1:05", "0:12"... */
export function formatDuration(sec: number | null): string {
  if (!sec || sec <= 0) return '';
  const t = Math.round(sec);
  const m = Math.floor(t / 60);
  const s = t % 60;
  return `${m}:${s < 10 ? '0' : ''}${s}`;
}

/** Vídeo escolhido na web ou num banco (nada é baixado): endereço do vídeo, capa e créditos. */
export type WebVideo = {
  /** Único: "pexels:123", "web:https://...". */
  uid: string;
  /** Endereço do vídeo. Vazio quando só se descobre ao escolher (veja `resolve`). */
  src: string;
  /** Descobre o endereço do vídeo na hora de adicionar (NASA: o arquivo vem de uma segunda consulta). */
  resolve?: () => Promise<string | null>;
  /** Capa (endereço). null = o app tenta tirar um quadro do vídeo. */
  poster: string | null;
  width: number;
  height: number;
  /** Segundos. */
  duration: number | null;
  pageUrl: string;
  author: string;
  /** Legenda pronta ("Fonte: ..."). */
  caption: string;
  license?: string;
};
