import React, { useEffect, useState } from 'react';
import { Keyboard, Pressable, ScrollView, Text, TextInput, View, useWindowDimensions } from 'react-native';
import { SheetShell } from './DialogBase';
import { Ficha, newFichaId } from './ficha';
import { FichaTemplate, fichaFromTemplate, loadFichaTemplates, removeFichaTemplate, saveFichaTemplate } from './fichaTemplates';
import { plainOf } from './RichText';
import { colors, fonts, HIT, SPACE, TYPE } from './theme';
import { useKeyboardInset } from './useKeyboardInset';

type Props = {
  visible: boolean;
  /** Muda a cada ficha aberta, para o rascunho recomeçar. */
  sheetKey: number | null;
  initial: Ficha;
  onCancel: () => void;
  onDone: (f: Ficha) => void;
  /** Abre o editor de texto formatado (a janela fecha e volta com o texto novo). */
  onEditText: (draft: Ficha) => void;
};

/** Janela de baixo para criar e editar uma ficha: título, texto corrido ou campos para preencher. */
export function FichaSheet({ visible, sheetKey, initial, onCancel, onDone, onEditText }: Props) {
  const { width: sw, height: sh } = useWindowDimensions();
  const kb = useKeyboardInset();
  const [draft, setDraft] = useState<Ficha>(initial);
  const [templates, setTemplates] = useState<FichaTemplate[]>([]);
  const [trashMode, setTrashMode] = useState(false);
  const [naming, setNaming] = useState<string | null>(null); // nome do modelo sendo digitado (null = fechado)

  // Ao abrir (ou voltar do editor de texto), parte do que o pai mandou.
  useEffect(() => {
    if (visible) setDraft(initial);
  }, [visible, sheetKey, initial]); // eslint-disable-line react-hooks/exhaustive-deps

  // Modelos: carrega ao abrir a janela.
  useEffect(() => {
    if (!visible) return;
    setTrashMode(false);
    setNaming(null);
    loadFichaTemplates().then(setTemplates);
  }, [visible, sheetKey]);

  const saveTemplate = async () => {
    const name = (naming ?? '').trim();
    if (!name) return;
    setNaming(null);
    setTemplates(await saveFichaTemplate(name, draft));
  };

  const set = (p: Partial<Ficha>) => setDraft((d) => ({ ...d, ...p }));
  const setField = (id: string, p: { label?: string; value?: string }) =>
    setDraft((d) => ({ ...d, fields: d.fields.map((f) => (f.id === id ? { ...f, ...p } : f)) }));

  const input = {
    fontFamily: fonts.regular,
    fontSize: sw * TYPE.body,
    color: colors.onLight,
    borderBottomWidth: 1,
    borderBottomColor: colors.line,
    paddingVertical: sw * 0.015,
  };
  const seg = (label: string, mode: Ficha['mode']) => (
    <Pressable
      onPress={() => set({ mode })}
      hitSlop={HIT.md}
      style={{
        flex: 1,
        alignItems: 'center',
        paddingVertical: sw * SPACE.sm,
        borderRadius: sw * 0.05,
        backgroundColor: draft.mode === mode ? colors.onLight : 'transparent',
        borderWidth: 1,
        borderColor: colors.line,
      }}
    >
      <Text style={{ color: draft.mode === mode ? colors.paper : colors.onLight, fontFamily: fonts.bold, fontSize: sw * TYPE.body }}>{label}</Text>
    </Pressable>
  );
  const done = () => {
    Keyboard.dismiss();
    onDone(draft);
  };
  const plain = plainOf(draft.html);

  return (
    <SheetShell visible={visible} onClose={onCancel} lift={kb} maxHeight={Math.max(sh * 0.4, Math.min(sh * 0.78, sh - kb - sw * 0.2))}>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingTop: sw * SPACE.xl, paddingHorizontal: sw * SPACE.xl }}>
        <Pressable onPress={onCancel} hitSlop={HIT.md} accessibilityRole="button">
          <Text style={{ color: colors.subtle, fontFamily: fonts.bold, fontSize: sw * TYPE.subtitle }}>Cancelar</Text>
        </Pressable>
        <Text style={{ color: colors.onLight, fontFamily: fonts.bold, fontSize: sw * TYPE.subtitle }}>Ficha</Text>
        <Pressable onPress={done} hitSlop={HIT.md} accessibilityRole="button">
          <Text style={{ color: colors.red, fontFamily: fonts.bold, fontSize: sw * TYPE.subtitle }}>Pronto</Text>
        </Pressable>
      </View>
      <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{ padding: sw * SPACE.xl, gap: sw * 0.03 }}>
        {templates.length > 0 && (
          <View>
            <Text style={{ color: colors.subtle, fontFamily: fonts.regular, fontSize: sw * TYPE.caption, marginBottom: sw * 0.015 }}>
              Modelos (segure para excluir)
            </Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} keyboardShouldPersistTaps="handled" contentContainerStyle={{ gap: sw * SPACE.sm }}>
              {templates.map((t) => (
                <Pressable
                  key={t.id}
                  onPress={() => (trashMode ? removeFichaTemplate(t.id).then(setTemplates) : setDraft((d) => fichaFromTemplate(t, d)))}
                  onLongPress={() => setTrashMode((v) => !v)}
                  hitSlop={HIT.md}
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    paddingVertical: sw * SPACE.sm,
                    paddingHorizontal: sw * SPACE.md,
                    borderRadius: sw * 0.05,
                    borderWidth: 1,
                    borderColor: trashMode ? colors.red : colors.line,
                  }}
                >
                  <Text style={{ color: trashMode ? colors.red : colors.onLight, fontFamily: fonts.bold, fontSize: sw * TYPE.body }}>
                    {trashMode ? `× ${t.name}` : t.name}
                  </Text>
                </Pressable>
              ))}
            </ScrollView>
          </View>
        )}
        <TextInput
          value={draft.title}
          onChangeText={(t) => set({ title: t })}
          placeholder="Título da ficha"
          placeholderTextColor={colors.subtle}
          style={{ ...input, fontFamily: fonts.bold }}
        />
        <View style={{ flexDirection: 'row', gap: sw * SPACE.sm }}>
          {seg('Texto corrido', 'text')}
          {seg('Campos', 'fields')}
        </View>

        {draft.mode === 'text' ? (
          <Pressable
            onPress={() => onEditText(draft)}
            style={{ borderWidth: 1, borderColor: colors.line, borderRadius: sw * 0.03, padding: sw * SPACE.md, minHeight: sw * 0.25 }}
          >
            <Text style={{ color: plain ? colors.onLight : colors.subtle, fontFamily: fonts.regular, fontSize: sw * TYPE.body }} numberOfLines={8}>
              {plain || 'Toque para escrever (negrito, tamanho e cor como no texto do quadro)'}
            </Text>
          </Pressable>
        ) : (
          <>
            {draft.fields.map((f) => (
              <View key={f.id} style={{ flexDirection: 'row', alignItems: 'flex-end', gap: sw * SPACE.md }}>
                <View style={{ flex: 1 }}>
                  <TextInput
                    value={f.label}
                    onChangeText={(t) => setField(f.id, { label: t })}
                    placeholder="Nome do campo"
                    placeholderTextColor={colors.subtle}
                    style={{ ...input, fontSize: sw * TYPE.caption, color: colors.subtle }}
                  />
                  <TextInput
                    value={f.value}
                    onChangeText={(t) => setField(f.id, { value: t })}
                    placeholder="Preencher"
                    placeholderTextColor={colors.subtle}
                    multiline
                    style={{ ...input, maxHeight: sw * 0.3 }}
                  />
                </View>
                <Pressable
                  onPress={() => set({ fields: draft.fields.filter((x) => x.id !== f.id) })}
                  hitSlop={HIT.md}
                  accessibilityRole="button"
                  accessibilityLabel="Remover campo"
                >
                  <Text style={{ color: colors.red, fontFamily: fonts.bold, fontSize: sw * TYPE.body, paddingBottom: sw * 0.02 }}>Remover</Text>
                </Pressable>
              </View>
            ))}
            <Pressable onPress={() => set({ fields: [...draft.fields, { id: newFichaId(), label: '', value: '' }] })} hitSlop={HIT.md}>
              <Text style={{ color: colors.onLight, fontFamily: fonts.bold, fontSize: sw * TYPE.body }}>+ Campo</Text>
            </Pressable>
          </>
        )}

        {naming === null ? (
          <Pressable onPress={() => setNaming(draft.title)} hitSlop={HIT.md}>
            <Text style={{ color: colors.subtle, fontFamily: fonts.bold, fontSize: sw * TYPE.body }}>Salvar como modelo</Text>
          </Pressable>
        ) : (
          <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: sw * SPACE.md }}>
            <TextInput
              value={naming}
              onChangeText={setNaming}
              autoFocus
              maxLength={40}
              placeholder="Nome do modelo"
              placeholderTextColor={colors.subtle}
              onSubmitEditing={saveTemplate}
              style={{ ...input, flex: 1 }}
            />
            <Pressable onPress={() => setNaming(null)} hitSlop={HIT.md}>
              <Text style={{ color: colors.subtle, fontFamily: fonts.bold, fontSize: sw * TYPE.body, paddingBottom: sw * 0.02 }}>Cancelar</Text>
            </Pressable>
            <Pressable onPress={saveTemplate} hitSlop={HIT.md}>
              <Text style={{ color: colors.red, fontFamily: fonts.bold, fontSize: sw * TYPE.body, paddingBottom: sw * 0.02 }}>Salvar</Text>
            </Pressable>
          </View>
        )}
      </ScrollView>
    </SheetShell>
  );
}
