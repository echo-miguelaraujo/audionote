import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, Image, Keyboard, Modal, NativeScrollEvent, NativeSyntheticEvent, Pressable, ScrollView, StyleSheet, Text, TextInput, View, useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ActionMenu } from './ActionMenu';
import { Background, useBg } from './Background';
import { IconButton } from './Button';
import { Icon } from './Icon';
import { ScreenHeader } from './ScreenHeader';
import { StateMessage } from './StateMessage';
import { NO_TRENDING, STOCK_SOURCES, StockPhoto, StockSource, availableSources, labelOf, searchStock } from './stockImages';
import { translateQuery } from './stockTranslate';
import { domainOf, fetchPreviewText, normalizeUrl } from './linkPreview';
import { colors, fonts, LEADING, MIN_TOUCH, RADIUS, SPACE, TYPE } from './theme';

type Props = {
  visible: boolean;
  onClose: () => void;
  /** Recebe as fotos escolhidas; o quadro as adiciona como cartões online. */
  onPick: (photos: StockPhoto[]) => void;
};

/** Altura relativa à largura, limitada para nenhum cartão ficar fino ou comprido demais. */
const ratioOf = (p: StockPhoto) => Math.min(1.7, Math.max(0.65, p.height / Math.max(1, p.width)));

/**
 * Tela cheia de "Foto da web": mural em duas colunas (cada foto com a própria proporção),
 * busca por tema, abas dos bancos e seleção múltipla com botões de vidro flutuantes.
 */
export function StockPickerScreen({ visible, onClose, onPick }: Props) {
  const { width: sw } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  // Segue a opção Vidro de Configurações > Aparência: desligado = painel sólido; leve/forte = translúcido.
  const bg = useBg();
  const GLASS_DARK = bg.glass === 0 ? colors.surface : bg.glass === 1 ? 'rgba(255,255,255,0.12)' : 'rgba(255,255,255,0.22)';
  const [sources, setSources] = useState<StockSource[]>([]);
  const [active, setActive] = useState<StockSource | null>(null);
  const [text, setText] = useState('');
  const [query, setQuery] = useState('');
  /** Termo em inglês realmente enviado ao banco, quando difere do que a pessoa digitou. */
  const [translated, setTranslated] = useState<string | null>(null);
  const [translating, setTranslating] = useState(false);
  const [photos, setPhotos] = useState<StockPhoto[]>([]);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [menu, setMenu] = useState(false);
  /** A seleção sobrevive à troca de banco e de busca. */
  const [picked, setPicked] = useState<Record<string, StockPhoto>>({});
  /** Descarta respostas atrasadas de buscas antigas. */
  const req = useRef(0);

  // Recalcula a cada abertura: o usuário pode ter acabado de cadastrar uma chave.
  useEffect(() => {
    if (!visible) return;
    setPicked({});
    availableSources().then((list) => {
      setSources(list);
      setActive((cur) => (cur && list.includes(cur) ? cur : list[0] ?? null));
    });
  }, [visible]);

  const load = useCallback(async (source: StockSource, q: string, p: number) => {
    const id = ++req.current;
    setLoading(true);
    setError(null);
    const r = await searchStock(source, q, p);
    if (id !== req.current) return;
    setLoading(false);
    if (!r.ok) {
      setError(r.message);
      if (p === 1) setPhotos([]);
      setHasMore(false);
      return;
    }
    setPhotos((prev) => {
      if (p === 1) return r.data.photos;
      const seen = new Set(prev.map((x) => x.uid));
      return [...prev, ...r.data.photos.filter((x) => !seen.has(x.uid))];
    });
    setPage(p);
    setHasMore(r.data.hasMore);
  }, []);

  // Banco ou busca mudou: recomeça da página 1.
  useEffect(() => {
    if (!visible || !active) return;
    setPhotos([]);
    setHasMore(false);
    load(active, query, 1);
  }, [visible, active, query, load]);

  const submit = async () => {
    Keyboard.dismiss();
    const typed = text.trim();
    if (active === 'link') {
      // Cosmos, Dupe etc.: sem busca. Pega a imagem de destaque da página do link colado.
      setTranslated(null);
      const url = normalizeUrl(typed);
      setPhotos([]);
      if (!url) return setError('Cole o endereço completo da foto (começa com http).');
      setError(null);
      setLoading(true);
      const pv = await fetchPreviewText(url);
      setLoading(false);
      if (!pv?.imageUrl) return setError('Não encontrei uma imagem nesse link. Alguns sites bloqueiam isso ou exigem login.');
      setPhotos([
        {
          uid: `link:${url}`,
          source: 'link',
          width: 800,
          height: 800,
          sizeUnknown: true,
          thumbUrl: pv.imageUrl,
          fullUrl: pv.imageUrl,
          pageUrl: url,
          author: pv.site || domainOf(url),
          authorUrl: url,
        },
      ]);
      return;
    }
    setTranslating(true);
    const q = await translateQuery(typed);
    setTranslating(false);
    setTranslated(q && q.toLowerCase() !== typed.toLowerCase() ? q : null);
    if (q === query && active) load(active, q, 1);
    else setQuery(q);
  };

  const more = () => {
    if (active && hasMore && !loading) load(active, query, page + 1);
  };

  const onScroll = (e: NativeSyntheticEvent<NativeScrollEvent>) => {
    const { layoutMeasurement, contentOffset, contentSize } = e.nativeEvent;
    if (contentOffset.y + layoutMeasurement.height >= contentSize.height - layoutMeasurement.height * 0.8) more();
  };

  const toggle = (p: StockPhoto) =>
    setPicked((cur) => {
      const next = { ...cur };
      if (next[p.uid]) delete next[p.uid];
      else next[p.uid] = p;
      return next;
    });

  const count = Object.keys(picked).length;
  const missing = STOCK_SOURCES.filter((s) => s.needsKey && !sources.includes(s.id));
  const side = sw * SPACE.lg;
  const gap = sw * 0.02;
  const cell = (sw - side * 2 - gap) / 2;
  const radius = sw * RADIUS.dialog * 0.7;

  // Mural: cada foto vai para a coluna mais baixa; a ordem é estável quando chegam mais fotos.
  const columns = useMemo(() => {
    const a: StockPhoto[] = [];
    const b: StockPhoto[] = [];
    let ha = 0;
    let hb = 0;
    for (const p of photos) {
      if (ha <= hb) {
        a.push(p);
        ha += ratioOf(p);
      } else {
        b.push(p);
        hb += ratioOf(p);
      }
    }
    return [a, b];
  }, [photos]);

  const empty = !loading && !error && photos.length === 0;
  const noTrending = !!active && NO_TRENDING.includes(active) && !query;
  const title = query ? query : 'Fotos da web';

  const tile = (item: StockPhoto) => {
    const on = !!picked[item.uid];
    return (
      <Pressable
        key={item.uid}
        onPress={() => toggle(item)}
        accessibilityRole="button"
        accessibilityLabel={`Foto de ${item.author}`}
        accessibilityState={{ selected: on }}
        style={{ width: cell, height: cell * ratioOf(item), marginBottom: gap, borderRadius: radius, overflow: 'hidden', backgroundColor: GLASS_DARK }}
      >
        <Image source={{ uri: item.thumbUrl }} style={StyleSheet.absoluteFill} resizeMode="cover" />
        {on && (
          <View style={[StyleSheet.absoluteFill, { borderWidth: 3, borderColor: colors.red, borderRadius: radius, backgroundColor: 'rgba(0,0,0,0.25)' }]}>
            <View style={{ position: 'absolute', top: gap * 1.5, right: gap * 1.5, width: sw * 0.07, height: sw * 0.07, borderRadius: sw * 0.035, backgroundColor: colors.red, alignItems: 'center', justifyContent: 'center' }}>
              <Icon name="check" size={sw * 0.04} color="#fff" />
            </View>
          </View>
        )}
      </Pressable>
    );
  };

  return (
    <Modal visible={visible} animationType="slide" statusBarTranslucent onRequestClose={onClose}>
      <View style={styles.root}>
        <Background />
        <ScreenHeader
          onBack={onClose}
          crumb={photos.length > 0 ? `${photos.length} fotos` : undefined}
          title={title}
          right={<IconButton icon="more" label="Mais opções" onPress={() => setMenu(true)} />}
        />

        {/* Abas dos bancos, em pílulas de vidro */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ flexGrow: 0 }} contentContainerStyle={{ paddingHorizontal: side, gap: sw * SPACE.sm, paddingVertical: sw * SPACE.xs }}>
          {sources.map((id) => {
            const on = id === active;
            return (
              <Pressable
                key={id}
                onPress={() => setActive(id)}
                accessibilityRole="button"
                accessibilityState={{ selected: on }}
                style={{
                  minHeight: MIN_TOUCH * 0.8,
                  justifyContent: 'center',
                  paddingHorizontal: sw * SPACE.lg,
                  borderRadius: sw * RADIUS.pill,
                  backgroundColor: on ? colors.glass : GLASS_DARK,
                }}
              >
                <Text style={{ color: on ? colors.onLight : colors.text, fontFamily: on ? fonts.bold : fonts.regular, fontSize: sw * TYPE.label }}>{labelOf(id)}</Text>
              </Pressable>
            );
          })}
        </ScrollView>

        {/* Busca em pílula */}
        <View style={{ marginHorizontal: side, marginTop: sw * SPACE.sm, flexDirection: 'row', alignItems: 'center', backgroundColor: GLASS_DARK, borderRadius: sw * RADIUS.pill, paddingLeft: sw * SPACE.lg, paddingRight: sw * SPACE.lg, gap: sw * SPACE.md }}>
          <TextInput
            value={text}
            onChangeText={setText}
            onSubmitEditing={submit}
            returnKeyType="search"
            autoCapitalize="none"
            autoCorrect={false}
            accessibilityLabel="Buscar fotos"
            placeholder={active === 'link' ? 'Cole o link da foto (Cosmos, Dupe...)' : active === 'arena' ? 'Link de um canal (are.na/usuario/canal)' : active === 'serper' ? 'Buscar (ex.: praia site:pinterest.com)' : active && NO_TRENDING.includes(active) ? 'Buscar (ex.: beach)' : 'Buscar (ex.: beach) ou deixe vazio'}
            placeholderTextColor={colors.muted}
            style={{ flex: 1, minHeight: MIN_TOUCH, color: colors.text, fontFamily: fonts.regular, fontSize: sw * TYPE.body }}
          />
          <Pressable onPress={submit} disabled={translating} hitSlop={12} accessibilityRole="button" accessibilityLabel="Buscar">
            {translating ? <ActivityIndicator color={colors.red} /> : <Text style={{ color: colors.red, fontFamily: fonts.bold, fontSize: sw * TYPE.body }}>Buscar</Text>}
          </Pressable>
        </View>
        {translated && (
          <Text style={{ paddingHorizontal: side + sw * SPACE.sm, marginTop: sw * SPACE.xs, color: colors.mutedLight, fontFamily: fonts.regular, fontSize: sw * TYPE.caption }}>
            {`Buscando por “${translated}”`}
          </Text>
        )}

        <ScrollView
          style={{ flex: 1, marginTop: sw * SPACE.md }}
          contentContainerStyle={{ paddingHorizontal: side, paddingBottom: (count > 0 ? sw * 0.25 : 0) + insets.bottom + sw * SPACE.xl }}
          keyboardShouldPersistTaps="handled"
          keyboardDismissMode="on-drag"
          onScroll={onScroll}
          scrollEventThrottle={120}
          showsVerticalScrollIndicator={false}
        >
          {error ? (
            <View style={{ marginBottom: sw * SPACE.md }}>
              <StateMessage kind="error">{error}</StateMessage>
              {active !== 'link' && (
                <Pressable onPress={() => active && load(active, query, 1)} accessibilityRole="button" style={{ minHeight: MIN_TOUCH, justifyContent: 'center' }}>
                  <Text style={{ color: colors.red, fontFamily: fonts.bold, fontSize: sw * TYPE.body }}>Tentar de novo</Text>
                </Pressable>
              )}
            </View>
          ) : empty ? (
            <StateMessage kind="empty">
              {noTrending
                ? active === 'link'
                  ? 'Cole o link de uma foto do Cosmos, do Dupe ou de outro site e toque em Buscar.'
                  : active === 'arena'
                    ? 'Cole o link de um canal do Are.na (are.na/usuario/canal) e toque em Buscar. Conta Premium também busca por tema.'
                    : `${labelOf(active!)} não tem fotos em alta. Digite um tema para buscar.`
                : active
                  ? 'Nenhuma foto encontrada.'
                  : 'Nenhum banco disponível.'}
            </StateMessage>
          ) : null}

          <View style={{ flexDirection: 'row', gap }}>
            {columns.map((col, i) => (
              <View key={i} style={{ width: cell }}>
                {col.map(tile)}
              </View>
            ))}
          </View>

          {loading && (
            <View style={{ paddingVertical: sw * SPACE.xl }}>
              <ActivityIndicator color={colors.text} />
            </View>
          )}
          {!loading && missing.length > 0 && photos.length === 0 && !error && (
            <Text style={{ marginTop: sw * SPACE.lg, color: colors.muted, fontFamily: fonts.regular, fontSize: sw * TYPE.caption, lineHeight: sw * TYPE.caption * LEADING }}>
              {`Sem chave: ${missing.map((s) => s.label).join(', ')}. Cadastre em Configurações para ativar.`}
            </Text>
          )}
        </ScrollView>

        {/* Botões de vidro flutuantes, como no mural de referência */}
        {count > 0 && (
          <View pointerEvents="box-none" style={{ position: 'absolute', left: side, right: side, bottom: insets.bottom + sw * SPACE.md, flexDirection: 'row', justifyContent: 'center', gap: sw * SPACE.md }}>
            <Pressable
              onPress={() => setPicked({})}
              accessibilityRole="button"
              accessibilityLabel="Limpar seleção"
              style={{ minHeight: MIN_TOUCH, flexDirection: 'row', alignItems: 'center', gap: sw * SPACE.sm, paddingHorizontal: sw * SPACE.xl, borderRadius: sw * RADIUS.pill, backgroundColor: colors.glass, borderWidth: 1, borderColor: colors.glassLine }}
            >
              <Icon name="close" size={sw * 0.035} color={colors.onLight} />
              <Text style={{ color: colors.onLight, fontFamily: fonts.bold, fontSize: sw * TYPE.body }}>{count}</Text>
            </Pressable>
            <Pressable
              onPress={() => onPick(Object.values(picked))}
              accessibilityRole="button"
              style={{ minHeight: MIN_TOUCH, justifyContent: 'center', paddingHorizontal: sw * SPACE.xl, borderRadius: sw * RADIUS.pill, backgroundColor: colors.red }}
            >
              <Text style={{ color: '#fff', fontFamily: fonts.bold, fontSize: sw * TYPE.body }}>{count === 1 ? 'Adicionar 1 foto' : `Adicionar ${count} fotos`}</Text>
            </Pressable>
          </View>
        )}

        <ActionMenu
          visible={menu}
          onClose={() => setMenu(false)}
          title="Fotos da web"
          items={[
            { key: 'all', label: 'Selecionar todas as visíveis', disabled: photos.length === 0, onPress: () => setPicked((cur) => ({ ...cur, ...Object.fromEntries(photos.map((p) => [p.uid, p])) })) },
            { key: 'clear', label: 'Limpar seleção', disabled: count === 0, onPress: () => setPicked({}) },
          ]}
        />
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
});
