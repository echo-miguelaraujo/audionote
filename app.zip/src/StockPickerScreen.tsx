import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, FlatList, Image, Keyboard, Modal, Pressable, StyleSheet, Text, TextInput, View, useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Button } from './Button';
import { Icon } from './Icon';
import { ScreenHeader } from './ScreenHeader';
import { StateMessage } from './StateMessage';
import { STOCK_SOURCES, StockPhoto, StockSource, availableSources, labelOf, searchStock } from './stockImages';
import { translateQuery } from './stockTranslate';
import { colors, fonts, LEADING, MIN_TOUCH, SPACE, TYPE } from './theme';

type Props = {
  visible: boolean;
  onClose: () => void;
  /** Recebe as fotos escolhidas. O quadro importa a partir do Bloco 4. */
  onPick: (photos: StockPhoto[]) => void;
};

const COLS = 2;
const clampRatio = (p: StockPhoto) => Math.min(1.5, Math.max(0.7, p.height / Math.max(1, p.width)));

/**
 * Tela cheia de "Foto da web": abas dos bancos, busca por tema, grade com rolagem infinita
 * e seleção múltipla. Sem texto de busca, mostra o que está em alta (quando o banco tem isso).
 */
export function StockPickerScreen({ visible, onClose, onPick }: Props) {
  const { width: sw } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const [sources, setSources] = useState<StockSource[]>([]);
  const [active, setActive] = useState<StockSource | null>(null);
  const [text, setText] = useState('');
  const [query, setQuery] = useState('');
  /** Termo em inglês realmente enviado ao banco, quando difere do que a pessoa digitou. */
  const [translated, setTranslated] = useState<string | null>(null);
  const [translating, setTranslating] = useState(false);
  const [photos, setPhotos] = useState<StockPhoto[]>([]);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  /** A seleção sobrevive à troca de banco e de busca. */
  const [picked, setPicked] = useState<Record<string, StockPhoto>>({});
  /** Descarta respostas atrasadas de buscas antigas. */
  const req = useRef(0);

  // Recalcula a cada abertura: o usuário pode ter acabado de cadastrar uma chave.
  useEffect(() => {
    if (!visible) return;
    setPicked({});
    availableSources().then((list) => {
      setSources(list);
      setActive((cur) => (cur && list.includes(cur) ? cur : list[0] ?? null));
    });
  }, [visible]);

  const load = useCallback(
    async (source: StockSource, q: string, p: number) => {
      const id = ++req.current;
      setLoading(true);
      setError(null);
      const r = await searchStock(source, q, p);
      if (id !== req.current) return;
      setLoading(false);
      if (!r.ok) {
        setError(r.message);
        if (p === 1) setPhotos([]);
        setHasMore(false);
        return;
      }
      setPhotos((prev) => {
        if (p === 1) return r.data.photos;
        const seen = new Set(prev.map((x) => x.uid));
        return [...prev, ...r.data.photos.filter((x) => !seen.has(x.uid))];
      });
      setPage(p);
      setHasMore(r.data.hasMore);
    },
    []
  );

  // Banco ou busca mudou: recomeça da página 1.
  useEffect(() => {
    if (!visible || !active) return;
    setPhotos([]);
    setHasMore(false);
    load(active, query, 1);
  }, [visible, active, query, load]);

  const submit = async () => {
    Keyboard.dismiss();
    const typed = text.trim();
    setTranslating(true);
    const q = await translateQuery(typed);
    setTranslating(false);
    setTranslated(q && q.toLowerCase() !== typed.toLowerCase() ? q : null);
    if (q === query && active) load(active, q, 1);
    else setQuery(q);
  };

  const more = () => {
    if (active && hasMore && !loading) load(active, query, page + 1);
  };

  const toggle = (p: StockPhoto) =>
    setPicked((cur) => {
      const next = { ...cur };
      if (next[p.uid]) delete next[p.uid];
      else next[p.uid] = p;
      return next;
    });

  const count = Object.keys(picked).length;
  const missing = STOCK_SOURCES.filter((s) => s.needsKey && !sources.includes(s.id));
  const gap = sw * SPACE.sm;
  const cell = (sw - sw * SPACE.xl * 2 - gap * (COLS - 1)) / COLS;

  const empty = !loading && !error && photos.length === 0;
  const noTrending = active === 'openverse' && !query;

  return (
    <Modal visible={visible} animationType="slide" statusBarTranslucent onRequestClose={onClose}>
      <View style={styles.root}>
        <ScreenHeader onBack={onClose} title="Fotos da web" />

        <View style={{ flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: sw * SPACE.xl }}>
          {sources.map((id) => {
            const on = id === active;
            return (
              <Pressable
                key={id}
                onPress={() => setActive(id)}
                accessibilityRole="button"
                accessibilityState={{ selected: on }}
                style={{
                  minHeight: MIN_TOUCH,
                  justifyContent: 'center',
                  paddingRight: sw * SPACE.xl,
                  borderBottomWidth: 2,
                  borderBottomColor: on ? colors.red : 'transparent',
                  marginRight: sw * SPACE.md,
                }}
              >
                <Text style={{ color: on ? colors.text : colors.muted, fontFamily: on ? fonts.bold : fonts.regular, fontSize: sw * TYPE.body }}>
                  {labelOf(id)}
                </Text>
              </Pressable>
            );
          })}
        </View>

        <View style={{ paddingHorizontal: sw * SPACE.xl, flexDirection: 'row', alignItems: 'center', gap: sw * SPACE.md }}>
          <TextInput
            value={text}
            onChangeText={setText}
            onSubmitEditing={submit}
            returnKeyType="search"
            autoCapitalize="none"
            autoCorrect={false}
            accessibilityLabel="Buscar fotos"
            placeholder={active === 'openverse' ? 'Buscar (ex.: beach)' : 'Buscar (ex.: beach) ou deixe vazio'}
            placeholderTextColor={colors.muted}
            style={{
              flex: 1,
              color: colors.text,
              fontFamily: fonts.regular,
              fontSize: sw * TYPE.subtitle,
              paddingVertical: sw * SPACE.sm,
              borderBottomWidth: 2,
              borderBottomColor: colors.text,
            }}
          />
          <Pressable onPress={submit} disabled={translating} hitSlop={12} accessibilityRole="button" accessibilityLabel="Buscar">
            <Text style={{ color: colors.red, fontFamily: fonts.bold, fontSize: sw * TYPE.body }}>Buscar</Text>
          </Pressable>
        </View>

        {translated && (
          <Text style={{ paddingHorizontal: sw * SPACE.xl, marginTop: sw * SPACE.sm, color: colors.muted, fontFamily: fonts.regular, fontSize: sw * TYPE.caption }}>
            {`Buscando por “${translated}”`}
          </Text>
        )}

        <FlatList
          style={{ flex: 1, marginTop: sw * SPACE.md }}
          data={photos}
          keyExtractor={(p) => p.uid}
          numColumns={COLS}
          columnWrapperStyle={{ gap, marginBottom: gap }}
          contentContainerStyle={{ paddingHorizontal: sw * SPACE.xl, paddingBottom: (count > 0 ? sw * 0.25 : 0) + insets.bottom + sw * SPACE.xl }}
          keyboardShouldPersistTaps="handled"
          keyboardDismissMode="on-drag"
          onEndReachedThreshold={0.6}
          onEndReached={more}
          ListHeaderComponent={
            error ? (
              <View style={{ marginBottom: sw * SPACE.md }}>
                <StateMessage kind="error">{error}</StateMessage>
                <Pressable onPress={() => active && load(active, query, page > 1 && photos.length ? page + 1 : 1)} accessibilityRole="button" style={{ minHeight: MIN_TOUCH, justifyContent: 'center' }}>
                  <Text style={{ color: colors.red, fontFamily: fonts.bold, fontSize: sw * TYPE.body }}>Tentar de novo</Text>
                </Pressable>
              </View>
            ) : empty ? (
              <StateMessage kind="empty">
                {noTrending ? 'O Openverse não tem fotos em alta. Digite um tema para buscar.' : active ? 'Nenhuma foto encontrada.' : 'Nenhum banco disponível.'}
              </StateMessage>
            ) : null
          }
          ListFooterComponent={
            loading ? (
              <View style={{ paddingVertical: sw * SPACE.xl }}>
                <ActivityIndicator color={colors.text} />
              </View>
            ) : missing.length > 0 && photos.length === 0 && !error ? (
              <Text style={{ marginTop: sw * SPACE.lg, color: colors.muted, fontFamily: fonts.regular, fontSize: sw * TYPE.caption, lineHeight: sw * TYPE.caption * LEADING }}>
                {`Sem chave: ${missing.map((s) => s.label).join(', ')}. Cadastre em Configurações para ativar.`}
              </Text>
            ) : null
          }
          renderItem={({ item }) => {
            const on = !!picked[item.uid];
            return (
              <Pressable
                onPress={() => toggle(item)}
                accessibilityRole="button"
                accessibilityLabel={`Foto de ${item.author}`}
                accessibilityState={{ selected: on }}
                style={{ width: cell, height: cell * clampRatio(item), backgroundColor: colors.muted + '33', overflow: 'hidden' }}
              >
                <Image source={{ uri: item.thumbUrl }} style={StyleSheet.absoluteFill} resizeMode="cover" />
                {on && (
                  <View style={[StyleSheet.absoluteFill, { borderWidth: 3, borderColor: colors.red, backgroundColor: 'rgba(0,0,0,0.25)' }]}>
                    <View style={{ position: 'absolute', top: gap, right: gap, width: sw * 0.07, height: sw * 0.07, borderRadius: sw * 0.035, backgroundColor: colors.red, alignItems: 'center', justifyContent: 'center' }}>
                      <Icon name="check" size={sw * 0.04} color="#fff" />
                    </View>
                  </View>
                )}
              </Pressable>
            );
          }}
        />

        {count > 0 && (
          <View style={{ position: 'absolute', left: sw * SPACE.xl, right: sw * SPACE.xl, bottom: insets.bottom + sw * SPACE.md }}>
            <Button label={count === 1 ? 'Adicionar 1 foto' : `Adicionar ${count} fotos`} onPress={() => onPick(Object.values(picked))} />
          </View>
        )}
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
});
