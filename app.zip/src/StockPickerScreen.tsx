import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, Image, Keyboard, Modal, NativeScrollEvent, NativeSyntheticEvent, Pressable, ScrollView, StyleSheet, Text, TextInput, View, useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ActionMenu } from './ActionMenu';
import { Background, useBg } from './Background';
import { IconButton } from './Button';
import { Icon } from './Icon';
import { ScreenHeader } from './ScreenHeader';
import { StateMessage } from './StateMessage';
import { NO_TRENDING, STOCK_SOURCES, StockPhoto, StockSource, availableSources, availableVideoSources, labelOf, searchStock, searchStockVideo } from './stockImages';
import { WebVideo, formatDuration } from './videoData';
import { translateQuery } from './stockTranslate';
import { domainOf, fetchPreviewText, normalizeUrl } from './linkPreview';
import { colors, fonts, LEADING, MIN_TOUCH, RADIUS, SPACE, TYPE } from './theme';

type Props = {
  visible: boolean;
  onClose: () => void;
  /** Recebe as fotos escolhidas; o quadro as adiciona como cartões online. */
  onPick: (photos: StockPhoto[]) => void;
  /** 'video' = mesma tela, mas busca vídeos (Pexels, NASA) e entrega por `onPickVideos`. */
  mode?: 'photo' | 'video';
  onPickVideos?: (videos: WebVideo[]) => void;
};

const SOURCE_TIMEOUT_MS = 8000;

/** Altura relativa à largura, limitada para nenhum cartão ficar fino ou comprido demais. */
const ratioOf = (p: StockPhoto) => Math.min(1.7, Math.max(0.65, p.height / Math.max(1, p.width)));

type TileProps = {
  item: StockPhoto; on: boolean; isVideo: boolean; duration: number | null;
  cell: number; gap: number; radius: number; sw: number; glass: string;
  onToggle: (p: StockPhoto) => void;
};

/** Cartão do mural. Memoizado: digitar na busca ou marcar outra foto não redesenha os demais. */
const Tile = React.memo(function Tile({ item, on, isVideo, duration, cell, gap, radius, sw, glass, onToggle }: TileProps) {
  const dur = formatDuration(duration);
  return (
    <Pressable
      onPress={() => onToggle(item)}
      accessibilityRole="button"
      accessibilityLabel={isVideo ? `Vídeo de ${item.author}` : `Foto de ${item.author}, ${labelOf(item.source)}`}
      accessibilityState={{ selected: on }}
      style={{ width: cell, height: cell * ratioOf(item), marginBottom: gap, borderRadius: radius, overflow: 'hidden', backgroundColor: glass }}
    >
      <Image source={{ uri: item.thumbUrl }} style={StyleSheet.absoluteFill} resizeMode="cover" fadeDuration={150} />
      {isVideo && (
        <View pointerEvents="none" style={[StyleSheet.absoluteFill, { alignItems: 'center', justifyContent: 'center' }]}>
          <View style={{ width: sw * 0.11, height: sw * 0.11, borderRadius: sw * 0.055, backgroundColor: 'rgba(0,0,0,0.55)', borderWidth: 1.5, borderColor: 'rgba(255,255,255,0.85)', alignItems: 'center', justifyContent: 'center' }}>
            <View style={{ marginLeft: sw * 0.008, borderTopWidth: sw * 0.0225, borderBottomWidth: sw * 0.0225, borderLeftWidth: sw * 0.036, borderTopColor: 'transparent', borderBottomColor: 'transparent', borderLeftColor: '#fff' }} />
          </View>
          {!!dur && (
            <View style={{ position: 'absolute', right: gap, bottom: gap, backgroundColor: 'rgba(0,0,0,0.7)', borderRadius: sw * 0.01, paddingHorizontal: sw * 0.012, paddingVertical: sw * 0.004 }}>
              <Text style={{ color: '#fff', fontFamily: fonts.regular, fontSize: sw * TYPE.caption }}>{dur}</Text>
            </View>
          )}
        </View>
      )}
      {!isVideo && (
        <View pointerEvents="none" style={{ position: 'absolute', left: gap, bottom: gap, backgroundColor: 'rgba(0,0,0,0.6)', borderRadius: sw * 0.01, paddingHorizontal: sw * 0.012, paddingVertical: sw * 0.004 }}>
          <Text style={{ color: '#fff', fontFamily: fonts.regular, fontSize: sw * TYPE.caption }}>{labelOf(item.source)}</Text>
        </View>
      )}
      {on && (
        <View style={[StyleSheet.absoluteFill, { borderWidth: 3, borderColor: colors.red, borderRadius: radius, backgroundColor: 'rgba(0,0,0,0.25)' }]}>
          <View style={{ position: 'absolute', top: gap * 1.5, right: gap * 1.5, width: sw * 0.07, height: sw * 0.07, borderRadius: sw * 0.035, backgroundColor: colors.red, alignItems: 'center', justifyContent: 'center' }}>
            <Icon name="check" size={sw * 0.04} color="#fff" />
          </View>
        </View>
      )}
    </Pressable>
  );
});

/**
 * Tela cheia de "Foto da web": mural em duas colunas (cada foto com a própria proporção),
 * busca por tema, abas dos bancos e seleção múltipla com botões de vidro flutuantes.
 */
export function StockPickerScreen({ visible, onClose, onPick, mode = 'photo', onPickVideos }: Props) {
  const isVideo = mode === 'video';
  /** Modo vídeo: a grade usa StockPhoto (só a capa); o vídeo de verdade fica aqui, por uid. */
  const vids = useRef<Record<string, WebVideo>>({});
  const { width: sw } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  // Segue a opção Vidro de Configurações > Aparência: desligado = painel sólido; leve/forte = translúcido.
  const bg = useBg();
  const GLASS_DARK = bg.glass === 0 ? colors.surface : bg.glass === 1 ? 'rgba(255,255,255,0.12)' : 'rgba(255,255,255,0.22)';
  const [sources, setSources] = useState<StockSource[]>([]);
  const [active, setActive] = useState<StockSource | null>(null);
  const [text, setText] = useState('');
  const [query, setQuery] = useState('');
  /** Termo em inglês realmente enviado ao banco, quando difere do que a pessoa digitou. */
  const [translated, setTranslated] = useState<string | null>(null);
  const [translating, setTranslating] = useState(false);
  const [photos, setPhotos] = useState<StockPhoto[]>([]);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [menu, setMenu] = useState(false);
  /** A seleção sobrevive à troca de banco e de busca. */
  const [picked, setPicked] = useState<Record<string, StockPhoto>>({});
  /** Descarta respostas atrasadas de buscas antigas. */
  const req = useRef(0);
  /** Modo foto: página atual e se ainda há mais resultados, por banco. */
  const srcState = useRef<Record<string, { page: number; hasMore: boolean }>>({});
  /** Quando a busca é um canal do Are.na, só esse banco responde. */
  const onlyRef = useRef<StockSource[] | null>(null);
  /** Bancos que não responderam na busca atual (mostrado como aviso discreto). */
  const [failed, setFailed] = useState<string[]>([]);

  // Recalcula a cada abertura: o usuário pode ter acabado de cadastrar uma chave.
  useEffect(() => {
    if (!visible) return;
    setPicked({});
    onlyRef.current = null;
    (isVideo ? availableVideoSources() : availableSources()).then((list) => {
      setSources(list);
      setActive((cur) => (cur && list.includes(cur) ? cur : list[0] ?? null));
    });
  }, [visible, isVideo]);

  const load = useCallback(async (source: StockSource, q: string, p: number) => {
    const id = ++req.current;
    setLoading(true);
    setError(null);
    let r: Awaited<ReturnType<typeof searchStock>>;
    if (isVideo) {
      const rv = await searchStockVideo(source, q, p);
      if (!rv.ok) r = rv;
      else {
        // Capa de cada vídeo vira uma "foto" da grade; o vídeo fica guardado à parte.
        const photos: StockPhoto[] = rv.data.videos.map((v) => {
          vids.current[v.uid] = v;
          return {
            uid: v.uid,
            source,
            width: v.width,
            height: v.height,
            sizeUnknown: !(v.width > 0 && v.height > 0),
            thumbUrl: v.poster ?? '',
            fullUrl: v.poster ?? '',
            pageUrl: v.pageUrl,
            author: v.author,
            authorUrl: v.pageUrl,
          };
        });
        r = { ok: true, data: { photos, page: rv.data.page, hasMore: rv.data.hasMore } };
      }
    } else {
      r = await searchStock(source, q, p);
    }
    if (id !== req.current) return;
    setLoading(false);
    if (!r.ok) {
      setError(r.message);
      if (p === 1) setPhotos([]);
      setHasMore(false);
      return;
    }
    setPhotos((prev) => {
      if (p === 1) return r.data.photos;
      const seen = new Set(prev.map((x) => x.uid));
      return [...prev, ...r.data.photos.filter((x) => !seen.has(x.uid))];
    });
    setPage(p);
    setHasMore(r.data.hasMore);
  }, [isVideo]);

  /** Modo foto: busca em TODOS os bancos ao mesmo tempo e intercala os resultados. */
  const loadMulti = useCallback(async (q: string, first: boolean) => {
    const id = ++req.current;
    setLoading(true);
    setError(null);
    if (first) {
      srcState.current = {};
      setFailed([]);
    }
    const pool = (onlyRef.current ?? sources).filter((s) => s !== 'link');
    const targets = pool.filter((s) => first || srcState.current[s]?.hasMore);
    if (targets.length === 0) {
      setLoading(false);
      setHasMore(false);
      return;
    }
    // Cada banco entra no mural assim que responde (sem esperar o mais lento).
    // As chegadas são agrupadas em lotes de ~120 ms para não re-renderizar o mural a cada resposta.
    let buf: StockPhoto[][] = [];
    let flushTimer: ReturnType<typeof setTimeout> | null = null;
    let shown = 0;
    let okCount = 0;
    let firstMessage = '';
    const bad: StockSource[] = [];
    const flush = () => {
      flushTimer = null;
      if (id !== req.current || buf.length === 0) return;
      const lists = buf;
      buf = [];
      const merged: StockPhoto[] = [];
      const longest = Math.max(0, ...lists.map((l) => l.length));
      for (let i = 0; i < longest; i++) for (const l of lists) if (i < l.length) merged.push(l[i]);
      shown += merged.length;
      setPhotos((prev) => {
        const base = first && prev.length === 0 ? [] : prev;
        const seen = new Set(base.map((x) => x.uid));
        return [...base, ...merged.filter((x) => !seen.has(x.uid))];
      });
    };
    await Promise.all(
      targets.map(async (s) => {
        const p = first ? 1 : (srcState.current[s]?.page ?? 1) + 1;
        // Um banco lento ou fora do ar não pode travar os outros.
        const r = await new Promise<Awaited<ReturnType<typeof searchStock>> | null>((resolve) => {
          const t = setTimeout(() => resolve(null), SOURCE_TIMEOUT_MS);
          searchStock(s, q, p).then(
            (v) => { clearTimeout(t); resolve(v); },
            () => { clearTimeout(t); resolve(null); },
          );
        });
        if (id !== req.current) return;
        if (r && r.ok) {
          srcState.current[s] = { page: p, hasMore: r.data.hasMore };
          okCount++;
          if (r.data.photos.length > 0) {
            buf.push(r.data.photos);
            // Primeiro resultado aparece na hora; os seguintes entram em lote.
            if (shown === 0 && !flushTimer) flush();
            else if (!flushTimer) flushTimer = setTimeout(flush, 120);
          }
        } else {
          srcState.current[s] = { page: p, hasMore: false };
          bad.push(s);
          if (!firstMessage && r && !r.ok) firstMessage = r.message;
        }
      }),
    );
    if (id !== req.current) return;
    if (flushTimer) clearTimeout(flushTimer);
    flush();
    setLoading(false);
    if (first && okCount === 0) {
      setError(firstMessage || 'Nenhum banco respondeu. Confira a conexão e tente de novo.');
      setPhotos([]);
      setHasMore(false);
      return;
    }
    setFailed(bad.length > 0 ? bad.map(labelOf) : []);
    setHasMore(Object.values(srcState.current).some((x) => x.hasMore));
  }, [sources]);

  // Busca mudou (ou os bancos ficaram prontos): recomeça da página 1.
  useEffect(() => {
    if (!visible) return;
    if (isVideo) {
      if (!active) return;
      setPhotos([]);
      setHasMore(false);
      load(active, query, 1);
      return;
    }
    if (sources.length === 0) return;
    setPhotos([]);
    setHasMore(false);
    loadMulti(query, true);
  }, [visible, isVideo, active, query, load, loadMulti, sources]);

  const submit = async () => {
    Keyboard.dismiss();
    const typed = text.trim();
    // Foto: endereço de página (Cosmos, Dupe...) continua pegando a imagem de destaque do link.
    const isLink = isVideo ? active === 'link' : /^(https?:\/\/|www\.)/i.test(typed) && !/are\.na\//i.test(typed);
    if (isLink) {
      // Cosmos, Dupe etc.: sem busca. Pega a imagem de destaque da página do link colado.
      setTranslated(null);
      const url = normalizeUrl(typed);
      setPhotos([]);
      if (!url) return setError('Cole o endereço completo da foto (começa com http).');
      setError(null);
      setLoading(true);
      const pv = await fetchPreviewText(url);
      setLoading(false);
      if (!pv?.imageUrl) return setError('Não encontrei uma imagem nesse link. Alguns sites bloqueiam isso ou exigem login.');
      setPhotos([
        {
          uid: `link:${url}`,
          source: 'link',
          width: 800,
          height: 800,
          sizeUnknown: true,
          thumbUrl: pv.imageUrl,
          fullUrl: pv.imageUrl,
          pageUrl: url,
          author: pv.site || domainOf(url),
          authorUrl: url,
        },
      ]);
      return;
    }
    // Link de canal do Are.na: só o Are.na responde, sem traduzir.
    const arenaOnly = !isVideo && /are\.na\//i.test(typed);
    onlyRef.current = arenaOnly ? ['arena'] : null;
    let q = typed;
    if (!arenaOnly) {
      setTranslating(true);
      q = await translateQuery(typed);
      setTranslating(false);
    }
    setTranslated(q && q.toLowerCase() !== typed.toLowerCase() ? q : null);
    if (q === query) {
      if (isVideo) active && load(active, q, 1);
      else loadMulti(q, true);
    } else setQuery(q);
  };

  const more = () => {
    if (!hasMore || loading) return;
    if (isVideo) active && load(active, query, page + 1);
    else loadMulti(query, false);
  };

  const onScroll = (e: NativeSyntheticEvent<NativeScrollEvent>) => {
    const { layoutMeasurement, contentOffset, contentSize } = e.nativeEvent;
    if (contentOffset.y + layoutMeasurement.height >= contentSize.height - layoutMeasurement.height * 0.8) more();
  };

  const toggle = useCallback((p: StockPhoto) =>
    setPicked((cur) => {
      const next = { ...cur };
      if (next[p.uid]) delete next[p.uid];
      else next[p.uid] = p;
      return next;
    }), []);

  const count = Object.keys(picked).length;
  const missing = STOCK_SOURCES.filter((s) => (isVideo ? s.id === 'pexels' : s.needsKey) && s.needsKey && !sources.includes(s.id));
  const side = sw * SPACE.lg;
  const gap = sw * 0.02;
  const cell = (sw - side * 2 - gap) / 2;
  const radius = sw * RADIUS.dialog * 0.7;

  // Mural: cada foto vai para a coluna mais baixa; a ordem é estável quando chegam mais fotos.
  const columns = useMemo(() => {
    const a: StockPhoto[] = [];
    const b: StockPhoto[] = [];
    let ha = 0;
    let hb = 0;
    for (const p of photos) {
      if (ha <= hb) {
        a.push(p);
        ha += ratioOf(p);
      } else {
        b.push(p);
        hb += ratioOf(p);
      }
    }
    return [a, b];
  }, [photos]);

  const empty = !loading && !error && photos.length === 0;
  const noTrending = isVideo ? !!active && NO_TRENDING.includes(active) && !query : false;
  const title = query ? query : isVideo ? 'Vídeos da web' : 'Fotos da web';

  return (
    <Modal visible={visible} animationType="slide" statusBarTranslucent onRequestClose={onClose}>
      <View style={styles.root}>
        <Background />
        <ScreenHeader
          onBack={onClose}
          crumb={photos.length > 0 ? `${photos.length} ${isVideo ? 'vídeos' : 'fotos'}` : undefined}
          title={title}
          right={<IconButton icon="more" label="Mais opções" onPress={() => setMenu(true)} />}
        />

        {/* Abas dos bancos, em pílulas de vidro (só vídeo; foto busca em todos de uma vez) */}
        {isVideo && <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ flexGrow: 0 }} contentContainerStyle={{ paddingHorizontal: side, gap: sw * SPACE.sm, paddingVertical: sw * SPACE.xs }}>
          {sources.map((id) => {
            const on = id === active;
            return (
              <Pressable
                key={id}
                onPress={() => setActive(id)}
                accessibilityRole="button"
                accessibilityState={{ selected: on }}
                style={{
                  minHeight: MIN_TOUCH * 0.8,
                  justifyContent: 'center',
                  paddingHorizontal: sw * SPACE.lg,
                  borderRadius: sw * RADIUS.pill,
                  backgroundColor: on ? colors.glass : GLASS_DARK,
                }}
              >
                <Text style={{ color: on ? colors.onLight : colors.text, fontFamily: on ? fonts.bold : fonts.regular, fontSize: sw * TYPE.label }}>{labelOf(id)}</Text>
              </Pressable>
            );
          })}
        </ScrollView>}

        {/* Busca em pílula */}
        <View style={{ marginHorizontal: side, marginTop: sw * SPACE.sm, flexDirection: 'row', alignItems: 'center', backgroundColor: GLASS_DARK, borderRadius: sw * RADIUS.pill, paddingLeft: sw * SPACE.lg, paddingRight: sw * SPACE.lg, gap: sw * SPACE.md }}>
          <TextInput
            value={text}
            onChangeText={setText}
            onSubmitEditing={submit}
            returnKeyType="search"
            autoCapitalize="none"
            autoCorrect={false}
            accessibilityLabel={isVideo ? 'Buscar vídeos' : 'Buscar fotos'}
            placeholder={isVideo ? (active === 'nasa' ? 'Buscar (ex.: launch)' : 'Buscar (ex.: ocean waves) ou deixe vazio') : 'Buscar em todos os bancos (ex.: beach), ou cole um link'}
            placeholderTextColor={colors.muted}
            style={{ flex: 1, minHeight: MIN_TOUCH, color: colors.text, fontFamily: fonts.regular, fontSize: sw * TYPE.body }}
          />
          <Pressable onPress={submit} disabled={translating} hitSlop={12} accessibilityRole="button" accessibilityLabel="Buscar">
            {translating ? <ActivityIndicator color={colors.red} /> : <Text style={{ color: colors.red, fontFamily: fonts.bold, fontSize: sw * TYPE.body }}>Buscar</Text>}
          </Pressable>
        </View>
        {translated && (
          <Text style={{ paddingHorizontal: side + sw * SPACE.sm, marginTop: sw * SPACE.xs, color: colors.mutedLight, fontFamily: fonts.regular, fontSize: sw * TYPE.caption }}>
            {`Buscando por “${translated}”`}
          </Text>
        )}

        <ScrollView
          style={{ flex: 1, marginTop: sw * SPACE.md }}
          contentContainerStyle={{ paddingHorizontal: side, paddingBottom: (count > 0 ? sw * 0.25 : 0) + insets.bottom + sw * SPACE.xl }}
          keyboardShouldPersistTaps="handled"
          keyboardDismissMode="on-drag"
          onScroll={onScroll}
          scrollEventThrottle={120}
          showsVerticalScrollIndicator={false}
        >
          {error ? (
            <View style={{ marginBottom: sw * SPACE.md }}>
              <StateMessage kind="error">{error}</StateMessage>
              {(isVideo ? active !== 'link' : true) && (
                <Pressable onPress={() => (isVideo ? active && load(active, query, 1) : loadMulti(query, true))} accessibilityRole="button" style={{ minHeight: MIN_TOUCH, justifyContent: 'center' }}>
                  <Text style={{ color: colors.red, fontFamily: fonts.bold, fontSize: sw * TYPE.body }}>Tentar de novo</Text>
                </Pressable>
              )}
            </View>
          ) : empty ? (
            <StateMessage kind="empty">
              {!isVideo
                ? sources.length === 0
                  ? 'Nenhum banco disponível.'
                  : query
                    ? 'Nenhuma foto encontrada em nenhum banco.'
                    : 'Digite um tema e toque em Buscar para pesquisar em todos os bancos de uma vez.'
                : noTrending
                ? active === 'link'
                  ? 'Cole o link de uma foto do Cosmos, do Dupe ou de outro site e toque em Buscar.'
                  : active === 'arena'
                    ? 'Cole o link de um canal do Are.na (are.na/usuario/canal) e toque em Buscar. Conta Premium também busca por tema.'
                    : `${labelOf(active!)} não tem ${isVideo ? 'vídeos' : 'fotos'} em alta. Digite um tema para buscar.`
                : active
                  ? isVideo ? 'Nenhum vídeo encontrado.' : 'Nenhuma foto encontrada.'
                  : isVideo ? 'Nenhum banco de vídeo disponível. Cadastre a chave do Pexels em Configurações.' : 'Nenhum banco disponível.'}
            </StateMessage>
          ) : null}

          <View style={{ flexDirection: 'row', gap }}>
            {columns.map((col, i) => (
              <View key={i} style={{ width: cell }}>
                {col.map((item) => (
                  <Tile
                    key={item.uid}
                    item={item}
                    on={!!picked[item.uid]}
                    isVideo={isVideo}
                    duration={isVideo ? vids.current[item.uid]?.duration ?? null : null}
                    cell={cell}
                    gap={gap}
                    radius={radius}
                    sw={sw}
                    glass={GLASS_DARK}
                    onToggle={toggle}
                  />
                ))}
              </View>
            ))}
          </View>

          {!loading && !isVideo && failed.length > 0 && photos.length > 0 && (
            <Text style={{ marginTop: sw * SPACE.sm, color: colors.muted, fontFamily: fonts.regular, fontSize: sw * TYPE.caption, lineHeight: sw * TYPE.caption * LEADING }}>
              {`Sem resposta: ${failed.join(', ')}.`}
            </Text>
          )}
          {loading && (
            <View style={{ paddingVertical: sw * SPACE.xl }}>
              <ActivityIndicator color={colors.text} />
            </View>
          )}
          {!loading && missing.length > 0 && photos.length === 0 && !error && (
            <Text style={{ marginTop: sw * SPACE.lg, color: colors.muted, fontFamily: fonts.regular, fontSize: sw * TYPE.caption, lineHeight: sw * TYPE.caption * LEADING }}>
              {`Sem chave: ${missing.map((s) => s.label).join(', ')}. Cadastre em Configurações para ativar.`}
            </Text>
          )}
        </ScrollView>

        {/* Botões de vidro flutuantes, como no mural de referência */}
        {count > 0 && (
          <View pointerEvents="box-none" style={{ position: 'absolute', left: side, right: side, bottom: insets.bottom + sw * SPACE.md, flexDirection: 'row', justifyContent: 'center', gap: sw * SPACE.md }}>
            <Pressable
              onPress={() => setPicked({})}
              accessibilityRole="button"
              accessibilityLabel="Limpar seleção"
              style={{ minHeight: MIN_TOUCH, flexDirection: 'row', alignItems: 'center', gap: sw * SPACE.sm, paddingHorizontal: sw * SPACE.xl, borderRadius: sw * RADIUS.pill, backgroundColor: colors.glass, borderWidth: 1, borderColor: colors.glassLine }}
            >
              <Icon name="close" size={sw * 0.035} color={colors.onLight} />
              <Text style={{ color: colors.onLight, fontFamily: fonts.bold, fontSize: sw * TYPE.body }}>{count}</Text>
            </Pressable>
            <Pressable
              onPress={() => {
                const list = Object.values(picked);
                if (isVideo) onPickVideos?.(list.map((p) => vids.current[p.uid]).filter(Boolean));
                else onPick(list);
              }}
              accessibilityRole="button"
              style={{ minHeight: MIN_TOUCH, justifyContent: 'center', paddingHorizontal: sw * SPACE.xl, borderRadius: sw * RADIUS.pill, backgroundColor: colors.red }}
            >
              <Text style={{ color: '#fff', fontFamily: fonts.bold, fontSize: sw * TYPE.body }}>{isVideo ? (count === 1 ? 'Adicionar 1 vídeo' : `Adicionar ${count} vídeos`) : count === 1 ? 'Adicionar 1 foto' : `Adicionar ${count} fotos`}</Text>
            </Pressable>
          </View>
        )}

        <ActionMenu
          visible={menu}
          onClose={() => setMenu(false)}
          title={isVideo ? 'Vídeos da web' : 'Fotos da web'}
          items={[
            { key: 'all', label: 'Selecionar todas as visíveis', disabled: photos.length === 0, onPress: () => setPicked((cur) => ({ ...cur, ...Object.fromEntries(photos.map((p) => [p.uid, p])) })) },
            { key: 'clear', label: 'Limpar seleção', disabled: count === 0, onPress: () => setPicked({}) },
          ]}
        />
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
});
