import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { setAudioModeAsync, useAudioPlayer, useAudioPlayerStatus } from 'expo-audio';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  AudioItem,
  Block,
  deleteAudio,
  getBlock,
  listAudios,
  moveAudio,
  renameAudio,
} from './db';
import { formatDate, formatDuration } from './format';
import { PromptDialog } from './PromptDialog';
import { audioUri } from './storage';
import { SelectorHandle, SelectorList, SelItem } from './SelectorList';
import { colors, fonts } from './theme';

type Props = {
  blockId: number;
  version: number;
  onBack: () => void;
  onChanged: () => void;
};

export function BlockScreen({ blockId, version, onBack, onChanged }: Props) {
  const { width: sw } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const [block, setBlock] = useState<Block | null>(null);
  const [audios, setAudios] = useState<AudioItem[] | null>(null);
  const [focus, setFocus] = useState(0);
  const [renaming, setRenaming] = useState(false);
  const listRef = useRef<SelectorHandle>(null);

  const player = useAudioPlayer();
  const status = useAudioPlayerStatus(player);
  const loadedId = useRef<number | null>(null);

  const load = useCallback(async () => {
    const [b, a] = await Promise.all([getBlock(blockId), listAudios(blockId)]);
    setBlock(b);
    setAudios(a);
  }, [blockId]);

  useEffect(() => {
    load().catch((e) => Alert.alert('Erro ao abrir o item', String(e)));
  }, [load, version]);

  useEffect(() => {
    setAudioModeAsync({ playsInSilentMode: true, allowsRecording: false }).catch(() => {});
  }, []);

  const current: AudioItem | undefined = audios?.[Math.min(focus, (audios?.length ?? 1) - 1)];

  // Ao trocar o áudio em foco, para a reprodução.
  useEffect(() => {
    if (loadedId.current !== null && loadedId.current !== current?.id) {
      try {
        player.pause();
      } catch {}
    }
  }, [current?.id, player]);

  // Ao terminar, volta ao início.
  useEffect(() => {
    if (status.didJustFinish) {
      try {
        player.seekTo(0);
      } catch {}
    }
  }, [status.didJustFinish, player]);

  const items: SelItem[] = useMemo(
    () =>
      (audios ?? []).map((a) => ({
        id: a.id,
        title: a.name,
        subtitle: `${formatDate(a.createdAt)}  ·  ${formatDuration(a.durationMs)}`,
      })),
    [audios]
  );

  const togglePlay = () => {
    if (!current) return;
    try {
      if (loadedId.current === current.id && status.playing) {
        player.pause();
        return;
      }
      if (loadedId.current !== current.id) {
        player.replace({ uri: audioUri(current.fileName) });
        loadedId.current = current.id;
      }
      player.play();
    } catch (e) {
      Alert.alert('Não foi possível reproduzir', String(e));
    }
  };

  const confirmDelete = () => {
    if (!current) return;
    Alert.alert('Apagar áudio?', `"${current.name}" será apagado do celular.`, [
      { text: 'Cancelar', style: 'cancel' },
      {
        text: 'Apagar',
        style: 'destructive',
        onPress: async () => {
          try {
            player.pause();
          } catch {}
          loadedId.current = null;
          await deleteAudio(current.id);
          setFocus((f) => Math.max(0, f - 1));
          onChanged();
        },
      },
    ]);
  };

  const move = async (dir: -1 | 1) => {
    if (!current || !audios) return;
    const idx = audios.findIndex((a) => a.id === current.id);
    const target = idx + dir;
    if (target < 0 || target >= audios.length) return;
    await moveAudio(blockId, current.id, dir);
    await load();
    onChanged();
    setTimeout(() => listRef.current?.scrollToIndex(target, true), 60);
  };

  if (!block || !audios) return <View style={styles.flex} />;

  const playing = loadedId.current === current?.id && status.playing;
  const pos = loadedId.current === current?.id ? status.currentTime : 0;
  const dur = current ? current.durationMs / 1000 : 0;
  const btn = sw * 0.05;

  return (
    <View style={styles.flex}>
      <View style={{ paddingTop: insets.top + sw * 0.05, paddingHorizontal: sw * 0.0587 }}>
        <Pressable onPress={onBack} hitSlop={16}>
          <Text style={{ color: colors.gray, fontFamily: fonts.regular, fontSize: btn }}>‹ Voltar</Text>
        </Pressable>
        <Pressable onPress={() => setRenaming(true)}>
          <Text
            numberOfLines={1}
            style={{
              color: colors.text,
              fontFamily: fonts.bold,
              fontSize: sw * 0.09,
              letterSpacing: -sw * 0.09 * 0.045,
              marginTop: sw * 0.04,
            }}
          >
            {block.name}
          </Text>
        </Pressable>
        <Text style={{ color: colors.gray, fontFamily: fonts.light, fontSize: sw * 0.046 }}>
          {formatDate(block.createdAt)}
        </Text>
      </View>

      <SelectorList
        key={audios.length === 0 ? 'empty' : 'list'}
        ref={listRef}
        data={items}
        emptyText="Nenhum áudio neste item ainda. Use “Selecionar Nota” na aba Gravação."
        onFocusIndex={setFocus}
        onPressFocused={togglePlay}
        onLongPressFocused={() => setRenaming(true)}
      />

      {current && (
        <View style={{ paddingHorizontal: sw * 0.0587, paddingBottom: sw * 0.03 }}>
          <View style={styles.rowBetween}>
            <Pressable onPress={togglePlay} style={[styles.play, { borderRadius: sw * 0.074 }]}>
              <Text style={{ color: '#000', fontFamily: fonts.black, fontSize: sw * 0.055 }}>
                {playing ? 'Pausar' : 'Ouvir'}
              </Text>
            </Pressable>
            <Text
              style={{
                color: colors.gray,
                fontFamily: fonts.light,
                fontSize: btn,
                fontVariant: ['tabular-nums'],
              }}
            >
              {formatDuration(pos * 1000)} / {formatDuration(dur * 1000)}
            </Text>
          </View>
          <View style={[styles.rowBetween, { marginTop: sw * 0.05 }]}>
            <Pressable onPress={() => setRenaming(true)} hitSlop={10}>
              <Text style={[styles.action, { fontSize: btn }]}>Renomear</Text>
            </Pressable>
            <Pressable onPress={() => move(-1)} hitSlop={10}>
              <Text style={[styles.action, { fontSize: btn }]}>Subir</Text>
            </Pressable>
            <Pressable onPress={() => move(1)} hitSlop={10}>
              <Text style={[styles.action, { fontSize: btn }]}>Descer</Text>
            </Pressable>
            <Pressable onPress={confirmDelete} hitSlop={10}>
              <Text style={[styles.action, { fontSize: btn, color: colors.red }]}>Apagar</Text>
            </Pressable>
          </View>
        </View>
      )}

      <PromptDialog
        visible={renaming}
        title={current ? 'Renomear áudio' : 'Renomear item'}
        initialValue={current ? current.name : block.name}
        onCancel={() => setRenaming(false)}
        onSubmit={async (value) => {
          if (current) await renameAudio(current.id, value);
          setRenaming(false);
          onChanged();
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: colors.bg },
  rowBetween: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  play: {
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 28,
    paddingVertical: 12,
  },
  action: { color: colors.text, fontFamily: fonts.regular, letterSpacing: -0.5 },
});
