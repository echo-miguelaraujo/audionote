import React from 'react';
import { Dimensions, Text, View } from 'react-native';
import { Button } from './Button';
import { colors, fonts, SPACE, TYPE } from './theme';

/** Erro de desenho numa tela mostra um aviso com "Tentar de novo", em vez de fechar o app. */
export class ErrorBoundary extends React.Component<{ children: React.ReactNode }, { err: string | null }> {
  state = { err: null as string | null };

  static getDerivedStateFromError(e: unknown) {
    return { err: String((e as any)?.stack ?? e) };
  }

  render() {
    if (this.state.err === null) return this.props.children;
    // Componente de classe: sem hooks, então a largura vem de Dimensions.
    const sw = Dimensions.get('window').width;
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: sw * SPACE.lg, backgroundColor: colors.paper }}>
        <Text style={{ color: colors.onLight, fontFamily: fonts.bold, fontSize: sw * TYPE.subtitle, marginBottom: sw * SPACE.sm }}>
          Algo deu errado nesta tela
        </Text>
        <Text
          style={{ color: colors.subtle, fontFamily: fonts.regular, fontSize: sw * TYPE.caption, marginBottom: sw * SPACE.md }}
          numberOfLines={12}
        >
          {this.state.err}
        </Text>
        <Button variant="destructive" size="compact" label="Tentar de novo" onPress={() => this.setState({ err: null })} />
      </View>
    );
  }
}
