import React from 'react';
import { Pressable, Text, View } from 'react-native';

/** Erro de desenho numa tela mostra um aviso com "Tentar de novo", em vez de fechar o app. */
export class ErrorBoundary extends React.Component<{ children: React.ReactNode }, { err: string | null }> {
  state = { err: null as string | null };

  static getDerivedStateFromError(e: unknown) {
    return { err: String((e as any)?.stack ?? e) };
  }

  render() {
    if (this.state.err === null) return this.props.children;
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24, backgroundColor: '#fff' }}>
        <Text style={{ fontSize: 18, fontWeight: '700', marginBottom: 8 }}>Algo deu errado nesta tela</Text>
        <Text style={{ fontSize: 11, color: '#666', marginBottom: 16 }} numberOfLines={12}>
          {this.state.err}
        </Text>
        <Pressable onPress={() => this.setState({ err: null })} style={{ backgroundColor: '#FF3030', borderRadius: 24, paddingHorizontal: 24, paddingVertical: 12 }}>
          <Text style={{ color: '#fff', fontWeight: '700' }}>Tentar de novo</Text>
        </Pressable>
      </View>
    );
  }
}
