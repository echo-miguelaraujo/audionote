import React from 'react';
import { Text, View } from 'react-native';
import { Button } from './Button';
import { colors } from './theme';

/** Erro de desenho numa tela mostra um aviso com "Tentar de novo", em vez de fechar o app. */
export class ErrorBoundary extends React.Component<{ children: React.ReactNode }, { err: string | null }> {
  state = { err: null as string | null };

  static getDerivedStateFromError(e: unknown) {
    return { err: String((e as any)?.stack ?? e) };
  }

  render() {
    if (this.state.err === null) return this.props.children;
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24, backgroundColor: colors.paper }}>
        <Text style={{ fontSize: 18, fontWeight: '700', marginBottom: 8 }}>Algo deu errado nesta tela</Text>
        <Text style={{ fontSize: 11, color: colors.subtle, marginBottom: 16 }} numberOfLines={12}>
          {this.state.err}
        </Text>
        <Button variant="destructive" size="compact" label="Tentar de novo" onPress={() => this.setState({ err: null })} />
      </View>
    );
  }
}
