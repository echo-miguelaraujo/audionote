/**
 * Modelo da nota (v2): um texto único em HTML (como no Notion), com capa e título.
 * Notas antigas (v1, divididas em tópicos e frases) são convertidas ao abrir.
 */
export type Note = { v: 2; title: string; cover: string | null; html: string };

let counter = 0;
export const uid = (): string =>
  `${Date.now().toString(36)}${(counter++).toString(36)}${Math.random().toString(36).slice(2, 6)}`;

export const emptyNote = (): Note => ({ v: 2, title: '', cover: null, html: '' });

export const escapeHtml = (s: string): string =>
  s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

/** Texto puro de um trecho de HTML (para prévia e Biblioteca). */
export function htmlToText(html: string): string {
  return html
    .replace(/<(script|style)[\s\S]*?<\/\1>/gi, ' ')
    // Elementos só de interface (data-ui) e o carimbo "gerado pela IA" não entram na prévia nem na busca.
    .replace(/<(\w+)\b[^>]*\bdata-ui="1"[^>]*>[\s\S]*?<\/\1>/gi, ' ')
    .replace(/<div\b[^>]*class="[^"]*\bai-h\b[^"]*"[^>]*>[\s\S]*?<\/div>/gi, ' ')
    .replace(/<(br|\/p|\/div|\/li|\/h[1-6]|\/tr|\/blockquote)\s*\/?>/gi, '\n')
    .replace(/<[^>]+>/g, '')
    .replace(/&nbsp;/g, ' ')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&amp;/g, '&')
    .replace(/[ \t]+/g, ' ')
    .replace(/\n\s*\n+/g, '\n')
    .trim();
}

type RunV1 = { t: string; b?: boolean; i?: boolean; c?: string };

function runsToHtml(runs: RunV1[]): string {
  return runs
    .map((r) => {
      let h = escapeHtml(r.t);
      if (r.c) h = `<span style="color:${escapeHtml(r.c)}">${h}</span>`;
      if (r.i) h = `<i>${h}</i>`;
      if (r.b) h = `<b>${h}</b>`;
      return h;
    })
    .join('');
}

/** v1 (tópicos + frases) -> HTML: cada tópico vira um subtítulo (h2) e cada frase um parágrafo. */
function migrateV1(raw: any): Note {
  let html = '';
  for (const t of Array.isArray(raw.topics) ? raw.topics : []) {
    if (typeof t?.title === 'string' && t.title.trim()) html += `<h2>${escapeHtml(t.title.trim())}</h2>`;
    for (const s of Array.isArray(t?.sentences) ? t.sentences : []) {
      const runs: RunV1[] = (Array.isArray(s?.runs) ? s.runs : []).filter(
        (r: any) => r && typeof r.t === 'string'
      );
      const inner = runsToHtml(runs);
      if (inner.trim()) html += `<p>${inner}</p>`;
    }
  }
  return { v: 2, title: typeof raw.title === 'string' ? raw.title : '', cover: null, html };
}

export function parseNote(json: string | null): Note | null {
  if (!json) return null;
  try {
    const raw = JSON.parse(json);
    if (!raw || typeof raw !== 'object') return null;
    if (raw.v === 2 && typeof raw.html === 'string') {
      return {
        v: 2,
        title: typeof raw.title === 'string' ? raw.title : '',
        cover: typeof raw.cover === 'string' && raw.cover ? raw.cover : null,
        html: raw.html,
      };
    }
    if (Array.isArray(raw.topics)) return migrateV1(raw);
    return null;
  } catch {
    return null;
  }
}

export function noteText(n: Note | null): string {
  return n ? htmlToText(n.html) : '';
}

export function noteIsEmpty(n: Note | null): boolean {
  if (!n) return true;
  return !n.title.trim() && !n.cover && !noteText(n) && !/<(img|video|iframe|table|hr)\b/i.test(n.html);
}

export function notePreview(n: Note | null): string {
  const t = noteText(n);
  return t ? t.split('\n')[0].slice(0, 200) : '';
}

/** Título mostrado na Biblioteca: título da nota, ou o primeiro título (h1–h5) do texto. */
export function noteDisplayTitle(n: Note | null): string {
  if (!n) return '';
  if (n.title.trim()) return n.title.trim();
  const m = n.html.match(/<h[1-5][^>]*>([\s\S]*?)<\/h[1-5]>/i);
  return m ? htmlToText(m[1]).split('\n')[0].trim() : '';
}

/** Índice da nota: os títulos (h1–h5) do texto, sem repetir o título do cartão. */
export function noteOutline(n: Note | null, skip = ''): string[] {
  if (!n) return [];
  const out: string[] = [];
  const skipN = skip.trim().toLowerCase();
  for (const m of n.html.matchAll(/<h[1-5][^>]*>([\s\S]*?)<\/h[1-5]>/gi)) {
    const t = htmlToText(m[1]).split('\n')[0].trim();
    if (t && t.toLowerCase() !== skipN) out.push(t.slice(0, 80));
  }
  return out.slice(0, 8);
}

/**
 * Acrescenta o texto transcrito ao fim da nota, como parágrafos.
 * O texto entra exatamente como veio da transcrição: nada é reescrito nem criado.
 */
export function appendTranscript(note: Note, text: string): Note {
  const paras = textToHtml(text);
  if (!paras) return note;
  return { ...note, html: note.html + paras };
}

const norm = (t: string) => htmlToText(t).toLowerCase().replace(/\s+/g, ' ').trim();

/** Títulos (h1–h5) que a nota já tem, para a IA reaproveitar o assunto certo. */
export function noteHeadings(n: Note): string[] {
  const out: string[] = [];
  for (const m of n.html.matchAll(/<h[1-5][^>]*>([\s\S]*?)<\/h[1-5]>/gi)) {
    const t = htmlToText(m[1]).split('\n')[0].trim();
    if (t) out.push(t);
  }
  return out.slice(-40);
}

/**
 * Texto da IA -> HTML. Linhas com "> " viram citação (linhas seguidas ficam numa citação só).
 * Linhas com marcador viram listas (itens seguidos do mesmo tipo ficam juntos):
 *   "- item"  -> lista com marcadores     "1. item" -> lista numerada
 *   "[ ] item" / "[x] item" -> lista de tarefas (marcada ou não)
 * Qualquer outra linha vira um parágrafo.
 */
const LIST_LINE = /^\s*(?:\[( |x|X)\]\s+|[-•*]\s+|\d{1,3}[.)]\s+)(\S.*)$/;
const QUOTE_LINE = /^\s*>\s?(\S.*)$/;

export function textToHtml(text: string): string {
  let html = '';
  let open: 'ul' | 'ol' | 'todo' | null = null;
  let quote: string[] = [];
  const close = () => {
    if (open) html += open === 'ol' ? '</ol>' : '</ul>';
    open = null;
  };
  const flushQuote = () => {
    if (quote.length) html += `<blockquote>${escapeHtml(quote.join(' '))}</blockquote>`;
    quote = [];
  };
  for (const raw of text.split(/\n+/)) {
    const line = raw.trim();
    if (!line) continue;
    const q = QUOTE_LINE.exec(line);
    if (q) {
      close();
      quote.push(q[1].trim());
      continue;
    }
    flushQuote();
    const m = LIST_LINE.exec(line);
    if (!m) {
      close();
      html += `<p>${escapeHtml(line)}</p>`;
      continue;
    }
    const kind: 'ul' | 'ol' | 'todo' = m[1] !== undefined ? 'todo' : /^\s*\d/.test(line) ? 'ol' : 'ul';
    if (open !== kind) {
      close();
      html += kind === 'ol' ? '<ol>' : kind === 'todo' ? '<ul class="todo">' : '<ul>';
      open = kind;
    }
    const done = kind === 'todo' ? ` data-done="${m[1] !== ' ' ? 'true' : 'false'}"` : '';
    html += `<li${done}>${escapeHtml(m[2].trim())}</li>`;
  }
  flushQuote();
  close();
  return html;
}

/**
 * Encaixa as seções da transcrição na nota: se o subtítulo já existe, o texto entra no fim
 * daquele assunto; senão, cria um novo subtítulo (h2) no fim da nota. O corpo é sempre a fala fiel.
 */
export function appendSections(note: Note, sections: { heading: string; text: string }[]): Note {
  let html = note.html;
  for (const sec of sections) {
    const body = textToHtml(sec.text);
    if (!body) continue;
    const heading = sec.heading.trim();
    if (!heading) {
      html += body;
      continue;
    }
    const hs = Array.from(html.matchAll(/<h[1-5][^>]*>([\s\S]*?)<\/h[1-5]>/gi));
    const idx = hs.findIndex((m) => norm(m[1]) === norm(heading));
    if (idx >= 0) {
      const next = hs[idx + 1];
      const at = next && next.index !== undefined ? next.index : html.length;
      html = html.slice(0, at) + body + html.slice(at);
    } else {
      html += `<h2>${escapeHtml(heading)}</h2>${body}`;
    }
  }
  return { ...note, html };
}
