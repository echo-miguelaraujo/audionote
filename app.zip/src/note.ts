import { Run, normalize, plain } from './richtext';

export type Sentence = { id: string; runs: Run[] };
export type Topic = { id: string; title: string; sentences: Sentence[] };
export type Note = { v: 1; title: string; topics: Topic[] };

let counter = 0;
export const uid = (): string =>
  `${Date.now().toString(36)}${(counter++).toString(36)}${Math.random().toString(36).slice(2, 6)}`;

export const emptyNote = (): Note => ({ v: 1, title: '', topics: [] });

export const makeSentence = (text: string): Sentence => ({
  id: uid(),
  runs: normalize([{ t: text }]),
});

export const sentenceText = (s: Sentence): string => plain(s.runs);

export function parseNote(json: string | null): Note | null {
  if (!json) return null;
  try {
    const raw = JSON.parse(json);
    if (!raw || typeof raw !== 'object' || !Array.isArray(raw.topics)) return null;
    const topics: Topic[] = raw.topics.map((t: any) => ({
      id: typeof t?.id === 'string' ? t.id : uid(),
      title: typeof t?.title === 'string' ? t.title : '',
      sentences: (Array.isArray(t?.sentences) ? t.sentences : []).map((s: any) => ({
        id: typeof s?.id === 'string' ? s.id : uid(),
        runs: normalize(
          (Array.isArray(s?.runs) ? s.runs : [])
            .filter((r: any) => r && typeof r.t === 'string')
            .map((r: any) => ({ t: r.t, b: !!r.b || undefined, i: !!r.i || undefined, c: r.c || undefined }))
        ),
      })),
    }));
    return { v: 1, title: typeof raw.title === 'string' ? raw.title : '', topics };
  } catch {
    return null;
  }
}

export function noteIsEmpty(n: Note | null): boolean {
  if (!n) return true;
  return !n.title.trim() && n.topics.every((t) => !t.title.trim() && t.sentences.length === 0);
}

export function notePreview(n: Note | null): string {
  if (!n) return '';
  for (const t of n.topics) {
    for (const s of t.sentences) {
      const tx = sentenceText(s).trim();
      if (tx) return tx;
    }
  }
  return '';
}

export type Placement = {
  topic_id: string | null;
  new_topic_title: string | null;
  sentences: string[];
};
export type OrganizerResult = { note_title?: string; placements: Placement[] };

/** Encaixa o resultado da IA na nota sem reescrever o que já existe. */
export function applyOrganizer(note: Note, res: OrganizerResult): Note {
  const topics: Topic[] = note.topics.map((t) => ({ ...t, sentences: [...t.sentences] }));
  for (const pl of res.placements) {
    const texts = (pl.sentences ?? []).map((s) => String(s).trim()).filter(Boolean);
    if (texts.length === 0) continue;
    const found = pl.topic_id ? topics.find((t) => t.id === pl.topic_id) : undefined;
    if (found) {
      texts.forEach((tx) => found.sentences.push(makeSentence(tx)));
    } else {
      const title = (pl.new_topic_title ?? '').trim() || 'Ideias';
      const existing = topics.find((t) => t.title.trim().toLowerCase() === title.toLowerCase());
      if (existing) texts.forEach((tx) => existing.sentences.push(makeSentence(tx)));
      else topics.push({ id: uid(), title, sentences: texts.map(makeSentence) });
    }
  }
  const title = note.title.trim() ? note.title : (res.note_title ?? '').trim();
  return { v: 1, title, topics };
}
