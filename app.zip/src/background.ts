import { getBgTheme, setBgTheme } from './settings';

/** 0 = menos, 1 = médio, 2 = mais. */
export type Level = 0 | 1 | 2;
export type Trio = [string, string, string];

export type BgSettings = {
  /** id de um dos PRESETS, ou 'custom' (usa `colors`). */
  preset: string;
  /** Cores escolhidas pelo usuário (usadas quando preset = 'custom'). */
  colors: Trio;
  intensity: Level;
  glass: Level;
};

export type Preset = { id: string; name: string; colors: Trio };

export const PRESETS: Preset[] = [
  { id: 'aurora', name: 'Aurora', colors: ['#7B3FE4', '#E0368A', '#F2B31B'] },
  { id: 'fogo', name: 'Fogo', colors: ['#FF3030', '#FF8A00', '#9B1FD1'] },
  { id: 'oceano', name: 'Oceano', colors: ['#0A5CFF', '#00C2C7', '#7A4DFF'] },
  { id: 'neon', name: 'Neon', colors: ['#C3FF6B', '#22D07A', '#F0F23C'] },
  { id: 'rosa', name: 'Rosa', colors: ['#FF4FA3', '#B24DFF', '#FF9A3D'] },
  { id: 'preto', name: 'Preto', colors: ['#000000', '#000000', '#000000'] },
];

export const DEFAULT_BG: BgSettings = {
  preset: 'aurora',
  colors: PRESETS[0].colors,
  intensity: 1,
  glass: 1,
};

const HEX = /^#[0-9a-fA-F]{6}$/;
const lvl = (v: unknown, d: Level): Level => (v === 0 || v === 1 || v === 2 ? v : d);

function sanitize(raw: any): BgSettings {
  const base = DEFAULT_BG;
  const ids = new Set([...PRESETS.map((p) => p.id), 'custom']);
  const cols: Trio = Array.isArray(raw?.colors) && raw.colors.length === 3 && raw.colors.every((c: any) => HEX.test(String(c)))
    ? [raw.colors[0], raw.colors[1], raw.colors[2]]
    : base.colors;
  return {
    preset: ids.has(raw?.preset) ? raw.preset : base.preset,
    colors: cols,
    intensity: lvl(raw?.intensity, base.intensity),
    glass: lvl(raw?.glass, base.glass),
  };
}

/** Três cores que estão valendo agora (do preset ou as personalizadas). */
export function colorsFor(s: BgSettings): Trio {
  if (s.preset === 'custom') return s.colors;
  return (PRESETS.find((p) => p.id === s.preset) ?? PRESETS[0]).colors;
}

export function hexToRgba(hex: string, a: number): string {
  const h = HEX.test(hex) ? hex : '#000000';
  const r = parseInt(h.slice(1, 3), 16);
  const g = parseInt(h.slice(3, 5), 16);
  const b = parseInt(h.slice(5, 7), 16);
  return `rgba(${r},${g},${b},${Math.max(0, Math.min(1, a))})`;
}

// Estado compartilhado: qualquer tela que usa o fundo atualiza na hora quando o usuário muda.
let current: BgSettings = DEFAULT_BG;
const listeners = new Set<() => void>();
const notify = () => listeners.forEach((f) => f());

export const getBg = () => current;

export function subscribeBg(fn: () => void): () => void {
  listeners.add(fn);
  return () => {
    listeners.delete(fn);
  };
}

export async function loadBg(): Promise<void> {
  try {
    const raw = await getBgTheme();
    if (raw) current = sanitize(JSON.parse(raw));
  } catch {
    current = DEFAULT_BG;
  }
  notify();
}

export async function updateBg(patch: Partial<BgSettings>): Promise<void> {
  current = sanitize({ ...current, ...patch });
  notify();
  await setBgTheme(JSON.stringify(current));
}
