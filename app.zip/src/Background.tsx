import React, { useEffect, useState } from 'react';
import { StyleSheet, View, ViewStyle, useWindowDimensions } from 'react-native';
import { BgSettings, colorsFor, getBg, hexToRgba, subscribeBg } from './background';

export function useBg(): BgSettings {
  const [s, setS] = useState<BgSettings>(getBg());
  useEffect(() => {
    setS(getBg());
    return subscribeBg(() => setS(getBg()));
  }, []);
  return s;
}

// Manchas de cor: posição (fração da tela), raio (fração da largura) e qual das 3 cores usam.
const BLOBS = [
  { cx: 0.02, cy: 0.27, r: 0.85, c: 0 },
  { cx: 1.0, cy: 0.52, r: 0.9, c: 1 },
  { cx: 0.12, cy: 1.0, r: 1.0, c: 2 },
  { cx: 0.95, cy: 0.97, r: 0.7, c: 0 },
];
const ALPHA = [0.4, 0.62, 0.9];
const VEIL = [0, 0.035, 0.08];

/** Fundo do app: gradientes desfocados + uma "camada de vidro" fosca por cima. Fica atrás de tudo. */
export function Background() {
  const { width: sw, height: sh } = useWindowDimensions();
  const s = useBg();
  if (s.preset === 'preto') return null;
  const cols = colorsFor(s);
  const a = ALPHA[s.intensity];

  return (
    <View pointerEvents="none" style={[StyleSheet.absoluteFill, { overflow: 'hidden' }]}>
      {BLOBS.map((b, i) => {
        const col = cols[b.c];
        const size = b.r * sw * 2;
        return (
          <View
            key={i}
            style={{
              position: 'absolute',
              width: size,
              height: size,
              left: b.cx * sw - b.r * sw,
              top: b.cy * sh - b.r * sw,
              experimental_backgroundImage: `radial-gradient(circle closest-side at 50% 50%, ${hexToRgba(col, a)} 0%, ${hexToRgba(col, a * 0.55)} 40%, ${hexToRgba(col, a * 0.18)} 72%, ${hexToRgba(col, 0)} 100%)`,
            }}
          />
        );
      })}
      {s.glass > 0 && (
        <View
          style={[
            StyleSheet.absoluteFill,
            {
              backgroundColor: `rgba(255,255,255,${VEIL[s.glass]})`,
              experimental_backgroundImage: `linear-gradient(180deg, rgba(255,255,255,${0.05 + s.glass * 0.04}) 0%, rgba(255,255,255,0) 38%)`,
            },
          ]}
        />
      )}
    </View>
  );
}

/** Painel de vidro: preenchimento translúcido, borda clara e um brilho suave por cima. */
export function Glass({ style, children }: { style?: ViewStyle | ViewStyle[]; children?: React.ReactNode }) {
  const s = useBg();
  if (s.glass === 0) {
    return <View style={style}>{children}</View>;
  }
  const fill = [0, 0.1, 0.18][s.glass];
  return (
    <View
      style={[
        {
          backgroundColor: `rgba(255,255,255,${fill})`,
          borderWidth: 1.5,
          borderColor: 'rgba(255,255,255,0.32)',
          borderTopColor: 'rgba(255,255,255,0.55)',
          experimental_backgroundImage: 'linear-gradient(180deg, rgba(255,255,255,0.16) 0%, rgba(255,255,255,0) 60%)',
        },
        style,
      ]}
    >
      {children}
    </View>
  );
}
