import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Text, View, useWindowDimensions } from 'react-native';
import { DialogAction, DialogShell, DialogTitle } from './DialogBase';
import { ActionItem, ActionMenu } from './ActionMenu';
import { colors, fonts, SPACE, TYPE } from './theme';

export type DialogButton = {
  text?: string;
  style?: 'default' | 'cancel' | 'destructive';
  onPress?: () => void | Promise<void>;
};

type Req = { title: string; message?: string; buttons: DialogButton[] };

// Fila simples: quem chama `appAlert` não precisa saber se a janela já está montada.
let enqueue: ((r: Req) => void) | null = null;
const waiting: Req[] = [];

/** Substitui o Alert.alert do Android (fora do padrão) por uma janela no visual do app. Mesmo uso. */
export function appAlert(title: string, message?: string, buttons?: DialogButton[]): void {
  const req: Req = { title, message, buttons: buttons && buttons.length > 0 ? buttons : [{ text: 'OK' }] };
  if (enqueue) enqueue(req);
  else waiting.push(req);
}

type MenuReq = { title: string; items: ActionItem[] };
let openMenu: ((r: MenuReq) => void) | null = null;
let waitingMenu: MenuReq | null = null;

/**
 * Menu de opções que sobe de baixo (mesmo visual de "+ Adicionar"). Mesmo uso do `appAlert` com botões:
 * "Cancelar" não vira linha (tocar fora fecha) e `destructive` fica vermelho. Para confirmar uma exclusão,
 * continue usando `appAlert`.
 */
export function appMenu(title: string, message: string | undefined, buttons: DialogButton[]): void {
  const req: MenuReq = {
    title: message ? `${title} · ${message}` : title,
    items: buttons
      .filter((b) => b.style !== 'cancel')
      .map((b, i) => ({
        key: String(i),
        label: b.text ?? 'OK',
        tone: b.style === 'destructive' ? ('danger' as const) : ('default' as const),
        onPress: () => {
          Promise.resolve(b.onPress?.()).catch(() => {});
        },
      })),
  };
  if (openMenu) openMenu(req);
  else waitingMenu = req;
}

/** Coloque uma vez na raiz do app. Mostra as janelas pedidas por `appAlert`, uma de cada vez. */
export function DialogHost() {
  const { width: sw } = useWindowDimensions();
  const [current, setCurrent] = useState<Req | null>(null);
  const queue = useRef<Req[]>([]);
  const [menu, setMenu] = useState<MenuReq | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const currentRef = useRef<Req | null>(null);

  const showNext = useCallback(() => {
    const next = queue.current.shift() ?? null;
    currentRef.current = next;
    setCurrent(next);
  }, []);

  useEffect(() => {
    enqueue = (r) => {
      queue.current.push(r);
      if (!currentRef.current) showNext();
    };
    waiting.splice(0).forEach((r) => enqueue?.(r));
    return () => {
      enqueue = null;
    };
  }, [showNext]);

  useEffect(() => {
    openMenu = (r) => {
      setMenu(r);
      setMenuOpen(true);
    };
    if (waitingMenu) {
      openMenu(waitingMenu);
      waitingMenu = null;
    }
    return () => {
      openMenu = null;
    };
  }, []);

  const press = (b?: DialogButton) => {
    showNext();
    // Roda a ação depois de fechar, para a próxima janela (se houver) abrir já limpa.
    if (b?.onPress) Promise.resolve(b.onPress()).catch(() => {});
  };

  const cancelBtn = current?.buttons.find((b) => b.style === 'cancel');

  return (
    <>
    <ActionMenu visible={menuOpen} onClose={() => setMenuOpen(false)} title={menu?.title} items={menu?.items ?? []} />
    <DialogShell visible={current !== null} onClose={() => press(cancelBtn)}>
      <DialogTitle>{current?.title}</DialogTitle>
      {!!current?.message && (
        <Text
          style={{
            color: colors.onLight,
            fontFamily: fonts.regular,
            fontSize: sw * TYPE.body,
            lineHeight: sw * 0.062,
            marginTop: sw * SPACE.md,
          }}
        >
          {current.message}
        </Text>
      )}
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'flex-end', columnGap: sw * SPACE.xl, rowGap: sw * SPACE.md, marginTop: sw * SPACE.lg }}>
        {current?.buttons.map((b, i) => (
          <DialogAction
            key={i}
            label={b.text ?? 'OK'}
            tone={b.style === 'cancel' ? 'cancel' : b.style === 'destructive' ? 'danger' : 'default'}
            onPress={() => press(b)}
          />
        ))}
      </View>
    </DialogShell>
    </>
  );
}
