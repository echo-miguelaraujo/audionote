import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Animated, Text, View, useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { DialogAction, DialogShell, DialogTitle } from './DialogBase';
import { ActionItem, ActionMenu } from './ActionMenu';
import { colors, fonts, SPACE, TYPE } from './theme';

export type DialogButton = {
  text?: string;
  style?: 'default' | 'cancel' | 'destructive';
  onPress?: () => void | Promise<void>;
};

type Req = { title: string; message?: string; buttons: DialogButton[] };

// Fila simples: quem chama `appAlert` não precisa saber se a janela já está montada.
let enqueue: ((r: Req) => void) | null = null;
const waiting: Req[] = [];

/** Substitui o Alert.alert do Android (fora do padrão) por uma janela no visual do app. Mesmo uso. */
export function appAlert(title: string, message?: string, buttons?: DialogButton[]): void {
  const req: Req = { title, message, buttons: buttons && buttons.length > 0 ? buttons : [{ text: 'OK' }] };
  if (enqueue) enqueue(req);
  else waiting.push(req);
}

/** Erro em linguagem simples; o texto técnico fica em "Ver detalhes". */
export function appError(title: string, e: unknown): void {
  const raw = e instanceof Error ? e.message || String(e) : String(e);
  appAlert(title, 'Algo deu errado. Tente de novo; se continuar, feche e abra o app.', [
    { text: 'OK' },
    { text: 'Ver detalhes', onPress: () => appAlert('Detalhes do erro', raw.slice(0, 600)) },
  ]);
}

/**
 * Confirmação de exclusão padrão: título "Excluir X?", Cancelar e um botão vermelho "Excluir".
 * `title` já vem com o ponto de interrogação (ex.: "Excluir coleção?").
 */
export function confirmDelete(title: string, message: string, onConfirm: () => void | Promise<void>, confirmLabel = 'Excluir'): void {
  appAlert(title, message, [
    { text: 'Cancelar', style: 'cancel' },
    { text: confirmLabel, style: 'destructive', onPress: onConfirm },
  ]);
}

let showToast: ((t: string) => void) | null = null;

/** Aviso curto que some sozinho (2,5 s), sem botão. Para avisos simples; o que exige uma decisão continua em `appAlert`. */
export function appToast(title: string, message?: string): void {
  showToast?.(message ? `${title}. ${message}` : title);
}

type MenuReq = { title: string; items: ActionItem[] };
let openMenu: ((r: MenuReq) => void) | null = null;
let waitingMenu: MenuReq | null = null;

/**
 * Menu de opções que sobe de baixo (mesmo visual de "+ Adicionar"). Mesmo uso do `appAlert` com botões:
 * "Cancelar" não vira linha (tocar fora fecha) e `destructive` fica vermelho. Para confirmar uma exclusão,
 * continue usando `appAlert`.
 */
export function appMenu(title: string, message: string | undefined, buttons: DialogButton[]): void {
  const req: MenuReq = {
    title: message ? `${title} · ${message}` : title,
    items: buttons
      .filter((b) => b.style !== 'cancel')
      .map((b, i) => ({
        key: String(i),
        label: b.text ?? 'OK',
        tone: b.style === 'destructive' ? ('danger' as const) : ('default' as const),
        onPress: () => {
          Promise.resolve(b.onPress?.()).catch(() => {});
        },
      })),
  };
  if (openMenu) openMenu(req);
  else waitingMenu = req;
}

/** Coloque uma vez na raiz do app. Mostra as janelas pedidas por `appAlert`, uma de cada vez. */
export function DialogHost() {
  const { width: sw } = useWindowDimensions();
  const [current, setCurrent] = useState<Req | null>(null);
  const queue = useRef<Req[]>([]);
  const insets = useSafeAreaInsets();
  const [toast, setToast] = useState<string | null>(null);
  const fade = useRef(new Animated.Value(0)).current;
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => {
    showToast = (t) => {
      setToast(t);
      fade.setValue(0);
      Animated.timing(fade, { toValue: 1, duration: 160, useNativeDriver: true }).start();
      if (toastTimer.current) clearTimeout(toastTimer.current);
      toastTimer.current = setTimeout(() => {
        Animated.timing(fade, { toValue: 0, duration: 200, useNativeDriver: true }).start(() => setToast(null));
      }, 2500);
    };
    return () => {
      showToast = null;
      if (toastTimer.current) clearTimeout(toastTimer.current);
    };
  }, [fade]);
  const [menu, setMenu] = useState<MenuReq | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const currentRef = useRef<Req | null>(null);

  const showNext = useCallback(() => {
    const next = queue.current.shift() ?? null;
    currentRef.current = next;
    setCurrent(next);
  }, []);

  useEffect(() => {
    enqueue = (r) => {
      queue.current.push(r);
      if (!currentRef.current) showNext();
    };
    waiting.splice(0).forEach((r) => enqueue?.(r));
    return () => {
      enqueue = null;
    };
  }, [showNext]);

  useEffect(() => {
    openMenu = (r) => {
      setMenu(r);
      setMenuOpen(true);
    };
    if (waitingMenu) {
      openMenu(waitingMenu);
      waitingMenu = null;
    }
    return () => {
      openMenu = null;
    };
  }, []);

  const press = (b?: DialogButton) => {
    showNext();
    // Roda a ação depois de fechar, para a próxima janela (se houver) abrir já limpa.
    if (b?.onPress) Promise.resolve(b.onPress()).catch(() => {});
  };

  const cancelBtn = current?.buttons.find((b) => b.style === 'cancel');

  return (
    <>
    {toast !== null && (
      <Animated.View
        pointerEvents="none"
        style={{
          position: 'absolute',
          left: sw * 0.06,
          right: sw * 0.06,
          bottom: insets.bottom + sw * 0.08,
          alignItems: 'center',
          opacity: fade,
        }}
      >
        <View style={{ backgroundColor: colors.onLight, borderRadius: sw * 0.08, paddingHorizontal: sw * 0.05, paddingVertical: sw * 0.03 }}>
          <Text style={{ color: colors.onDark, fontFamily: fonts.regular, fontSize: sw * TYPE.caption * 1.1, textAlign: 'center' }}>{toast}</Text>
        </View>
      </Animated.View>
    )}
    <ActionMenu visible={menuOpen} onClose={() => setMenuOpen(false)} title={menu?.title} items={menu?.items ?? []} />
    <DialogShell visible={current !== null} onClose={() => press(cancelBtn)}>
      <DialogTitle>{current?.title}</DialogTitle>
      {!!current?.message && (
        <Text
          style={{
            color: colors.onLight,
            fontFamily: fonts.regular,
            fontSize: sw * TYPE.body,
            lineHeight: sw * 0.062,
            marginTop: sw * SPACE.md,
          }}
        >
          {current.message}
        </Text>
      )}
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'flex-end', columnGap: sw * SPACE.xl, rowGap: sw * SPACE.md, marginTop: sw * SPACE.lg }}>
        {current?.buttons.map((b, i) => (
          <DialogAction
            key={i}
            label={b.text ?? 'OK'}
            tone={b.style === 'cancel' ? 'cancel' : b.style === 'destructive' ? 'danger' : 'default'}
            onPress={() => press(b)}
          />
        ))}
      </View>
    </DialogShell>
    </>
  );
}
