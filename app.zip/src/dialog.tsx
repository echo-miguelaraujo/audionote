import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Modal, Pressable, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { colors, fonts } from './theme';

export type DialogButton = {
  text?: string;
  style?: 'default' | 'cancel' | 'destructive';
  onPress?: () => void | Promise<void>;
};

type Req = { title: string; message?: string; buttons: DialogButton[] };

// Fila simples: quem chama `appAlert` não precisa saber se a janela já está montada.
let enqueue: ((r: Req) => void) | null = null;
const waiting: Req[] = [];

/** Substitui o Alert.alert do Android (fora do padrão) por uma janela no visual do app. Mesmo uso. */
export function appAlert(title: string, message?: string, buttons?: DialogButton[]): void {
  const req: Req = { title, message, buttons: buttons && buttons.length > 0 ? buttons : [{ text: 'OK' }] };
  if (enqueue) enqueue(req);
  else waiting.push(req);
}

/** Coloque uma vez na raiz do app. Mostra as janelas pedidas por `appAlert`, uma de cada vez. */
export function DialogHost() {
  const { width: sw, height: sh } = useWindowDimensions();
  const [current, setCurrent] = useState<Req | null>(null);
  const queue = useRef<Req[]>([]);
  const currentRef = useRef<Req | null>(null);

  const showNext = useCallback(() => {
    const next = queue.current.shift() ?? null;
    currentRef.current = next;
    setCurrent(next);
  }, []);

  useEffect(() => {
    enqueue = (r) => {
      queue.current.push(r);
      if (!currentRef.current) showNext();
    };
    waiting.splice(0).forEach((r) => enqueue?.(r));
    return () => {
      enqueue = null;
    };
  }, [showNext]);

  const press = (b?: DialogButton) => {
    showNext();
    // Roda a ação depois de fechar, para a próxima janela (se houver) abrir já limpa.
    if (b?.onPress) Promise.resolve(b.onPress()).catch(() => {});
  };

  const cancelBtn = current?.buttons.find((b) => b.style === 'cancel');

  return (
    <Modal
      visible={current !== null}
      transparent
      animationType="fade"
      statusBarTranslucent
      onRequestClose={() => press(cancelBtn)}
    >
      <Pressable style={[styles.overlay, { paddingTop: sh * 0.08 }]} onPress={() => press(cancelBtn)}>
        <Pressable
          style={{ width: sw * 0.84, borderRadius: sw * 0.074, padding: sw * 0.06, backgroundColor: '#FFFFFF' }}
          onPress={() => {}}
        >
          <Text style={{ color: '#000', fontFamily: fonts.bold, fontSize: sw * 0.06, letterSpacing: -1 }}>
            {current?.title}
          </Text>
          {!!current?.message && (
            <Text
              style={{
                color: '#000',
                fontFamily: fonts.regular,
                fontSize: sw * 0.045,
                lineHeight: sw * 0.062,
                marginTop: sw * 0.035,
              }}
            >
              {current.message}
            </Text>
          )}
          <View style={styles.row}>
            {current?.buttons.map((b, i) => (
              <Pressable key={i} onPress={() => press(b)} hitSlop={12}>
                <Text
                  style={{
                    fontFamily: fonts.bold,
                    fontSize: sw * 0.05,
                    color: b.style === 'cancel' ? '#808080' : b.style === 'destructive' ? colors.red : '#000',
                  }}
                >
                  {b.text ?? 'OK'}
                </Text>
              </Pressable>
            ))}
          </View>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.78)', alignItems: 'center' },
  row: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'flex-end', columnGap: 28, rowGap: 14, marginTop: 28 },
});
