import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Text, View, useWindowDimensions } from 'react-native';
import { DialogAction, DialogShell, DialogTitle } from './DialogBase';
import { colors, fonts, SPACE, TYPE } from './theme';

export type DialogButton = {
  text?: string;
  style?: 'default' | 'cancel' | 'destructive';
  onPress?: () => void | Promise<void>;
};

type Req = { title: string; message?: string; buttons: DialogButton[] };

// Fila simples: quem chama `appAlert` não precisa saber se a janela já está montada.
let enqueue: ((r: Req) => void) | null = null;
const waiting: Req[] = [];

/** Substitui o Alert.alert do Android (fora do padrão) por uma janela no visual do app. Mesmo uso. */
export function appAlert(title: string, message?: string, buttons?: DialogButton[]): void {
  const req: Req = { title, message, buttons: buttons && buttons.length > 0 ? buttons : [{ text: 'OK' }] };
  if (enqueue) enqueue(req);
  else waiting.push(req);
}

/** Coloque uma vez na raiz do app. Mostra as janelas pedidas por `appAlert`, uma de cada vez. */
export function DialogHost() {
  const { width: sw } = useWindowDimensions();
  const [current, setCurrent] = useState<Req | null>(null);
  const queue = useRef<Req[]>([]);
  const currentRef = useRef<Req | null>(null);

  const showNext = useCallback(() => {
    const next = queue.current.shift() ?? null;
    currentRef.current = next;
    setCurrent(next);
  }, []);

  useEffect(() => {
    enqueue = (r) => {
      queue.current.push(r);
      if (!currentRef.current) showNext();
    };
    waiting.splice(0).forEach((r) => enqueue?.(r));
    return () => {
      enqueue = null;
    };
  }, [showNext]);

  const press = (b?: DialogButton) => {
    showNext();
    // Roda a ação depois de fechar, para a próxima janela (se houver) abrir já limpa.
    if (b?.onPress) Promise.resolve(b.onPress()).catch(() => {});
  };

  const cancelBtn = current?.buttons.find((b) => b.style === 'cancel');

  return (
    <DialogShell visible={current !== null} onClose={() => press(cancelBtn)}>
      <DialogTitle>{current?.title}</DialogTitle>
      {!!current?.message && (
        <Text
          style={{
            color: colors.onLight,
            fontFamily: fonts.regular,
            fontSize: sw * TYPE.body,
            lineHeight: sw * 0.062,
            marginTop: sw * SPACE.md,
          }}
        >
          {current.message}
        </Text>
      )}
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'flex-end', columnGap: sw * SPACE.xl, rowGap: sw * SPACE.md, marginTop: sw * SPACE.lg }}>
        {current?.buttons.map((b, i) => (
          <DialogAction
            key={i}
            label={b.text ?? 'OK'}
            tone={b.style === 'cancel' ? 'cancel' : b.style === 'destructive' ? 'danger' : 'default'}
            onPress={() => press(b)}
          />
        ))}
      </View>
    </DialogShell>
  );
}
