import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Alert,
  FlatList,
  PanResponder,
  Pressable,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
} from 'react-native';
import {
  AgendaEntry,
  DayMap,
  MONTHS,
  WEEKDAYS_LONG,
  WEEKDAYS_SHORT,
  addDays,
  dayKey,
  loadEntries,
  monthGrid,
  pad2,
  startOfDay,
  timeLabel,
} from './agenda';
import { AgendaEditor } from './AgendaEditor';
import { Glass } from './Background';
import { ensureCalendarPermission } from './calendar';
import {
  AgendaItem,
  Category,
  createAgendaItem,
  deleteAgendaItem,
  listCategories,
  updateAgendaItem,
} from './db';
import { colors, fonts } from './theme';

type Props = {
  /** Muda quando algo é salvo no app (ex.: um áudio virou compromisso). */
  version: number;
  onOpenNote: (blockId: number) => void;
};

// Ajustes finos do número grande do dia (cortado no canto, como no layout).
const BIG_SIZE = 0.5; // tamanho da fonte, em fração da largura da tela
const BIG_STRETCH = 1.75; // quanto o número é esticado na vertical
const BIG_LEFT = -0.035; // posição horizontal (negativo = corta no canto esquerdo)

type Group = { key: string; date: Date; entries: AgendaEntry[] };

export function AgendaScreen({ version, onOpenNote }: Props) {
  const { width: sw } = useWindowDimensions();
  const today = useMemo(() => startOfDay(new Date()), []);
  const [view, setView] = useState({ y: today.getFullYear(), m: today.getMonth() });
  const [selected, setSelected] = useState<Date>(today);
  const [map, setMap] = useState<DayMap>(new Map());
  const [cats, setCats] = useState<Category[]>([]);
  const [rootH, setRootH] = useState(0);
  const [reloadTick, setReloadTick] = useState(0);
  const [editor, setEditor] = useState<{ item: AgendaItem | null } | null>(null);
  const listRef = useRef<FlatList<Group>>(null);

  const grid = useMemo(() => monthGrid(view.y, view.m), [view]);

  // Carrega compromissos do app + agenda do celular: grade do mês e ~60 dias à frente (para a lista de baixo).
  useEffect(() => {
    let alive = true;
    (async () => {
      await ensureCalendarPermission();
      const c = await listCategories();
      const from = grid[0];
      const to = addDays(new Date(view.y, view.m + 1, 0), 61);
      const m = await loadEntries(from, to, c);
      if (!alive) return;
      setCats(c);
      setMap(m);
    })().catch(() => {});
    return () => {
      alive = false;
    };
  }, [grid, view, version, reloadTick]);

  const reload = useCallback(() => setReloadTick((n) => n + 1), []);

  const goMonth = useCallback(
    (delta: number) => {
      const d = new Date(view.y, view.m + delta, 1);
      setView({ y: d.getFullYear(), m: d.getMonth() });
      setSelected(d.getFullYear() === today.getFullYear() && d.getMonth() === today.getMonth() ? today : d);
    },
    [view, today]
  );

  const goToday = useCallback(() => {
    setView({ y: today.getFullYear(), m: today.getMonth() });
    setSelected(today);
  }, [today]);

  const selectDay = useCallback((d: Date) => {
    setSelected(d);
    setView((v) => (d.getFullYear() === v.y && d.getMonth() === v.m ? v : { y: d.getFullYear(), m: d.getMonth() }));
  }, []);

  // Arrastar o calendário para os lados troca de mês.
  const goMonthRef = useRef(goMonth);
  goMonthRef.current = goMonth;
  const pan = useMemo(
    () =>
      PanResponder.create({
        onMoveShouldSetPanResponder: (_, g) => Math.abs(g.dx) > 20 && Math.abs(g.dx) > Math.abs(g.dy) * 1.5,
        onPanResponderRelease: (_, g) => {
          if (g.dx <= -50) goMonthRef.current(1);
          else if (g.dx >= 50) goMonthRef.current(-1);
        },
      }),
    []
  );

  // Lista de baixo: o dia escolhido (mesmo vazio) e os próximos dias que têm compromisso.
  const groups: Group[] = useMemo(() => {
    const selKey = dayKey(selected);
    const out: Group[] = [{ key: selKey, date: selected, entries: map.get(selKey) ?? [] }];
    const later = Array.from(map.keys())
      .filter((k) => k > selKey)
      .sort()
      .slice(0, 14);
    later.forEach((k) => {
      const [y, m, d] = k.split('-').map(Number);
      out.push({ key: k, date: new Date(y, m - 1, d), entries: map.get(k)! });
    });
    return out;
  }, [map, selected]);

  useEffect(() => {
    listRef.current?.scrollToOffset({ offset: 0, animated: false });
  }, [selected]);

  const openEntry = (e: AgendaEntry) => {
    if (e.source === 'app' && e.itemId != null) {
      setEditor({
        item: {
          id: e.itemId,
          title: e.title,
          startAt: e.startMs,
          allDay: e.allDay,
          categoryId: e.categoryId ?? null,
          notes: e.notes ?? '',
        },
      });
      return;
    }
    if (e.blockId != null) {
      onOpenNote(e.blockId);
      return;
    }
    Alert.alert(e.title, `${e.allDay ? 'Dia inteiro' : timeLabel(e.startMs)}\n\nEvento da agenda do celular. Para editar, use o app de Agenda.`);
  };

  // ---------- medidas (tudo em fração da largura, como o resto do app) ----------
  const rows = grid.length / 7;
  const gap = sw * 0.0075;
  const cardH = sw * 0.5; // cartão branco de baixo
  const calTop = sw * 0.495;
  const pad = sw * 0.012;
  const weekH = sw * 0.1;
  const calBottomMax = rootH > 0 ? rootH - sw * 0.02 - cardH + sw * 0.07 : calTop + sw * 1.0;
  const area = calBottomMax - calTop - pad * 2 - weekH - sw * 0.02;
  const cellH = Math.max(sw * 0.095, Math.min(sw * 0.14, area / rows - gap));
  const cellW = (sw * 0.916 - pad * 2 - gap * 6) / 7;

  const monthName = MONTHS[view.m];
  const pillText = view.y === today.getFullYear() ? monthName : `${monthName} ${view.y}`;
  const bigNumber = pad2(selected.getDate());
  const T = sw * 0.28; // lado do quadrado vermelho das datas
  const groupW = sw * 0.8;

  return (
    <View style={styles.root} onLayout={(e) => setRootH(e.nativeEvent.layout.height)}>
      {/* Pílula de vidro com o mês */}
      <Pressable
        onPress={goToday}
        style={{ position: 'absolute', left: sw * 0.575, top: sw * 0.34 }}
      >
        <Glass
          style={{
            minWidth: sw * 0.34,
            height: sw * 0.125,
            paddingHorizontal: sw * 0.05,
            borderRadius: sw * 0.0625,
            justifyContent: 'center',
            alignItems: 'center',
          }}
        >
          <Text
            numberOfLines={1}
            adjustsFontSizeToFit
            style={{ color: colors.text, fontFamily: fonts.bold, fontSize: sw * 0.058, letterSpacing: -sw * 0.058 * 0.04 }}
          >
            {pillText}
          </Text>
        </Glass>
      </Pressable>

      {/* Dia grande, cortado no canto */}
      <View pointerEvents="none" style={{ position: 'absolute', left: sw * BIG_LEFT, top: 0 }}>
        <Text
          allowFontScaling={false}
          style={{
            color: colors.text,
            fontFamily: fonts.regular,
            fontSize: sw * BIG_SIZE,
            lineHeight: sw * BIG_SIZE,
            includeFontPadding: false,
            letterSpacing: -sw * BIG_SIZE * 0.05,
            transform: [{ scaleY: BIG_STRETCH }],
          }}
        >
          {bigNumber}
        </Text>
      </View>

      {/* Calendário do mês */}
      <View
        {...pan.panHandlers}
        style={{
          position: 'absolute',
          left: sw * 0.042,
          right: sw * 0.042,
          top: calTop,
          borderRadius: sw * 0.085,
          backgroundColor: '#000',
          padding: pad,
          paddingBottom: sw * 0.12,
        }}
      >
        <View style={{ flexDirection: 'row', height: weekH, alignItems: 'center', gap }}>
          {WEEKDAYS_SHORT.map((w) => (
            <Text
              key={w}
              style={{
                width: cellW,
                textAlign: 'center',
                color: colors.text,
                fontFamily: fonts.regular,
                fontSize: sw * 0.045,
                letterSpacing: -sw * 0.045 * 0.04,
              }}
            >
              {w}
            </Text>
          ))}
        </View>

        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap }}>
          {grid.map((d) => {
            const k = dayKey(d);
            const inMonth = d.getMonth() === view.m;
            const isSel = k === dayKey(selected);
            const isToday = k === dayKey(today);
            const list = inMonth ? map.get(k) ?? [] : [];
            const dots = list.slice(0, 3);
            return (
              <Pressable
                key={k}
                onPress={() => selectDay(d)}
                onLongPress={() => {
                  selectDay(d);
                  setEditor({ item: null });
                }}
                delayLongPress={350}
                style={{
                  width: cellW,
                  height: cellH,
                  borderRadius: sw * 0.03,
                  backgroundColor: isSel && inMonth ? colors.red : '#FFFFFF',
                  alignItems: 'center',
                  paddingTop: cellH * 0.07,
                }}
              >
                {inMonth && (
                  <>
                    <Text
                      style={{
                        color: isSel ? colors.text : isToday ? colors.red : '#000',
                        fontFamily: isToday && !isSel ? fonts.bold : fonts.regular,
                        fontSize: sw * 0.05,
                        letterSpacing: -sw * 0.05 * 0.04,
                      }}
                    >
                      {d.getDate()}
                    </Text>
                    {dots.length > 0 && (
                      <View style={{ flexDirection: 'row', gap: sw * 0.008, position: 'absolute', bottom: cellH * 0.1 }}>
                        {dots.map((e, i) => (
                          <View
                            key={i}
                            style={{
                              width: sw * 0.014,
                              height: sw * 0.014,
                              borderRadius: sw * 0.007,
                              backgroundColor: isSel ? '#fff' : e.color,
                            }}
                          />
                        ))}
                      </View>
                    )}
                  </>
                )}
              </Pressable>
            );
          })}
        </View>
      </View>

      {/* Cartão branco "Agenda" */}
      <View
        style={{
          position: 'absolute',
          left: sw * 0.02,
          right: sw * 0.02,
          bottom: sw * 0.02,
          height: cardH,
          borderRadius: sw * 0.085,
          backgroundColor: '#FFFFFF',
          overflow: 'hidden',
        }}
      >
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
            paddingTop: sw * 0.045,
            paddingHorizontal: sw * 0.085,
          }}
        >
          <Text style={{ color: '#000', fontFamily: fonts.bold, fontSize: sw * 0.052, letterSpacing: -sw * 0.052 * 0.045 }}>
            Agenda
          </Text>
          <Pressable onPress={() => setEditor({ item: null })} hitSlop={16}>
            <Text style={{ color: colors.red, fontFamily: fonts.bold, fontSize: sw * 0.08, lineHeight: sw * 0.085 }}>+</Text>
          </Pressable>
        </View>

        <FlatList
          ref={listRef}
          horizontal
          data={groups}
          keyExtractor={(g) => g.key}
          showsHorizontalScrollIndicator={false}
          snapToInterval={groupW}
          decelerationRate="fast"
          contentContainerStyle={{ paddingLeft: sw * 0.055, paddingTop: sw * 0.03 }}
          renderItem={({ item: g }) => {
            const shown = g.entries.slice(0, 3);
            const extra = g.entries.length - shown.length;
            const isSelGroup = g.key === dayKey(selected);
            return (
              <View style={{ width: groupW, flexDirection: 'row', alignItems: 'center' }}>
                <Pressable
                  onPress={() => selectDay(g.date)}
                  style={{
                    width: T,
                    height: T,
                    borderRadius: sw * 0.07,
                    backgroundColor: colors.red,
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Text
                    allowFontScaling={false}
                    style={{
                      color: colors.text,
                      fontFamily: fonts.regular,
                      fontSize: sw * 0.19,
                      lineHeight: sw * 0.22,
                      includeFontPadding: false,
                      letterSpacing: -sw * 0.19 * 0.05,
                    }}
                  >
                    {pad2(g.date.getDate())}
                  </Text>
                </Pressable>

                <View style={{ flex: 1, paddingLeft: sw * 0.04, paddingRight: sw * 0.02, justifyContent: 'center' }}>
                  {g.entries.length === 0 ? (
                    <>
                      <Text style={{ color: colors.gray, fontFamily: fonts.regular, fontSize: sw * 0.042 }}>
                        {WEEKDAYS_LONG[g.date.getDay()]}
                      </Text>
                      <Text style={{ color: colors.gray, fontFamily: fonts.regular, fontSize: sw * 0.042 }}>
                        {isSelGroup ? 'Nada marcado' : ''}
                      </Text>
                    </>
                  ) : (
                    <>
                      {shown.map((e) => (
                        <Pressable key={e.key} onPress={() => openEntry(e)} style={{ marginVertical: sw * 0.012 }}>
                          <View style={{ flexDirection: 'row', alignItems: 'center', gap: sw * 0.018 }}>
                            <View style={{ width: sw * 0.018, height: sw * 0.018, borderRadius: sw * 0.009, backgroundColor: e.color }} />
                            <Text
                              numberOfLines={1}
                              style={{
                                flex: 1,
                                color: '#000',
                                fontFamily: fonts.regular,
                                fontSize: sw * 0.045,
                                letterSpacing: -sw * 0.045 * 0.03,
                              }}
                            >
                              {e.title}
                            </Text>
                          </View>
                          {!e.allDay && (
                            <Text style={{ color: colors.gray, fontFamily: fonts.regular, fontSize: sw * 0.03, marginLeft: sw * 0.036 }}>
                              {timeLabel(e.startMs)}
                            </Text>
                          )}
                        </Pressable>
                      ))}
                      {extra > 0 && (
                        <Text style={{ color: colors.gray, fontFamily: fonts.regular, fontSize: sw * 0.035 }}>
                          +{extra} {extra === 1 ? 'compromisso' : 'compromissos'}
                        </Text>
                      )}
                    </>
                  )}
                </View>
              </View>
            );
          }}
        />
      </View>

      <AgendaEditor
        visible={editor !== null}
        item={editor?.item ?? null}
        defaultDate={selected}
        cats={cats}
        onCancel={() => setEditor(null)}
        onSave={async (data, id) => {
          if (id != null) await updateAgendaItem(id, data);
          else await createAgendaItem(data);
          setEditor(null);
          const d = startOfDay(new Date(data.startAt));
          selectDay(d);
          reload();
        }}
        onDelete={async (id) => {
          await deleteAgendaItem(id);
          setEditor(null);
          reload();
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: 'transparent', overflow: 'hidden' },
});
