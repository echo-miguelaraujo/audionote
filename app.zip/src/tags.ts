/** Texto sem acento e em minúsculas, para comparar e buscar. */
export function fold(s: string): string {
  return s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
}

export const TAG_MAX = 30;

/** Tag limpa: sem "#", espaços colapsados, até 30 caracteres. Vazia → null. */
export function normalizeTag(raw: string): string | null {
  const t = raw.replace(/^#+/, '').replace(/\s+/g, ' ').trim().slice(0, TAG_MAX).trim();
  return t ? t : null;
}

/** Chave de comparação: a mesma tag sem diferenciar maiúscula nem acento. */
export const tagKey = (t: string): string => fold(t);

/** Lê o JSON de tags guardado na nota. Inválido → []. Remove repetidas (guarda a grafia da primeira). */
export function parseTags(json: string | null | undefined): string[] {
  if (!json) return [];
  try {
    const arr = JSON.parse(json);
    if (!Array.isArray(arr)) return [];
    return uniqueTags(arr.filter((x): x is string => typeof x === 'string'));
  } catch {
    return [];
  }
}

export function uniqueTags(list: string[]): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const raw of list) {
    const t = normalizeTag(raw);
    if (!t) continue;
    const k = tagKey(t);
    if (seen.has(k)) continue;
    seen.add(k);
    out.push(t);
  }
  return out;
}

export const stringifyTags = (tags: string[]): string | null => {
  const u = uniqueTags(tags);
  return u.length ? JSON.stringify(u) : null;
};
