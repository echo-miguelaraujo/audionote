import React, { useEffect, useState } from 'react';
import { appAlert } from './dialog';
import {
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  useWindowDimensions,
} from 'react-native';
import { AgendaItem, Category } from './db';
import { addDays, pad2 } from './agenda';
import { DialogActions, DialogShell, DialogTitle } from './DialogBase';
import { colors, fonts, TYPE, SPACE } from './theme';

type Props = {
  visible: boolean;
  /** null = novo compromisso. */
  item: AgendaItem | null;
  /** Dia sugerido para um compromisso novo. */
  defaultDate: Date;
  cats: Category[];
  onCancel: () => void;
  onSave: (data: Omit<AgendaItem, 'id'>, editingId: number | null) => void;
  onDelete: (id: number) => void;
};

const fmtDate = (d: Date) => `${pad2(d.getDate())}/${pad2(d.getMonth() + 1)}/${d.getFullYear()}`;

/** Deixa só números e coloca as barras sozinho: 06102026 -> 06/10/2026 */
function maskDate(raw: string): string {
  const n = raw.replace(/\D/g, '').slice(0, 8);
  if (n.length <= 2) return n;
  if (n.length <= 4) return `${n.slice(0, 2)}/${n.slice(2)}`;
  return `${n.slice(0, 2)}/${n.slice(2, 4)}/${n.slice(4)}`;
}

/** 1530 -> 15:30 */
function maskTime(raw: string): string {
  const n = raw.replace(/\D/g, '').slice(0, 4);
  return n.length <= 2 ? n : `${n.slice(0, 2)}:${n.slice(2)}`;
}

export function AgendaEditor({ visible, item, defaultDate, cats, onCancel, onSave, onDelete }: Props) {
  const { width: sw, height: sh } = useWindowDimensions();
  const [title, setTitle] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [allDay, setAllDay] = useState(true);
  const [catId, setCatId] = useState<number | null>(null);
  const [notes, setNotes] = useState('');

  useEffect(() => {
    if (!visible) return;
    if (item) {
      const d = new Date(item.startAt);
      setTitle(item.title);
      setDate(fmtDate(d));
      setAllDay(item.allDay);
      setTime(item.allDay ? '' : `${pad2(d.getHours())}:${pad2(d.getMinutes())}`);
      setCatId(item.categoryId);
      setNotes(item.notes);
    } else {
      setTitle('');
      setDate(fmtDate(defaultDate));
      setAllDay(true);
      setTime('');
      setCatId(null);
      setNotes('');
    }
  }, [visible, item, defaultDate]);

  const submit = () => {
    const t = title.trim();
    if (!t) {
      appAlert('Falta o título', 'Escreva o nome do compromisso.');
      return;
    }
    const m = date.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
    if (!m) {
      appAlert('Data inválida', 'Use o formato dd/mm/aaaa.');
      return;
    }
    let hh = 0;
    let mm = 0;
    if (!allDay) {
      const tm = time.match(/^(\d{2}):(\d{2})$/);
      if (!tm || +tm[1] > 23 || +tm[2] > 59) {
        appAlert('Hora inválida', 'Use o formato hh:mm (ex.: 19:30).');
        return;
      }
      hh = +tm[1];
      mm = +tm[2];
    }
    const d = new Date(+m[3], +m[2] - 1, +m[1], hh, mm, 0, 0);
    if (isNaN(d.getTime()) || d.getDate() !== +m[1]) {
      appAlert('Data inválida', 'Esse dia não existe no calendário.');
      return;
    }
    onSave({ title: t, startAt: d.getTime(), allDay, categoryId: catId, notes: notes.trim() }, item?.id ?? null);
  };

  const label = { fontSize: sw * TYPE.caption, color: colors.muted, fontFamily: fonts.bold, marginTop: sw * SPACE.md };
  const input = {
    color: colors.onLight,
    fontFamily: fonts.regular,
    fontSize: sw * TYPE.subtitle,
    borderBottomWidth: 2,
    borderBottomColor: colors.onLight,
    paddingVertical: 6,
  };

  return (
    <DialogShell visible={visible} onClose={onCancel} maxHeight={sh * 0.82}>
      <ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
              <DialogTitle>{item ? 'Editar compromisso' : 'Novo compromisso'}</DialogTitle>

              <Text style={label}>Título</Text>
              <TextInput
                value={title}
                onChangeText={setTitle}
                maxLength={80}
                autoFocus={!item}
                placeholder="Ex.: Ensaio, reunião, entrega…"
                placeholderTextColor={colors.mutedLight}
                style={input}
              />

              <Text style={label}>Data</Text>
              <TextInput
                value={date}
                onChangeText={(v) => setDate(maskDate(v))}
                keyboardType="number-pad"
                maxLength={10}
                placeholder="dd/mm/aaaa"
                placeholderTextColor={colors.mutedLight}
                style={input}
              />

              <View style={styles.chips}>
                {[
                  ['Hoje', 0],
                  ['Amanhã', 1],
                  ['Em 1 semana', 7],
                ].map(([name, n]) => (
                  <Pressable
                    key={name as string}
                    onPress={() => setDate(fmtDate(addDays(new Date(), n as number)))}
                    style={[styles.chip, { borderColor: colors.line }]}
                  >
                    <Text style={{ fontFamily: fonts.regular, fontSize: sw * TYPE.label, color: colors.onLight }}>{name as string}</Text>
                  </Pressable>
                ))}
              </View>

              <View style={[styles.rowBetween, { marginTop: sw * SPACE.lg }]}>
                <Text style={{ color: colors.onLight, fontFamily: fonts.regular, fontSize: sw * TYPE.subtitle }}>Dia inteiro</Text>
                <Pressable
                  onPress={() => setAllDay((v) => !v)}
                  hitSlop={10}
                  style={{
                    width: sw * 0.13,
                    height: sw * 0.075,
                    borderRadius: sw * 0.04,
                    backgroundColor: allDay ? colors.red : colors.line,
                    justifyContent: 'center',
                    paddingHorizontal: sw * SPACE.xs,
                    alignItems: allDay ? 'flex-end' : 'flex-start',
                  }}
                >
                  <View style={{ width: sw * 0.059, height: sw * 0.059, borderRadius: sw * 0.03, backgroundColor: colors.paper }} />
                </Pressable>
              </View>

              {!allDay && (
                <>
                  <Text style={label}>Hora</Text>
                  <TextInput
                    value={time}
                    onChangeText={(v) => setTime(maskTime(v))}
                    keyboardType="number-pad"
                    maxLength={5}
                    placeholder="hh:mm"
                    placeholderTextColor={colors.mutedLight}
                    style={input}
                  />
                </>
              )}

              {cats.length > 0 && (
                <>
                  <Text style={label}>Categoria</Text>
                  <View style={styles.chips}>
                    <Pressable
                      onPress={() => setCatId(null)}
                      style={[styles.chip, { borderColor: catId === null ? colors.onLight : colors.line }]}
                    >
                      <View style={[styles.dot, { backgroundColor: colors.red }]} />
                      <Text style={{ fontFamily: fonts.regular, fontSize: sw * TYPE.label, color: colors.onLight }}>Nenhuma</Text>
                    </Pressable>
                    {cats.map((c) => (
                      <Pressable
                        key={c.id}
                        onPress={() => setCatId(c.id)}
                        style={[styles.chip, { borderColor: catId === c.id ? colors.onLight : colors.line }]}
                      >
                        <View style={[styles.dot, { backgroundColor: c.color }]} />
                        <Text style={{ fontFamily: fonts.regular, fontSize: sw * TYPE.label, color: colors.onLight }}>{c.name}</Text>
                      </Pressable>
                    ))}
                  </View>
                </>
              )}

              <Text style={label}>Observações</Text>
              <TextInput
                value={notes}
                onChangeText={setNotes}
                multiline
                maxLength={500}
                placeholder="Opcional"
                placeholderTextColor={colors.mutedLight}
                style={[input, { maxHeight: sw * 0.3 }]}
              />

              <DialogActions
                onCancel={onCancel}
                confirmLabel="Salvar"
                onConfirm={submit}
                extra={
                  item
                    ? {
                        label: 'Excluir',
                        onPress: () =>
                          appAlert('Excluir compromisso?', `"${item.title}" será removido da Agenda.`, [
                            { text: 'Cancelar', style: 'cancel' },
                            { text: 'Excluir', style: 'destructive', onPress: () => onDelete(item.id) },
                          ]),
                      }
                    : undefined
                }
              />
      </ScrollView>
    </DialogShell>
  );
}

const styles = StyleSheet.create({
  rowBetween: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 10 },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    borderWidth: 2,
    borderRadius: 999,
    paddingHorizontal: 12,
    paddingVertical: 6,
  },
  dot: { width: 12, height: 12, borderRadius: 6 },
});
