// Projeto "audionote" no Supabase: Settings → API (Project URL e a chave "anon"/"publishable").
// A chave anon é pública por desenho: quem protege os dados são as regras RLS do esquema.
// NUNCA coloque aqui a chave "service_role".
export const SUPABASE_URL = 'https://sdnjskstqsvbjjgbtiez.supabase.co';
export const SUPABASE_ANON_KEY = 'sb_publishable_hZtkHlklyonpYrZaBguSeA_PDDIOHFS';

export const supabaseConfigured = (): boolean =>
  /^https:\/\/[a-z0-9-]+\.supabase\.co\/?$/i.test(SUPABASE_URL) &&
  !SUPABASE_URL.includes('SEU-PROJETO') &&
  SUPABASE_ANON_KEY.length > 40 &&
  !SUPABASE_ANON_KEY.startsWith('COLE');
