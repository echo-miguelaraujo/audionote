import { File } from 'expo-file-system';
import type { MoodItem } from './db';
import { File as FsFile, Paths as FsPaths } from 'expo-file-system';
import { isRemote, mediaFile, mimeFor } from './media';

/** Conteúdo (JSON) de um item kind='swatch'. */
export type SwatchData = { v: 1; colors: string[]; src: string[] | null };

const HEX = /^#[0-9A-F]{6}$/;

/** Leitura segura do JSON do cartão de paleta. Inválido → null. */
export function parseSwatch(content: string): SwatchData | null {
  try {
    const j = JSON.parse(content);
    if (!j || !Array.isArray(j.colors)) return null;
    const colors = j.colors
      .filter((c: unknown): c is string => typeof c === 'string')
      .map((c: string) => c.trim().toUpperCase())
      .filter((c: string) => HEX.test(c))
      .slice(0, 8);
    if (colors.length === 0) return null;
    const src = Array.isArray(j.src) ? j.src.filter((s: unknown): s is string => typeof s === 'string') : null;
    return { v: 1, colors, src };
  } catch {
    return null;
  }
}

/** Cores de todos os cartões de paleta do quadro, sem repetir, na ordem em que aparecem. */
export function boardPaletteColors(items: MoodItem[]): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const it of items) {
    if (it.kind !== 'swatch') continue;
    for (const c of parseSwatch(it.content)?.colors ?? []) {
      if (!seen.has(c)) {
        seen.add(c);
        out.push(c);
      }
    }
  }
  return out;
}

// ---------- extração (WebView oculto, só no aparelho) ----------
/** Foto acima disso não é lida (vira base64 em memória). */
const MAX_IMAGE_BYTES = 6 * 1024 * 1024;

type Bridge = { inject: (js: string) => void };
type Msg = { type: string; id?: number; ok?: boolean; colors?: string[]; err?: string };

let bridge: Bridge | null = null;
let readyWaiters: (() => void)[] = [];
let isReady = false;
let waiter: { id: number; resolve: (m: Msg) => void } | null = null;

/** Chamado pelo componente PaletteExtractor ao montar. Devolve a função que desfaz o registro. */
export function registerPaletteBridge(b: Bridge): () => void {
  bridge = b;
  isReady = false;
  return () => {
    if (bridge === b) bridge = null;
  };
}

/** Chamado pelo componente para cada mensagem vinda do WebView. */
export function handlePaletteMessage(raw: string): void {
  let m: Msg;
  try {
    m = JSON.parse(raw);
  } catch {
    return;
  }
  if (m.type === 'ready') {
    isReady = true;
    readyWaiters.splice(0).forEach((f) => f());
  } else if (waiter && m.id === waiter.id) {
    const w = waiter;
    waiter = null;
    w.resolve(m);
  }
}

const lit = (v: unknown): string =>
  JSON.stringify(v).replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');

function waitReady(): Promise<void> {
  if (isReady) return Promise.resolve();
  return new Promise((resolve) => readyWaiters.push(resolve));
}

function call(id: number, js: string): Promise<Msg> {
  return new Promise((resolve) => {
    waiter = { id, resolve };
    bridge?.inject(`${js};true;`);
  });
}

async function remoteToDataUri(url: string): Promise<string | null> {
  const tmp = new FsFile(FsPaths.cache, `pal_${Date.now().toString(36)}.tmp`);
  try {
    const got = await FsFile.downloadFileAsync(url, tmp);
    if (!got.exists || got.size === 0 || got.size > MAX_IMAGE_BYTES) return null;
    return `data:image/jpeg;base64,${await got.base64()}`;
  } catch {
    return null;
  } finally {
    try {
      if (tmp.exists) tmp.delete();
    } catch {
      // ignora
    }
  }
}

async function toDataUri(name: string): Promise<string | null> {
  if (isRemote(name)) return remoteToDataUri(name);
  const f = mediaFile(name);
  if (!f.exists) return null;
  if (f.size > MAX_IMAGE_BYTES) throw new Error(`A imagem "${name}" é grande demais (mais de 6 MB).`);
  const b64 = await new File(f.uri).base64();
  const mime = mimeFor(name);
  return `data:${mime.startsWith('image/') ? mime : 'image/jpeg'};base64,${b64}`;
}

let jobSeq = 0;
let chain: Promise<unknown> = Promise.resolve();

async function doExtract(names: string[], k: number): Promise<string[]> {
  if (!bridge) throw new Error('O extrator de cores não está pronto.');
  await waitReady();
  const id = ++jobSeq;
  await call(id, `window.startJob(${id})`);
  let loaded = 0;
  for (const name of names) {
    const uri = await toDataUri(name);
    if (!uri) continue;
    const r = await call(id, `window.addImage(${id},${lit(uri)})`);
    if (r.ok) loaded++;
  }
  if (loaded === 0) throw new Error('Nenhuma imagem pôde ser lida.');
  const done = await call(id, `window.finishJob(${id},${k})`);
  if (!done.ok || !done.colors || done.colors.length === 0) throw new Error(done.err || 'Sem cores.');
  return done.colors;
}

/**
 * Cores predominantes (#RRGGBB maiúsculo, da mais para a menos presente) de uma ou várias imagens da pasta media.
 * Pedidos entram numa fila; o tempo limite é de 15 s (mais 0,6 s por imagem além da primeira).
 */
export function extractPalette(mediaNames: string[], k = 5): Promise<string[]> {
  const run = () =>
    new Promise<string[]>((resolve, reject) => {
      const limit = 15000 + Math.max(0, mediaNames.length - 1) * 600;
      const timer = setTimeout(() => {
        waiter = null;
        reject(new Error('Demorou demais para extrair as cores.'));
      }, limit);
      doExtract(mediaNames, k).then(
        (c) => {
          clearTimeout(timer);
          resolve(c);
        },
        (e) => {
          clearTimeout(timer);
          reject(e);
        }
      );
    });
  const p = chain.then(run, run);
  chain = p.catch(() => {});
  return p;
}
