import React, { useEffect, useRef } from 'react';
import { StyleSheet, View } from 'react-native';
import { WebView } from 'react-native-webview';
import { handlePaletteMessage, registerPaletteBridge } from './palette';
import { PALETTE_HTML } from './paletteHtml';

/** WebView oculto (1×1, transparente) que faz a conta das cores. Monte uma vez, na raiz do app. */
export function PaletteExtractor() {
  const web = useRef<WebView>(null);
  useEffect(() => registerPaletteBridge({ inject: (js) => web.current?.injectJavaScript(js) }), []);
  return (
    <View pointerEvents="none" style={styles.box}>
      <WebView
        ref={web}
        originWhitelist={['*']}
        source={{ html: PALETTE_HTML }}
        onMessage={(e) => handlePaletteMessage(e.nativeEvent.data)}
        javaScriptEnabled
        scrollEnabled={false}
        style={styles.web}
        containerStyle={styles.web}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  box: { position: 'absolute', left: 0, top: 0, width: 1, height: 1, opacity: 0 },
  web: { width: 1, height: 1, opacity: 0, backgroundColor: 'transparent' },
});
