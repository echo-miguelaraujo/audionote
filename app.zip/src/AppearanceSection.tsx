import React, { useState } from 'react';
import { Pressable, ScrollView, Text, View, useWindowDimensions } from 'react-native';
import { BgColorDialog } from './BgColorDialog';
import { useBg } from './Background';
import { Level, PRESETS, Trio, colorsFor, hexToRgba, updateBg } from './background';
import { colors, fonts, TYPE, SPACE } from './theme';

/** Miniatura do fundo: 3 manchas de cor sobre preto, igual ao fundo de verdade. */
function Preview({ cols, size, none }: { cols: Trio; size: number; none?: boolean }) {
  const blob = (col: string, x: number, y: number, r: number) => (
    <View
      key={col + x}
      style={{
        position: 'absolute',
        width: r * 2,
        height: r * 2,
        left: x - r,
        top: y - r,
        experimental_backgroundImage: `radial-gradient(circle closest-side at 50% 50%, ${hexToRgba(col, 0.9)} 0%, ${hexToRgba(col, 0.4)} 50%, ${hexToRgba(col, 0)} 100%)`,
      }}
    />
  );
  return (
    <View style={{ width: size, height: size, borderRadius: size * 0.26, backgroundColor: colors.bg, overflow: 'hidden' }}>
      {!none && (
        <>
          {blob(cols[0], size * 0.1, size * 0.3, size * 0.55)}
          {blob(cols[1], size * 1.0, size * 0.5, size * 0.6)}
          {blob(cols[2], size * 0.2, size * 1.0, size * 0.7)}
        </>
      )}
    </View>
  );
}

/** Seção "Aparência" das Configurações: escolher o fundo, personalizar as cores, intensidade e vidro. */
export function AppearanceSection() {
  const { width: sw } = useWindowDimensions();
  const s = useBg();
  const [slot, setSlot] = useState<0 | 1 | 2 | null>(null);
  const cols = colorsFor(s);
  const label = sw * 0.04;
  const box = sw * 0.17;

  const frame = (selected: boolean) => ({
    padding: 3,
    borderRadius: box * 0.3,
    borderWidth: 2,
    borderColor: selected ? colors.text : 'rgba(255,255,255,0.18)',
  });

  const options = (title: string, names: string[], value: Level, onPick: (v: Level) => void) => (
    <View style={{ marginTop: sw * SPACE.lg, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 12 }}>
      <Text style={{ color: colors.text, fontFamily: fonts.regular, fontSize: sw * TYPE.label }}>{title}</Text>
      <View style={{ flexDirection: 'row', gap: sw * SPACE.md }}>
        {names.map((n, i) => (
          <Pressable key={n} onPress={() => onPick(i as Level)} hitSlop={10}>
            <Text
              style={{
                color: value === i ? colors.red : colors.muted,
                fontFamily: value === i ? fonts.bold : fonts.regular,
                fontSize: sw * TYPE.label,
              }}
            >
              {n}
            </Text>
          </Pressable>
        ))}
      </View>
    </View>
  );

  return (
    <View style={{ marginTop: sw * 0.09 }}>
      <Text style={{ color: colors.muted, fontFamily: fonts.regular, fontSize: label }}>Fundo</Text>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: sw * SPACE.sm, paddingTop: sw * SPACE.md, paddingBottom: 4 }}>
        {PRESETS.map((p) => (
          <Pressable key={p.id} onPress={() => updateBg({ preset: p.id })} style={{ alignItems: 'center', gap: 6 }}>
            <View style={frame(s.preset === p.id)}>
              <Preview cols={p.colors} size={box} none={p.id === 'preto'} />
            </View>
            <Text style={{ color: s.preset === p.id ? colors.text : colors.muted, fontFamily: fonts.regular, fontSize: sw * TYPE.caption }}>
              {p.name}
            </Text>
          </Pressable>
        ))}
        <Pressable
          onPress={() => updateBg({ preset: 'custom', colors: s.preset === 'custom' ? s.colors : colorsFor(s) })}
          style={{ alignItems: 'center', gap: 6 }}
        >
          <View style={frame(s.preset === 'custom')}>
            <Preview cols={s.preset === 'custom' ? s.colors : colorsFor(s)} size={box} />
          </View>
          <Text style={{ color: s.preset === 'custom' ? colors.text : colors.muted, fontFamily: fonts.regular, fontSize: sw * TYPE.caption }}>
            Personalizar
          </Text>
        </Pressable>
      </ScrollView>

      {s.preset === 'custom' && (
        <View style={{ marginTop: sw * SPACE.lg }}>
          <Text style={{ color: colors.muted, fontFamily: fonts.regular, fontSize: label }}>Toque numa cor para trocar</Text>
          <View style={{ flexDirection: 'row', gap: sw * SPACE.md, marginTop: sw * SPACE.sm }}>
            {s.colors.map((c, i) => (
              <Pressable
                key={i}
                onPress={() => setSlot(i as 0 | 1 | 2)}
                style={{
                  width: sw * 0.12,
                  height: sw * 0.12,
                  borderRadius: sw * 0.06,
                  backgroundColor: c,
                  borderWidth: 2,
                  borderColor: 'rgba(255,255,255,0.5)',
                }}
              />
            ))}
          </View>
        </View>
      )}

      {s.preset !== 'preto' && options('Intensidade das cores', ['Suave', 'Médio', 'Forte'], s.intensity, (v) => updateBg({ intensity: v }))}
      {options('Vidro', ['Desligado', 'Leve', 'Forte'], s.glass, (v) => updateBg({ glass: v }))}

      <BgColorDialog
        visible={slot !== null}
        initial={slot !== null ? s.colors[slot] : colors.onDark}
        onCancel={() => setSlot(null)}
        onPick={(hex) => {
          if (slot !== null) {
            const next = [...s.colors] as Trio;
            next[slot] = hex.toUpperCase();
            updateBg({ colors: next });
          }
          setSlot(null);
        }}
      />
    </View>
  );
}
