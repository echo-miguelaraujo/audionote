import React, { useRef, useState } from 'react';
import { PanResponder, Text, View, useWindowDimensions } from 'react-native';
import { colors, fonts, TYPE, SPACE } from './theme';

type Props = {
  label: string;
  value: number;
  min: number;
  max: number;
  /** Texto do valor à direita (ex.: "12"). */
  display: string;
  /** Chamado enquanto arrasta (para ver o resultado ao vivo). */
  onChange: (v: number) => void;
  /** Chamado ao soltar (para salvar). */
  onCommit: (v: number) => void;
};

/** Controle deslizante simples (sem biblioteca): arraste ou toque na trilha. */
export function SliderRow({ label, value, min, max, display, onChange, onCommit }: Props) {
  const { width: sw } = useWindowDimensions();
  const [trackW, setTrackW] = useState(1);
  const trackWRef = useRef(1);
  const last = useRef(value);
  const cbs = useRef({ onChange, onCommit, min, max });
  cbs.current = { onChange, onCommit, min, max };

  const at = (x: number) => {
    const f = Math.min(Math.max(x / trackWRef.current, 0), 1);
    const v = cbs.current.min + f * (cbs.current.max - cbs.current.min);
    last.current = v;
    cbs.current.onChange(v);
  };

  const pan = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderTerminationRequest: () => false,
      onPanResponderGrant: (e) => at(e.nativeEvent.locationX),
      onPanResponderMove: (e) => at(e.nativeEvent.locationX),
      onPanResponderRelease: () => cbs.current.onCommit(last.current),
      onPanResponderTerminate: () => cbs.current.onCommit(last.current),
    })
  ).current;

  const f = max > min ? Math.min(Math.max((value - min) / (max - min), 0), 1) : 0;
  const knob = sw * 0.065;
  return (
    <View style={{ marginTop: sw * SPACE.md }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
        <Text style={{ color: colors.onLight, fontFamily: fonts.regular, fontSize: sw * TYPE.body }}>{label}</Text>
        <Text style={{ color: colors.subtle, fontFamily: fonts.regular, fontSize: sw * TYPE.body }}>{display}</Text>
      </View>
      <View
        {...pan.panHandlers}
        onLayout={(e) => {
          trackWRef.current = Math.max(e.nativeEvent.layout.width, 1);
          setTrackW(e.nativeEvent.layout.width);
        }}
        style={{ height: knob * 1.6, justifyContent: 'center' }}
      >
        <View pointerEvents="none" style={{ height: 3, borderRadius: 2, backgroundColor: colors.hairline }} />
        <View pointerEvents="none" style={{ position: 'absolute', left: 0, height: 3, borderRadius: 2, width: f * trackW, backgroundColor: colors.onLight }} />
        <View
          pointerEvents="none"
          style={{
            position: 'absolute',
            left: f * trackW - knob / 2,
            width: knob,
            height: knob,
            borderRadius: knob / 2,
            backgroundColor: colors.onLight,
          }}
        />
      </View>
    </View>
  );
}
