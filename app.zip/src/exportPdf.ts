import { File, Paths } from 'expo-file-system';
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import { escapeHtml } from './note';
import { nameFromRef } from './media';

const PRINT_CSS = `
@page{margin:22mm 18mm}
body{font-family:Roboto,Arial,sans-serif;color:#111;background:#fff;font-size:12.5pt;line-height:1.55}
h1.doc-title{font-size:30pt;font-weight:800;letter-spacing:-.03em;line-height:1.1;margin:0 0 .5em}
.cover{width:100%;height:150px;object-fit:cover;border-radius:10px;margin:0 0 18px}
h1,h2,h3,h4,h5{color:#000;line-height:1.2;margin:1.1em 0 .35em;page-break-after:avoid}
h1{font-size:22pt}h2{font-size:18pt}h3{font-size:15pt}h4{font-size:13pt}h5{font-size:11pt;text-transform:uppercase;letter-spacing:.04em;color:#444}
p{margin:.4em 0}
blockquote{margin:.8em 0;padding:.1em 0 .1em 14px;border-left:4px solid #111;color:#333;font-style:italic}
.callout{margin:.8em 0;padding:12px 14px;border-left:5px solid #FF3030;background:#FFF1F1;border-radius:8px;font-weight:600}
ul,ol{padding-left:1.4em}
ul.todo{list-style:none;padding-left:0}
ul.todo li{position:relative;padding-left:26px}
ul.todo li:before{content:"";position:absolute;left:0;top:.28em;width:13px;height:13px;border:1.5px solid #555;border-radius:3px}
ul.todo li[data-done="true"]:before{content:"✓";text-align:center;font-size:10px;line-height:13px;background:#FF3030;border-color:#FF3030;color:#fff}
ul.todo li[data-done="true"]{color:#777;text-decoration:line-through}
a{color:#1a56c7}
hr{border:0;border-top:1.5px solid #ccc;margin:1.2em 0}
img{max-width:100%;height:auto;border-radius:8px;margin:.6em 0}
table{border-collapse:collapse;width:100%;margin:.8em 0;page-break-inside:avoid}
th,td{border:1px solid #bbb;padding:6px 8px;vertical-align:top;font-size:.92em}
th{background:#f0f0f0;text-align:left}
.toc{margin:.8em 0;padding:12px 14px;border:1px solid #ddd;border-radius:8px;background:#fafafa}
.toc .th{font-weight:800;margin-bottom:4px}
.toc .it{padding:2px 0;color:#333}
.toc .it.l2{padding-left:14px}.toc .it.l3{padding-left:28px}.toc .it.l4{padding-left:42px}.toc .it.l5{padding-left:56px}
.vidcard{margin:.8em 0;padding:10px 12px;border:1px solid #ccc;border-radius:8px}
.vidcard img{margin:0 0 6px}.vidcard .play{display:none}
.vidcard .vt:before{content:"▶ Vídeo: "}
.filechip{display:inline-block;padding:6px 10px;border:1px solid #bbb;border-radius:8px;text-decoration:none;color:#111}
`;

async function inlineImage(src: string): Promise<string> {
  if (!src.startsWith('file:')) return src;
  try {
    const f = new File(src);
    const b64 = await f.base64();
    const ext = (src.split('.').pop() || 'jpeg').toLowerCase().split('?')[0];
    const mime = ext === 'png' ? 'image/png' : ext === 'gif' ? 'image/gif' : ext === 'webp' ? 'image/webp' : 'image/jpeg';
    return `data:${mime};base64,${b64}`;
  } catch {
    return '';
  }
}

async function prepareBody(html: string): Promise<string> {
  let out = html;
  // Texto branco do editor (tema escuro) some no papel: vira preto.
  out = out.replace(/color:\s*(?:#fff(?:fff)?|rgb\(\s*255\s*,\s*255\s*,\s*255\s*\))/gi, 'color:#000');
  // Vídeos locais não cabem no PDF: vira uma linha com o nome.
  out = out.replace(/<video[^>]*?src="([^"]*)"[^>]*>\s*<\/video>/gi, (_m, src: string) => {
    const name = escapeHtml(nameFromRef(src.split('/').pop() || 'vídeo'));
    return `<div class="vidcard"><div class="vt">${name}</div></div>`;
  });
  // Arquivos anexados: só o nome (o PDF não carrega o arquivo).
  out = out.replace(/<a class="filechip"[^>]*>([\s\S]*?)<\/a>/gi, '<span class="filechip">$1</span>');
  // Imagens locais -> incorporadas ao PDF.
  const srcs = Array.from(new Set(Array.from(out.matchAll(/<img[^>]*?src="([^"]+)"/gi)).map((m) => m[1])));
  for (const s of srcs) {
    const data = await inlineImage(s);
    out = out.split(`src="${s}"`).join(`src="${data}"`);
  }
  return out;
}

/** Nome de arquivo seguro: sem acentos nem símbolos, espaços viram "_", até 40 caracteres. */
export function safeFileName(title: string, fallback: string): string {
  return (
    (title || fallback)
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^A-Za-z0-9 _-]+/g, '')
      .trim()
      .replace(/\s+/g, '_')
      .slice(0, 40) || fallback
  );
}

export async function exportNotePdf(title: string, webHtml: string, coverUri: string | null): Promise<void> {
  const body = await prepareBody(webHtml);
  const cover = coverUri ? await inlineImage(coverUri) : '';
  const heading = title.trim();
  const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><style>${PRINT_CSS}</style></head><body>${
    cover ? `<img class="cover" src="${cover}">` : ''
  }${heading ? `<h1 class="doc-title">${escapeHtml(heading)}</h1>` : ''}${body}</body></html>`;
  const { uri } = await Print.printToFileAsync({ html });
  const safe = safeFileName(heading, 'Nota');
  let shareUri = uri;
  try {
    const dest = new File(Paths.cache, `${safe}.pdf`);
    if (dest.exists) dest.delete();
    new File(uri).copy(dest);
    shareUri = dest.uri;
  } catch {
    // compartilha com o nome automático
  }
  if (await Sharing.isAvailableAsync()) {
    await Sharing.shareAsync(shareUri, { mimeType: 'application/pdf', UTI: 'com.adobe.pdf', dialogTitle: 'Exportar nota em PDF' });
  }
}


/** Copia o arquivo para o cache com um nome legível e abre o menu de compartilhar. Devolve o caminho da cópia. */
export async function shareCachedCopy(
  uri: string,
  fileName: string,
  mimeType: string,
  dialogTitle: string,
  UTI?: string
): Promise<string> {
  let shareUri = uri;
  try {
    const dest = new File(Paths.cache, fileName);
    if (dest.exists) dest.delete();
    new File(uri).copy(dest);
    shareUri = dest.uri;
  } catch {
    // compartilha com o nome automático
  }
  if (await Sharing.isAvailableAsync()) {
    await Sharing.shareAsync(shareUri, { mimeType, UTI, dialogTitle });
  }
  return shareUri;
}

/**
 * PDF de uma página com a imagem do quadro (PNG, que pode ter fundo transparente) sobre fundo branco.
 * A página tem a proporção da imagem. `pxW`/`pxH` = tamanho em pixels do PNG.
 */
export async function exportBoardPdf(title: string, pngUri: string, pxW: number, pxH: number): Promise<string> {
  const b64 = await new File(pngUri).base64();
  const W = 595;
  const H = Math.max(100, Math.round((W * pxH) / Math.max(1, pxW)));
  const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><style>@page{size:${W}px ${H}px;margin:0}html,body{margin:0;padding:0;background:#fff}img{display:block;width:${W}px;height:${H}px}</style></head><body><img src="data:image/png;base64,${b64}"></body></html>`;
  const { uri } = await Print.printToFileAsync({ html, width: W, height: H });
  return shareCachedCopy(uri, `${safeFileName(title, 'Quadro')}.pdf`, 'application/pdf', 'Exportar quadro em PDF', 'com.adobe.pdf');
}
