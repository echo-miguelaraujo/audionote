import React, { useEffect, useRef, useState } from 'react';
import { Animated, Modal, Pressable, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors, fonts } from './theme';

export type SheetItem = {
  key: string;
  label: string;
  /** Quadradinho colorido à direita (categorias). */
  color?: string;
  selected?: boolean;
  muted?: boolean;
  onPress?: () => void;
  onLongPress?: () => void;
};

type Props = {
  visible: boolean;
  onClose: () => void;
  /** Ação principal, em destaque no topo (ex.: "Gravar novo", "Criar categoria"). */
  title: string;
  onTitlePress: () => void;
  /** Rótulo da lista abaixo da linha (ex.: "Selecionar nota"). */
  subtitle: string;
  items: SheetItem[];
  separators?: boolean;
};

/** Janela branca que sobe de baixo: ação no topo, linha, e uma lista rolável com barrinha vermelha. */
export function BottomSheet({ visible, onClose, title, onTitlePress, subtitle, items, separators }: Props) {
  const { width: sw } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const [viewH, setViewH] = useState(0);
  const [contentH, setContentH] = useState(0);
  const y = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (visible) y.setValue(0);
  }, [visible, y]);

  const scrollable = viewH > 0 && contentH > viewH + 1;
  const thumbH = scrollable ? Math.max(sw * 0.07, (viewH / contentH) * viewH) : 0;
  const thumbY = scrollable
    ? y.interpolate({
        inputRange: [0, contentH - viewH],
        outputRange: [0, viewH - thumbH],
        extrapolate: 'clamp',
      })
    : 0;

  const rowH = sw * 0.097;

  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      statusBarTranslucent
      navigationBarTranslucent
      onRequestClose={onClose}
    >
      <View style={styles.root}>
        <Pressable style={styles.backdrop} onPress={onClose} />
        <Pressable
          onPress={() => {}}
          style={{
            marginHorizontal: sw * 0.0185,
            marginBottom: insets.bottom + sw * 0.021,
            height: sw * 0.625,
            borderRadius: sw * 0.088,
            backgroundColor: '#FFFFFF',
            overflow: 'hidden',
          }}
        >
          <Pressable
            onPress={onTitlePress}
            hitSlop={8}
            style={{ paddingTop: sw * 0.07, paddingLeft: sw * 0.0833 }}
          >
            <Text
              style={{
                color: '#000',
                fontFamily: fonts.bold,
                fontSize: sw * 0.052,
                letterSpacing: -sw * 0.052 * 0.045,
              }}
            >
              {title}
            </Text>
          </Pressable>
          <View
            style={{
              height: 3,
              backgroundColor: '#000',
              marginTop: sw * 0.045,
              marginHorizontal: sw * 0.1145,
            }}
          />
          <Text
            style={{
              color: '#000',
              fontFamily: fonts.regular,
              fontSize: sw * 0.036,
              marginTop: sw * 0.025,
              marginLeft: sw * 0.1145,
              letterSpacing: -sw * 0.036 * 0.03,
            }}
          >
            {subtitle}
          </Text>

          <View
            style={{ flex: 1, marginTop: sw * 0.008 }}
            onLayout={(e) => setViewH(e.nativeEvent.layout.height)}
          >
            <Animated.ScrollView
              showsVerticalScrollIndicator={false}
              scrollEventThrottle={16}
              onScroll={Animated.event([{ nativeEvent: { contentOffset: { y } } }], {
                useNativeDriver: true,
              })}
              onContentSizeChange={(_w, h) => setContentH(h)}
              contentContainerStyle={{
                paddingLeft: sw * 0.0833,
                paddingRight: sw * 0.0815,
                paddingBottom: sw * 0.03,
              }}
            >
              {items.map((it, i) => (
                <Pressable
                  key={it.key}
                  onPress={it.onPress}
                  onLongPress={it.onLongPress}
                  style={{
                    height: rowH,
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                  }}
                >
                  <Text
                    numberOfLines={1}
                    style={{
                      flex: 1,
                      color: it.selected ? colors.red : it.muted ? '#8A8A8A' : '#000',
                      fontFamily: it.muted ? fonts.regular : fonts.bold,
                      fontSize: sw * 0.045,
                      letterSpacing: -sw * 0.045 * 0.045,
                    }}
                  >
                    {it.label}
                  </Text>
                  {it.color ? (
                    <View
                      style={{
                        width: sw * 0.077,
                        height: sw * 0.077,
                        borderRadius: sw * 0.03,
                        backgroundColor: it.color,
                        marginLeft: 12,
                      }}
                    />
                  ) : null}
                  {separators && i < items.length - 1 ? (
                    <View
                      style={{
                        position: 'absolute',
                        left: sw * 0.0312,
                        right: sw * 0.033,
                        bottom: 0,
                        height: 1.5,
                        backgroundColor: '#6B6B6B',
                      }}
                    />
                  ) : null}
                </Pressable>
              ))}
            </Animated.ScrollView>
            {scrollable && (
              <Animated.View
                pointerEvents="none"
                style={{
                  position: 'absolute',
                  right: sw * 0.027,
                  top: 0,
                  width: sw * 0.02,
                  height: thumbH,
                  borderRadius: sw * 0.01,
                  backgroundColor: colors.red,
                  transform: [{ translateY: thumbY as any }],
                }}
              />
            )}
          </View>
        </Pressable>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, justifyContent: 'flex-end' },
  backdrop: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.76)' },
});
