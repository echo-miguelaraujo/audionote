import React, { useEffect, useRef, useState } from 'react';
import { Animated, Pressable, Text, View, useWindowDimensions } from 'react-native';
import { SheetShell } from './DialogBase';
import { colors, fonts, TYPE, SPACE } from './theme';

export type SheetItem = {
  key: string;
  label: string;
  /** Quadradinho colorido à direita (categorias). */
  color?: string;
  selected?: boolean;
  muted?: boolean;
  onPress?: () => void;
  onLongPress?: () => void;
};

type Props = {
  visible: boolean;
  onClose: () => void;
  /** Ação principal, em destaque no topo (ex.: "Gravar novo", "Criar categoria"). */
  title: string;
  onTitlePress: () => void;
  /** Rótulo da lista abaixo da linha (ex.: "Selecionar nota"). */
  subtitle: string;
  items: SheetItem[];
  separators?: boolean;
};

/** Janela branca que sobe de baixo: ação no topo, linha, e uma lista rolável com barrinha vermelha. */
export function BottomSheet({ visible, onClose, title, onTitlePress, subtitle, items, separators }: Props) {
  const { width: sw } = useWindowDimensions();
  const [viewH, setViewH] = useState(0);
  const [contentH, setContentH] = useState(0);
  const y = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (visible) y.setValue(0);
  }, [visible, y]);

  const scrollable = viewH > 0 && contentH > viewH + 1;
  const thumbH = scrollable ? Math.max(sw * 0.07, (viewH / contentH) * viewH) : 0;
  const thumbY = scrollable
    ? y.interpolate({
        inputRange: [0, contentH - viewH],
        outputRange: [0, viewH - thumbH],
        extrapolate: 'clamp',
      })
    : 0;

  const rowH = sw * 0.097;

  return (
    <SheetShell visible={visible} onClose={onClose} height={sw * 0.625}>
          <Pressable
            onPress={onTitlePress}
            hitSlop={8}
            style={{ paddingTop: sw * SPACE.xl, paddingLeft: sw * SPACE.xl }}
          >
            <Text
              style={{
                color: colors.onLight,
                fontFamily: fonts.bold,
                fontSize: sw * TYPE.subtitle,
                letterSpacing: -sw * 0.052 * 0.045,
              }}
            >
              {title}
            </Text>
          </Pressable>
          <View
            style={{
              height: 3,
              backgroundColor: colors.bg,
              marginTop: sw * SPACE.md,
              marginHorizontal: sw * 0.1145,
            }}
          />
          <Text
            style={{
              color: colors.onLight,
              fontFamily: fonts.regular,
              fontSize: sw * TYPE.caption,
              marginTop: sw * SPACE.sm,
              marginLeft: sw * 0.1145,
              letterSpacing: -sw * 0.036 * 0.03,
            }}
          >
            {subtitle}
          </Text>

          <View
            style={{ flex: 1, marginTop: sw * SPACE.xs }}
            onLayout={(e) => setViewH(e.nativeEvent.layout.height)}
          >
            <Animated.ScrollView
              showsVerticalScrollIndicator={false}
              scrollEventThrottle={16}
              onScroll={Animated.event([{ nativeEvent: { contentOffset: { y } } }], {
                useNativeDriver: true,
              })}
              onContentSizeChange={(_w, h) => setContentH(h)}
              contentContainerStyle={{
                paddingLeft: sw * SPACE.xl,
                paddingRight: sw * SPACE.xl,
                paddingBottom: sw * SPACE.sm,
              }}
            >
              {items.map((it, i) => (
                <Pressable
                  key={it.key}
                  onPress={it.onPress}
                  onLongPress={it.onLongPress}
                  style={{
                    height: rowH,
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                  }}
                >
                  <Text
                    numberOfLines={1}
                    style={{
                      flex: 1,
                      color: it.selected ? colors.red : it.muted ? colors.muted : colors.onLight,
                      fontFamily: it.muted ? fonts.regular : fonts.bold,
                      fontSize: sw * TYPE.body,
                      letterSpacing: -sw * 0.045 * 0.045,
                    }}
                  >
                    {it.label}
                  </Text>
                  {it.color ? (
                    <View
                      style={{
                        width: sw * 0.077,
                        height: sw * 0.077,
                        borderRadius: sw * 0.03,
                        backgroundColor: it.color,
                        marginLeft: 12,
                      }}
                    />
                  ) : null}
                  {separators && i < items.length - 1 ? (
                    <View
                      style={{
                        position: 'absolute',
                        left: sw * 0.0312,
                        right: sw * 0.033,
                        bottom: 0,
                        height: 1.5,
                        backgroundColor: colors.subtle,
                      }}
                    />
                  ) : null}
                </Pressable>
              ))}
            </Animated.ScrollView>
            {scrollable && (
              <Animated.View
                pointerEvents="none"
                style={{
                  position: 'absolute',
                  right: sw * 0.027,
                  top: 0,
                  width: sw * 0.02,
                  height: thumbH,
                  borderRadius: sw * 0.01,
                  backgroundColor: colors.red,
                  transform: [{ translateY: thumbY as any }],
                }}
              />
            )}
          </View>
    </SheetShell>
  );
}
