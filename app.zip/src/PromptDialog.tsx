import React, { useEffect, useState } from 'react';
import {
  Modal,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
  useWindowDimensions,
} from 'react-native';
import { fonts } from './theme';

type Props = {
  visible: boolean;
  title: string;
  initialValue: string;
  maxLength?: number;
  placeholder?: string;
  url?: boolean;
  onCancel: () => void;
  onSubmit: (value: string) => void;
};

export function PromptDialog({ visible, title, initialValue, maxLength = 80, placeholder, url, onCancel, onSubmit }: Props) {
  const { width: sw, height: sh } = useWindowDimensions();
  const [value, setValue] = useState(initialValue);

  useEffect(() => {
    if (visible) setValue(initialValue);
  }, [visible, initialValue]);

  const submit = () => {
    const v = value.trim();
    if (v) onSubmit(v);
  };

  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      statusBarTranslucent
      onRequestClose={onCancel}
    >
      <Pressable style={[styles.overlay, { paddingTop: sh * 0.2 }]} onPress={onCancel}>
        <Pressable
          style={[styles.card, { width: sw * 0.84, borderRadius: sw * 0.074, padding: sw * 0.06 }]}
          onPress={() => {}}
        >
          <Text style={[styles.title, { fontSize: sw * 0.06 }]}>{title}</Text>
          <TextInput
            value={value}
            onChangeText={setValue}
            autoFocus
            selectTextOnFocus={!url}
            maxLength={maxLength}
            placeholder={placeholder}
            placeholderTextColor="#808080"
            keyboardType={url ? 'url' : 'default'}
            autoCapitalize={url ? 'none' : 'sentences'}
            autoCorrect={!url}
            onSubmitEditing={submit}
            returnKeyType="done"
            style={[styles.input, { fontSize: sw * 0.05 }]}
          />
          <View style={styles.row}>
            <Pressable onPress={onCancel} hitSlop={12}>
              <Text style={[styles.btn, { fontSize: sw * 0.05, color: '#808080' }]}>Cancelar</Text>
            </Pressable>
            <Pressable onPress={submit} hitSlop={12}>
              <Text style={[styles.btn, { fontSize: sw * 0.05 }]}>Salvar</Text>
            </Pressable>
          </View>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.78)',
    alignItems: 'center',
  },
  card: { backgroundColor: '#FFFFFF' },
  title: { color: '#000', fontFamily: fonts.bold, letterSpacing: -1 },
  input: {
    color: '#000',
    fontFamily: fonts.regular,
    borderBottomWidth: 2,
    borderBottomColor: '#000',
    paddingVertical: 8,
    marginTop: 16,
  },
  row: { flexDirection: 'row', justifyContent: 'flex-end', gap: 28, marginTop: 24 },
  btn: { color: '#000', fontFamily: fonts.bold },
});
