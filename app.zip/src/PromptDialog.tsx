import React, { useEffect, useState } from 'react';
import { DialogActions, DialogInput, DialogShell, DialogTitle } from './DialogBase';

type Props = {
  visible: boolean;
  title: string;
  initialValue: string;
  maxLength?: number;
  placeholder?: string;
  url?: boolean;
  onCancel: () => void;
  onSubmit: (value: string) => void;
};

export function PromptDialog({ visible, title, initialValue, maxLength = 80, placeholder, url, onCancel, onSubmit }: Props) {
  const [value, setValue] = useState(initialValue);

  useEffect(() => {
    if (visible) setValue(initialValue);
  }, [visible, initialValue]);

  const submit = () => {
    const v = value.trim();
    if (v) onSubmit(v);
  };

  return (
    <DialogShell visible={visible} onClose={onCancel} keyboard>
      <DialogTitle>{title}</DialogTitle>
      <DialogInput
        value={value}
        onChangeText={setValue}
        autoFocus
        selectTextOnFocus={!url}
        maxLength={maxLength}
        placeholder={placeholder}
        keyboardType={url ? 'url' : 'default'}
        autoCapitalize={url ? 'none' : 'sentences'}
        autoCorrect={!url}
        onSubmitEditing={submit}
        returnKeyType="done"
      />
      <DialogActions onCancel={onCancel} confirmLabel="Salvar" onConfirm={submit} />
    </DialogShell>
  );
}
