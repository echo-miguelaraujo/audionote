import React, { useEffect, useRef } from 'react';
import { PixelRatio, StyleSheet, View, useWindowDimensions } from 'react-native';
import { WebView, WebViewMessageEvent } from 'react-native-webview';
import { captureRef } from 'react-native-view-shot';
import { StateMessage } from './StateMessage';
import { colors } from './theme';
import { dropFile } from './noteShare';

/** Largura, em pixels, de cada imagem 16:9 gerada (1920x1080). Se sair em branco no aparelho, use 0 (usa a largura da tela). */
const OUT_W_PX = 1920;

type Props = {
  /** HTML do paginador (buildPagerHtml). */
  html: string;
  /** Chamado com os PNGs temporários de cada página, na ordem. */
  onDone: (uris: string[]) => void;
  onError: (e: unknown) => void;
  /** Texto de progresso mostrado sobre a tela. */
  label?: string;
};

/**
 * Desenha as páginas 16:9 da nota numa WebView e fotografa uma a uma.
 * A WebView fica sob o aviso opaco "Gerando páginas…", como a camada de exportação do quadro.
 */
export function NotePagesCapture({ html, onDone, onError, label }: Props) {
  const { width: sw } = useWindowDimensions();
  const web = useRef<WebView>(null);
  const box = useRef<View>(null);
  const total = useRef(0);
  const shown = useRef<((i: number) => void) | null>(null);
  const started = useRef(false);

  const wDp = OUT_W_PX > 0 ? OUT_W_PX / PixelRatio.get() : sw;
  const hDp = (wDp * 9) / 16;
  const doneRef = useRef(onDone);
  const errRef = useRef(onError);
  doneRef.current = onDone;
  errRef.current = onError;

  const waitShown = (i: number) =>
    new Promise<void>((resolve, reject) => {
      const t = setTimeout(() => reject(new Error('A página demorou demais para desenhar.')), 15000);
      shown.current = (k) => {
        if (k !== i) return;
        clearTimeout(t);
        shown.current = null;
        resolve();
      };
      web.current?.injectJavaScript(`window.showPage(${i});true;`);
    });

  const run = async (n: number) => {
    const files: string[] = [];
    try {
      for (let i = 0; i < n; i++) {
        await waitShown(i);
        const uri = await captureRef(box, { format: 'png', result: 'tmpfile', quality: 1 });
        files.push(uri);
      }
      doneRef.current(files);
    } catch (e) {
      files.forEach(dropFile);
      errRef.current(e);
    }
  };

  const onMessage = (e: WebViewMessageEvent) => {
    let m: any;
    try {
      m = JSON.parse(e.nativeEvent.data);
    } catch {
      return;
    }
    if (m.type === 'ready' && !started.current) {
      started.current = true;
      total.current = Math.max(1, Number(m.pages) || 1);
      run(total.current).catch(() => {});
    } else if (m.type === 'shown') {
      shown.current?.(Number(m.i));
    }
  };

  useEffect(() => {
    const t = setTimeout(() => {
      if (!started.current) errRef.current(new Error('Não consegui preparar as páginas.'));
    }, 20000);
    return () => clearTimeout(t);
  }, []);

  return (
    <View style={StyleSheet.absoluteFill} pointerEvents="auto">
      <View
        ref={box}
        collapsable={false}
        style={{ position: 'absolute', left: 0, top: 0, width: wDp, height: hDp, backgroundColor: '#fff', overflow: 'hidden' }}
      >
        <WebView
          ref={web}
          originWhitelist={['*']}
          source={{ html, baseUrl: 'file:///' }}
          onMessage={onMessage}
          javaScriptEnabled
          allowFileAccess
          allowFileAccessFromFileURLs
          allowUniversalAccessFromFileURLs
          mixedContentMode="always"
          setSupportMultipleWindows={false}
          textZoom={100}
          scrollEnabled={false}
          overScrollMode="never"
          androidLayerType="software"
          style={{ width: wDp, height: hDp, backgroundColor: '#fff' }}
          containerStyle={{ width: wDp, height: hDp, backgroundColor: '#fff' }}
        />
      </View>
      <View style={[StyleSheet.absoluteFill, { backgroundColor: colors.bg, alignItems: 'center', justifyContent: 'center' }]}>
        <StateMessage kind="loading" centered>{label ?? 'Gerando páginas…'}</StateMessage>
      </View>
    </View>
  );
}
