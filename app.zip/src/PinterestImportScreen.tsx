import React, { useRef, useState } from 'react';
import { ActivityIndicator, Modal, Pressable, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { WebView, WebViewMessageEvent } from 'react-native-webview';
import { MAX_PINS, type PinImage } from './pinterest';
import { colors, fonts, SPACE, TYPE } from './theme';

/**
 * Roda dentro da página da pasta: rola sozinha e junta as imagens dos pins.
 * O Pinterest só mantém na tela os pins que estão visíveis, então a coleta acontece a cada passo da rolagem.
 * A ordem final é a posição na página (de cima para baixo), e o total vem do "N Pins" do cabeçalho da pasta:
 * assim as sugestões ("Mais ideias") que aparecem depois da pasta ficam de fora.
 */
const PIN_JS = String.raw`(function(){
if(window.__pin){return;}window.__pin=1;
var MAX=${MAX_PINS};
var found={},list=[],idle=0,tick=null,total=0,steps=0,strict=true,fin=false;
function post(o){window.ReactNativeWebView.postMessage(JSON.stringify(o));}
function absu(u){try{return new URL(u,location.href).toString();}catch(e){return '';}}
function cands(img){
  var out=[];var s=img.getAttribute('srcset')||'';
  if(s){s.split(',').forEach(function(p){var a=p.trim().split(/\s+/);if(a[0])out.push(absu(a[0]));});}
  out.push(absu(img.currentSrc||img.src||''));
  return out;
}
function pinUrl(img){
  var c=cands(img);
  for(var i=0;i<c.length;i++){
    var u=c[i];
    if(/^https:\/\/i\.pinimg\.com\/(\d+x|originals)\//.test(u)){return u.replace(/pinimg\.com\/\d+x\//,'pinimg.com/736x/');}
  }
  return '';
}
function key(u){var m=/pinimg\.com\/[^\/]+\/(.+)$/.exec(u);return m?m[1].replace(/\.[a-z]+$/i,''):u;}
function readTotal(){
  if(total)return;
  var t=(document.body.innerText||'').slice(0,3000);
  var m=/(\d[\d.,]*)\s*(mil\b)?\s*pins?\b/i.exec(t);
  if(m&&!m[2]){var n=parseInt(m[1].replace(/[.,]/g,''),10);if(n>0&&n<100000)total=n;}
}
function collect(){
  var added=0;
  document.querySelectorAll('img').forEach(function(img){
    var u=pinUrl(img);if(!u)return;
    if(strict&&!img.closest('a[href*="/pin/"]'))return;
    var nw=img.naturalWidth||0,nh=img.naturalHeight||0;
    var r=img.getBoundingClientRect();
    if((nw&&nw<100)||r.width<60)return;
    var k=key(u);if(found[k])return;
    var o={url:u,w:nw||Math.round(r.width),h:nh||Math.round(r.height),y:Math.round(r.top+window.scrollY),x:Math.round(r.left+window.scrollX)};
    found[k]=1;list.push(o);added++;
  });
  return added;
}
function result(){
  var s=list.slice().sort(function(a,b){return (Math.abs(a.y-b.y)<30?a.x-b.x:a.y-b.y);});
  if(total>0&&s.length>total)s=s.slice(0,total);
  if(s.length>MAX)s=s.slice(0,MAX);
  return s.map(function(o){return {url:o.url,w:o.w,h:o.h};});
}
function finish(){
  if(fin)return;fin=true;
  if(tick){clearInterval(tick);tick=null;}
  post({type:'done',items:result(),total:total});
}
function step(){
  steps++;readTotal();
  var n=collect();
  if(steps>=5&&list.length===0&&strict){strict=false;}
  idle=n>0?0:idle+1;
  post({type:'progress',n:Math.min(list.length,total||MAX),total:total});
  if(total>0&&list.length>=total){finish();return;}
  if(list.length>=MAX||idle>=10){finish();return;}
  window.scrollBy(0,Math.round(window.innerHeight*0.7));
}
window.__pinStart=function(){if(tick||fin)return;tick=setInterval(step,700);};
window.__pinStop=finish;
})();true;`;

type Props = {
  visible: boolean;
  /** Endereço da pasta. */
  url: string | null;
  onClose: () => void;
  onDone: (list: PinImage[]) => void;
};

/** Abre a pasta do Pinterest, coleta as imagens sozinha e devolve a lista. Se a pasta pedir login, entre pela própria página. */
export function PinterestImportScreen({ visible, url, onClose, onDone }: Props) {
  const { width: sw } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const web = useRef<WebView>(null);
  const wantNow = useRef(false);
  const [count, setCount] = useState(0);
  const [total, setTotal] = useState(0);
  const [result, setResult] = useState<PinImage[] | null>(null);

  const reset = () => {
    wantNow.current = false;
    setCount(0);
    setTotal(0);
    setResult(null);
  };
  const close = () => {
    reset();
    onClose();
  };
  const send = (list: PinImage[]) => {
    reset();
    onDone(list);
  };

  const onMessage = (e: WebViewMessageEvent) => {
    try {
      const m = JSON.parse(e.nativeEvent.data);
      if (m.type === 'progress') {
        setCount(Number(m.n) || 0);
        setTotal(Number(m.total) || 0);
      } else if (m.type === 'done') {
        const list: PinImage[] = Array.isArray(m.items)
          ? m.items.filter((i: any) => typeof i?.url === 'string').map((i: any) => ({ url: i.url, w: Number(i.w) || 0, h: Number(i.h) || 0 }))
          : [];
        setCount(list.length);
        setTotal(Number(m.total) || 0);
        if (wantNow.current) send(list);
        else setResult(list);
      }
    } catch {
      // mensagem de outra origem: ignora
    }
  };

  const pad = sw * SPACE.md;
  const pill = { borderRadius: sw * 0.08, paddingHorizontal: sw * 0.04, paddingVertical: sw * 0.022 };
  const floatPill = (dark?: boolean) => ({
    ...pill,
    backgroundColor: dark ? colors.onLight : colors.paper,
    borderWidth: dark ? 0 : 1,
    borderColor: colors.line,
    elevation: 4,
    shadowColor: '#000',
    shadowOpacity: 0.25,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 2 },
  });
  const txt = (dark?: boolean) => ({ color: dark ? colors.onDark : colors.onLight, fontFamily: fonts.bold, fontSize: sw * TYPE.label });

  const finished = result !== null;
  const status = finished
    ? count > 0
      ? `${count} imagens encontradas`
      : 'Nenhuma imagem encontrada. Se a página pediu login, entre e a busca recomeça.'
    : count > 0
      ? `Coletando… ${count}${total > 0 ? ` de ${total}` : ''}`
      : 'Abrindo a pasta…';

  return (
    <Modal visible={visible} animationType="slide" statusBarTranslucent navigationBarTranslucent onRequestClose={close}>
      <View style={[styles.root, { paddingTop: insets.top }]}>
        <View style={{ flex: 1, backgroundColor: colors.paper }}>
          {visible && url && (
            <WebView
              ref={web}
              source={{ uri: url }}
              injectedJavaScript={PIN_JS}
              onMessage={onMessage}
              onLoadStart={() => {
                // página nova (ex.: depois do login): recomeça a coleta
                if (!wantNow.current) {
                  setResult(null);
                  setCount(0);
                }
              }}
              onLoadEnd={() => web.current?.injectJavaScript('window.__pinStart&&setTimeout(window.__pinStart,2000);true;')}
              javaScriptEnabled
              domStorageEnabled
              setSupportMultipleWindows={false}
            />
          )}
        </View>

        <View
          pointerEvents="box-none"
          style={{ position: 'absolute', left: pad, right: pad, bottom: insets.bottom + sw * SPACE.md, gap: sw * SPACE.sm }}
        >
          <View pointerEvents="none" style={{ ...pill, backgroundColor: colors.onLight, flexDirection: 'row', alignItems: 'center', gap: sw * 0.025 }}>
            {!finished && <ActivityIndicator size="small" color={colors.onDark} />}
            <Text style={{ flex: 1, color: colors.onDark, fontFamily: fonts.regular, fontSize: sw * TYPE.caption * 1.1 }}>{status}</Text>
          </View>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: sw * SPACE.sm }}>
            <Pressable onPress={close} style={floatPill()}>
              <Text style={{ ...txt(), color: colors.red }}>Cancelar</Text>
            </Pressable>
            <View style={{ flex: 1 }} />
            {count > 0 && (
              <Pressable
                onPress={() => {
                  if (result) send(result);
                  else {
                    wantNow.current = true;
                    web.current?.injectJavaScript('window.__pinStop&&window.__pinStop();true;');
                  }
                }}
                style={floatPill(true)}
              >
                <Text style={txt(true)}>{finished ? `Importar ${count}` : `Parar e importar ${count}`}</Text>
              </Pressable>
            )}
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.onDark },
});
