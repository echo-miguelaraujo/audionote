import { Directory, File, Paths } from 'expo-file-system';
import { getDb } from './db';

const pad = (n: number) => String(n).padStart(2, '0');

/** Data e hora no formato 20261016-1530, para dar nome único à pasta do backup. */
function stamp(): string {
  const d = new Date();
  return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}`;
}

/** Copia cada arquivo de uma pasta do app para a pasta de destino. Devolve quantos copiou e quantos falharam. */
function copyFolder(source: Directory, dest: Directory): { ok: number; failed: number } {
  let ok = 0;
  let failed = 0;
  if (!source.exists) return { ok, failed };
  for (const item of source.list()) {
    if (item instanceof File) {
      try {
        item.copy(dest);
        ok++;
      } catch {
        failed++;
      }
    }
  }
  return { ok, failed };
}

/**
 * Backup completo: banco (ideias.db) + imagens/vídeos/anexos (media) + áudios (audios).
 * O usuário escolhe a pasta de destino (ex.: Downloads) e o app cria dentro dela
 * uma subpasta "ideias-backup-AAAAMMDD-HHMM". Não altera nada nos dados do app.
 */
export async function exportBackup(): Promise<string> {
  // O banco usa o modo WAL: parte dos dados recentes pode estar num arquivo temporário (-wal).
  // O checkpoint passa tudo para o arquivo principal antes de copiar.
  const db = await getDb();
  await db.execAsync('PRAGMA wal_checkpoint(TRUNCATE);');

  const dbFile = new File(new Directory(Paths.document, 'SQLite'), 'ideias.db');
  if (!dbFile.exists) throw new Error('Arquivo do banco (ideias.db) não encontrado.');

  const target = await Directory.pickDirectoryAsync();
  const folderName = `ideias-backup-${stamp()}`;
  const root = target.createDirectory(folderName);

  dbFile.copy(root);
  const media = copyFolder(new Directory(Paths.document, 'media'), new Directory(root.createDirectory('media').uri));
  const audios = copyFolder(new Directory(Paths.document, 'audios'), new Directory(root.createDirectory('audios').uri));

  const falhas = media.failed + audios.failed;
  return (
    `Backup salvo na pasta "${folderName}".\n` +
    `Banco: copiado. Imagens e anexos: ${media.ok}. Áudios: ${audios.ok}.` +
    (falhas > 0 ? `\nAtenção: ${falhas} arquivo(s) não puderam ser copiados.` : '')
  );
}
