-- Etapa 11 (Status personalizados): rode ANTES de abrir o app com o código novo.
-- Sem isso, o envio (push) de mood_collections falha com "column scene_statuses does not exist".
alter table public.mood_collections
  add column if not exists scene_statuses text;
