-- Etapa 11 (Box do texto no moodboard): rode ANTES de abrir o app com o código novo.
alter table public.mood_items
  add column if not exists box text;
