-- Etapa 1 (Cenas): rode ANTES de abrir o app com o código novo.
-- Sem isso, o envio (push) de mood_collections falha com "column ... does not exist".
alter table public.mood_collections
  add column if not exists scene_desc    text,
  add column if not exists scene_place   text,
  add column if not exists scene_emotion text,
  add column if not exists scene_done    boolean not null default false,
  add column if not exists scene_cover   text;
